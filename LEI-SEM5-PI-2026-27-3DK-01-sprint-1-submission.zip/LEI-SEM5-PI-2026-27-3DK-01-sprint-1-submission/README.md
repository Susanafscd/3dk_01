# LEI-SEM5-PI-2026-27-3DK-01

## Team Members

- 1240692 - Rodrigo Mendes
- 1241286 - Rafael Vieira
- 1240625 - Tiago Lima
- 1240713 - Guilherme Machado
- 1201262 - João Ferreira

## Repository layout

| Folder      | Contents                                                                       |
| ----------- | ------------------------------------------------------------------------------ |
| `backend/`  | .NET / ASP.NET Core back-end. Solution: [`backend/Api.sln`](backend/Api.sln); production code under `backend/src/`, tests under `backend/tests/`. |
| `frontend/` | Web application.                                                                |
| `3dviz/`    | 3D visualization and interaction.                                               |
| `ai/`       | Artificial intelligence scheduling.                                             |
| `docs/`     | Architecture, domain model, API contract and sprint documentation.              |

## Getting started

Each part of the project has its own setup guide:

- **Back-end** — [backend/SETUP.md](backend/SETUP.md) (reference: [backend/README.md](backend/README.md)).
- **Front-end** — [frontend/SETUP.md](frontend/SETUP.md) (reference: [frontend/README.md](frontend/README.md)).
- **The whole stack with Docker** — [Docker Deployment](#docker-deployment) below.

## Open the back-end solution

Open the repository root in JetBrains Rider (or another .NET IDE) and it loads the
back-end automatically through the [`LaPrizza.slnf`](LaPrizza.slnf) solution
filter at the root, which points to `backend/Api.sln`.

The same entry point works from the command line:

```bash
dotnet build LaPrizza.slnf
dotnet test LaPrizza.slnf
```

## Problem Background

LaPrizza is a modern pizza restaurant that needs an information system to support and improve its business and operational processes. Its activities involve several interconnected concerns, including customer management, product and allergen management, pizza configuration, stock control, customer orders, and food preparation. Managing these concerns in an integrated way is important because changes in one area can affect others, such as product availability, allergen information, data consistency and kitchen preparation.

The project is therefore focused on developing an information system that provides a common technological foundation for these business processes.

## System Overview

The LaPrizza system is envisioned as a modular, web-based information system composed of several technological areas that progressively integrate with each other. The main areas are the Web Application, 3D Visualization and Interaction, Artificial Intelligence, and Systems Administration and Infrastructure. These areas are expected to communicate through well-defined interfaces and APIs while remaining sufficiently independent to support development, maintenance, and future evolution.

The system covers business information such as customers, products, allergens, pizza sizes and components, stock, predefined pizzas, orders, preparation activities, and kitchen resources.

## Goals and Context

The project is developed as a proof of concept for the LaPrizza information system. Its goal is not to implement the entire restaurant system at once, but to progressively build an integrated solution through multiple development sprints.

Sprint 1 establishes the initial technical and organizational foundations. It focuses on setting up the development environment, modelling the core business domain, defining the system architecture, and implementing the first back-end capabilities and REST APIs. These foundations are intended to support the integration of additional functionality in later sprints.

## Significant Driving Requirements

The main requirements driving the system design are:

- **Modularity and extensibility:** the architecture must allow the different system areas to evolve and be integrated progressively.
- **Clear separation of concerns:** domain and business rules should remain separated from presentation, persistence, and infrastructure concerns.
- **REST-based integration:** implemented back-end functionality must be exposed through consistent REST APIs suitable for future clients and modules.
- **Data persistence and integrity:** business information must be stored persistently while maintaining identifiers, relationships, and business rules.
- **Security and access control:** users must be authenticated and assigned roles so that access to protected functionality can be controlled.
- **Maintainability and scalability:** the system should provide a coherent foundation that can evolve as additional functionality is introduced.
- **Automated testing:** implemented business rules and relevant application/API behaviour must be covered by repeatable automated tests.

## Docker Deployment

### Prerequisites

- [Docker](https://docs.docker.com/get-docker/) (v29.8+ tested)
- [Docker Compose](https://docs.docker.com/compose/install/) (v2.x)

### Quick Start

1. **Configure environment variables (optional)**: Copy the example environment file and modify as needed. For local development with defaults, this step is optional.

   ```bash
   cp .env.example .env
   ```

   **Note**: The `.env` file is git-ignored and contains sensitive configuration. Never commit it to source control.

2. **Build and start all services**:

   ```bash
   docker compose up --build
   ```

   This will:
   - Build the API Docker image
   - Start PostgreSQL, MongoDB, Redis, and the API in a dedicated network
   - Create persistent volumes for database data

   > **The API image does not migrate or seed on start-up.** After the containers
   > are up, apply the EF Core migrations and run the bootstrap once from
   > `backend/` to create the schema and the initial accounts — the EF tools and
   > the API both read `backend/src/Api/.env`, so they follow whichever host port
   > (`POSTGRES_HOST_PORT`) you configured. See
   > [backend/SETUP.md §3](backend/SETUP.md).

3. **Access the application**:

   | Service | URL | Description |
   | --- | --- | --- |
   | API | http://localhost:8080 | REST API endpoint |
   | Swagger UI | http://localhost:8080/swagger | Interactive API documentation |
   | Health Check | http://localhost:8080/api/v1/health | API health status |
   | PostgreSQL | localhost:5432 (host port `POSTGRES_HOST_PORT`) | Direct database access (optional) |
   | MongoDB | localhost:27017 | Direct database access (optional) |
   | Redis | localhost:6379 | Direct cache access (optional) |

### Management Commands

#### Stop services
```bash
docker compose down
```

#### Stop and remove volumes (reset all data)
```bash
docker compose down --volumes
```

#### View logs
```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f api
docker compose logs -f postgres
docker compose logs -f mongodb
docker compose logs -f redis
```

#### Inspect container health
```bash
docker compose ps
docker inspect --format='{{json .State.Health}}' laprizza-api
```

#### Rebuild only the API
```bash
docker compose build api
docker compose up -d api
```

### Running Automated Tests

#### In a Docker container (isolated)
```bash
cd backend
docker build -f Dockerfile.test -t laprizza-test .
docker run --rm laprizza-test
```

#### Locally (without Docker)
```bash
cd backend
dotnet test Api.sln
```

### Data Persistence

All databases use Docker volumes for persistence:
- `postgres_data`: PostgreSQL database files
- `mongodb_data`: MongoDB database files  
- `redis_data`: Redis data with AOF persistence

Data persists between container restarts. To completely reset the database (including schema and data), use `docker compose down --volumes`.

> **Upgrading database images across major versions:** PostgreSQL 18 changed its
> in-container data directory (`PGDATA`) to `/var/lib/postgresql/18/docker` and
> expects the volume mounted at `/var/lib/postgresql`, so a `postgres_data` volume
> created by an older image is not reused automatically. Recreate the volume
> (`docker compose down --volumes`) and re-apply the migrations and bootstrap.

### Configuration

#### Environment Variables

Configuration is handled via environment variables. See `.env.example` for all available options. Key variables:

| Variable | Default (Docker) | Description |
| --- | --- | --- |
| `ConnectionStrings__Postgres` | Auto-configured for Docker | PostgreSQL connection string |
| `Mongo__ConnectionString` | Auto-configured for Docker | MongoDB connection string |
| `Redis__ConnectionString` | Auto-configured for Docker | Redis connection string |
| `ASPNETCORE_ENVIRONMENT` | `Development` | Runtime environment |
| `API_PORT` | `8080` | Host port the API is published on |
| `POSTGRES_HOST_PORT` | `5432` | Host port PostgreSQL is published on |
| `CORS_ALLOWED_ORIGIN_0` / `_1` | `http://localhost:5173` / `http://localhost:3000` | Allowed CORS origins |

**Note**: Inside Docker, services communicate using service names (`postgres`, `mongodb`, `redis`), not `localhost`. The application is configured to handle both Docker and local development.

### Troubleshooting

| Issue | Solution |
| --- | --- |
| Container fails to start due to port conflicts | Change the host port in `compose.yaml` (e.g., `"8081:8080"` for API) or stop the conflicting service |
| Database connection errors | Ensure health checks pass (`docker compose ps`). Check logs (`docker compose logs postgres`). |
| API can't reach dependencies | Verify all services are on the same network and using correct service names |
| Health check fails for API | Wait for startup (can take 30-60 seconds). Check API logs for errors. |
| "Connection refused" errors | Services may still be initializing. Use `depends_on` with health checks as configured. |

### Security Notes

- Change default passwords in production by setting environment variables
- Use secrets management for production deployments
- The API runs as a non-root user inside the container
- HTTPS should be configured in production (reverse proxy/load balancer recommended)
- Database ports are exposed to host only for development convenience - remove port mappings in production if not needed


## Use of Artificial Intelligence in Project Development

Table 1 — AI Tools Used.

| AI Tool | Purpose
|---|---|
| ChatGPT | Guidance and help understanding the key concepts and decisions 
| Claude | Codegen and diagrams formatting and styling
| Opencode | Help with documentation, walking skeleton creation and repository pattern codegen  
| Codex | Codegen 

Table 2 — AI Usage Across the Software Development Process

| Development Process | Component / Activity | AI Usage and Contribution |
|---|---|---|
| Requirements Engineering | Requirements analysis, use cases, and business rules | It was used to format the requirements in the project repository. It had an overall **low** contribution |
| Project Management | Sprint planning, task breakdown, and meeting documentation | It was used to create a consistent and structured scrum documentation format. It had an overall **low** contribution |
| Software Architecture | Architecture definition, component responsibilities, and technology evaluation | It was used to help and guide the selection of the tecnology stack by clarifying questions and getting a global view over the possible alternatives. It had an overall **low to moderate** contribution |
| Software Modelling and Design | Domain modelling, UML/C4 diagrams, design principles, and API contracts | It was used to express our architectural constrains into template UML diagrams with proper styling and formatation for further editing and improvement. It was not used to design the Domain Model. It had an overall **low to moderate** contribution |
| Backend Environment Creation | Authentication, authorization, and data protection | AI-assisted code reviews, refactoring suggestions, and guidance on dependency injection, ASP.NET Core Identity, cookie-based authentication, authorization policies, and CSRF protection.  It had an overall **high** contribution |
| Backend Development | Business logic, REST endpoints, validation, and database integration | AI-assisted code generation, implementation guidance, debugging, and review of application services, REST controllers, data validation, Entity Framework Core configurations, and database interactions.  It had an overall **moderate to high** contribution |
| Software Testing | Test strategies, unit tests, integration tests, and failure diagnosis | AI-assisted identification of test scenarios, generation of test cases, review of NUnit tests, and analysis of test failures to improve test coverage and reliability.  It had an overall **high** contribution |
| DevOps and Infrastructure | Environment configuration, containers, supporting services, and troubleshooting | AI-assisted configuration of Docker Compose services, PostgreSQL and MongoDB environments, development tools, and troubleshooting of configuration and execution issues.  It had an overall **high** contribution |
| Technical Documentation | Architecture, API, installation, and configuration documentation | AI-assisted drafting and revision of architecture documentation, C4 diagrams, Architecture Decision Records, OpenAPI contracts, and setup instructions.  It had an overall **low to moderate** contribution |
| Review and Delivery | Requirements verification and delivery preparation | AI-assisted verification identification of potential omissions. It had an overall **low** contribution |
