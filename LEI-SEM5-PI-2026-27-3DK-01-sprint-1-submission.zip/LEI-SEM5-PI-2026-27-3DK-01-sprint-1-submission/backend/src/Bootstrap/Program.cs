using dotenv.net;
using LaPrizza.Application;
using LaPrizza.Bootstrapper;
using LaPrizza.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

// ---------------------------------------------------------------------------
// Standalone entry point for the project bootstrap. It composes the same
// Application and Infrastructure layers as the API and then runs the ordered
// bootstrap actions of the Bootstrapper project against the configured store.
// Run it from the IDE or with:
//     dotnet run --project src/Bootstrap
// ---------------------------------------------------------------------------

var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
{
    Args = args,
    // Configuration files are copied next to the executable, so resolve them
    // from there regardless of how the process was started.
    ContentRootPath = AppContext.BaseDirectory,
    // The bootstrap is a development/seed tool. Default to Development when the
    // caller did not pick an environment, so the copied appsettings.Development.json
    // and .env are loaded even when the built executable is started directly
    // (the launch profile only applies to `dotnet run`). An explicit
    // DOTNET_ENVIRONMENT/ASPNETCORE_ENVIRONMENT still wins.
    EnvironmentName = Environment.GetEnvironmentVariable("DOTNET_ENVIRONMENT")
        ?? Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")
        ?? Environments.Development,
});

// Same convenience as the API: load a git-ignored .env file (see .env.example)
// into the process environment, but only in Development. Any variable already
// present in the real environment wins.
if (builder.Environment.IsDevelopment())
{
    var envFile = Path.Combine(builder.Environment.ContentRootPath, ".env");

    if (File.Exists(envFile))
    {
        new DotEnvOptions()
            .WithEnvFiles([envFile])
            .WithoutOverwriteExistingVars()
            .WithoutProbeForEnv()
            .Load();

        builder.Configuration.AddEnvironmentVariables();
    }
}

// The same use cases and outbound adapters as the API. AddInfrastructure reads
// the connection string from configuration and fails fast when it is missing.
builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration, builder.Environment);

// The bootstrap runner composes the create use cases in the order it runs them.
builder.Services.AddScoped<ProjectBootstrapRunner>();

using var host = builder.Build();
var logger = host.Services.GetRequiredService<ILoggerFactory>().CreateLogger("Bootstrap");

try
{
    using var scope = host.Services.CreateScope();
    var runner = scope.ServiceProvider.GetRequiredService<ProjectBootstrapRunner>();
    var result = await runner.RunAsync(ProjectBootstrap.Default);

    // One line per seeded entity, in execution order. A successful run prints
    // nothing else: the SQL the store executes is filtered out of the logs (see
    // the "Logging" section in appsettings.json), so this is the whole output.
    foreach (var step in result.Steps)
    {
        Console.WriteLine(step.Created
            ? $"[PASS]    {step.Entity} created."
            : $"[SKIPPED] {step.Entity} already exists.");
    }

    var created = result.Steps.Count(step => step.Created);

    Console.WriteLine();
    Console.WriteLine(
        $"Project bootstrap finished: {created} created, {result.Steps.Count - created} skipped.");

    return 0;
}
catch (Exception exception)
{
    logger.LogError(exception, "Project bootstrap failed.");
    return 1;
}
