using dotenv.net;
using LaPrizza.Application;
using LaPrizza.Bootstrap.Domain.Allergens;
using LaPrizza.Bootstrap.Domain.Customers;
using LaPrizza.Bootstrap.Domain.ProductCategories;
using LaPrizza.Bootstrap.Domain.PizzaComponentTypes;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrap.Roles;
using LaPrizza.Bootstrapper;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Allergens;
using LaPrizza.Infrastructure;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

// ---------------------------------------------------------------------------
// Standalone entry point for the project bootstrap.
// ---------------------------------------------------------------------------

var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
{
    Args = args,
    ContentRootPath = AppContext.BaseDirectory,
    EnvironmentName = Environment.GetEnvironmentVariable("DOTNET_ENVIRONMENT")
        ?? Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")
        ?? Environments.Development,
});

if (builder.Environment.IsDevelopment())
{
    var envFile = Path.Combine(builder.Environment.ContentRootPath, ".env");

    if (File.Exists(envFile))
    {
        new DotEnvOptions()
            .WithEnvFiles([envFile])
            .WithoutOverwriteExistingVars()
            .WithoutProbeForEnv()
            .Load();

        builder.Configuration.AddEnvironmentVariables();
    }
}

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration, builder.Environment);

builder.Services.AddSingleton<BootstrapReporter>();
builder.Services.AddScoped<BootstrapRunner>();

builder.Services.AddScoped<IDataSeeder, RoleBootstrap>();
builder.Services.AddScoped<IDataSeeder, ManagerBootstrap>();
builder.Services.AddScoped<IDataSeeder, CustomerBootstrap>();
builder.Services.AddScoped<IDataSeeder, ProductCategoryBootstrap>();
builder.Services.AddScoped<IDataSeeder, PizzaComponentTypeBootstrap>();
builder.Services.AddScoped<IDataSeeder, AllergenBootstrap>();
builder.Services.AddScoped<IDataSeeder, LaPrizza.Bootstrap.Domain.Sizes.PizzaSizeBootstrap>();
builder.Services.AddScoped<IDataSeeder, LaPrizza.Bootstrap.Domain.Products.ProductBootstrap>();

builder.Services.AddScoped<IAllergenRepository, AllergenRepository>();

var scenarioParamString = args.Length > 0 ? args[0].ToLowerInvariant() : "default";

var scenario = scenarioParamString switch
{
    "minimal" or "min" => BootstrapScenario.Minimal,
    "default" or _ => BootstrapScenario.Default,
};

using var host = builder.Build();

await using var scope = host.Services.CreateAsyncScope();

var runner = scope.ServiceProvider
    .GetRequiredService<BootstrapRunner>();

var logger = scope.ServiceProvider
    .GetRequiredService<ILogger<Program>>();

try
{
    await runner.RunAsync(scenario);
}
catch (Exception exception)
{
    logger.LogCritical(exception, "Bootstrap failed.");
    Environment.ExitCode = 1;
}

