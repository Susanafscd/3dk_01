using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Users.CreateUser;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Users;

namespace LaPrizza.Bootstrapper;

/// <summary>
/// Seeds the initial manager account through the Application layer.
/// </summary>
public sealed class ManagerBootstrap(
    CreateUserCommandHandler handler) : IDataSeeder
{
    private sealed record ManagerDefinition(
        string Email,
        string DisplayName,
        string Password,
        string JobTitle,
        string RoleName);

    private static IReadOnlyList<ManagerDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal =>
            [
                new(
                    Email: "manager@laprizza.local",
                    DisplayName: "LaPrizza Manager",
                    Password: "Manager123!",
                    JobTitle: "Manager",
                    RoleName: "Manager")
            ],

            BootstrapScenario.Default =>
            [
                new(
                    Email: "manager@laprizza.local",
                    DisplayName: "LaPrizza Manager",
                    Password: "Manager123!",
                    JobTitle: "Manager",
                    RoleName: "Manager")
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var manager in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"User \"{manager.DisplayName}\" ({manager.Email})";

            try
            {
                await handler.HandleAsync(
                    new CreateUserCommand(
                        Email: manager.Email,
                        DisplayName: manager.DisplayName,
                        Password: manager.Password,
                        Type: UserType.Staff,
                        RoleNames: [manager.RoleName],
                        JobTitle: manager.JobTitle),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(User),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(User),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The user already exists."));
            }
        }

        return results;
    }
}
