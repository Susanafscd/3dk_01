namespace LaPrizza.Bootstrap.Orchestration;

public enum BootstrapScenario
{
    Minimal,
    Default
}
