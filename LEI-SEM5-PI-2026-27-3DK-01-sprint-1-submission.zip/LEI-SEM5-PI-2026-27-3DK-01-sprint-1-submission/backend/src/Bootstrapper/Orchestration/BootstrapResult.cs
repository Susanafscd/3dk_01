namespace LaPrizza.Bootstrap.Orchestration;


/// <summary>
/// Represents the outcome of a bootstrap operation.
/// </summary>
public enum BootstrapResult
{
    /// <summary>
    /// The entity was successfully created.
    /// </summary>
    Created,

    /// <summary>
    /// The operation was intentionally skipped,
    /// for example because the entity already exists.
    /// </summary>
    Skipped,

    /// <summary>
    /// The operation failed.
    /// </summary>
    Failed
}
