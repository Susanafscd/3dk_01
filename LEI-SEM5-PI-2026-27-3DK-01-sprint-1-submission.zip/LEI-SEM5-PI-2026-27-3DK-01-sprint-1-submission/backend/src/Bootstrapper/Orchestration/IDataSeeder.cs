using LaPrizza.Bootstrap.Orchestration;

namespace LaPrizza.Bootstrapper.Orchestration;

public interface IDataSeeder
{
    Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default);
}
