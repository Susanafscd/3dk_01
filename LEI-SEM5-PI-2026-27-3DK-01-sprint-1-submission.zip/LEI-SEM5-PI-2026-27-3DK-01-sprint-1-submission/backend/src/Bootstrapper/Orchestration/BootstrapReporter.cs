namespace LaPrizza.Bootstrap.Orchestration;

public sealed class BootstrapReporter
{
    public void Report(
        BootstrapStepResult result)
    {
        var message = result.Outcome switch
        {
            BootstrapResult.Created =>
                $"[CREATED] {result.EntityType}: {result.Identifier}",

            BootstrapResult.Skipped =>
                $"[SKIPPED] {result.EntityType}: {result.Identifier}" +
                FormatReason(result.Reason),

            BootstrapResult.Failed =>
                $"[FAILED] {result.EntityType}: {result.Identifier}" +
                FormatReason(result.Reason),

            _ => throw new ArgumentOutOfRangeException(
                nameof(result.Outcome),
                result.Outcome,
                "Unknown bootstrap outcome.")
        };

        Console.WriteLine(message);
    }

    public void ReportSummary(
        BootstrapScenario scenario,
        IReadOnlyCollection<BootstrapStepResult> results)
    {
        var created = results.Count(
            result => result.Outcome == BootstrapResult.Created);

        var skipped = results.Count(
            result => result.Outcome == BootstrapResult.Skipped);

        var failed = results.Count(
            result => result.Outcome == BootstrapResult.Failed);

        Console.WriteLine();
        Console.WriteLine("==================================");
        Console.WriteLine("       LaPrizza Bootstrap");
        Console.WriteLine("==================================");
        Console.WriteLine($"Scenario : {scenario}");
        Console.WriteLine($"Created  : {created}");
        Console.WriteLine($"Skipped  : {skipped}");
        Console.WriteLine($"Failed   : {failed}");
        Console.WriteLine("==================================");
    }

    private static string FormatReason(string? reason)
    {
        return string.IsNullOrWhiteSpace(reason)
            ? string.Empty
            : $" — {reason}";
    }
}

