using LaPrizza.Bootstrapper;
using LaPrizza.Bootstrapper.Orchestration;
using Microsoft.Extensions.Logging;

namespace LaPrizza.Bootstrap.Orchestration;

public sealed class BootstrapRunner(
    IEnumerable<IDataSeeder> seeders,
    BootstrapReporter reporter,
    ILogger<BootstrapRunner> logger)
{
    public async Task<IReadOnlyList<BootstrapStepResult>> RunAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        logger.LogInformation(
            "Starting bootstrap with scenario {Scenario}.",
            scenario);

        foreach (var seeder in seeders)
        {
            cancellationToken.ThrowIfCancellationRequested();

            logger.LogInformation(
                "Executing {Seeder}.",
                seeder.GetType().Name);

            var stepResults = await seeder.CreateAsync(
                scenario,
                cancellationToken);

            foreach (var result in stepResults)
            {
                results.Add(result);
                reporter.Report(result);
            }

            if (stepResults.Any(
                    r => r.Outcome == BootstrapResult.Failed))
            {
                throw new InvalidOperationException(
                    $"Bootstrap step {seeder.GetType().Name} failed.");
            }
        }

        reporter.ReportSummary(scenario, results);

        logger.LogInformation(
            "Bootstrap completed using scenario {Scenario}.",
            scenario);

        return results;
    }
}
