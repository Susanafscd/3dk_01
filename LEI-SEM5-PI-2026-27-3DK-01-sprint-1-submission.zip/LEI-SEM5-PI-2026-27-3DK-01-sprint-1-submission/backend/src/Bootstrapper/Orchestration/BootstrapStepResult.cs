namespace LaPrizza.Bootstrap.Orchestration;

/// <summary>
/// Represents the result of a bootstrap operation.
/// </summary>
/// <param name="EntityType">The type of entity being processed.</param>
/// <param name="Identifier">The identifier of the entity.</param>
/// <param name="Outcome">The outcome of the operation.</param>
/// <param name="Reason">An optional explanation of the outcome.</param>
public sealed record BootstrapStepResult(
        string EntityType,
        string Identifier,
        BootstrapResult Outcome,
        string? Reason = null);

