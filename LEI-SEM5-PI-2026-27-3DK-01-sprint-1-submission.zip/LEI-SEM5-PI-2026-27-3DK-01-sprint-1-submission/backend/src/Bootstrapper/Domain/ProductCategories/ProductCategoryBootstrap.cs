using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories.CreateProductCategory;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Bootstrap.Domain.ProductCategories;

/// <summary>
/// Seeds the initial product categories required by the product catalogue.
/// </summary>
public sealed class ProductCategoryBootstrap(
    CreateProductCategoryCommandHandler handler) : IDataSeeder
{
    private sealed record ProductCategoryDefinition(
        string Code,
        string Name,
        string? Description,
        bool AllowsComponentTypes);

    private static IReadOnlyList<ProductCategoryDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal => [],

            BootstrapScenario.Default =>
            [
                new(
                    Code: "beverages",
                    Name: "Beverages",
                    Description: "Drinks available from the restaurant.",
                    AllowsComponentTypes: false),
                new(
                    Code: "snacks",
                    Name: "Snacks",
                    Description: "Snacks and sides available from the restaurant.",
                    AllowsComponentTypes: false),
                new(
                    Code: "pizza-component",
                    Name: "Pizza Component",
                    Description: "Products used as pizza components.",
                    AllowsComponentTypes: true)
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var category in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"ProductCategory \"{category.Name}\" ({category.Code})";

            try
            {
                await handler.HandleAsync(
                    new CreateProductCategoryCommand(
                        category.Code,
                        category.Name,
                        category.Description,
                        category.AllowsComponentTypes),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(ProductCategory),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(ProductCategory),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The product category already exists."));
            }
        }

        return results;
    }
}
