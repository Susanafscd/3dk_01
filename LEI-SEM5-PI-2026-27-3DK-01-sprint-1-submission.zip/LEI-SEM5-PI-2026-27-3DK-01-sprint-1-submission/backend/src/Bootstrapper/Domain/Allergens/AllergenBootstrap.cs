﻿using LaPrizza.Application.Allergens.CreateAllergen;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Bootstrap.Domain.Allergens;

/// <summary>
/// Seeds the initial allergens required by the product catalogue
/// (the EU 14 major allergens).
/// </summary>
public sealed class AllergenBootstrap(
    CreateAllergenCommandHandler handler) : IDataSeeder
{
    private sealed record AllergenDefinition(
        string Code,
        string Name,
        string? Description);

    private static IReadOnlyList<AllergenDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal => [],

            BootstrapScenario.Default =>
            [
                new("gluten", "Gluten", "Cereals containing gluten: wheat, rye, barley, oats, spelt and kamut."),
                new("crustaceans", "Crustaceans", "Crustaceans and products thereof."),
                new("eggs", "Eggs", "Eggs and products thereof."),
                new("fish", "Fish", "Fish and products thereof."),
                new("peanuts", "Peanuts", "Peanuts and products thereof."),
                new("soybeans", "Soybeans", "Soybeans and products thereof."),
                new("milk", "Milk", "Milk and products thereof, including lactose."),
                new("tree-nuts", "Tree nuts", "Almonds, hazelnuts, walnuts, cashews, pecans, Brazil nuts, pistachios and macadamia nuts."),
                new("celery", "Celery", "Celery and products thereof."),
                new("mustard", "Mustard", "Mustard and products thereof."),
                new("sesame", "Sesame", "Sesame seeds and products thereof."),
                new("sulphur-dioxide-and-sulphites", "Sulphur dioxide and sulphites", "Sulphur dioxide and sulphites above 10 mg/kg or 10 mg/L."),
                new("lupin", "Lupin", "Lupin and products thereof."),
                new("molluscs", "Molluscs", "Molluscs and products thereof.")
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var allergen in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"Allergen \"{allergen.Name}\" ({allergen.Code})";

            try
            {
                await handler.HandleAsync(
                    new CreateAllergenCommand(
                        allergen.Code,
                        allergen.Name,
                        allergen.Description),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Allergen),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Allergen),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The allergen already exists."));
            }
        }

        return results;
    }
}
