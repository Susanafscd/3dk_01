using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.CreatePizzaSize;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Bootstrap.Domain.Sizes;

/// <summary>
/// Seeds the canonical pizza sizes referenced by the component size
/// configurations (BCK06/BCK08).
/// </summary>
public sealed class PizzaSizeBootstrap(
    CreatePizzaSizeCommandHandler handler) : IDataSeeder
{
    private sealed record PizzaSizeDefinition(
        string Name,
        string? Description);

    private static IReadOnlyList<PizzaSizeDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal => [],

            BootstrapScenario.Default =>
            [
                new("small", "The 25 cm base size."),
                new("medium", "The 33 cm base size."),
                new("large", "The 50 cm base size.")
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var size in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"PizzaSize \"{size.Name}\"";

            try
            {
                await handler.HandleAsync(
                    new CreatePizzaSizeCommand(
                        size.Name,
                        size.Description),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(PizzaSize),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(PizzaSize),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The pizza size already exists."));
            }
        }

        return results;
    }
}
