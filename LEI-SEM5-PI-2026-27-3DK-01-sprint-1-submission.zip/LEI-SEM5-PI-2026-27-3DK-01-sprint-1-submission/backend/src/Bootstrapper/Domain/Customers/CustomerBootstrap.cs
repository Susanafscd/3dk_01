using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Customers.CreateCustomer;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;

namespace LaPrizza.Bootstrap.Domain.Customers;

/// <summary>
/// Seeds the sample customers a freshly set-up project starts with.
/// </summary>
public sealed class CustomerBootstrap(
    CreateCustomerCommandHandler handler,
    IAllergenRepository allergenRepo
    ) : IDataSeeder
{
    private sealed record CustomerDefinition(
        string Name,
        string Email,
        List<string> Allergens,
        string PhoneNumber,
        string Password);

    private static IReadOnlyList<CustomerDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal => [],

            BootstrapScenario.Default =>
            [
                new(
                    Name: "LaPrizza Customer",
                    Email: "customer@laprizza.local",
                    [],
                    PhoneNumber: "+351 911 000 000",
                    Password: "Customer123!"),
                new(
                    Name: "Maria Santos",
                    Email: "maria.santos@example.com",
                    ["peanuts", "fish"],
                    PhoneNumber: "+351 912 345 678",
                    Password: "Customer123!"),
                new(
                    Name: "João Oliveira",
                    Email: "joao.oliveira@example.com",
                    ["milk", "fish"],
                    PhoneNumber: "+351 913 456 789",
                    Password: "Customer123!")
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }


    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var customer in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"Customer \"{customer.Name}\" ({customer.Email})";

            try
            {

                await handler.HandleAsync(
                    new CreateCustomerCommand(
                        customer.Name,
                        customer.Email,
                        customer.PhoneNumber,
                        customer.Password,
                        customer.Allergens),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Customer),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Customer),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The customer already exists."));
            }
        }

        return results;
    }
}
