using LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Bootstrap.Domain.PizzaComponentTypes;

/// <summary>
/// Seeds the initial pizza component types required by BCK07.
/// </summary>
public sealed class PizzaComponentTypeBootstrap(CreatePizzaComponentTypeCommandHandler handler)
    : IDataSeeder
{
    private sealed record PizzaComponentTypeDefinition(
        string Code,
        string CategoryCode,
        string Name,
        string? Description,
        int AssemblyOrder,
        int MinQuantity,
        int? MaxQuantity);

    private static IReadOnlyList<PizzaComponentTypeDefinition> GetDefinitions(BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal or BootstrapScenario.Default =>
            [
                new("base-dough", "pizza-component", "Base Dough", null, 1, 1, 1),
                new("base-sauce", "pizza-component", "Base Sauce", null, 2, 0, 1),
                new("cheese", "pizza-component", "Cheese", null, 3, 0, 1),
                new("topping", "pizza-component", "Topping", null, 4, 0, null)
            ],
            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var type in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"Pizza component type \"{type.Code}\" (order {type.AssemblyOrder})";

            try
            {
                await handler.HandleAsync(
                    new CreatePizzaComponentTypeCommand(
                        type.Code,
                        type.CategoryCode,
                        type.Name,
                        type.Description,
                        type.AssemblyOrder,
                        type.MinQuantity,
                        type.MaxQuantity),
                    cancellationToken);

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(PizzaComponentType),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(PizzaComponentType),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The pizza component type already exists."));
            }
        }

        return results;
    }
}
