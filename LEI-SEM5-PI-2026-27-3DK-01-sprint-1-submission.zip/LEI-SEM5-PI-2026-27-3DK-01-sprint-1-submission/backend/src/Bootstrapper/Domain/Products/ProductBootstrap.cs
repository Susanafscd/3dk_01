using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Bootstrap.Domain.Products;

/// <summary>
/// Seeds sample pizza components through the Application layer.
/// </summary>
/// <remarks>
/// A product also carries its size configuration, which the create-product use case
/// does not accept. So the seeder creates the product through the use case and then
/// attaches its configuration through the aggregate and the product repository.
/// </remarks>
public sealed class ProductBootstrap(
    CreateProductCommandHandler createProduct,
    IProductRepository products) : IDataSeeder
{
    private sealed record ProductDefinition(
        string Code,
        string Name,
        string Description,
        string CategoryCode,
        bool Sellable,
        bool StockControlled,
        decimal? Price,
        IReadOnlyList<string> AllergenCodes,
        string? ComponentTypeCode,
        IReadOnlyList<SizeValuesBootstrap> Sizes);

    private sealed record SizeValuesBootstrap(
        string SizeId,
        decimal Price,
        int StockConsumption);

    private static IReadOnlyList<ProductDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal => [],

            BootstrapScenario.Default =>
            [
                new(
                    Code: "pizza-dough",
                    Name: "Pizza dough",
                    Description: "Basic wheat dough prepared in house.",
                    CategoryCode: "pizza-component",
                    Sellable: false,
                    StockControlled: true,
                    Price: null,
                    AllergenCodes: [],
                    ComponentTypeCode: "base-dough",
                    Sizes:
                    [
                        new SizeValuesBootstrap("small", 2.00m, 1),
                        new SizeValuesBootstrap("medium", 3.00m, 1),
                        new SizeValuesBootstrap("large", 4.00m, 2),
                    ]),
                new(
                    Code: "pizza-tomato-sauce",
                    Name: "Tomato sauce",
                    Description: "House tomato sauce prepared in house.",
                    CategoryCode: "pizza-component",
                    Sellable: false,
                    StockControlled: true,
                    Price: null,
                    AllergenCodes: [],
                    ComponentTypeCode: "base-sauce",
                    Sizes:
                    [
                        new SizeValuesBootstrap("small", 0.75m, 1),
                        new SizeValuesBootstrap("medium", 1.00m, 1),
                        new SizeValuesBootstrap("large", 1.25m, 1),
                    ]),
                new(
                    Code: "pizza-mozzarella",
                    Name: "Mozzarella",
                    Description: "Fresh mozzarella prepared in house.",
                    CategoryCode: "pizza-component",
                    Sellable: false,
                    StockControlled: true,
                    Price: null,
                    AllergenCodes: ["milk"],
                    ComponentTypeCode: "cheese",
                    Sizes:
                    [
                        new SizeValuesBootstrap("small", 2.50m, 1),
                        new SizeValuesBootstrap("medium", 3.25m, 1),
                        new SizeValuesBootstrap("large", 4.00m, 2),
                    ]),
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var product in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"Product \"{product.Name}\" ({product.Code})";

            try
            {
                await createProduct.HandleAsync(
                    new CreateProductCommand(
                        product.Code,
                        product.Name,
                        product.Description,
                        product.CategoryCode,
                        product.Sellable,
                        product.StockControlled,
                        product.Price,
                        product.AllergenCodes,
                        product.ComponentTypeCode),
                    cancellationToken);

                var sizeConfiguration = product.Sizes.Aggregate(
                    SizeConfiguration.Empty,
                    (configuration, size) => configuration.AddSizeConfiguration(
                        size.SizeId,
                        size.Price,
                        size.StockConsumption));

                var entity = await products.GetByCodeAsync(ProductCode.Create(product.Code), cancellationToken);

                if (entity is BaseProduct component)
                {
                    component.SetSizeConfiguration(sizeConfiguration);
                    await products.SaveAsync(component, cancellationToken);
                }

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Product),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (ConflictException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(Product),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Skipped,
                    Reason: "The product already exists."));
            }
        }

        return results;
    }
}
