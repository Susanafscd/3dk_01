using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrapper.Orchestration;
using Microsoft.AspNetCore.Identity;

namespace LaPrizza.Bootstrap.Roles;

/// <summary>
/// Seeds the built-in roles through the Application layer.
/// </summary>
public sealed class RoleBootstrap(RoleManager<IdentityRole> roleManager) : IDataSeeder
{
    private sealed record RoleDefinition(
        string Name,
        string? Description);

    private static IReadOnlyList<RoleDefinition> GetDefinitions(
        BootstrapScenario scenario)
    {
        return scenario switch
        {
            BootstrapScenario.Minimal =>
            [
                new("Manager", "Runs the restaurant."),
                new("Customer", "Restaurant customer.")
            ],

            BootstrapScenario.Default =>
            [
                new("Manager", "Runs the restaurant."),
                new("Customer", "Restaurant customer.")
            ],

            _ => throw new ArgumentOutOfRangeException(nameof(scenario))
        };
    }

    public async Task<IReadOnlyList<BootstrapStepResult>> CreateAsync(
        BootstrapScenario scenario,
        CancellationToken cancellationToken = default)
    {
        var results = new List<BootstrapStepResult>();

        foreach (var definition in GetDefinitions(scenario))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var identifier = $"Role \"{definition.Name}\"";

            try
            {
                if (await roleManager.RoleExistsAsync(definition.Name))
                {
                    results.Add(new BootstrapStepResult(
                        EntityType: nameof(IdentityRole),
                        Identifier: identifier,
                        Outcome: BootstrapResult.Skipped,
                        Reason: "The role already exists."));

                    continue;
                }

                var role = new IdentityRole(definition.Name);

                var identityResult = await roleManager.CreateAsync(role);

                if (!identityResult.Succeeded)
                {
                    results.Add(new BootstrapStepResult(
                        EntityType: nameof(IdentityRole),
                        Identifier: identifier,
                        Outcome: BootstrapResult.Failed,
                        Reason: string.Join(
                            "; ",
                            identityResult.Errors.Select(error =>
                                $"{error.Code}: {error.Description}"))));

                    continue;
                }

                results.Add(new BootstrapStepResult(
                    EntityType: nameof(IdentityRole),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Created));
            }
            catch (Exception exception) when (
                exception is not OperationCanceledException)
            {
                results.Add(new BootstrapStepResult(
                    EntityType: nameof(IdentityRole),
                    Identifier: identifier,
                    Outcome: BootstrapResult.Failed,
                    Reason: exception.Message));
            }
        }

        return results;
    }
}
