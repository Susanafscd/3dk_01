namespace LaPrizza.Infrastructure.Redis;

/// <summary>Tags for read projections; keys also include their filters and pagination.</summary>
public static class CatalogueCacheTags
{
    public const string Allergens = "laprizza:catalogue:v1:allergens";
    public const string ProductCategories = "laprizza:catalogue:v1:product-categories";
    public const string Products = "laprizza:catalogue:v1:products";
    public const string Catalogue = "laprizza:catalogue:v1:offers";
}
