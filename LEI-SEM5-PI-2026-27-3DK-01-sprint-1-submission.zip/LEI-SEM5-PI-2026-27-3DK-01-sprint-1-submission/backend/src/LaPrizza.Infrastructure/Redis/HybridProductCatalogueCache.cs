using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Products.GetProduct;
using Microsoft.Extensions.Caching.Hybrid;

namespace LaPrizza.Infrastructure.Redis;

/// <summary>
/// HybridCache adapter for the product detail projections and the public
/// catalogue (BCK11). The catalogue entries share the manager product detail
/// tag plus the catalogue tag, so a committed product change (creation, size
/// configuration, ...) invalidates both at once; the catalogue tag also lets a
/// broad refresh drop every reachable projection. A short expiry bounds how
/// long stale data could be served if invalidation misses.
/// </summary>
internal sealed class HybridProductCatalogueCache(HybridCache cache) : IProductCatalogueCache
{
    public Task<ProductLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<ProductLookupResult>> factory,
        CancellationToken cancellationToken = default) =>
        cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:products:detail:{code}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.Products],
            cancellationToken: cancellationToken).AsTask();

    public Task<CatalogueResult> GetListAsync(
        int page,
        int pageSize,
        Func<CancellationToken, Task<CatalogueResult>> factory,
        CancellationToken cancellationToken = default) =>
        cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:offers:list:{page}:{pageSize}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.Products, CatalogueCacheTags.Catalogue],
            cancellationToken: cancellationToken).AsTask();

    public Task<CatalogueProductResult?> GetByIdAsync(
        Guid id,
        Func<CancellationToken, Task<CatalogueProductResult?>> factory,
        CancellationToken cancellationToken = default) =>
        cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:offers:detail:{id}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.Products, CatalogueCacheTags.Catalogue],
            cancellationToken: cancellationToken).AsTask();
}
