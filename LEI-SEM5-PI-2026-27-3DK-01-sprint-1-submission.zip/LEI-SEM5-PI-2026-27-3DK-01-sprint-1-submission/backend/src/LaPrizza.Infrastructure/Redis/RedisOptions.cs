namespace LaPrizza.Infrastructure.Redis;

/// <summary>
/// Redis cache settings, bound from the 'Redis' configuration section
/// (environment variable 'Redis__ConnectionString').
/// </summary>
public sealed class RedisOptions
{
    public const string SectionName = "Redis";

    public string ConnectionString { get; set; } = "localhost:6379";
}
