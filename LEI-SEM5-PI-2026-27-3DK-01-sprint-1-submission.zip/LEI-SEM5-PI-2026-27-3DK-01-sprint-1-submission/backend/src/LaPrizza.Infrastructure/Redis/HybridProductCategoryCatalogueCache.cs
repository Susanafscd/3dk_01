using LaPrizza.Application.Abstractions;
using LaPrizza.Application.ProductCategories;
using LaPrizza.Application.ProductCategories.SearchProductCategories;
using LaPrizza.Domain.ProductCategories;
using Microsoft.Extensions.Caching.Hybrid;

namespace LaPrizza.Infrastructure.Redis;

internal sealed class HybridProductCategoryCatalogueCache(HybridCache cache)
    : IProductCategoryCatalogueCache
{
    public Task<ProductCategoryLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<ProductCategoryLookupResult>> factory,
        CancellationToken cancellationToken = default) =>
        cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:product-categories:detail:{code}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.ProductCategories],
            cancellationToken: cancellationToken).AsTask();

    public Task<SearchProductCategoriesResult> SearchAsync(
        string cacheKey,
        Func<CancellationToken, Task<SearchProductCategoriesResult>> factory,
        CancellationToken cancellationToken = default) =>
        cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:product-categories:search:{cacheKey}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.ProductCategories],
            cancellationToken: cancellationToken).AsTask();
}
