using LaPrizza.Application.Abstractions;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Logging;

namespace LaPrizza.Infrastructure.Redis;

internal sealed class HybridCatalogueCacheInvalidator(
    HybridCache cache,
    ILogger<HybridCatalogueCacheInvalidator> logger) : ICatalogueCacheInvalidator
{
    public async Task InvalidateAllergensAsync(CancellationToken cancellationToken = default)
    {
        // A disconnected request must not skip the attempt after commit.
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
        try
        {
            await cache.RemoveByTagAsync(
                [CatalogueCacheTags.Allergens, CatalogueCacheTags.Catalogue], timeout.Token);
        }
        catch (Exception exception)
        {
            // Expiration bounds staleness if Redis is unavailable. Returning an
            // error cannot undo the commit and encourages duplicate retries.
            logger.LogWarning(exception,
                "Allergen write committed, but catalogue cache invalidation failed. Entries will expire.");
        }
    }

    public async Task InvalidateProductCategoriesAsync(CancellationToken cancellationToken = default)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
        try
        {
            await cache.RemoveByTagAsync(
                [CatalogueCacheTags.ProductCategories, CatalogueCacheTags.Catalogue], timeout.Token);
        }
        catch (Exception exception)
        {
            logger.LogWarning(exception,
                "Product-category write committed, but catalogue cache invalidation failed. Entries will expire.");
        }
    }

    public async Task InvalidateProductsAsync(CancellationToken cancellationToken = default)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
        try
        {
            await cache.RemoveByTagAsync(
                [CatalogueCacheTags.Products, CatalogueCacheTags.Catalogue], timeout.Token);
        }
        catch (Exception exception)
        {
            logger.LogWarning(exception,
                "Product write committed, but catalogue cache invalidation failed. Entries will expire.");
        }
    }
}
