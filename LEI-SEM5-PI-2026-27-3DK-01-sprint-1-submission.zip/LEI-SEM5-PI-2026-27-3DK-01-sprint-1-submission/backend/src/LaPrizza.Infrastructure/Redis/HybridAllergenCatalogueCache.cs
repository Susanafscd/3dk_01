using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Domain.Allergens;
using Microsoft.Extensions.Caching.Hybrid;

namespace LaPrizza.Infrastructure.Redis;

internal sealed class HybridAllergenCatalogueCache(HybridCache cache) : IAllergenCatalogueCache
{
    public async Task<AllergenLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<AllergenLookupResult>> factory,
        CancellationToken cancellationToken = default)
    {
        return await cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:allergens:detail:{code}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.Allergens],
            cancellationToken: cancellationToken);
    }

    public async Task<SearchAllergensResult> SearchAsync(
        string cacheKey,
        Func<CancellationToken, Task<SearchAllergensResult>> factory,
        CancellationToken cancellationToken = default)
    {
        return await cache.GetOrCreateAsync(
            $"laprizza:catalogue:v1:allergens:search:{cacheKey}",
            async token => await factory(token),
            tags: [CatalogueCacheTags.Allergens],
            cancellationToken: cancellationToken);
    }
}
