using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using Microsoft.AspNetCore.Identity;

namespace LaPrizza.Infrastructure.Identity;

internal sealed class UserAccountManager(UserManager<IdentityUser> userManager) : IUserAccountManager
{
    public async Task<string> CreateAccountAsync(
        string email,
        string password,
        CancellationToken cancellationToken = default)
    {
        var account = new IdentityUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
        };

        var result = await userManager.CreateAsync(account, password);

        if (!result.Succeeded)
        {
            var failures = string.Join(" ", result.Errors.Select(error => error.Description));
            throw new ValidationException($"The account could not be created: {failures}");
        }

        return account.Id;
    }

    public async Task AssignRolesAsync(
        string accountId,
        IEnumerable<string> roleNames,
        CancellationToken cancellationToken = default)
    {
        var account = await userManager.FindByIdAsync(accountId.ToString());

        if (account is null)
        {
            throw new InvalidOperationException(
                $"Identity account '{accountId}' was not found.");
        }

        var roles = roleNames
            .Where(role => !string.IsNullOrWhiteSpace(role))
            .Select(role => role.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        if (roles.Length == 0)
        {
            return;
        }

        var result = await userManager.AddToRolesAsync(
            account,
            roles);

        if (!result.Succeeded)
        {
            throw new InvalidOperationException(
                "Failed to assign roles: " +
                string.Join(
                    "; ",
                    result.Errors.Select(error => error.Description)));
        }
    }

    public async Task DeleteAccountAsync(string accountId, CancellationToken cancellationToken = default)
    {
        var account = await userManager.FindByIdAsync(accountId);

        if (account is not null)
        {
            await userManager.DeleteAsync(account);
        }
    }
}
