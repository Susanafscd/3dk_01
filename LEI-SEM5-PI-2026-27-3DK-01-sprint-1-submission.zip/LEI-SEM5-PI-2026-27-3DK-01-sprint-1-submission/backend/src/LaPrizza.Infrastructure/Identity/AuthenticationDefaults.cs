namespace LaPrizza.Infrastructure.Identity;

/// <summary>
/// Names shared by the authentication setup and everything that has to refer to
/// them, such as the OpenAPI security scheme. Keeping them here stops the cookie
/// name from being duplicated as a magic string.
/// </summary>
public static class AuthenticationDefaults
{
    /// <summary>Name of the HttpOnly cookie that carries the authenticated session.</summary>
    public const string CookieName = "Api.Auth";
}
