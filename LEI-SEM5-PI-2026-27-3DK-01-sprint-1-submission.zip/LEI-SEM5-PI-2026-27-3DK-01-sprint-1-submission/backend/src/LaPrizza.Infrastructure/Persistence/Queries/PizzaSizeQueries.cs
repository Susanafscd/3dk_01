using LaPrizza.Application.ComponentTypes;
using LaPrizza.Domain.ComponentTypes;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>EF Core adapter for read-only pizza-size queries (BCK06).</summary>
internal sealed class PizzaSizeQueries(DomainDbContext context) : IPizzaSizeQueries
{
    public async Task<PizzaSizeSearchPage> SearchAsync(
        string? search,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var query = context.Set<PizzaSize>().AsNoTracking();
        var term = search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var identifier = TryCreateIdentifier(term);

            query = identifier is null
                ? query.Where(size => size.Name.ToLower().Contains(lowered))
                : query.Where(size => size.Id == identifier || size.Name.ToLower().Contains(lowered));
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)page - 1) * pageSize;

        if (skip >= totalCount)
        {
            return new PizzaSizeSearchPage([], totalCount);
        }

        var sizes = await query
            .OrderBy(size => size.Name)
            .ThenBy(size => size.Id)
            .Skip((int)skip)
            .Take(pageSize)
            .Select(size => new
            {
                size.Id,
                size.Name,
                size.Description,
            })
            .ToListAsync(cancellationToken);

        IReadOnlyList<PizzaSizeResult> items = sizes
            .Select(size => new PizzaSizeResult(size.Id, size.Name, size.Description))
            .ToList();

        return new PizzaSizeSearchPage(items, totalCount);
    }

    private static Guid? TryCreateIdentifier(string value)
    {
        return Guid.TryParse(value, out var identifier) ? identifier : null;
    }
}
