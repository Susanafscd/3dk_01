using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

internal sealed class ProductRelationshipQueries(DomainDbContext db) : IProductRelationshipQueries
{
    public async Task<ProductChangeContext> GetChangeContextAsync(
        ProductCategoryCode category,
        IReadOnlyCollection<AllergenCode> allergens,
        PizzaComponentTypeCode? componentTypeCode = null,
        CancellationToken cancellationToken = default)
    {
        var categoryEntity = await db.Set<ProductCategory>()
            .AsNoTracking()
            .SingleOrDefaultAsync(c => c.Code == category, cancellationToken);

        // Compared in memory because the value converters on AllergenCode may not translate to SQL.
        // Fine for a small catalogue; move to a SQL filter once the converter is confirmed.
        var knownAllergens = (await db.Set<Allergen>()
                .Select(a => a.Code)
                .ToListAsync(cancellationToken))
            .Select(code => code.Value)
            .ToHashSet();

        var unknown = allergens
            .Where(a => !knownAllergens.Contains(a.Value))
            .ToList();

        var componentType = componentTypeCode is null
            ? null
            : await db.PizzaComponentTypes
                .AsNoTracking()
                .SingleOrDefaultAsync(t => t.Code == componentTypeCode, cancellationToken);

        return new ProductChangeContext(
            categoryEntity is not null,
            unknown,
            categoryEntity?.AllowsComponentTypes ?? false,
            componentTypeCode is not null,
            componentType is not null,
            componentType is not null && componentType.CategoryCode == category);
    }
}
