using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>
/// Reads what a predefined pizza needs from other aggregates (BCK10). The
/// component type is the <c>ComponentTypeCode</c> shadow property of Products
/// (BCK05), so it is read here rather than through the product aggregate.
/// </summary>
internal sealed class PredefinedPizzaQueries(DomainDbContext db) : IPredefinedPizzaQueries
{
    public async Task<IReadOnlyList<PizzaComponentFacts>> GetComponentsAsync(
        IReadOnlyCollection<ProductCode> codes,
        CancellationToken cancellationToken = default)
    {
        var facts = new List<PizzaComponentFacts>();
        var categoryRules = new Dictionary<ProductCategoryCode, bool>();
        var assemblyOrders = (await db.Set<PizzaComponentType>()
                .AsNoTracking()
                .Select(type => new { type.Code, type.AssemblyOrder })
                .ToListAsync(cancellationToken))
            .ToDictionary(type => type.Code.Value, type => type.AssemblyOrder);

        // A pizza has a handful of components, so one lookup per code keeps the
        // value-converted comparison simple to translate.
        foreach (var code in codes.Distinct())
        {
            var row = await db.Set<Product>()
                .AsNoTracking()
                .Where(product => product.Code == code)
                .Select(product => new
                {
                    Product = product,
                    ComponentTypeCode = EF.Property<string?>(product, "ComponentTypeCode"),
                })
                .SingleOrDefaultAsync(cancellationToken);

            if (row is null)
            {
                continue;
            }

            if (!categoryRules.TryGetValue(row.Product.CategoryCode, out var allowsComponentTypes))
            {
                allowsComponentTypes = await db.Set<ProductCategory>()
                    .Where(category => category.Code == row.Product.CategoryCode)
                    .Select(category => category.AllowsComponentTypes)
                    .SingleOrDefaultAsync(cancellationToken);
                categoryRules[row.Product.CategoryCode] = allowsComponentTypes;
            }

            var activeSizePrices = row.Product is BaseProduct { SizeConfiguration: { } configuration }
                ? configuration.SizeMappings
                    .Where(entry => entry.Value.Active)
                    .ToDictionary(entry => entry.Key, entry => entry.Value.Price)
                : new Dictionary<string, decimal>();

            facts.Add(new PizzaComponentFacts(
                row.Product.Code,
                row.Product.Name,
                row.Product is BaseProduct,
                row.Product.Active,
                allowsComponentTypes,
                row.ComponentTypeCode,
                row.ComponentTypeCode is { } type && assemblyOrders.TryGetValue(type, out var order) ? order : null,
                activeSizePrices));
        }

        return facts;
    }

    public async Task<IReadOnlyList<ComponentTypeLimit>> GetComponentTypeLimitsAsync(
        CancellationToken cancellationToken = default)
    {
        var types = await db.Set<PizzaComponentType>()
            .AsNoTracking()
            .Select(type => new { type.Code, type.MinQuantity, type.MaxQuantity })
            .ToListAsync(cancellationToken);

        return types
            .Select(type => new ComponentTypeLimit(type.Code.Value, type.MinQuantity, type.MaxQuantity))
            .ToList();
    }

    /// <summary>
    /// Matches a full pizza code or a case-insensitive part of the name, like the
    /// product and stock searches, and reads PostgreSQL on every call (ADR-002).
    /// </summary>
    public async Task<PredefinedPizzaSearchPage> SearchAsync(
        PredefinedPizzaSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        var query = db.Set<Product>().AsNoTracking().OfType<ComposedProduct>();

        if (criteria.Search is { } term)
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);
            query = code is null
                ? query.Where(p => p.Name.ToLower().Contains(lowered))
                : query.Where(p => p.Code == code || p.Name.ToLower().Contains(lowered));
        }

        if (criteria.Active is not null)
        {
            query = query.Where(p => p.Active == criteria.Active.Value);
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)criteria.Page - 1) * criteria.PageSize;
        if (skip >= totalCount)
        {
            return new PredefinedPizzaSearchPage([], totalCount);
        }

        var pizzas = await query
            .OrderBy(p => p.Name)
            .ThenBy(p => p.Code)
            .Skip((int)skip)
            .Take(criteria.PageSize)
            .Select(p => new { p.Code, p.Name, p.CategoryCode, p.Active })
            .ToListAsync(cancellationToken);

        var items = pizzas
            .Select(p => new PredefinedPizzaSearchItem(p.Code.Value, p.Name, p.CategoryCode.Value, p.Active))
            .ToList();

        return new PredefinedPizzaSearchPage(items, totalCount);
    }

    private static ProductCode? TryCreateCode(string value)
    {
        try
        {
            return ProductCode.Create(value);
        }
        catch (DomainException)
        {
            return null;
        }
    }
}
