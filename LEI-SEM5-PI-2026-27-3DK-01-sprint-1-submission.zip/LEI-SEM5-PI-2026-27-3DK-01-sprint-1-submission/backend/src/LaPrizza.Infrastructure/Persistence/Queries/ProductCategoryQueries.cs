using LaPrizza.Application.ProductCategories;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>EF Core adapter for read-only product-category catalogue queries.</summary>
internal sealed class ProductCategoryQueries(DomainDbContext context) : IProductCategoryQueries
{
    public async Task<ProductCategorySearchPage> SearchAsync(
        string? search,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var query = context.ProductCategories.AsNoTracking();
        var term = search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);

            query = code is null
                ? query.Where(category => category.Name.ToLower().Contains(lowered))
                : query.Where(category =>
                    category.Code == code
                    || category.Name.ToLower().Contains(lowered));
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)page - 1) * pageSize;

        if (skip >= totalCount)
        {
            return new ProductCategorySearchPage([], totalCount);
        }

        var categories = await query
            .OrderBy(category => category.Name)
            .ThenBy(category => category.Code)
            .Skip((int)skip)
            .Take(pageSize)
            .Select(category => new
            {
                category.Code,
                category.Name,
                category.Description,
                category.AllowsComponentTypes,
            })
            .ToListAsync(cancellationToken);

        IReadOnlyList<ProductCategorySearchItem> items = categories
            .Select(category => new ProductCategorySearchItem(
                category.Code.Value,
                category.Name,
                category.Description,
                category.AllowsComponentTypes))
            .ToList();

        return new ProductCategorySearchPage(items, totalCount);
    }

    private static ProductCategoryCode? TryCreateCode(string value)
    {
        try
        {
            return ProductCategoryCode.Create(value);
        }
        catch (DomainException)
        {
            return null;
        }
    }
}
