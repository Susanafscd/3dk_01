using LaPrizza.Domain.Allergens;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

internal sealed class AllergenUsageQueries(DomainDbContext context) : IAllergenUsageQueries
{
    public async Task<AllergenUsageFacts> GetUsageAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default)
    {
        var value = code.Value;
        var hasProductReferences = await context.Products
            .AnyAsync(product => product.Allergens.Any(allergen => allergen.Value == value), cancellationToken);

        var hasDietaryRestrictions = await context.DietaryRestrictions
            .AnyAsync(
                restriction => restriction.Allergens.Any(allergen => allergen.Code == code),
                cancellationToken);

        return new AllergenUsageFacts(hasProductReferences, hasDietaryRestrictions, false);
    }
}
