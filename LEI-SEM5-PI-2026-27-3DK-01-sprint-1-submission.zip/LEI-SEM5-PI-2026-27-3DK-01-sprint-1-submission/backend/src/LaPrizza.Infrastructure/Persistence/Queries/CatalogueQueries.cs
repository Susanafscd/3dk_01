using LaPrizza.Application.Catalogue;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.SizeConfigurations;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>
/// EF Core adapter for the public catalogue query port (BCK11). Loads only the
/// products that are currently active and sellable — inactive or non-sellable
/// products never materialize — and enriches each entry with its category
/// (business-code aggregates are joined by code), the allergen names and, for
/// products configured by size, the available pizza sizes with their prices.
/// Price-by-size rules follow the contract: a product whose size configuration
/// has active entries does not carry a unit price (the pricing lives in the
/// sizes), otherwise the sellable price is the unit price and the size list is
/// empty. Deactivated size configurations keep being retained but stop
/// applying, so they are not offered.
/// </summary>
internal sealed class CatalogueQueries(DomainDbContext context) : ICatalogueQueries
{
    public async Task<CatalogueResult> LoadAsync(
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var skip = (page - 1) * pageSize;

        var products = await OnSale()
            .OrderBy(product => product.Name)
            .ThenBy(product => product.Id)
            .Skip(skip)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return new CatalogueResult(await MapAsync(products, cancellationToken));
    }

    public async Task<CatalogueProductResult?> LoadByIdAsync(
        Guid id,
        CancellationToken cancellationToken = default)
    {
        var product = await OnSale()
            .SingleOrDefaultAsync(candidate => candidate.Id == id, cancellationToken);

        if (product is null)
        {
            return null;
        }

        var entries = await MapAsync([product], cancellationToken);
        return entries.FirstOrDefault();
    }

    private IQueryable<Product> OnSale() =>
        context.Products
            .AsNoTracking()
            .Include(product => product.Allergens)
            .Where(product => product.Sellable != null && product.Active);

    /// <summary>
    /// Enriches the given products in a fixed number of lookups — the page, plus
    /// the reference categories, allergens and pizza sizes — so a page never
    /// degenerates into per-entry queries. Categories and allergens are filtered
    /// in memory: their business codes are value objects behind converters and
    /// the reference sets are small and bounded (a business catalogue), so one
    /// trivial read per set is cheaper than a converted-code IN filter.
    /// </summary>
    private async Task<IReadOnlyList<CatalogueProductResult>> MapAsync(
        IReadOnlyCollection<Product> products,
        CancellationToken cancellationToken)
    {
        if (products.Count == 0)
        {
            return [];
        }

        var allergenCodes = products
            .SelectMany(product => product.Allergens.Select(allergen => allergen.Value))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var sizeNames = products
            .OfType<BaseProduct>()
            .SelectMany(product => product.SizeConfiguration?.SizeMappings ?? (IReadOnlyDictionary<string, SizeValues>)new Dictionary<string, SizeValues>())
            .Where(mapping => mapping.Value.Active)
            .Select(mapping => mapping.Key)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var categoriesLookedUp = await context.ProductCategories
            .AsNoTracking()
            .Select(category => new { category.Code, category.Name })
            .ToListAsync(cancellationToken);

        var allergensLookedUp = await context.Allergens
            .AsNoTracking()
            .Select(allergen => new { allergen.Code, allergen.Name })
            .ToListAsync(cancellationToken);

        var sizesLookedUp = await context.PizzaSizes
            .AsNoTracking()
            .Where(size => sizeNames.Contains(size.Name))
            .Select(size => new { size.Name })
            .ToListAsync(cancellationToken);

        var categoryByCode = categoriesLookedUp.ToDictionary(
            category => category.Code.Value,
            category => new CatalogueCategoryResult(category.Code.Value, category.Name),
            StringComparer.OrdinalIgnoreCase);
        var allergenNameByCode = allergensLookedUp
            .Where(allergen => allergenCodes.Contains(allergen.Code.Value))
            .ToDictionary(
                allergen => allergen.Code.Value,
                allergen => allergen.Name,
                StringComparer.OrdinalIgnoreCase);
        var sizeByCode = sizesLookedUp.ToDictionary(
            size => size.Name,
            size => size.Name,
            StringComparer.OrdinalIgnoreCase);

        return products.Select(product => Map(
            product,
            categoryByCode,
            allergenNameByCode,
            sizeByCode)).ToList();
    }

    private static CatalogueProductResult Map(
        Product product,
        IReadOnlyDictionary<string, CatalogueCategoryResult> categories,
        IReadOnlyDictionary<string, string> allergenNames,
        IReadOnlyDictionary<string, string> sizesByCode)
    {
        List<KeyValuePair<string, SizeValues>>? configuredSizes = product is BaseProduct baseProduct
            ? baseProduct.SizeConfiguration?.SizeMappings
                .Where(mapping => mapping.Value.Active)
                .ToList()
            : [];

        List<CatalogueSizeResult> sizes;
        if (configuredSizes is { Count: > 0 })
        {
            sizes = configuredSizes
                .Select(mapping => sizesByCode.TryGetValue(mapping.Key, out var size)
                    ? new CatalogueSizeResult(size, mapping.Value.Price)
                    : null)
                // A configuration naming an unknown size is a data anomaly; the
                // entry simply does not offer that size.
                .OfType<CatalogueSizeResult>()
                .OrderBy(size => size.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        else
        {
            sizes = [];
        }

        // A product priced by size carries no unit price: the pricing lives in
        // the sizes. Otherwise the sellable price is the unit price.
        var unitPrice = configuredSizes is { Count: > 0 }
            ? null
            : product.Sellable?.Price.Amount;

        return new CatalogueProductResult(
            product.Code.Value,
            product.Name,
            string.IsNullOrWhiteSpace(product.Description) ? null : product.Description,
            categories.TryGetValue(product.CategoryCode.Value, out var category) ? category : null,
            unitPrice,
            sizes,
            product.Allergens
                .Select(allergen => allergenNames.TryGetValue(allergen.Value, out var name) ? name : null)
                // An allergen code that no longer references a known allergen is
                // a data anomaly; the entry simply does not report it.
                .OfType<string>()
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToList(),
            // Composed pizzas do not exist in the domain yet, so no entry has a
            // configuration; the field stays null until that aggregate lands.
            null);
    }
}
