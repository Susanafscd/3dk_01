using LaPrizza.Domain.Common;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>EF Core adapter for the read-only product catalogue query.</summary>
internal sealed class ProductQueries(DomainDbContext context) : IProductQueries
{
    public async Task<ProductSearchPage> SearchAsync(
        ProductSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        var query = context.Products.AsNoTracking();
        var term = criteria.Search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);
            query = code is null
                ? query.Where(p => p.Name.ToLower().Contains(lowered))
                : query.Where(p => p.Code == code || p.Name.ToLower().Contains(lowered));
        }

        if (criteria.CategoryCode is not null)
        {
            query = query.Where(p => p.CategoryCode == criteria.CategoryCode);
        }

        if (criteria.AllergenCode is not null)
        {
            var allergenCode = criteria.AllergenCode.Value;
            query = query.Where(p => p.Allergens.Any(a => a.Value == allergenCode));
        }

        if (criteria.Sellable is not null)
        {
            query = criteria.Sellable.Value
                ? query.Where(p => p.Sellable != null || EF.Property<string>(p, "Kind") == "Composed")
                : query.Where(p => p.Sellable == null && EF.Property<string>(p, "Kind") != "Composed");
        }

        if (criteria.StockControlled is not null)
        {
            query = query.Where(p => p.StockControlled == criteria.StockControlled.Value);
        }

        if (criteria.Active is not null)
        {
            query = query.Where(p => p.Active == criteria.Active.Value);
        }

        if (criteria.Kind is not null)
        {
            query = query.Where(p => EF.Property<string>(p, "Kind") == criteria.Kind.Value.ToString());
        }

        if (criteria.ComponentTypeCode is not null)
        {
            query = query.Where(p => EF.Property<string>(p, "ComponentTypeCode") == criteria.ComponentTypeCode);
        }

        if (criteria.IsPizzaComponent is not null)
        {
            query = criteria.IsPizzaComponent.Value
                ? query.Where(p => EF.Property<string>(p, "ComponentTypeCode") != null)
                : query.Where(p => EF.Property<string>(p, "ComponentTypeCode") == null);
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)criteria.Page - 1) * criteria.PageSize;
        if (skip >= totalCount)
        {
            return new ProductSearchPage([], totalCount);
        }

        var products = await query
            .OrderBy(p => p.Name)
            .ThenBy(p => p.Code)
            .Skip((int)skip)
            .Take(criteria.PageSize)
            .Select(p => new
            {
                p.Code,
                p.Name,
                p.Description,
                p.CategoryCode,
                Sellable = p.Sellable != null,
                p.StockControlled,
                ComponentTypeCode = EF.Property<string?>(p, "ComponentTypeCode"),
                p.Active,
                Kind = EF.Property<string>(p, "Kind"),
                Allergens = p.Allergens.Select(a => a.Value).ToList()
            })
            .ToListAsync(cancellationToken);

        var items = products.Select(p => new ProductSearchItem(
            p.Code.Value,
            p.Name,
            p.Description,
            p.CategoryCode.Value,
            p.Sellable,
            p.StockControlled,
            p.ComponentTypeCode,
            p.ComponentTypeCode is not null,
            Enum.TryParse<ProductKind>(p.Kind, out var kind) ? kind : ProductKind.Base,
            p.Active,
            p.Allergens.OrderBy(code => code).ToList())).ToList();

        return new ProductSearchPage(items, totalCount);
    }

    private static ProductCode? TryCreateCode(string value)
    {
        try { return ProductCode.Create(value); }
        catch (DomainException) { return null; }
    }
}
