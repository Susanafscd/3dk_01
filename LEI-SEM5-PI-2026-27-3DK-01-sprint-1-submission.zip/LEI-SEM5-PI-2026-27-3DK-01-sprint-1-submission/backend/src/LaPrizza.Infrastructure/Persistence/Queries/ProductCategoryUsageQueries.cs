using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.ComponentTypes;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>
/// Read-only reference checks used by category writes. Product references are
/// mapped in this bounded context. Component types are queried by business code
/// so the BCK07 aggregate never becomes a navigation property of ProductCategory.
/// </summary>
internal sealed class ProductCategoryUsageQueries(DomainDbContext context)
    : IProductCategoryUsageQueries
{
    public Task<bool> HasProductReferencesAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default) =>
        context.Products.AnyAsync(product => product.CategoryCode == code, cancellationToken);

    public async Task<bool> HasComponentTypeReferencesAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default)
    {
        return await context.PizzaComponentTypes.AsNoTracking()
            .AnyAsync(type => type.CategoryCode == code, cancellationToken);
    }
}
