using LaPrizza.Domain.Common;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>
/// EF Core adapter for the read-only stock search (BCK09, UC-40). It follows the
/// product search of BCK05 and reads PostgreSQL on every call (ADR-002).
/// </summary>
internal sealed class StockQueries(DomainDbContext context) : IStockQueries
{
    public async Task<StockSearchPage> SearchAsync(
        StockSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        var query = context.Products.AsNoTracking().Where(p => p.StockControlled);
        var term = criteria.Search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);
            query = code is null
                ? query.Where(p => p.Name.ToLower().Contains(lowered))
                : query.Where(p => p.Code == code || p.Name.ToLower().Contains(lowered));
        }

        if (criteria.CategoryCode is not null)
        {
            query = query.Where(p => p.CategoryCode == criteria.CategoryCode);
        }

        if (criteria.Active is not null)
        {
            query = query.Where(p => p.Active == criteria.Active.Value);
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)criteria.Page - 1) * criteria.PageSize;
        if (skip >= totalCount)
        {
            return new StockSearchPage([], totalCount);
        }

        var products = await query
            .OrderBy(p => p.Name)
            .ThenBy(p => p.Code)
            .Skip((int)skip)
            .Take(criteria.PageSize)
            .Select(p => new { p.Code, p.Name, p.CategoryCode, p.Active, p.StockBalance })
            .ToListAsync(cancellationToken);

        var items = products.Select(p => new StockSearchItem(
            p.Code.Value,
            p.Name,
            p.CategoryCode.Value,
            p.Active,
            p.StockBalance ?? 0)).ToList();

        return new StockSearchPage(items, totalCount);
    }

    private static ProductCode? TryCreateCode(string value)
    {
        try
        {
            return ProductCode.Create(value);
        }
        catch (DomainException)
        {
            return null;
        }
    }
}
