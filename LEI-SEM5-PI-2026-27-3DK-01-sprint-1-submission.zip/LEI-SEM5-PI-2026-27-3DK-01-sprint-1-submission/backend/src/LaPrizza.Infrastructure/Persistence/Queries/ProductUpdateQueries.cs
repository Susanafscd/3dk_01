using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>Loads product dependency facts without crossing aggregate boundaries.</summary>
internal sealed class ProductUpdateQueries(DomainDbContext db) : IProductUpdateQueries
{
    public async Task<ProductUpdateFacts> GetFactsAsync(
        ProductCode productCode,
        CancellationToken cancellationToken = default)
    {
        var referenced = await db.Set<ComposedProduct>()
            .AsNoTracking()
            .AnyAsync(product => product.Components.Any(component => component.Value == productCode.Value), cancellationToken);

        return new ProductUpdateFacts(referenced);
    }
}
