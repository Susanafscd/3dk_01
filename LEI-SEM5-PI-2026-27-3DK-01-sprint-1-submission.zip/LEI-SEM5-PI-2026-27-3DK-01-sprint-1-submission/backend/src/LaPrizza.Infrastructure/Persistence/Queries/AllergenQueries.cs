using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>EF Core adapter for read-only allergen catalogue queries.</summary>
internal sealed class AllergenQueries(DomainDbContext context) : IAllergenQueries
{
    public async Task<AllergenSearchPage> SearchAsync(
        AllergenSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        var query = context.Allergens.AsNoTracking();
        var term = criteria.Search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);
            query = code is null
                ? query.Where(a => a.Name.ToLower().Contains(lowered))
                : query.Where(a => a.Code == code || a.Name.ToLower().Contains(lowered));
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)criteria.Page - 1) * criteria.PageSize;
        if (skip >= totalCount)
        {
            return new AllergenSearchPage([], totalCount);
        }

        var allergens = await query
            .OrderBy(a => a.Name)
            .ThenBy(a => a.Code)
            .Skip((int)skip)
            .Take(criteria.PageSize)
            .Select(a => new
            {
                a.Code,
                a.Name,
                a.Description,
            })
            .ToListAsync(cancellationToken);

        IReadOnlyList<AllergenSearchItem> items = allergens
            .Select(a => new AllergenSearchItem(a.Code.Value, a.Name, a.Description))
            .ToList();

        return new AllergenSearchPage(items, totalCount);
    }

    private static AllergenCode? TryCreateCode(string value)
    {
        try { return AllergenCode.Create(value); }
        catch (DomainException) { return null; }
    }
}
