using LaPrizza.Application.ComponentTypes;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Queries;

/// <summary>EF Core adapter for read-only pizza component type catalogue queries.</summary>
internal sealed class PizzaComponentTypeQueries(DomainDbContext context) : IPizzaComponentTypeQueries
{
    public async Task<PizzaComponentTypeSearchPage> SearchAsync(
        string? search,
        string? categoryCode,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var query = context.PizzaComponentTypes.AsNoTracking();
        var term = search?.Trim();
        var category = string.IsNullOrWhiteSpace(categoryCode)
            ? null
            : ProductCategoryCode.Create(categoryCode.Trim());

        if (category is not null)
        {
            query = query.Where(type => type.CategoryCode == category);
        }

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();
            var code = TryCreateCode(term);

            query = code is null
                ? query.Where(t => t.Name.ToLower().Contains(lowered))
                : query.Where(t => t.Code == code || t.Name.ToLower().Contains(lowered));
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var skip = ((long)page - 1) * pageSize;
        if (skip >= totalCount && totalCount > 0)
        {
            return new PizzaComponentTypeSearchPage([], totalCount);
        }

        var types = await query
            .OrderBy(t => t.AssemblyOrder)
            .Skip((int)skip)
            .Take(pageSize)
            .Select(t => new
            {
                t.Code,
                t.CategoryCode,
                t.Name,
                t.Description,
                t.AssemblyOrder,
                t.MinQuantity,
                t.MaxQuantity,
            })
            .ToListAsync(cancellationToken);

        IReadOnlyList<PizzaComponentTypeResult> items = types
            .Select(t => new PizzaComponentTypeResult(t.Code.Value, t.CategoryCode.Value, t.Name, t.Description, t.AssemblyOrder, t.MinQuantity, t.MaxQuantity))
            .ToList();

        return new PizzaComponentTypeSearchPage(items, totalCount);
    }

    private static PizzaComponentTypeCode? TryCreateCode(string value)
    {
        try
        {
            return PizzaComponentTypeCode.Create(value);
        }
        catch (DomainException)
        {
            return null;
        }
    }
}
