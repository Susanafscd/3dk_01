using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace LaPrizza.Infrastructure.Persistence;

/// <summary>
/// Lets the EF Core tools build the domain store (<see cref="DomainDbContext"/>)
/// without the API host, so migrations can be added against this class library.
/// </summary>
public sealed class DomainDbContextFactory : IDesignTimeDbContextFactory<DomainDbContext>
{
    public DomainDbContext CreateDbContext(string[] args) => new(
        new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(DesignTimeConnectionString.Resolve())
            .Options);
}
