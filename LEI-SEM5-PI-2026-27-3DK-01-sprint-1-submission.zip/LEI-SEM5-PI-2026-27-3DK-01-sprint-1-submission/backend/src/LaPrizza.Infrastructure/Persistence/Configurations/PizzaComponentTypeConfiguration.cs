using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class PizzaComponentTypeConfiguration
    : IEntityTypeConfiguration<PizzaComponentType>
{
    public void Configure(EntityTypeBuilder<PizzaComponentType> builder)
    {
        builder.ToTable(
            "PizzaComponentTypes",
            table => table.HasCheckConstraint(
                "CK_PizzaComponentTypes_Code",
                "\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));

        // The Guid is an internal persistence key; the business code is the public identity.
        builder.HasKey(type => type.Id);

        builder.Property(type => type.Code)
            .HasConversion(
                code => code.Value,
                value => PizzaComponentTypeCode.Create(value))
            .HasMaxLength(PizzaComponentTypeCode.MaxLength)
            .IsRequired();

        builder.Property(type => type.CategoryCode)
            .HasConversion(
                code => code.Value,
                value => ProductCategoryCode.Create(value))
            .HasMaxLength(ProductCategoryCode.MaxLength)
            .IsRequired();

        builder.HasOne<ProductCategory>()
            .WithMany()
            .HasForeignKey(type => type.CategoryCode)
            .HasPrincipalKey(category => category.Code)
            .OnDelete(DeleteBehavior.Restrict)
            .HasConstraintName("FK_PizzaComponentTypes_ProductCategories_CategoryCode");

        builder.HasIndex(type => type.Code)
            .IsUnique();

        builder.Property(type => type.Name)
            .HasMaxLength(PizzaComponentType.MaxNameLength)
            .IsRequired();

        builder.Property(type => type.Description)
            .HasMaxLength(PizzaComponentType.MaxDescriptionLength);

        builder.Property(type => type.AssemblyOrder)
            .IsRequired();

        builder.Property(type => type.MinQuantity)
            .IsRequired();

        builder.Property(type => type.MaxQuantity);

        // Business uniqueness is enforced in the application layer with
        // case-insensitive lookups (see PizzaComponentTypeRepository).
        builder.HasIndex(type => type.Name)
            .IsUnique();

        builder.HasIndex(type => type.AssemblyOrder)
            .IsUnique();
    }
}
