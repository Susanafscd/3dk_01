using LaPrizza.Domain.ComponentTypes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

/// <summary>
/// Maps the pizza sizes (BCK06). The name is the canonical business identifier
/// returned to BCK08 callers as the size identifier and is unique; the slug
/// shape is enforced in the store as well.
/// </summary>
internal sealed class PizzaSizeConfiguration : IEntityTypeConfiguration<PizzaSize>
{
    public void Configure(EntityTypeBuilder<PizzaSize> builder)
    {
        builder.ToTable(
            "PizzaSizes",
            table => table.HasCheckConstraint(
                "CK_PizzaSizes_Name",
                "\"Name\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));

        builder.HasKey(size => size.Id);

        builder.Property(size => size.Name)
            .HasMaxLength(PizzaSize.MaxNameLength)
            .IsRequired();

        builder.HasIndex(size => size.Name)
            .IsUnique();

        builder.Property(size => size.Description)
            .HasMaxLength(PizzaSize.MaxDescriptionLength);
    }
}
