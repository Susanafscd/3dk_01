using LaPrizza.Domain.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.ToTable("Users");
        builder.HasKey(user => user.Id);

        builder.Property(user => user.Email)
            .HasConversion(email => email.Value, value => Email.Create(value))
            .HasMaxLength(Email.MaxLength)
            .IsRequired();

        builder.Property(user => user.DisplayName)
            .HasMaxLength(User.MaxDisplayNameLength)
            .IsRequired();

        builder.Property(user => user.Active).IsRequired();

        // Customer and Staff share the table; the discriminator tells them apart.
        builder.HasDiscriminator<string>("UserType")
            .HasValue<Customer>(nameof(Customer))
            .HasValue<Staff>(nameof(Staff));

        builder.Property<string>("UserType").HasMaxLength(20).IsRequired();
    }
}
