using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

/// <summary>
/// Maps a predefined pizza (BCK10): a <c>Composed</c> row of Products, with its
/// default configuration and its available sizes in child tables. Each child row
/// references its component by product code and its size by name; the
/// restrictive foreign keys behind those references are created by the
/// migration against the existing unique indexes, so the model gains no
/// alternate key that would rename them.
/// </summary>
internal sealed class ComposedProductConfiguration : IEntityTypeConfiguration<ComposedProduct>
{
    public void Configure(EntityTypeBuilder<ComposedProduct> builder)
    {
        builder.OwnsMany(p => p.Components, component =>
        {
            component.ToTable("ProductComponents");
            component.WithOwner().HasForeignKey("ProductId");

            component.Property(c => c.Value)
                .HasColumnName("ComponentCode")
                .HasMaxLength(ProductCode.MaxLength)
                .IsRequired();
            component.HasKey("ProductId", "Value");
        });

        builder.Navigation(p => p.Components)
            .UsePropertyAccessMode(PropertyAccessMode.Field);

        builder.OwnsMany(p => p.AvailableSizes, size =>
        {
            size.ToTable("ProductAvailableSizes");
            size.WithOwner().HasForeignKey("ProductId");

            size.Property(s => s.SizeName)
                .HasMaxLength(PizzaSize.MaxNameLength)
                .IsRequired();
            size.HasKey("ProductId", nameof(AvailableSize.SizeName));
        });

        builder.Navigation(p => p.AvailableSizes)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}
