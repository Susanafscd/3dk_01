using System.Linq.Expressions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.SizeConfigurations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

/// <summary>
/// Maps the size configuration a base product carries (BCK08). The value object
/// is whole per product, so it is stored as a single nullable jsonb column inside
/// the product row rather than as a child table; a product without a
/// configuration stores null. The property is mutated through
/// <c>SetSizeConfiguration</c>, so the value comparer is what lets EF's change
/// detection notice the whole-object replacement on save.
/// </summary>
internal sealed class BaseProductConfiguration : IEntityTypeConfiguration<BaseProduct>
{
    public void Configure(EntityTypeBuilder<BaseProduct> builder)
    {
        builder.Property(b => b.SizeConfiguration)
            .HasColumnName("SizeConfiguration")
            .HasColumnType("jsonb")
            .HasConversion(
                configuration => SizeConfigurationSerializer.ToJson(configuration),
                json => SizeConfigurationSerializer.FromJson(json),
                new ValueComparer<SizeConfiguration>(
                    Comparer,
                    Hasher,
                    Snapshot));
    }

    /// <summary>Two configurations are equal when they configure exactly the same sizes with equal values.</summary>
    private static readonly Expression<Func<
        SizeConfiguration?, SizeConfiguration?, bool>> Comparer =
        (left, right) =>
            left == null
                ? right == null
                : right != null
                  && left.SizeMappings.Count == right.SizeMappings.Count
                  && left.SizeMappings.All(entry =>
                      right.SizeMappings.ContainsKey(entry.Key)
                      && right.SizeMappings[entry.Key].Price == entry.Value.Price
                      && right.SizeMappings[entry.Key].StockConsumption == entry.Value.StockConsumption
                      && right.SizeMappings[entry.Key].Active == entry.Value.Active);

    private static readonly Expression<Func<SizeConfiguration, int>> Hasher =
        configuration => configuration.SizeMappings
            .Select(entry => HashCode.Combine(
                entry.Key,
                entry.Value.Price,
                entry.Value.StockConsumption,
                entry.Value.Active))
            .Aggregate(17, (hash, entryHash) => HashCode.Combine(hash, entryHash));

    /// <summary>A value clone, so later change detection compares against frozen state.</summary>
    private static readonly Expression<Func<SizeConfiguration, SizeConfiguration>> Snapshot =
        configuration => SizeConfiguration.FromSizeMappings(
            configuration.SizeMappings.ToDictionary(
                entry => entry.Key,
                entry => new SizeValues(
                    entry.Value.Price,
                    entry.Value.StockConsumption,
                    entry.Value.Active)));
}
