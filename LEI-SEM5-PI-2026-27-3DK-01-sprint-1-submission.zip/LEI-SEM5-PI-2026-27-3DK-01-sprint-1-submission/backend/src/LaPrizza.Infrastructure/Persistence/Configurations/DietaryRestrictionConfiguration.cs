using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class DietaryRestrictionConfiguration : IEntityTypeConfiguration<DietaryRestriction>
{
    public void Configure(EntityTypeBuilder<DietaryRestriction> builder)
    {
        builder.ToTable("DietaryRestrictions");
        builder.HasKey(restriction => restriction.Id);
        builder.Property(restriction => restriction.Name)
            .HasMaxLength(DietaryRestriction.MaxNameLength)
            .IsRequired();
        builder.Property(restriction => restriction.Description)
            .HasMaxLength(DietaryRestriction.MaxDescriptionLength);

        builder.HasMany(restriction => restriction.Allergens)
            .WithMany()
            .UsingEntity<Dictionary<string, object>>(
                "DietaryRestrictionAllergens",
                allergen => allergen
                    .HasOne<Allergen>()
                    .WithMany()
                    .HasForeignKey("AllergensId")
                    .OnDelete(DeleteBehavior.Restrict),
                restriction => restriction
                    .HasOne<DietaryRestriction>()
                    .WithMany()
                    .HasForeignKey("DietaryRestrictionId")
                    .OnDelete(DeleteBehavior.Cascade),
                join => join.HasKey("AllergensId", "DietaryRestrictionId"));

        builder.Navigation(restriction => restriction.Allergens)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}
