using LaPrizza.Domain.ProductCategories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class ProductCategoryConfiguration
    : IEntityTypeConfiguration<ProductCategory>
{
    public void Configure(EntityTypeBuilder<ProductCategory> builder)
    {
        builder.ToTable(
            "ProductCategories",
            table => table.HasCheckConstraint(
                "CK_ProductCategories_Code",
                "\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));

        builder.HasKey(category => category.Id);

        builder.Property(category => category.Code)
            .HasConversion(
                code => code.Value,
                value => ProductCategoryCode.Create(value))
            .HasMaxLength(100)
            .IsRequired();

        builder.HasIndex(category => category.Code)
            .IsUnique();

        builder.HasAlternateKey(category => category.Code)
            .HasName("AK_ProductCategories_Code");

        builder.Property(category => category.Name)
            .HasMaxLength(ProductCategory.NameMaxLength)
            .IsRequired();

        builder.Property(category => category.Description)
            .HasMaxLength(ProductCategory.DescriptionMaxLength);

        builder.Property(category => category.AllowsComponentTypes)
            .IsRequired();
    }
}
