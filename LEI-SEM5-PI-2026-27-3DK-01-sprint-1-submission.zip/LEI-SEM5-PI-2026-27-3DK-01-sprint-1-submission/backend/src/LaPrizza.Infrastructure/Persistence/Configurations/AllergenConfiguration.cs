using LaPrizza.Domain.Allergens;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class AllergenConfiguration : IEntityTypeConfiguration<Allergen>
{
    public void Configure(EntityTypeBuilder<Allergen> builder)
    {
        builder.ToTable(
            "Allergens",
            table => table.HasCheckConstraint(
                "CK_Allergens_Code",
                "\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));

        builder.HasKey(allergen => allergen.Id);

        builder.Property(allergen => allergen.Code)
            .HasConversion(
                code => code.Value,
                value => AllergenCode.Create(value))
            .HasMaxLength(AllergenCode.MaxLength)
            .IsRequired();

        builder.HasIndex(allergen => allergen.Code)
            .IsUnique();

        builder.Property(allergen => allergen.Name)
            .HasMaxLength(Allergen.NameMaxLength)
            .IsRequired();

        builder.Property(allergen => allergen.Description)
            .HasMaxLength(Allergen.DescriptionMaxLength);
    }
}
