using LaPrizza.Domain.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.Property(customer => customer.Name)
            .HasMaxLength(Customer.MaxNameLength)
            .IsRequired();

        builder.Property(customer => customer.VATNumber)
            .HasConversion(vatNumber => vatNumber == null ? null : vatNumber.Value, value => VATNumber.Create(value))
            .HasMaxLength(VATNumber.MaxLength)
            .IsRequired(false);

        builder.Property(customer => customer.PhoneNumber)
            .HasConversion(phoneNumber => phoneNumber.Value, value => PhoneNumber.Create(value))
            .HasMaxLength(PhoneNumber.MaxLength)
            .IsRequired();

        builder.HasMany(customer => customer.DietaryRestrictions)
            .WithOne()
            .HasForeignKey("CustomerId")
            .OnDelete(DeleteBehavior.Cascade);

        builder.Navigation(customer => customer.DietaryRestrictions)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}
