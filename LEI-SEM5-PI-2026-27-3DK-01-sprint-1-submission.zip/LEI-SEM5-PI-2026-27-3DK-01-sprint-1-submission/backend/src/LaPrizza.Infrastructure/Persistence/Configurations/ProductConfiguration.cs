using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

internal sealed class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        // Stock control is stored as columns of Products, so the database itself
        // rules out the contradictory states a separate stock table would prevent
        // (ADR-008): a balance exists only for stock-controlled products and is
        // never negative (BR-08, BCK09).
        builder.ToTable("Products", table =>
        {
            table.HasCheckConstraint(
                "CK_Products_StockBalance_NonNegative",
                "\"StockBalance\" >= 0");
            table.HasCheckConstraint(
                "CK_Products_StockBalance_StockControlled",
                "(\"StockControlled\" AND \"StockBalance\" IS NOT NULL) OR (NOT \"StockControlled\" AND \"StockBalance\" IS NULL)");
        });
        builder.HasKey(p => p.Id);

        builder.HasDiscriminator<string>("Kind")
            .HasValue<BaseProduct>("Base")
            .HasValue<ComposedProduct>("Composed");

        builder.Property(p => p.Code)
            .HasConversion(c => c.Value, v => ProductCode.Create(v))
            .HasMaxLength(ProductCode.MaxLength)
            .IsRequired();
        builder.HasIndex(p => p.Code).IsUnique();

        builder.Property(p => p.Name).HasMaxLength(Product.NameMaxLength).IsRequired();
        builder.Property(p => p.Description).HasMaxLength(Product.DescriptionMaxLength).IsRequired();

        builder.Property(p => p.CategoryCode)
            .HasConversion(c => c.Value, v => ProductCategoryCode.Create(v))
            .HasMaxLength(100)
            .IsRequired();

        builder.HasOne<ProductCategory>()
            .WithMany()
            .HasForeignKey(product => product.CategoryCode)
            .HasPrincipalKey(category => category.Code)
            .OnDelete(DeleteBehavior.Restrict)
            .HasConstraintName("FK_Products_ProductCategories_CategoryCode");

        builder.Property(p => p.StockControlled).IsRequired();
        builder.Property(p => p.StockBalance);
        builder.Property(p => p.Active).IsRequired();

        // The product stores only the component type business code. The type is a
        // separate aggregate; no navigation or technical database id crosses the
        // aggregate boundary.
        builder.Property(p => p.ComponentTypeCode)
            .HasMaxLength(PizzaComponentTypeCode.MaxLength);

        builder.OwnsOne(p => p.Sellable, sellable =>
        {
            // Sellable is optional. It therefore has its own table rather than
            // sharing Products with its nested Money value object.
            sellable.ToTable("ProductSellables");

            sellable.OwnsOne(s => s.Price, price =>
            {
                price.Property(m => m.Amount)
                    .HasColumnName("PriceAmount")
                    .HasPrecision(18, 2);
            });
        });

        builder.OwnsMany(p => p.Allergens, allergen =>
        {
            allergen.ToTable("ProductAllergens");
            allergen.WithOwner().HasForeignKey("ProductId");

            allergen.Property(a => a.Value)
                .HasColumnName("AllergenCode")
                .HasMaxLength(100)
                .IsRequired();
            allergen.HasKey("ProductId", "Value");

        });

        builder.Navigation(p => p.Allergens)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}
