using System.Text.Json;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Infrastructure.Persistence.Configurations;

/// <summary>
/// Serialises the <c>SizeConfiguration</c> value object to and from the single
/// <c>jsonb</c> column that stores it inside the product row. Keys are written in
/// ordinal key order so equal configurations always produce equal JSON.
/// </summary>
internal static class SizeConfigurationSerializer
{
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web);

    public static string ToJson(SizeConfiguration? configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);

        var document = new SizeConfigurationPayload(
            configuration.SizeMappings
                .OrderBy(entry => entry.Key, StringComparer.Ordinal)
                .Select(entry => new SizeValuesPayload(
                    entry.Key,
                    entry.Value.Price,
                    entry.Value.StockConsumption,
                    entry.Value.Active)));

        return JsonSerializer.Serialize(document, Options);
    }

    public static SizeConfiguration FromJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return SizeConfiguration.Empty;
        }

        var payload = JsonSerializer.Deserialize<SizeConfigurationPayload>(json, Options)
            ?? throw new FormatException("The stored size configuration is null.");

        return SizeConfiguration.FromSizeMappings(
            payload.SizeConfigurations.ToDictionary(
                entry => entry.SizeId,
                entry => new SizeValues(entry.Price, entry.StockConsumption, entry.Active)));
    }

    internal sealed record SizeConfigurationPayload(
        IEnumerable<SizeValuesPayload> SizeConfigurations);

    internal sealed record SizeValuesPayload(
        string SizeId,
        decimal Price,
        int StockConsumption,
        bool Active);
}
