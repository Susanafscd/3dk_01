﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class GuardAllergenDeletionFromDietaryRestrictions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
                table: "DietaryRestrictionAllergens");

            migrationBuilder.AddForeignKey(
                name: "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
                table: "DietaryRestrictionAllergens",
                column: "AllergensId",
                principalTable: "Allergens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
                table: "DietaryRestrictionAllergens");

            migrationBuilder.AddForeignKey(
                name: "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
                table: "DietaryRestrictionAllergens",
                column: "AllergensId",
                principalTable: "Allergens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
