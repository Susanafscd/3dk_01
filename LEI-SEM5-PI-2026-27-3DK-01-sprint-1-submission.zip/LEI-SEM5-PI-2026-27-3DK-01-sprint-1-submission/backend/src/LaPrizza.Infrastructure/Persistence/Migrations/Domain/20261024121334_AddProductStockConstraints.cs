using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddProductStockConstraints : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddCheckConstraint(
                name: "CK_Products_StockBalance_NonNegative",
                table: "Products",
                sql: "\"StockBalance\" >= 0");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Products_StockBalance_StockControlled",
                table: "Products",
                sql: "(\"StockControlled\" AND \"StockBalance\" IS NOT NULL) OR (NOT \"StockControlled\" AND \"StockBalance\" IS NULL)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Products_StockBalance_NonNegative",
                table: "Products");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Products_StockBalance_StockControlled",
                table: "Products");
        }
    }
}
