﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddPizzaComponentTypeCode : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Added as nullable first so that rows created before this migration
            // can be given a code before the column becomes required.
            migrationBuilder.AddColumn<string>(
                name: "Code",
                table: "PizzaComponentTypes",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            // Backfill: derive a lowercase, hyphen-separated slug from the name
            // (e.g. "Base Dough" -> "base-dough"). Rows whose slug would collide
            // get a numeric suffix so the unique index can be created safely.
            migrationBuilder.Sql("""
                WITH slugs AS (
                    SELECT "Id",
                           COALESCE(
                               NULLIF(trim(both '-' from regexp_replace(lower("Name"), '[^a-z0-9]+', '-', 'g')), ''),
                               'type') AS slug
                    FROM "PizzaComponentTypes"
                ),
                ranked AS (
                    SELECT "Id", slug, row_number() OVER (PARTITION BY slug ORDER BY "Id") AS rn
                    FROM slugs
                )
                UPDATE "PizzaComponentTypes" AS t
                SET "Code" = CASE
                    WHEN r.rn = 1 THEN rtrim(left(r.slug, 100), '-')
                    ELSE rtrim(left(r.slug, 90), '-') || '-' || r.rn::text
                END
                FROM ranked AS r
                WHERE r."Id" = t."Id";
                """);

            migrationBuilder.AlterColumn<string>(
                name: "Code",
                table: "PizzaComponentTypes",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_PizzaComponentTypes_Code",
                table: "PizzaComponentTypes",
                column: "Code",
                unique: true);

            migrationBuilder.AddCheckConstraint(
                name: "CK_PizzaComponentTypes_Code",
                table: "PizzaComponentTypes",
                sql: "\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_PizzaComponentTypes_Code",
                table: "PizzaComponentTypes");

            migrationBuilder.DropIndex(
                name: "IX_PizzaComponentTypes_Code",
                table: "PizzaComponentTypes");

            migrationBuilder.DropColumn(
                name: "Code",
                table: "PizzaComponentTypes");
        }
    }
}
