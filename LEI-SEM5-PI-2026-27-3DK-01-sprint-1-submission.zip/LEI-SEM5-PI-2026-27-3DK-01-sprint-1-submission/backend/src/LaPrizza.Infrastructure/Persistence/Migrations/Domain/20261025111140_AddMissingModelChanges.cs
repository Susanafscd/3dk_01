﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddMissingModelChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "RoleIds",
                table: "Users",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<Guid>(
                name: "CustomerId",
                table: "Allergens",
                type: "uuid",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Allergens_CustomerId",
                table: "Allergens",
                column: "CustomerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Allergens_Users_CustomerId",
                table: "Allergens",
                column: "CustomerId",
                principalTable: "Users",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Allergens_Users_CustomerId",
                table: "Allergens");

            migrationBuilder.DropIndex(
                name: "IX_Allergens_CustomerId",
                table: "Allergens");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "Allergens");

            migrationBuilder.AlterColumn<string>(
                name: "RoleIds",
                table: "Users",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);
        }
    }
}
