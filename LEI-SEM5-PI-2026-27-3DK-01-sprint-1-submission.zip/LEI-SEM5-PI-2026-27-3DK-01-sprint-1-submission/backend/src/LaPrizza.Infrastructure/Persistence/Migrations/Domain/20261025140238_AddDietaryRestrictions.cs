﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddDietaryRestrictions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Allergens_Users_CustomerId",
                table: "Allergens");

            migrationBuilder.DropIndex(
                name: "IX_Allergens_CustomerId",
                table: "Allergens");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "Allergens");

            migrationBuilder.CreateTable(
                name: "DietaryRestrictions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    CustomerId = table.Column<Guid>(type: "uuid", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DietaryRestrictions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DietaryRestrictions_Users_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DietaryRestrictionAllergens",
                columns: table => new
                {
                    AllergensId = table.Column<Guid>(type: "uuid", nullable: false),
                    DietaryRestrictionId = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DietaryRestrictionAllergens", x => new { x.AllergensId, x.DietaryRestrictionId });
                    table.ForeignKey(
                        name: "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
                        column: x => x.AllergensId,
                        principalTable: "Allergens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DietaryRestrictionAllergens_DietaryRestrictions_DietaryRest~",
                        column: x => x.DietaryRestrictionId,
                        principalTable: "DietaryRestrictions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DietaryRestrictionAllergens_DietaryRestrictionId",
                table: "DietaryRestrictionAllergens",
                column: "DietaryRestrictionId");

            migrationBuilder.CreateIndex(
                name: "IX_DietaryRestrictions_CustomerId",
                table: "DietaryRestrictions",
                column: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DietaryRestrictionAllergens");

            migrationBuilder.DropTable(
                name: "DietaryRestrictions");

            migrationBuilder.AddColumn<Guid>(
                name: "CustomerId",
                table: "Allergens",
                type: "uuid",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Allergens_CustomerId",
                table: "Allergens",
                column: "CustomerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Allergens_Users_CustomerId",
                table: "Allergens",
                column: "CustomerId",
                principalTable: "Users",
                principalColumn: "Id");
        }
    }
}
