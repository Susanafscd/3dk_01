﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddPizzaComponentTypes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PizzaComponentTypes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                    AssemblyOrder = table.Column<int>(type: "integer", nullable: false),
                    MinQuantity = table.Column<int>(type: "integer", nullable: false),
                    MaxQuantity = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PizzaComponentTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PizzaComponentTypes_AssemblyOrder",
                table: "PizzaComponentTypes",
                column: "AssemblyOrder",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PizzaComponentTypes_Name",
                table: "PizzaComponentTypes",
                column: "Name",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PizzaComponentTypes");
        }
    }
}
