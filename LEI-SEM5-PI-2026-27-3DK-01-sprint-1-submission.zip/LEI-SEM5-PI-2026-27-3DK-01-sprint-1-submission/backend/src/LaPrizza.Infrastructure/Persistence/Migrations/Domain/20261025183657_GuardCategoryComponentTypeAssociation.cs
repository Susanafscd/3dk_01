﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class GuardCategoryComponentTypeAssociation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("""
                CREATE OR REPLACE FUNCTION "enforce_product_category_component_type_flag"()
                RETURNS trigger
                LANGUAGE plpgsql
                AS $function$
                BEGIN
                    IF TG_TABLE_NAME = 'ProductCategories' THEN
                        IF NOT NEW."AllowsComponentTypes"
                           AND EXISTS (
                               SELECT 1
                               FROM "PizzaComponentTypes"
                               WHERE "CategoryCode" = NEW."Code") THEN
                            RAISE EXCEPTION
                                'Product category % is referenced by component types.', NEW."Code"
                                USING ERRCODE = '23514',
                                      CONSTRAINT = 'CK_ProductCategories_AllowsComponentTypes';
                        END IF;
                    ELSE
                        IF NOT EXISTS (
                            SELECT 1
                            FROM "ProductCategories"
                            WHERE "Code" = NEW."CategoryCode"
                              AND "AllowsComponentTypes") THEN
                            RAISE EXCEPTION
                                'Product category % does not allow component types.', NEW."CategoryCode"
                                USING ERRCODE = '23514',
                                      CONSTRAINT = 'CK_PizzaComponentTypes_CategoryAllowsTypes';
                        END IF;
                    END IF;
                    RETURN NEW;
                END;
                $function$;
                """);

            migrationBuilder.Sql("""
                CREATE TRIGGER "TR_ProductCategories_ComponentTypeFlag"
                BEFORE UPDATE OF "AllowsComponentTypes" ON "ProductCategories"
                FOR EACH ROW
                EXECUTE FUNCTION "enforce_product_category_component_type_flag"();
                """);

            migrationBuilder.Sql("""
                CREATE TRIGGER "TR_PizzaComponentTypes_CategoryAllowsTypes"
                BEFORE INSERT OR UPDATE OF "CategoryCode" ON "PizzaComponentTypes"
                FOR EACH ROW
                EXECUTE FUNCTION "enforce_product_category_component_type_flag"();
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TRIGGER IF EXISTS \"TR_PizzaComponentTypes_CategoryAllowsTypes\" ON \"PizzaComponentTypes\";");
            migrationBuilder.Sql("DROP TRIGGER IF EXISTS \"TR_ProductCategories_ComponentTypeFlag\" ON \"ProductCategories\";");
            migrationBuilder.Sql("DROP FUNCTION IF EXISTS \"enforce_product_category_component_type_flag\"();");
        }
    }
}
