using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain;

/// <summary>Protects the Product.ComponentTypeCode business-code reference.</summary>
[DbContext(typeof(DomainDbContext))]
[Migration("20261025211500_AddProductComponentTypeReference")]
public partial class AddProductComponentTypeReference : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateIndex(
            name: "IX_Products_ComponentTypeCode",
            table: "Products",
            column: "ComponentTypeCode");

        migrationBuilder.AddForeignKey(
            name: "FK_Products_PizzaComponentTypes_ComponentTypeCode",
            table: "Products",
            column: "ComponentTypeCode",
            principalTable: "PizzaComponentTypes",
            principalColumn: "Code",
            onDelete: ReferentialAction.NoAction);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "FK_Products_PizzaComponentTypes_ComponentTypeCode",
            table: "Products");

        migrationBuilder.DropIndex(
            name: "IX_Products_ComponentTypeCode",
            table: "Products");
    }
}
