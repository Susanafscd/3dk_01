﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class NormalizeLegacyCustomerPhoneNumbers : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "UPDATE \"Users\" SET \"PhoneNumber\" = '+351 000 000 000' " +
                "WHERE \"PhoneNumber\" IS NULL " +
                "OR \"PhoneNumber\" !~ '^\\+?[1-9][0-9 ()-]*[0-9]$' " +
                "OR length(regexp_replace(\"PhoneNumber\", '[^0-9]', '', 'g')) NOT BETWEEN 7 AND 15;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
