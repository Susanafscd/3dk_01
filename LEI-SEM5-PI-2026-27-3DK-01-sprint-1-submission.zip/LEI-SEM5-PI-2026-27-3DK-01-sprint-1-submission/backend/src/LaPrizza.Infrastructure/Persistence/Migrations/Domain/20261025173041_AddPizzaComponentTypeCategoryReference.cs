﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddPizzaComponentTypeCategoryReference : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CategoryCode",
                table: "PizzaComponentTypes",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "pizza-component");

            // AK_ProductCategories_Code is created by GuardProductCategoryDeletion,
            // which runs first and also needs it, so it is not created again here.
            migrationBuilder.CreateIndex(
                name: "IX_PizzaComponentTypes_CategoryCode",
                table: "PizzaComponentTypes",
                column: "CategoryCode");

            migrationBuilder.AddForeignKey(
                name: "FK_PizzaComponentTypes_ProductCategories_CategoryCode",
                table: "PizzaComponentTypes",
                column: "CategoryCode",
                principalTable: "ProductCategories",
                principalColumn: "Code",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PizzaComponentTypes_ProductCategories_CategoryCode",
                table: "PizzaComponentTypes");

            // AK_ProductCategories_Code stays: it belongs to GuardProductCategoryDeletion.
            migrationBuilder.DropIndex(
                name: "IX_PizzaComponentTypes_CategoryCode",
                table: "PizzaComponentTypes");

            migrationBuilder.DropColumn(
                name: "CategoryCode",
                table: "PizzaComponentTypes");
        }
    }
}
