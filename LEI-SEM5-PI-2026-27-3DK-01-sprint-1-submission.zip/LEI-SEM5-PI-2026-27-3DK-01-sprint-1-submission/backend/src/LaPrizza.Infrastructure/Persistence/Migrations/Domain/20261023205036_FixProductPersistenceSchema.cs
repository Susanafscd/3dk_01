using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain;

/// <summary>
/// Corrects the table layout introduced by AddProductsAndAllergensTable without
/// discarding registered products, prices, or allergen associations.
/// </summary>
public partial class FixProductPersistenceSchema : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey("FK_Products_ProductAllergens_ProductId", "Products");
        migrationBuilder.DropForeignKey("FK_AllergenCode_ProductAllergens_ProductId", "AllergenCode");
        migrationBuilder.DropPrimaryKey("PK_Products", "Products");
        migrationBuilder.DropPrimaryKey("PK_ProductAllergens", "ProductAllergens");
        migrationBuilder.DropPrimaryKey("PK_AllergenCode", "AllergenCode");

        // The original migration created the three tables with their roles
        // rotated. Rename them so existing rows keep their meaning.
        migrationBuilder.RenameTable(name: "Products", newName: "ProductSellables");
        migrationBuilder.RenameTable(name: "ProductAllergens", newName: "Products");
        migrationBuilder.RenameTable(name: "AllergenCode", newName: "ProductAllergens");
        migrationBuilder.RenameIndex(
            name: "IX_ProductAllergens_Code",
            newName: "IX_Products_Code");

        migrationBuilder.AddPrimaryKey("PK_Products", "Products", "Id");
        migrationBuilder.AddPrimaryKey(
            "PK_ProductAllergens",
            "ProductAllergens",
            new[] { "ProductId", "AllergenCode" });
        migrationBuilder.AddPrimaryKey("PK_ProductSellables", "ProductSellables", "ProductId");

        migrationBuilder.AddForeignKey(
            name: "FK_ProductAllergens_Products_ProductId",
            table: "ProductAllergens",
            column: "ProductId",
            principalTable: "Products",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
        migrationBuilder.AddForeignKey(
            name: "FK_ProductSellables_Products_ProductId",
            table: "ProductSellables",
            column: "ProductId",
            principalTable: "Products",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey("FK_ProductAllergens_Products_ProductId", "ProductAllergens");
        migrationBuilder.DropForeignKey("FK_ProductSellables_Products_ProductId", "ProductSellables");
        migrationBuilder.DropPrimaryKey("PK_Products", "Products");
        migrationBuilder.DropPrimaryKey("PK_ProductAllergens", "ProductAllergens");
        migrationBuilder.DropPrimaryKey("PK_ProductSellables", "ProductSellables");

        migrationBuilder.RenameIndex(
            name: "IX_Products_Code",
            newName: "IX_ProductAllergens_Code");
        migrationBuilder.RenameTable(name: "ProductAllergens", newName: "AllergenCode");
        migrationBuilder.RenameTable(name: "Products", newName: "ProductAllergens");
        migrationBuilder.RenameTable(name: "ProductSellables", newName: "Products");

        migrationBuilder.AddPrimaryKey("PK_ProductAllergens", "ProductAllergens", "Id");
        migrationBuilder.AddPrimaryKey(
            "PK_AllergenCode",
            "AllergenCode",
            new[] { "ProductId", "AllergenCode" });
        migrationBuilder.AddPrimaryKey("PK_Products", "Products", "ProductId");

        migrationBuilder.AddForeignKey(
            name: "FK_AllergenCode_ProductAllergens_ProductId",
            table: "AllergenCode",
            column: "ProductId",
            principalTable: "ProductAllergens",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
        migrationBuilder.AddForeignKey(
            name: "FK_Products_ProductAllergens_ProductId",
            table: "Products",
            column: "ProductId",
            principalTable: "ProductAllergens",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
    }
}
