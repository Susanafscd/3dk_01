﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class AddComposedProducts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ProductAvailableSizes",
                columns: table => new
                {
                    SizeName = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    ProductId = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductAvailableSizes", x => new { x.ProductId, x.SizeName });
                    table.ForeignKey(
                        name: "FK_ProductAvailableSizes_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductComponents",
                columns: table => new
                {
                    ComponentCode = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    ProductId = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductComponents", x => new { x.ProductId, x.ComponentCode });
                    table.ForeignKey(
                        name: "FK_ProductComponents_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            // Restrictive references by business identifier (BCK10): a pizza never
            // points at a missing component or size, and neither can be deleted
            // while a pizza uses it. They target the existing unique indexes
            // IX_Products_Code and IX_PizzaSizes_Name, so they are declared here
            // rather than as alternate keys in the model. NO ACTION (not RESTRICT)
            // reports a blocked deletion as a foreign-key violation (23503), which
            // is what the existing repositories translate into "in use".
            migrationBuilder.CreateIndex(
                name: "IX_ProductComponents_ComponentCode",
                table: "ProductComponents",
                column: "ComponentCode");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductComponents_Products_ComponentCode",
                table: "ProductComponents",
                column: "ComponentCode",
                principalTable: "Products",
                principalColumn: "Code",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.CreateIndex(
                name: "IX_ProductAvailableSizes_SizeName",
                table: "ProductAvailableSizes",
                column: "SizeName");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAvailableSizes_PizzaSizes_SizeName",
                table: "ProductAvailableSizes",
                column: "SizeName",
                principalTable: "PizzaSizes",
                principalColumn: "Name",
                onDelete: ReferentialAction.NoAction);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProductAvailableSizes");

            migrationBuilder.DropTable(
                name: "ProductComponents");
        }
    }
}
