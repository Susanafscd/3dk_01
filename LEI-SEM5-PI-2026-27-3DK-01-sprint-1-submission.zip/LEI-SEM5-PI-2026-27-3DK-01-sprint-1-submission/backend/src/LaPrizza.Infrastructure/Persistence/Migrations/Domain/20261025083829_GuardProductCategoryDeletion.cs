﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class GuardProductCategoryDeletion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddUniqueConstraint(
                name: "AK_ProductCategories_Code",
                table: "ProductCategories",
                column: "Code");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryCode",
                table: "Products",
                column: "CategoryCode");

            migrationBuilder.AddForeignKey(
                name: "FK_Products_ProductCategories_CategoryCode",
                table: "Products",
                column: "CategoryCode",
                principalTable: "ProductCategories",
                principalColumn: "Code",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_ProductCategories_CategoryCode",
                table: "Products");

            migrationBuilder.DropIndex(
                name: "IX_Products_CategoryCode",
                table: "Products");

            migrationBuilder.DropUniqueConstraint(
                name: "AK_ProductCategories_Code",
                table: "ProductCategories");
        }
    }
}
