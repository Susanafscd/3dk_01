﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaPrizza.Infrastructure.Persistence.Migrations.Domain
{
    /// <inheritdoc />
    public partial class GuardAllergenDeletion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_ProductAllergens_AllergenCode",
                table: "ProductAllergens",
                column: "AllergenCode");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAllergens_Allergens_AllergenCode",
                table: "ProductAllergens",
                column: "AllergenCode",
                principalTable: "Allergens",
                principalColumn: "Code",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProductAllergens_Allergens_AllergenCode",
                table: "ProductAllergens");

            migrationBuilder.DropIndex(
                name: "IX_ProductAllergens_AllergenCode",
                table: "ProductAllergens");
        }
    }
}
