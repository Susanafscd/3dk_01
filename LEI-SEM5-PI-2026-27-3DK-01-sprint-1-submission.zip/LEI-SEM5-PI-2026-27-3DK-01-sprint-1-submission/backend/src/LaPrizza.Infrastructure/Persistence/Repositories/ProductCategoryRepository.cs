using LaPrizza.Domain.ProductCategories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

internal sealed class ProductCategoryRepository(DomainDbContext context)
    : IProductCategoryRepository
{
    public Task<ProductCategory?> GetByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default)
    {
        return context.ProductCategories.FirstOrDefaultAsync(
            category => category.Code == code,
            cancellationToken);
    }

    public async Task AddAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        await context.ProductCategories.AddAsync(category, cancellationToken);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsDuplicateCode(exception))
        {
            // Remove the rejected entity so a bootstrap can continue with its next seed.
            context.Entry(category).State = EntityState.Detached;
            throw new DuplicateProductCategoryCodeException(category.Code);
        }
    }

    public async Task RemoveAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        // Keep the repository safe when the aggregate and a referencing
        // product are tracked by the same DbContext. EF can otherwise try to
        // null the required FK during relationship fix-up before PostgreSQL
        // gets the chance to enforce the restrictive relationship.
        if (await context.Products.AnyAsync(
                product => product.CategoryCode == category.Code,
                cancellationToken))
        {
            throw new ProductCategoryInUseException(category.Code);
        }

        // Check component-type references in the same context before EF
        // relationship fix-up can null their required business-code FK.
        if (await context.PizzaComponentTypes.AnyAsync(
                type => type.CategoryCode == category.Code,
                cancellationToken))
        {
            throw new ProductCategoryInUseException(category.Code);
        }

        context.ProductCategories.Remove(category);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsProtectedReference(exception))
        {
            context.Entry(category).State = EntityState.Unchanged;
            throw new ProductCategoryInUseException(category.Code);
        }
    }

    public async Task UpdateAndSaveAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        // GetByCodeAsync returns a tracked aggregate. Update also supports a
        // caller that loaded the category in another context.
        context.ProductCategories.Update(category);
        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsComponentTypeReferenceViolation(exception))
        {
            // The database trigger closes the check-then-update race with a
            // concurrent component-type association. Expose the same domain
            // conflict as the application-side usage query.
            throw new CategoryComponentTypeReferenceException(category.Code);
        }
    }

    public async Task<ProductCategoryLookupResult?> GetLookupByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default)
    {
        var category = await context.ProductCategories
            .AsNoTracking()
            .Where(category => category.Code == code)
            .Select(category => new
            {
                category.Code,
                category.Name,
                category.Description,
                category.AllowsComponentTypes,
            })
            .SingleOrDefaultAsync(cancellationToken);

        return category is null
            ? null
            : new ProductCategoryLookupResult(
                category.Code.Value,
                category.Name,
                category.Description,
                category.AllowsComponentTypes);
    }

    private static bool IsDuplicateCode(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.UniqueViolation,
            ConstraintName: "IX_ProductCategories_Code" or "AK_ProductCategories_Code",
        };

    private static bool IsProtectedReference(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            // PostgreSQL reports ON DELETE RESTRICT as 23001
            // (restrict_violation), while other FK operations report 23503.
            SqlState: PostgresErrorCodes.ForeignKeyViolation or "23001",
            ConstraintName:
                "FK_Products_ProductCategories_CategoryCode"
                or "FK_PizzaComponentTypes_ProductCategories_CategoryCode",
        };

    private static bool IsComponentTypeReferenceViolation(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.CheckViolation,
            ConstraintName: "CK_ProductCategories_AllowsComponentTypes",
        };
}
