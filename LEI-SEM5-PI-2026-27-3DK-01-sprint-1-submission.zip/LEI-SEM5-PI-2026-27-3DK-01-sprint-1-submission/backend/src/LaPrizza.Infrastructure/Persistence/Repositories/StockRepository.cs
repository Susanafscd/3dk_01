using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

/// <summary>
/// PostgreSQL adapter for stock changes (BCK09). Each change is a single
/// <c>UPDATE … RETURNING</c> that commits on its own instead of going through
/// <c>SaveChangesAsync</c>: the <c>WHERE</c> clause keeps the stock in range under
/// concurrency, so no EF Core concurrency token is needed (ADR-008).
/// </summary>
internal sealed class StockRepository(DomainDbContext db) : IStockRepository
{
    public async Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default)
    {
        var stored = await db.Database
            .SqlQuery<int>($"""
                UPDATE "Products"
                SET "StockBalance" = "StockBalance" + {units}
                WHERE "Id" = {productId}
                  AND "StockControlled"
                  AND "StockBalance" <= {Product.MaximumStockBalance} - {units}
                RETURNING "StockBalance" AS "Value"
                """)
            .ToListAsync(cancellationToken);

        return stored.Count == 0 ? null : stored[0];
    }

    public async Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default)
    {
        var stored = await db.Database
            .SqlQuery<int>($"""
                UPDATE "Products"
                SET "StockBalance" = "StockBalance" - {units}
                WHERE "Id" = {productId}
                  AND "StockControlled"
                  AND "StockBalance" >= {units}
                RETURNING "StockBalance" AS "Value"
                """)
            .ToListAsync(cancellationToken);

        return stored.Count == 0 ? null : stored[0];
    }
}
