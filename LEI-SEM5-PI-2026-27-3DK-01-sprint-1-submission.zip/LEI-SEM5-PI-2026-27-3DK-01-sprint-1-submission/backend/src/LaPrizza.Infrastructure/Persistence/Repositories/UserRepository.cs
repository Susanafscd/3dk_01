using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Users;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

internal sealed class UserRepository(DomainDbContext context, IUnitOfWork unitOfWork) : BaseAutoSaveRepository<User, Guid>(context, unitOfWork), IUserRepository
{
    public Task<bool> ExistsByEmailAsync(Email email, CancellationToken cancellationToken = default) =>
        Set.AnyAsync(user => user.Email == email, cancellationToken);

    public Task<User?> GetByEmailAsync(Email email, CancellationToken cancellationToken = default) =>
        Set.FirstOrDefaultAsync(user => user.Email == email, cancellationToken);

    public async Task<IReadOnlyList<Customer>> SearchCustomersAsync(
        string? search,
        CancellationToken cancellationToken = default)
    {
        var query = Set.OfType<Customer>();
        var term = search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();

            // PhoneNumber is a value object converted to a string column. EF
            // cannot translate the nested Value member, so materialize the
            // customer list before applying the value-object search predicate.
            var customers = await query.OrderBy(customer => customer.Name)
                .ToListAsync(cancellationToken);
            var email = Email.TryCreate(term, out var parsedEmail) ? parsedEmail : null;

            return customers
                .Where(customer =>
                    customer.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                    || customer.PhoneNumber.Value.Contains(term, StringComparison.OrdinalIgnoreCase)
                    || (email is not null && customer.Email == email))
                .ToList();
        }

        return await query.OrderBy(customer => customer.Name).ToListAsync(cancellationToken);
    }
}
