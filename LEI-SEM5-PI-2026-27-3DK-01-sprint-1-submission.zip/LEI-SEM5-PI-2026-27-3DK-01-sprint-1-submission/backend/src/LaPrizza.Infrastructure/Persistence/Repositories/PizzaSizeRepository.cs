using LaPrizza.Application.ComponentTypes;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

internal sealed class PizzaSizeRepository(DomainDbContext context)
    : IPizzaSizeRepository
{
    public Task<PizzaSize?> Get(Guid id, CancellationToken cancellationToken = default)
    {
        return context.Set<PizzaSize>().FirstOrDefaultAsync(size => size.Id == id, cancellationToken);
    }

    public async Task<PizzaSize> Add(PizzaSize size, CancellationToken cancellationToken = default)
    {
        await context.Set<PizzaSize>().AddAsync(size, cancellationToken);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsDuplicateName(exception))
        {
            context.Entry(size).State = EntityState.Detached;
            throw new DuplicatePizzaSizeNameException(size.Name);
        }

        return size;
    }

    public Task<bool> InUse(Guid id, CancellationToken cancellationToken = default)
    {
        // In tests we use EF Core InMemory; in production we use PostgreSQL.
        // We support both by selecting the cheapest correct strategy per provider.
        if (context.Database.ProviderName?.Contains("InMemory", StringComparison.Ordinal) == true)
        {
            return InUseInMemory(id, cancellationToken);
        }

        return InUsePostgres(id, cancellationToken);
    }

    private async Task<bool> InUseInMemory(Guid id, CancellationToken cancellationToken)
    {
        var sizeName = await context.PizzaSizes
            .AsNoTracking()
            .Where(size => size.Id == id)
            .Select(size => size.Name)
            .SingleOrDefaultAsync(cancellationToken);

        if (sizeName is null)
        {
            return false;
        }

        var baseProducts = await context.Products
            .AsNoTracking()
            .OfType<BaseProduct>()
            .Where(p => p.SizeConfiguration != null)
            .ToListAsync(cancellationToken);

        var inSizeConfigurations = baseProducts.Any(p =>
            p.SizeConfiguration!.SizeMappings.ContainsKey(sizeName));

        if (inSizeConfigurations)
        {
            return true;
        }

        // Configured pizzas store available sizes in a separate owned collection.
        return await context.Set<ComposedProduct>()
            .AsNoTracking()
            .AnyAsync(p => p.AvailableSizes.Any(s => s.SizeName == sizeName), cancellationToken);
    }

    private async Task<bool> InUsePostgres(Guid id, CancellationToken cancellationToken)
    {
        var sizeName = await context.PizzaSizes
            .AsNoTracking()
            .Where(size => size.Id == id)
            .Select(size => size.Name)
            .SingleOrDefaultAsync(cancellationToken);

        if (sizeName is null)
        {
            return false;
        }

        // BCK08: size configurations are stored as a jsonb value object inside the product row.
        // SizeConfigurationSerializer serialises SizeId as "sizeId" and the outer array as "sizeConfigurations".
        var jsonPath = "$.sizeConfigurations[*] ? (@.sizeId == \"" + sizeName + "\")";
        var inSizeConfigurations = await context.Database
            .SqlQuery<bool>($"""
                SELECT EXISTS(
                    SELECT 1
                    FROM \"Products\" p
                    WHERE p.\"SizeConfiguration\" IS NOT NULL
                      AND jsonb_path_exists(p.\"SizeConfiguration\", {jsonPath}::jsonpath)
                    LIMIT 1
                )
                """)
            .ToListAsync(cancellationToken);

        var inSize = inSizeConfigurations.Count == 1 && inSizeConfigurations[0];
        if (inSize)
        {
            return true;
        }

        // BCK10: product available sizes are stored in a separate table with a restrictive FK.
        var inComposedPizzas = await context.Database
            .SqlQuery<bool>($"""
                SELECT EXISTS(
                    SELECT 1
                    FROM \"ProductAvailableSizes\" pas
                    WHERE pas.\"SizeName\" = {sizeName}
                    LIMIT 1
                )
                """)
            .ToListAsync(cancellationToken);

        return inComposedPizzas.Count == 1 && inComposedPizzas[0];
    }

    public async Task Remove(PizzaSize size, CancellationToken cancellationToken = default)
    {
        context.Set<PizzaSize>().Remove(size);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsInUse(exception))
        {
            throw new PizzaSizeInUseException(size.Id);
        }
    }

    public Task<bool> ExistsByName(string name, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return Task.FromResult(false);
        }

        var normalized = name.Trim();
        return context.Set<PizzaSize>().AsNoTracking()
            .AnyAsync(size => size.Name == normalized, cancellationToken);
    }

    private static bool IsDuplicateName(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.UniqueViolation,
            ConstraintName: "IX_PizzaSizes_Name",
        };

    private static bool IsInUse(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.ForeignKeyViolation,
        };
}
