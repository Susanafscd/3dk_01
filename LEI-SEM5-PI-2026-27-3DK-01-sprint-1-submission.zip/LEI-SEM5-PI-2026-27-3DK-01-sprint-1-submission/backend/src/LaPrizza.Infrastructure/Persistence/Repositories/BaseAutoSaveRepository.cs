using LaPrizza.Application.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

/// <summary>
/// Generic base repository that implements CRUD operations and automatically
/// commits changes via the unit of work.
/// </summary>
internal abstract class BaseAutoSaveRepository<TAggregate, TKey>(DbContext context, IUnitOfWork unitOfWork)
    : BaseRepository<TAggregate, TKey>(context)
    where TAggregate : class
{
    protected IUnitOfWork UnitOfWork { get; } = unitOfWork;

    public override async Task AddAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        await base.AddAsync(aggregate, cancellationToken);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
    }

    public override async Task UpdateAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        await base.UpdateAsync(aggregate, cancellationToken);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
    }

    public override async Task RemoveAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        await base.RemoveAsync(aggregate, cancellationToken);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return UnitOfWork.SaveChangesAsync(cancellationToken);
    }
}
