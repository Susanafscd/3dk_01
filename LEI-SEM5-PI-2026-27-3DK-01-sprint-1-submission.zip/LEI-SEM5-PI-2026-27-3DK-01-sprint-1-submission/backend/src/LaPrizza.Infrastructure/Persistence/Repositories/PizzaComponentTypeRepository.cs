using LaPrizza.Domain.ComponentTypes;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

internal sealed class PizzaComponentTypeRepository(DomainDbContext context)
    : IPizzaComponentTypeRepository
{
    public Task<PizzaComponentType?> GetByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default)
    {
        return context.PizzaComponentTypes.FirstOrDefaultAsync(type => type.Code == code, cancellationToken);
    }

    public async Task<PizzaComponentType> Add(PizzaComponentType type, CancellationToken cancellationToken = default)
    {
        await context.PizzaComponentTypes.AddAsync(type, cancellationToken);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsDuplicateCode(exception))
        {
            context.Entry(type).State = EntityState.Detached;
            throw new DuplicatePizzaComponentTypeCodeException(type.Code);
        }
        catch (DbUpdateException exception) when (IsDuplicateName(exception))
        {
            context.Entry(type).State = EntityState.Detached;
            throw new DuplicatePizzaComponentTypeNameException(type.Name);
        }
        catch (DbUpdateException exception) when (IsDuplicateAssemblyOrder(exception))
        {
            context.Entry(type).State = EntityState.Detached;
            throw new DuplicatePizzaComponentTypeAssemblyOrderException(type.AssemblyOrder);
        }

        return type;
    }

    public async Task Update(PizzaComponentType type, CancellationToken cancellationToken = default)
    {
        context.PizzaComponentTypes.Update(type);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsDuplicateName(exception))
        {
            throw new DuplicatePizzaComponentTypeNameException(type.Name);
        }
        catch (DbUpdateException exception) when (IsDuplicateAssemblyOrder(exception))
        {
            throw new DuplicatePizzaComponentTypeAssemblyOrderException(type.AssemblyOrder);
        }
    }

    public async Task Remove(PizzaComponentType type, CancellationToken cancellationToken = default)
    {
        context.PizzaComponentTypes.Remove(type);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsInUse(exception))
        {
            throw new PizzaComponentTypeInUseException(type.Code);
        }
    }

    public Task<bool> ExistsByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default)
    {
        return context.PizzaComponentTypes.AsNoTracking()
            .AnyAsync(type => type.Code == code, cancellationToken);
    }

    public Task<bool> ExistsByName(string name, Guid? excludeId = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return Task.FromResult(false);
        }

        var normalized = name.Trim();
        var lowered = normalized.ToLowerInvariant();
        var query = context.PizzaComponentTypes.AsNoTracking()
            .Where(type => type.Name.ToLower() == lowered);

        if (excludeId.HasValue)
        {
            query = query.Where(type => type.Id != excludeId.Value);
        }

        return query.AnyAsync(cancellationToken);
    }

    public Task<bool> ExistsByAssemblyOrder(int assemblyOrder, Guid? excludeId = null, CancellationToken cancellationToken = default)
    {
        var query = context.PizzaComponentTypes.AsNoTracking()
            .Where(type => type.AssemblyOrder == assemblyOrder);

        if (excludeId.HasValue)
        {
            query = query.Where(type => type.Id != excludeId.Value);
        }

        return query.AnyAsync(cancellationToken);
    }

    public async Task<bool> InUse(Guid id, CancellationToken cancellationToken = default)
    {
        var typeCode = await context.PizzaComponentTypes
            .AsNoTracking()
            .Where(type => type.Id == id)
            .Select(type => type.Code.Value)
            .SingleOrDefaultAsync(cancellationToken);

        if (typeCode is null)
        {
            return false;
        }

        // Component type references are stored as business codes on products.
        // The query deliberately includes inactive products: deactivation does
        // not erase historical relationships.
        return await context.Products.AsNoTracking()
            .AnyAsync(product => EF.Property<string?>(product, "ComponentTypeCode") == typeCode,
                cancellationToken);
    }

    private static bool IsDuplicateCode(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.UniqueViolation,
            ConstraintName: "IX_PizzaComponentTypes_Code",
        };

    private static bool IsDuplicateName(DbUpdateException exception)
    {
        if (exception.InnerException is not PostgresException postgres)
        {
            return false;
        }

        if (postgres.SqlState != PostgresErrorCodes.UniqueViolation)
        {
            return false;
        }

        return postgres.ConstraintName?.Contains("Name", StringComparison.OrdinalIgnoreCase) == true;
    }

    private static bool IsDuplicateAssemblyOrder(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.UniqueViolation,
        } && (exception.InnerException as PostgresException)?.ConstraintName?.Contains("AssemblyOrder") == true;

    private static bool IsInUse(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.ForeignKeyViolation,
        };
}
