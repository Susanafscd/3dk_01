using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

internal sealed class ProductRepository(DomainDbContext db) : IProductRepository
{
    public Task<Product?> GetByCodeAsync(ProductCode code, CancellationToken cancellationToken = default) =>
        db.Set<Product>()
            .Include(p => p.Allergens)
            .FirstOrDefaultAsync(p => p.Code == code, cancellationToken);

    public async Task AddAndSaveAsync(Product product, CancellationToken cancellationToken = default)
    {
        // SaveChanges runs in one transaction, so the product and its allergen rows commit together.
        db.Set<Product>().Add(product);

        try
        {
            await db.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception)
            when (exception.InnerException is PostgresException { SqlState: PostgresErrorCodes.UniqueViolation })
        {
            throw new DuplicateProductCodeException(product.Code);
        }
    }

    public async Task SaveAsync(Product product, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(product);

        // The aggregate comes tracked from GetByCodeAsync, so change detection
        // (including the value comparer on the size configuration) writes only
        // what the domain changed.
        try
        {
            await db.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new ProductConcurrencyException(
                $"Product '{product.Code.Value}' changed concurrently.");
        }
    }

}
