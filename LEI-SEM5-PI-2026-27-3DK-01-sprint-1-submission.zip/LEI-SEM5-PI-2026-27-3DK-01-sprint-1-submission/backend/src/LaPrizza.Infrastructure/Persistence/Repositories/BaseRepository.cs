using LaPrizza.Application.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

/// <summary>
/// Base repository providing shared CRUD implementation without persistence.
/// Changes must be committed explicitly via <see cref="IUnitOfWork"/>.
/// </summary>
internal abstract class BaseRepository<TAggregate, TKey>(DbContext context)
    : IBaseRepository<TAggregate, TKey>
    where TAggregate : class
{
    protected DbContext Context { get; } = context;
    protected DbSet<TAggregate> Set { get; } = context.Set<TAggregate>();

    public virtual async Task<TAggregate?> GetByIdAsync(TKey id, CancellationToken cancellationToken = default)
    {
        return await Set.FindAsync([id], cancellationToken);
    }

    public virtual async Task<IReadOnlyList<TAggregate>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await Set.ToListAsync(cancellationToken);
    }

    public virtual async Task AddAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(aggregate);
        await Set.AddAsync(aggregate, cancellationToken);
    }

    public virtual Task UpdateAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(aggregate);
        var entry = Context.Entry(aggregate);
        if (entry.State == EntityState.Detached)
        {
            Set.Update(aggregate);
        }

        return Task.CompletedTask;
    }

    public virtual Task RemoveAsync(TAggregate aggregate, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(aggregate);
        Set.Remove(aggregate);
        return Task.CompletedTask;
    }

    public virtual async Task<bool> ExistsAsync(TKey id, CancellationToken cancellationToken = default)
    {
        var entity = await GetByIdAsync(id, cancellationToken);
        return entity is not null;
    }

    public virtual Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return Context.SaveChangesAsync(cancellationToken);
    }
}
