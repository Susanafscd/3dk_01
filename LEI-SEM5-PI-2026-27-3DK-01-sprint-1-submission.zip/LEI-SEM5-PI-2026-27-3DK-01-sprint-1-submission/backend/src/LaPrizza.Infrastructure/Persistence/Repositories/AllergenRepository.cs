using LaPrizza.Domain.Allergens;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Persistence.Repositories;

public sealed class AllergenRepository(DomainDbContext context) : IAllergenRepository
{
    public Task<Allergen?> GetByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default)
    {
        return context.Allergens.FirstOrDefaultAsync(
            allergen => allergen.Code == code,
            cancellationToken);
    }

    public async Task AddAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default)
    {
        await context.Allergens.AddAsync(allergen, cancellationToken);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsDuplicateCode(exception))
        {
            context.Entry(allergen).State = EntityState.Detached;
            throw new DuplicateAllergenCodeException(allergen.Code);
        }
    }

    public async Task UpdateAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default)
    {
        // Aggregates returned by GetByCodeAsync are tracked by this context.
        // Update also makes the contract safe for an aggregate supplied by a
        // caller that loaded it in a different context.
        context.Allergens.Update(allergen);
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task RemoveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default)
    {
        // Avoid EF relationship fix-up severing a tracked required join row.
        // The database constraint below remains the race-safe final guard.
        if (await context.DietaryRestrictions.AnyAsync(
                restriction => restriction.Allergens.Any(value => value.Code == allergen.Code),
                cancellationToken))
        {
            throw new AllergenInUseException(allergen.Code);
        }

        context.Allergens.Remove(allergen);

        try
        {
            await context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateException exception) when (IsProtectedReference(exception))
        {
            context.Entry(allergen).State = EntityState.Unchanged;
            throw new AllergenInUseException(allergen.Code);
        }
    }

    public async Task<AllergenLookupResult?> GetLookupByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default)
    {
        var allergen = await context.Allergens
            .AsNoTracking()
            .Where(allergen => allergen.Code == code)
            .Select(allergen => new
            {
                allergen.Code,
                allergen.Name,
                allergen.Description,
            })
            .SingleOrDefaultAsync(cancellationToken);

        return allergen is null
            ? null
            : new AllergenLookupResult(
                allergen.Code.Value,
                allergen.Name,
                allergen.Description);
    }

    private static bool IsDuplicateCode(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            SqlState: PostgresErrorCodes.UniqueViolation,
            ConstraintName: "IX_Allergens_Code",
        };

    private static bool IsProtectedReference(DbUpdateException exception) =>
        exception.InnerException is PostgresException
        {
            // PostgreSQL reports ON DELETE RESTRICT as 23001
            // (restrict_violation), while other FK operations report 23503.
            SqlState: PostgresErrorCodes.ForeignKeyViolation or "23001",
            ConstraintName: "FK_ProductAllergens_Allergens_AllergenCode"
                or "FK_DietaryRestrictionAllergens_Allergens_AllergensId",
        };
}
