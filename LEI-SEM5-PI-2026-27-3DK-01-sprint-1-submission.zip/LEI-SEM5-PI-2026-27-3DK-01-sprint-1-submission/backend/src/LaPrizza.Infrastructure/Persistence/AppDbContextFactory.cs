using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace LaPrizza.Infrastructure.Persistence;

/// <summary>
/// Lets the EF Core tools build the Identity store (<see cref="AppDbContext"/>)
/// without the API host, so migrations can be added against this class library.
/// </summary>
public sealed class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args) => new(
        new DbContextOptionsBuilder<AppDbContext>()
            .UseNpgsql(DesignTimeConnectionString.Resolve())
            .Options);
}
