using LaPrizza.Application.Abstractions;

namespace LaPrizza.Infrastructure.Persistence;

internal sealed class UnitOfWork(DomainDbContext context) : IUnitOfWork
{
    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        context.SaveChangesAsync(cancellationToken);
}
