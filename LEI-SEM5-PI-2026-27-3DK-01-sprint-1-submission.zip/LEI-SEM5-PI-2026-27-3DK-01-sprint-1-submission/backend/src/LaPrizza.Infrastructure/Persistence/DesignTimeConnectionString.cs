using dotenv.net;

namespace LaPrizza.Infrastructure.Persistence;

/// <summary>
/// Supplies the connection string used by the design-time factories. The EF Core
/// tools only open a connection for <c>dotnet ef database update</c>; scaffolding
/// a migration never connects, so a placeholder is enough there.
/// <para>
/// Resolution order: the <c>ConnectionStrings__Postgres</c> environment variable,
/// then the same git-ignored <c>.env</c> file the API uses (so the tools and the
/// running application never drift), then the placeholder.
/// </para>
/// </summary>
internal static class DesignTimeConnectionString
{
    private const string VariableName = "ConnectionStrings__Postgres";

    private const string Placeholder =
        "Host=localhost;Port=5432;Database=laprizza;Username=laprizza_user;Password=change_me";

    public static string Resolve()
    {
        var configured = Environment.GetEnvironmentVariable(VariableName);

        if (!string.IsNullOrWhiteSpace(configured))
        {
            return configured;
        }

        foreach (var envFile in FindEnvFiles())
        {
            new DotEnvOptions()
                .WithEnvFiles([envFile])
                .WithoutOverwriteExistingVars()
                .WithoutProbeForEnv()
                .WithoutExceptions()
                .Load();

            configured = Environment.GetEnvironmentVariable(VariableName);

            if (!string.IsNullOrWhiteSpace(configured))
            {
                return configured;
            }
        }

        return Placeholder;
    }

    /// <summary>
    /// Walks up from the working directory, so the tools find the API's
    /// <c>.env</c> whether they run from <c>backend/</c> or from the project.
    /// </summary>
    private static IEnumerable<string> FindEnvFiles()
    {
        for (var directory = new DirectoryInfo(Directory.GetCurrentDirectory());
             directory is not null;
             directory = directory.Parent)
        {
            var candidates = new[]
            {
                Path.Combine(directory.FullName, ".env"),
                Path.Combine(directory.FullName, "src", "Api", ".env"),
                Path.Combine(directory.FullName, "backend", "src", "Api", ".env"),
            };

            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate))
                {
                    yield return candidate;
                }
            }
        }
    }
}
