using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence;

/// <summary>
/// Relational store for authentication. It carries the ASP.NET Core Identity
/// schema only; the business data lives in <see cref="DomainDbContext"/>.
/// Credentials are deliberately kept apart from the domain (MD-06).
/// </summary>
public sealed class AppDbContext(DbContextOptions<AppDbContext> options)
    : IdentityDbContext<IdentityUser>(options);
