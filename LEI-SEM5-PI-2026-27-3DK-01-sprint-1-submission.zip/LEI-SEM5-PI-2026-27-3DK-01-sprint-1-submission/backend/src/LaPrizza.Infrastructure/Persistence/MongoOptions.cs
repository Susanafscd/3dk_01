namespace LaPrizza.Infrastructure.Persistence;

/// <summary>
/// Document store settings, bound from the 'Mongo' configuration section
/// (environment variable 'Mongo__ConnectionString', 'Mongo__DatabaseName').
/// </summary>
public sealed class MongoOptions
{
    public const string SectionName = "Mongo";

    public string ConnectionString { get; set; } = "mongodb://localhost:27017";

    public string DatabaseName { get; set; } = "appdb";
}
