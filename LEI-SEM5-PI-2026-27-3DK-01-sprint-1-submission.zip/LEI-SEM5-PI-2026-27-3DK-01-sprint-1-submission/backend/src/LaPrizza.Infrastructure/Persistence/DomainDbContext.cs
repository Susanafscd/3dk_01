using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.Users;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Persistence;

public sealed class DomainDbContext(DbContextOptions<DomainDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Product> Products => Set<Product>();

    public DbSet<ProductCategory> ProductCategories => Set<ProductCategory>();

    public DbSet<Allergen> Allergens => Set<Allergen>();

    public DbSet<DietaryRestriction> DietaryRestrictions => Set<DietaryRestriction>();

    public DbSet<PizzaSize> PizzaSizes => Set<PizzaSize>();

    public DbSet<PizzaComponentType> PizzaComponentTypes => Set<PizzaComponentType>();


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(DomainDbContext).Assembly);

        base.OnModelCreating(modelBuilder);
    }
}
