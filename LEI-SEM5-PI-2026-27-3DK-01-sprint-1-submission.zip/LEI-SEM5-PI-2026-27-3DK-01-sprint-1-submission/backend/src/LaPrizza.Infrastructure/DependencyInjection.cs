using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Abstractions;
using LaPrizza.Application.ComponentTypes;
using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.ProductCategories;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Identity;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using LaPrizza.Infrastructure.Redis;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StackExchange.Redis;

namespace LaPrizza.Infrastructure;

/// <summary>Registers the outbound adapters: relational store, identity, document store and distributed cache.</summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration,
        IHostEnvironment environment)
    {
        var connectionString = configuration.GetConnectionString("Postgres")
            ?? throw new InvalidOperationException(
                "No relational connection string is configured. Set 'ConnectionStrings__Postgres' "
                + "(see .env.example) or 'ConnectionStrings:Postgres' in appsettings.Development.json.");

        services.AddDbContext<AppDbContext>(options => options.UseNpgsql(connectionString));
        services.AddDbContext<DomainDbContext>(options => options.UseNpgsql(connectionString));

        AddIdentity(services, environment);
        AddDocumentStore(services, configuration);
        AddRedis(services, configuration);

        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IDistributedCacheService, DistributedCacheService>();
        services.AddScoped<ICatalogueCacheInvalidator, HybridCatalogueCacheInvalidator>();
        services.AddScoped<IAllergenCatalogueCache, HybridAllergenCatalogueCache>();
        services.AddScoped<IProductCategoryCatalogueCache, HybridProductCategoryCatalogueCache>();
        services.AddScoped<IProductCatalogueCache, HybridProductCatalogueCache>();
        services.AddScoped<ICatalogueQueries, CatalogueQueries>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<IUserAccountManager, UserAccountManager>();
        services.AddScoped<IProductCategoryRepository, ProductCategoryRepository>();
        services.AddScoped<IProductCategoryQueries, ProductCategoryQueries>();
        services.AddScoped<IProductCategoryUsageQueries, ProductCategoryUsageQueries>();
        services.AddScoped<IAllergenRepository, AllergenRepository>();
        services.AddScoped<IAllergenQueries, AllergenQueries>();
        services.AddScoped<IPizzaComponentTypeRepository, PizzaComponentTypeRepository>();
        services.AddScoped<IPizzaComponentTypeQueries, PizzaComponentTypeQueries>();
        services.AddScoped<IAllergenUsageQueries, AllergenUsageQueries>();
        services.AddScoped<IPizzaSizeRepository, PizzaSizeRepository>();
        services.AddScoped<IPizzaSizeQueries, PizzaSizeQueries>();
        services.AddScoped<IProductRepository, ProductRepository>();
        services.AddScoped<IProductRelationshipQueries, ProductRelationshipQueries>();
        services.AddScoped<IProductUpdateQueries, ProductUpdateQueries>();
        services.AddScoped<IProductQueries, ProductQueries>();
        services.AddScoped<IStockQueries, StockQueries>();
        services.AddScoped<IStockRepository, StockRepository>();
        services.AddScoped<IPredefinedPizzaQueries, PredefinedPizzaQueries>();
        return services;
    }

    private static void AddIdentity(IServiceCollection services, IHostEnvironment environment)
    {
        services
            .AddIdentity<IdentityUser, IdentityRole>()
            .AddEntityFrameworkStores<AppDbContext>()
            .AddSignInManager()
            .AddDefaultTokenProviders();

        // Session management: the cookie is HttpOnly and SameSite=Lax (and Secure
        // in production, see below), and an API answers 401/403 instead of
        // redirecting to an HTML login page.
        services.ConfigureApplicationCookie(options =>
        {
            options.Cookie.Name = AuthenticationDefaults.CookieName;
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.Lax;
            // Cookies are Secure in production. In development they follow the
            // request scheme so the API can also be exercised over plain HTTP
            // (for example the Docker stack, which serves http://+:8080).
            options.Cookie.SecurePolicy = environment.IsDevelopment()
                ? CookieSecurePolicy.SameAsRequest
                : CookieSecurePolicy.Always;
            options.SlidingExpiration = true;
            options.ExpireTimeSpan = TimeSpan.FromHours(8);

            options.Events.OnRedirectToLogin = context =>
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return Task.CompletedTask;
            };
            options.Events.OnRedirectToAccessDenied = context =>
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                return Task.CompletedTask;
            };
        });
    }

    private static void AddDocumentStore(IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<MongoOptions>(configuration.GetSection(MongoOptions.SectionName));

        services.AddSingleton<IMongoClient>(provider =>
            new MongoClient(provider.GetRequiredService<IOptions<MongoOptions>>().Value.ConnectionString));

        services.AddSingleton(provider =>
            provider.GetRequiredService<IMongoClient>()
                .GetDatabase(provider.GetRequiredService<IOptions<MongoOptions>>().Value.DatabaseName));
    }

    private static void AddRedis(IServiceCollection services, IConfiguration configuration)
    {
        var redisOptions = configuration.GetSection(RedisOptions.SectionName).Get<RedisOptions>()
            ?? new RedisOptions();

        services.Configure<RedisOptions>(configuration.GetSection(RedisOptions.SectionName));

        services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = redisOptions.ConnectionString;
            options.InstanceName = "LaPrizza";
        });

        services.AddSingleton<IConnectionMultiplexer>(_ =>
            ConnectionMultiplexer.Connect(redisOptions.ConnectionString));

        services.AddHybridCache(options =>
        {
            options.DefaultEntryOptions = new HybridCacheEntryOptions
            {
                Expiration = TimeSpan.FromMinutes(5),
                LocalCacheExpiration = TimeSpan.FromSeconds(30),
            };
        });
    }
}
