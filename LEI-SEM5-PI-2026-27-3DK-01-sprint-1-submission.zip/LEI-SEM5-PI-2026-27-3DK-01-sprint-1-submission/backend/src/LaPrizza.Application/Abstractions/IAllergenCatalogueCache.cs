using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Abstractions;

/// <summary>Cache port for allergen read projections.</summary>
public interface IAllergenCatalogueCache
{
    Task<AllergenLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<AllergenLookupResult>> factory,
        CancellationToken cancellationToken = default);

    Task<SearchAllergensResult> SearchAsync(
        string cacheKey,
        Func<CancellationToken, Task<SearchAllergensResult>> factory,
        CancellationToken cancellationToken = default);
}
