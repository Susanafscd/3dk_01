namespace LaPrizza.Application.Abstractions;

/// <summary>
/// Invalidates disposable catalogue projections after an authoritative commit.
/// Infrastructure handles cache outages without failing an already committed registration.
/// </summary>
public interface ICatalogueCacheInvalidator
{
    Task InvalidateAllergensAsync(CancellationToken cancellationToken = default);

    Task InvalidateProductCategoriesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Invalidates the cached projections of the products shown in the public
    /// catalogue (its entries and the product detail views), so a committed
    /// product change (creation, size configuration, ...) is served on the next
    /// consultation.
    /// </summary>
    Task InvalidateProductsAsync(CancellationToken cancellationToken = default);
}
