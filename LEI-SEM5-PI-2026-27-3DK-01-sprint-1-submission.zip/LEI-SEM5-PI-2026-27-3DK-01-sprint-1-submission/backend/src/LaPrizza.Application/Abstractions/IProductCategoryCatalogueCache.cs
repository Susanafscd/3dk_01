using LaPrizza.Application.ProductCategories;
using LaPrizza.Application.ProductCategories.SearchProductCategories;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.Abstractions;

/// <summary>Cache port for product-category read projections.</summary>
public interface IProductCategoryCatalogueCache
{
    Task<ProductCategoryLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<ProductCategoryLookupResult>> factory,
        CancellationToken cancellationToken = default);

    Task<SearchProductCategoriesResult> SearchAsync(
        string cacheKey,
        Func<CancellationToken, Task<SearchProductCategoriesResult>> factory,
        CancellationToken cancellationToken = default);
}
