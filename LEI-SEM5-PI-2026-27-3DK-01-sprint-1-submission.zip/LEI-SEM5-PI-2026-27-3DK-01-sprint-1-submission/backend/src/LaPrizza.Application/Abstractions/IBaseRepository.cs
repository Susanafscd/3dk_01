namespace LaPrizza.Application.Abstractions;

/// <summary>
/// Generic repository contract for aggregate roots.
/// </summary>
public interface IBaseRepository<TAggregate, TKey>
    where TAggregate : class
{
    Task<TAggregate?> GetByIdAsync(TKey id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<TAggregate>> GetAllAsync(CancellationToken cancellationToken = default);

    Task AddAsync(TAggregate aggregate, CancellationToken cancellationToken = default);

    Task UpdateAsync(TAggregate aggregate, CancellationToken cancellationToken = default);

    Task RemoveAsync(TAggregate aggregate, CancellationToken cancellationToken = default);

    Task<bool> ExistsAsync(TKey id, CancellationToken cancellationToken = default);

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
