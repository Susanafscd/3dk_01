namespace LaPrizza.Application.Abstractions;

/// <summary>
/// Port for the authentication store. Credentials are not a domain concept
/// (MD-06), so the application talks to them through this port instead of
/// touching the domain model.
/// </summary>
public interface IUserAccountManager
{
    /// <summary>
    /// Creates a login account for the given email and password and returns the
    /// opaque account identifier.
    /// </summary>
    Task<string> CreateAccountAsync(
        string email,
        string password,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Deletes an account previously created by
    /// <see cref="CreateAccountAsync"/>. Used to compensate when the rest of the
    /// operation fails.
    /// </summary>
    Task DeleteAccountAsync(string accountId, CancellationToken cancellationToken = default);

    Task AssignRolesAsync(string accountId, IEnumerable<string> roleNames, CancellationToken cancellationToken = default);
}
