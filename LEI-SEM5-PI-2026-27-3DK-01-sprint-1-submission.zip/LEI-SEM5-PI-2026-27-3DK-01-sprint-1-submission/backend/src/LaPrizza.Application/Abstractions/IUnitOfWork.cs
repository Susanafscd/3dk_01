namespace LaPrizza.Application.Abstractions;

/// <summary>
/// Transactional boundary over the application's relational store. A use case
/// stages changes through repositories and commits them once, at the end.
/// </summary>
public interface IUnitOfWork
{
    /// <summary>Commits every pending change and returns the number of rows written.</summary>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
