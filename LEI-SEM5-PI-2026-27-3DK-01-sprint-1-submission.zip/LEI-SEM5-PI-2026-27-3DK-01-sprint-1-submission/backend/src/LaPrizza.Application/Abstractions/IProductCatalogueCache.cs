using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Products.GetProduct;

namespace LaPrizza.Application.Abstractions;

/// <summary>Cache port for product detail projections and the public catalogue (BCK11).</summary>
public interface IProductCatalogueCache
{
    Task<ProductLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<ProductLookupResult>> factory,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the cached sellable catalogue page, loading it through
    /// <paramref name="factory"/> on a miss; keyed by page and page size.
    /// </summary>
    Task<CatalogueResult> GetListAsync(
        int page,
        int pageSize,
        Func<CancellationToken, Task<CatalogueResult>> factory,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the cached catalogue entry of a sellable product by its
    /// identifier (null when the product is not on sale), loading it through
    /// <paramref name="factory"/> on a miss.
    /// </summary>
    Task<CatalogueProductResult?> GetByIdAsync(
        Guid id,
        Func<CancellationToken, Task<CatalogueProductResult?>> factory,
        CancellationToken cancellationToken = default);
}
