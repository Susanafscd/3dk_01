namespace LaPrizza.Application.Abstractions;

/// <summary>
/// Abstraction for distributed caching operations following Clean Architecture.
/// The application layer defines this port; infrastructure implements it.
/// </summary>
public interface IDistributedCacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);

    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);

    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
}
