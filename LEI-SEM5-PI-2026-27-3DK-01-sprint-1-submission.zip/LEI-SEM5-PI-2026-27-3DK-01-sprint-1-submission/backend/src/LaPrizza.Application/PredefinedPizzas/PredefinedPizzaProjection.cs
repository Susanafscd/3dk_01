using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas;

/// <summary>
/// Builds the representation of a predefined pizza from the facts of its
/// components, shared by the use cases that return a pizza (UC-43, UC-44).
/// </summary>
internal static class PredefinedPizzaProjection
{
    public static PredefinedPizzaResult ToResult(
        ComposedProduct pizza,
        IReadOnlyDictionary<ProductCode, PizzaComponentFacts> facts,
        IReadOnlyList<PredefinedPizzaSizePrice> sizes) =>
        new(
            pizza.Code.Value,
            pizza.Name,
            pizza.Description,
            pizza.CategoryCode.Value,
            pizza.Active,
            DefaultConfigurationOf(pizza, facts),
            sizes);

    /// <summary>
    /// The price of the pizza in a size: the sum of its components' prices there,
    /// or null when a component has no active size configuration for it (BR-13).
    /// </summary>
    public static decimal? PriceIn(
        string sizeId,
        IEnumerable<ProductCode> components,
        IReadOnlyDictionary<ProductCode, PizzaComponentFacts> facts)
    {
        var price = 0m;
        foreach (var code in components)
        {
            if (!facts.TryGetValue(code, out var component)
                || !component.ActiveSizePrices.TryGetValue(sizeId, out var componentPrice))
            {
                return null;
            }

            price += componentPrice;
        }

        return price;
    }

    /// <summary>The components in the order a pizza is assembled (BCK07).</summary>
    private static List<PredefinedPizzaComponent> DefaultConfigurationOf(
        ComposedProduct pizza,
        IReadOnlyDictionary<ProductCode, PizzaComponentFacts> facts) =>
        pizza.Components
            .Where(facts.ContainsKey)
            .Select(code => facts[code])
            .Select(component => new PredefinedPizzaComponent(
                component.Code.Value,
                component.Name,
                component.ComponentTypeCode ?? string.Empty,
                component.AssemblyOrder.GetValueOrDefault()))
            .OrderBy(component => component.AssemblyOrder)
            .ThenBy(component => component.ProductCode, StringComparer.Ordinal)
            .ToList();
}
