using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;

/// <summary>
/// UC-46: replaces the details, the default configuration and the available sizes
/// of a predefined pizza with the same rules as UC-43. A rejected update changes
/// nothing.
/// </summary>
public sealed class UpdatePredefinedPizzaCommandHandler(
    IProductRepository products,
    IPizzaSizeRepository sizes,
    IPredefinedPizzaQueries queries)
{
    public async Task<PredefinedPizzaResult> HandleAsync(
        UpdatePredefinedPizzaCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        // 1. The pizza in the path must exist (400 malformed, 404 unknown).
        var code = ProductCode.Create(command.ProductCode);
        if (await products.GetByCodeAsync(code, cancellationToken) is not ComposedProduct pizza)
        {
            throw new NotFoundException($"Predefined pizza '{code.Value}' does not exist.");
        }

        // 2. Every referenced component and size must exist (400).
        var configuration = await PredefinedPizzaReferences.ResolveAsync(
            command.ComponentCodes, command.SizeIds, sizes, queries, cancellationToken);

        // 3. BR-13 is checked before the pizza changes, so a rejection leaves it intact (409).
        var prices = PredefinedPizzaReferences.PricesOrConflict(configuration);

        // 4. The composed product applies the configuration rules (409).
        try
        {
            pizza.ReplaceConfiguration(
                command.Name,
                command.Description,
                configuration.Components,
                configuration.TypeLimits,
                configuration.SizeIds);
        }
        catch (InvalidPizzaConfigurationException exception)
        {
            throw new ConflictException(exception.Message);
        }

        // 5. Persist the tracked aggregate; the foreign keys recheck the existence
        // of the components and sizes inside the write.
        await products.SaveAsync(pizza, cancellationToken);

        return PredefinedPizzaProjection.ToResult(pizza, configuration.Facts, prices);
    }
}
