namespace LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;

/// <summary>
/// Input for UC-46: the pizza code from the path and the replacement body. The
/// code and the category of a pizza never change.
/// </summary>
public sealed record UpdatePredefinedPizzaCommand(
    string? ProductCode,
    string? Name,
    string? Description,
    IReadOnlyList<string>? ComponentCodes,
    IReadOnlyList<string>? SizeIds);
