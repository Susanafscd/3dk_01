using LaPrizza.Application.Common.Exceptions;

namespace LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;

/// <summary>
/// Validates the predefined pizza search input and delegates the read to the
/// predefined pizza query port (UC-45), as the product and stock searches do.
/// </summary>
public sealed class SearchPredefinedPizzasQueryHandler(IPredefinedPizzaQueries queries)
{
    public async Task<SearchPredefinedPizzasResult> HandleAsync(
        SearchPredefinedPizzasQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchPredefinedPizzasQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchPredefinedPizzasQuery.MaximumPageSize}.");
        }

        var search = string.IsNullOrWhiteSpace(query.Search) ? null : query.Search.Trim();
        var page = await queries.SearchAsync(
            new PredefinedPizzaSearchCriteria(search, query.Active, query.Page, query.PageSize),
            cancellationToken);

        return new SearchPredefinedPizzasResult(page.Items, query.Page, query.PageSize, page.TotalCount);
    }
}
