namespace LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;

/// <summary>
/// Validated criteria of the predefined pizza search: a full pizza code or a
/// case-insensitive part of the name, and an optional active filter.
/// </summary>
public sealed record PredefinedPizzaSearchCriteria(string? Search, bool? Active, int Page, int PageSize);

/// <summary>One predefined pizza returned by the search.</summary>
public sealed record PredefinedPizzaSearchItem(string Code, string Name, string CategoryCode, bool Active);

/// <summary>A page of predefined pizzas together with the count before pagination.</summary>
public sealed record PredefinedPizzaSearchPage(IReadOnlyList<PredefinedPizzaSearchItem> Items, int TotalCount);

/// <summary>The page returned by UC-45, ordered by name and then code.</summary>
public sealed record SearchPredefinedPizzasResult(
    IReadOnlyList<PredefinedPizzaSearchItem> Items,
    int Page,
    int PageSize,
    int TotalCount);
