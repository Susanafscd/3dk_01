namespace LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;

/// <summary>Search term, filter and page of the predefined pizza search (UC-45).</summary>
public sealed record SearchPredefinedPizzasQuery(
    string? Search = null,
    bool? Active = null,
    int Page = 1,
    int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
