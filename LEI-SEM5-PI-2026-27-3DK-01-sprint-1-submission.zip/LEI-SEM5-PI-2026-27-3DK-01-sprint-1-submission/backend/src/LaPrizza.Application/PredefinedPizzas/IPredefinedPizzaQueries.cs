using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas;

/// <summary>
/// Read port of the predefined pizzas (BCK10): the facts a pizza needs from other
/// aggregates — its components (BCK05, BCK08) and the limits of the component
/// types (BCK07) — and the pizza search.
/// </summary>
public interface IPredefinedPizzaQueries
{
    /// <summary>The facts of the products with the given codes; codes that do not exist are left out.</summary>
    Task<IReadOnlyList<PizzaComponentFacts>> GetComponentsAsync(
        IReadOnlyCollection<ProductCode> codes,
        CancellationToken cancellationToken = default);

    /// <summary>The minimum and maximum of every component type.</summary>
    Task<IReadOnlyList<ComponentTypeLimit>> GetComponentTypeLimitsAsync(CancellationToken cancellationToken = default);

    /// <summary>A page of predefined pizzas matching the criteria, ordered by name and then code (UC-45).</summary>
    Task<PredefinedPizzaSearchPage> SearchAsync(
        PredefinedPizzaSearchCriteria criteria,
        CancellationToken cancellationToken = default);
}

/// <summary>What a predefined pizza needs to know about one of its components.</summary>
/// <param name="Name">The product's display name.</param>
/// <param name="IsBaseProduct">Only base products can be pizza components.</param>
/// <param name="CategoryAllowsComponentTypes">The product's category allows component types (BCK03).</param>
/// <param name="ComponentTypeCode">The product's component type (BCK05, BCK07), if any.</param>
/// <param name="AssemblyOrder">The assembly order of the component type (BCK07), if the type exists.</param>
/// <param name="ActiveSizePrices">The price in each size with an active size configuration (BCK08).</param>
public sealed record PizzaComponentFacts(
    ProductCode Code,
    string Name,
    bool IsBaseProduct,
    bool Active,
    bool CategoryAllowsComponentTypes,
    string? ComponentTypeCode,
    int? AssemblyOrder,
    IReadOnlyDictionary<string, decimal> ActiveSizePrices);
