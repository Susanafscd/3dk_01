using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas;

/// <summary>
/// The components, component type limits and sizes of a requested default
/// configuration, resolved against the other aggregates (BCK05 to BCK08).
/// </summary>
internal sealed record ResolvedConfiguration(
    IReadOnlyList<ProductCode> ComponentCodes,
    IReadOnlyList<PizzaComponent> Components,
    IReadOnlyDictionary<ProductCode, PizzaComponentFacts> Facts,
    IReadOnlyList<ComponentTypeLimit> TypeLimits,
    IReadOnlyList<string> SizeIds);

/// <summary>
/// Resolves and checks the references of a default configuration, shared by the
/// use cases that write a pizza (UC-43, UC-46).
/// </summary>
internal static class PredefinedPizzaReferences
{
    /// <exception cref="InvalidProductException">A list is missing or a component code is malformed (400).</exception>
    /// <exception cref="ValidationException">A component or a size does not exist (400).</exception>
    public static async Task<ResolvedConfiguration> ResolveAsync(
        IReadOnlyList<string>? componentCodes,
        IReadOnlyList<string>? sizeIds,
        IPizzaSizeRepository sizes,
        IPredefinedPizzaQueries queries,
        CancellationToken cancellationToken)
    {
        var codes = (componentCodes ?? throw new InvalidProductException("Component codes cannot be null."))
            .Select(ProductCode.Create)
            .ToList();
        var requestedSizes = sizeIds ?? throw new InvalidProductException("Size ids cannot be null.");

        var facts = (await queries.GetComponentsAsync(codes, cancellationToken))
            .ToDictionary(component => component.Code);
        var unknownComponent = codes.FirstOrDefault(code => !facts.ContainsKey(code));
        if (unknownComponent is not null)
        {
            throw new ValidationException($"Product '{unknownComponent.Value}' does not exist.");
        }

        foreach (var sizeId in requestedSizes.Distinct())
        {
            if (string.IsNullOrWhiteSpace(sizeId) || !await sizes.ExistsByName(sizeId, cancellationToken))
            {
                throw new ValidationException($"Size '{sizeId}' does not exist.");
            }
        }

        var typeLimits = await queries.GetComponentTypeLimitsAsync(cancellationToken);
        var components = codes
            .Select(code => facts[code])
            .Select(component => new PizzaComponent(component.Code, component.Active, ComponentTypeOf(component)))
            .ToList();

        return new ResolvedConfiguration(codes, components, facts, typeLimits, requestedSizes);
    }

    /// <summary>The price in each requested size; every component must be configured in it (BR-13, 409).</summary>
    public static List<PredefinedPizzaSizePrice> PricesOrConflict(ResolvedConfiguration configuration) =>
        configuration.SizeIds
            .Distinct()
            .Select(sizeId => new PredefinedPizzaSizePrice(
                sizeId,
                PredefinedPizzaProjection.PriceIn(sizeId, configuration.ComponentCodes.Distinct(), configuration.Facts)
                ?? throw new ConflictException(
                    $"Not every component has an active size configuration for size '{sizeId}'.")))
            .ToList();

    /// <summary>
    /// The component type the configuration rules see: none unless the product is a
    /// base product of a category that allows component types and has a type.
    /// </summary>
    private static string? ComponentTypeOf(PizzaComponentFacts component) =>
        component.IsBaseProduct && component.CategoryAllowsComponentTypes
            ? component.ComponentTypeCode
            : null;
}
