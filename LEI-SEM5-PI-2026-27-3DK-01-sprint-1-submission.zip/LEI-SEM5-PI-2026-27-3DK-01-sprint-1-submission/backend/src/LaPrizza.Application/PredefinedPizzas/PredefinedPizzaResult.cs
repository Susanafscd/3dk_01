namespace LaPrizza.Application.PredefinedPizzas;

/// <summary>
/// A predefined pizza with its default configuration, ordered by the assembly order
/// of the component types, and its price in each available size.
/// </summary>
public sealed record PredefinedPizzaResult(
    string Code,
    string Name,
    string Description,
    string CategoryCode,
    bool Active,
    IReadOnlyList<PredefinedPizzaComponent> DefaultConfiguration,
    IReadOnlyList<PredefinedPizzaSizePrice> Sizes);

/// <summary>One component of the default configuration, in the role given by its component type.</summary>
public sealed record PredefinedPizzaComponent(string ProductCode, string Name, string ComponentTypeCode, int AssemblyOrder);

/// <summary>The derived price of a predefined pizza in one size: the sum of its components' prices there.</summary>
public sealed record PredefinedPizzaSizePrice(string SizeId, decimal Price);
