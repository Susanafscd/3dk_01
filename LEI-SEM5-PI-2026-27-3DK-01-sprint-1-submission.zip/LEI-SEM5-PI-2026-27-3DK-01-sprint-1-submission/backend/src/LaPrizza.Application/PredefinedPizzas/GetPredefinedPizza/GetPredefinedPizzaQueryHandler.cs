using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas.GetPredefinedPizza;

/// <summary>
/// UC-44: retrieves a predefined pizza, inactive ones included, with its default
/// configuration and its price in each available size.
/// </summary>
public sealed class GetPredefinedPizzaQueryHandler(
    IProductRepository products,
    IPredefinedPizzaQueries queries)
{
    public async Task<PredefinedPizzaResult> HandleAsync(
        GetPredefinedPizzaQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = ProductCode.Create(query.ProductCode);
        if (await products.GetByCodeAsync(code, cancellationToken) is not ComposedProduct pizza)
        {
            throw new NotFoundException($"Predefined pizza '{code.Value}' does not exist.");
        }

        var facts = (await queries.GetComponentsAsync(pizza.Components, cancellationToken))
            .ToDictionary(component => component.Code);

        // A stored size is offered only while every component keeps an active size
        // configuration for it (P8); the stored pizza itself does not change.
        var sizes = pizza.AvailableSizes
            .Select(size => (size.SizeName, Price: PredefinedPizzaProjection.PriceIn(size.SizeName, pizza.Components, facts)))
            .Where(size => size.Price is not null)
            .Select(size => new PredefinedPizzaSizePrice(size.SizeName, size.Price!.Value))
            .ToList();

        return PredefinedPizzaProjection.ToResult(pizza, facts, sizes);
    }
}
