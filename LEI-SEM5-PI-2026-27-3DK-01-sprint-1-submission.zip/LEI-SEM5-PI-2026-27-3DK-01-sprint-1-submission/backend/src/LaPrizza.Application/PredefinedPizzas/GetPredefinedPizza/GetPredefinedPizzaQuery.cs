namespace LaPrizza.Application.PredefinedPizzas.GetPredefinedPizza;

/// <summary>Input for UC-44: the business code of the pizza, from the path.</summary>
public sealed record GetPredefinedPizzaQuery(string? ProductCode);
