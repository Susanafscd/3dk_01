namespace LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;

/// <summary>Input for UC-43. Field names match the request body.</summary>
public sealed record CreatePredefinedPizzaCommand(
    string? Code,
    string? Name,
    string? Description,
    string? CategoryCode,
    IReadOnlyList<string>? ComponentCodes,
    IReadOnlyList<string>? SizeIds);
