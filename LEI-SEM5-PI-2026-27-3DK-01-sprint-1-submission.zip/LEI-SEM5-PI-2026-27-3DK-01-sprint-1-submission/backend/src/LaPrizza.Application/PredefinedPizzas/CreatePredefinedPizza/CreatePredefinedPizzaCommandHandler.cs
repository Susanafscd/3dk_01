using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;

/// <summary>UC-43: creates a predefined pizza with its default configuration and available sizes.</summary>
public sealed class CreatePredefinedPizzaCommandHandler(
    IProductRepository products,
    IProductRelationshipQueries relationships,
    IPizzaSizeRepository sizes,
    IPredefinedPizzaQueries queries)
{
    public async Task<PredefinedPizzaResult> HandleAsync(
        CreatePredefinedPizzaCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        // 1. Every referenced category, component and size must exist (400).
        var category = ProductCategoryCode.Create(command.CategoryCode);
        var context = await relationships.GetChangeContextAsync(category, [], cancellationToken: cancellationToken);
        if (!context.CategoryExists)
        {
            throw new ValidationException($"Category '{category.Value}' does not exist.");
        }

        var configuration = await PredefinedPizzaReferences.ResolveAsync(
            command.ComponentCodes, command.SizeIds, sizes, queries, cancellationToken);

        // 2. The composed product applies the configuration rules (409).
        ComposedProduct pizza;
        try
        {
            pizza = ComposedProduct.Create(
                command.Code,
                command.Name,
                command.Description,
                command.CategoryCode,
                configuration.Components,
                configuration.TypeLimits,
                configuration.SizeIds);
        }
        catch (InvalidPizzaConfigurationException exception)
        {
            throw new ConflictException(exception.Message);
        }

        // 3. Every component must be configured in every available size (BR-13, 409).
        var prices = PredefinedPizzaReferences.PricesOrConflict(configuration);

        // 4. Persist atomically. The repository rechecks uniqueness, and the foreign
        // keys the existence of the components and sizes, inside the write.
        try
        {
            await products.AddAndSaveAsync(pizza, cancellationToken);
        }
        catch (DuplicateProductCodeException exception)
        {
            throw new ConflictException(exception.Message);
        }

        return PredefinedPizzaProjection.ToResult(pizza, configuration.Facts, prices);
    }
}
