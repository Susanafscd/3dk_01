﻿namespace LaPrizza.Application.Allergens.CreateAllergen;

/// <summary>The newly registered allergen.</summary>
public sealed record CreateAllergenResult(
    Guid Id,
    string Code,
    string Name,
    string? Description);
