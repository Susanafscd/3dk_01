﻿namespace LaPrizza.Application.Allergens.CreateAllergen;

/// <summary>Input for registering an allergen.</summary>
public sealed record CreateAllergenCommand(
    string? Code,
    string? Name,
    string? Description);
