﻿using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Allergens.CreateAllergen;

/// <summary>Validates and registers an allergen using the allergen repository.</summary>
public sealed class CreateAllergenCommandHandler(
    IAllergenRepository allergens,
    ICatalogueCacheInvalidator catalogueCache)
{
    public async Task<CreateAllergenResult> HandleAsync(
        CreateAllergenCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var allergen = Allergen.Create(
            command.Code,
            command.Name,
            command.Description);

        if (await allergens.GetByCodeAsync(allergen.Code, cancellationToken) is not null)
        {
            throw new ConflictException(
                $"An allergen with code '{allergen.Code.Value}' already exists.");
        }

        try
        {
            await allergens.AddAndSaveAsync(allergen, cancellationToken);
        }
        catch (DuplicateAllergenCodeException exception)
        {
            // The unique index can detect a duplicate inserted after the lookup.
            throw new ConflictException(exception.Message);
        }

        // AddAndSaveAsync returns only after commit. Rejected/failed writes
        // never invalidate projections, and the domain never depends on cache.
        await catalogueCache.InvalidateAllergensAsync(cancellationToken);

        return new CreateAllergenResult(
            allergen.Id,
            allergen.Code.Value,
            allergen.Name,
            allergen.Description);
    }
}
