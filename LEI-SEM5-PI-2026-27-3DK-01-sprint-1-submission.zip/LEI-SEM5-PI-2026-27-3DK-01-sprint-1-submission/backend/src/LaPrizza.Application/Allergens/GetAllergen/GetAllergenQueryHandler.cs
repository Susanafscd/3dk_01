using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Allergens.GetAllergen;

/// <summary>Retrieves one allergen projection by business code.</summary>
public sealed class GetAllergenQueryHandler(
    IAllergenRepository allergens,
    IAllergenCatalogueCache cache)
{
    public async Task<AllergenLookupResult> HandleAsync(
        GetAllergenQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = AllergenCode.Create(query.Code);
        return await cache.GetByCodeAsync(
            code.Value,
            async token =>
            {
                var allergen = await allergens.GetLookupByCodeAsync(code, token);
                return allergen ?? throw new NotFoundException(
                    $"No allergen with code '{code}' was found.");
            },
            cancellationToken);
    }
}
