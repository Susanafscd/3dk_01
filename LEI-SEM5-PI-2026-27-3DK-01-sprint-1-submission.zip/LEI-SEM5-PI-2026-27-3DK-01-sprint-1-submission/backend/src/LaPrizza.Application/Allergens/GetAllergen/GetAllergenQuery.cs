namespace LaPrizza.Application.Allergens.GetAllergen;

/// <summary>Identifies the allergen to retrieve by its business code.</summary>
/// <param name="Code">Immutable allergen business code.</param>
public sealed record GetAllergenQuery(string? Code);
