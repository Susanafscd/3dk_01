using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Allergens.UpdateAllergen;

/// <summary>
/// Coordinates the domain/persistence part of allergen replacement. Transport
/// concerns, including HTTP PUT semantics, belong to the subsequent API task.
/// </summary>
public sealed class UpdateAllergenCommandHandler(
    IAllergenRepository allergens,
    ICatalogueCacheInvalidator cache)
{
    public async Task<UpdateAllergenResult> HandleAsync(
        UpdateAllergenCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = AllergenCode.Create(command.Code);
        var allergen = await allergens.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No allergen with code '{code.Value}' was found.");

        allergen.UpdateDetails(command.Name, command.Description);
        await allergens.UpdateAndSaveAsync(allergen, cancellationToken);
        await cache.InvalidateAllergensAsync(cancellationToken);

        return new UpdateAllergenResult(
            allergen.Id,
            allergen.Code.Value,
            allergen.Name,
            allergen.Description);
    }
}
