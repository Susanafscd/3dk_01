namespace LaPrizza.Application.Allergens.UpdateAllergen;

/// <summary>Details of the allergen after a successful descriptive update.</summary>
public sealed record UpdateAllergenResult(
    Guid Id,
    string Code,
    string Name,
    string? Description);
