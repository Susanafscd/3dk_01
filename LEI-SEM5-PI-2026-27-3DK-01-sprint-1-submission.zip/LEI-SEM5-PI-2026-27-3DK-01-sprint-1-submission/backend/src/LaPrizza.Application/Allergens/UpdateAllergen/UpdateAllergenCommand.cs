namespace LaPrizza.Application.Allergens.UpdateAllergen;

/// <summary>
/// Replacement of the editable descriptive details of an allergen. The code is
/// a lookup key only: it is never changed by this command.
/// </summary>
public sealed record UpdateAllergenCommand(
    string? Code,
    string? Name,
    string? Description);
