using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;

namespace LaPrizza.Application.Allergens.RemoveAllergen;

public sealed record RemoveAllergenCommand(string Code);

public interface IRemoveAllergenUseCase
{
    Task ExecuteAsync(RemoveAllergenCommand command, CancellationToken cancellationToken = default);
}

public sealed class RemoveAllergenCommandHandler(
    IAllergenRepository allergens,
    IAllergenUsageQueries usage,
    ICatalogueCacheInvalidator cache) : IRemoveAllergenUseCase
{
    public async Task ExecuteAsync(
        RemoveAllergenCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = AllergenCode.Create(command.Code);
        var allergen = await allergens.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No allergen with code '{code.Value}' was found.");

        try
        {
            var facts = await usage.GetUsageAsync(code, cancellationToken);
            AllergenRemovalPolicy.EnsureCanRemove(
                facts.HasProductReferences,
                facts.HasDietaryRestrictions,
                facts.HasOtherReferences);
            await allergens.RemoveAsync(allergen, cancellationToken);
        }
        catch (AllergenInUseException exception)
        {
            // The restrictive FK closes the race between the usage read and DELETE.
            throw new ConflictException(exception.Message);
        }
        catch (DomainException exception)
        {
            throw new ConflictException(exception.Message);
        }

        await cache.InvalidateAllergensAsync(cancellationToken);
    }
}
