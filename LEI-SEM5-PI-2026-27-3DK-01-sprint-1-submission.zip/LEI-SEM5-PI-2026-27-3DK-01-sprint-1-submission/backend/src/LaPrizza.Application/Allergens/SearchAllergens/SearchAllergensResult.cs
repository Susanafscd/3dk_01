using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Allergens.SearchAllergens;

public sealed record SearchAllergensResult(
    IReadOnlyList<AllergenSearchItem> Items,
    int Page,
    int PageSize,
    int TotalCount);
