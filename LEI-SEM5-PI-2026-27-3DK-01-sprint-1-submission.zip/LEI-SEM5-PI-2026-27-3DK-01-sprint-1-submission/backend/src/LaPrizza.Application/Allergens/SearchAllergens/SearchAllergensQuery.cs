namespace LaPrizza.Application.Allergens.SearchAllergens;

public sealed record SearchAllergensQuery(
    string? Search = null,
    int Page = 1,
    int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
