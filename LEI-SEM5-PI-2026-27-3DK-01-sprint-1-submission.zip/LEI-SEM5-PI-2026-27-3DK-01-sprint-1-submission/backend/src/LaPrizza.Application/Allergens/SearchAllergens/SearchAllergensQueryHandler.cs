using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Allergens.SearchAllergens;

/// <summary>Validates paging and delegates allergen lookup to the query port.</summary>
public sealed class SearchAllergensQueryHandler(
    IAllergenQueries queries,
    IAllergenCatalogueCache cache)
{
    public async Task<SearchAllergensResult> HandleAsync(
        SearchAllergensQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchAllergensQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchAllergensQuery.MaximumPageSize}.");
        }

        var normalizedSearch = query.Search?.Trim();
        var cacheKey = $"{Uri.EscapeDataString(normalizedSearch?.ToLowerInvariant() ?? string.Empty)}:{query.Page}:{query.PageSize}";

        return await cache.SearchAsync(
            cacheKey,
            async token =>
            {
                var page = await queries.SearchAsync(
                    new AllergenSearchCriteria(normalizedSearch, query.Page, query.PageSize),
                    token);
                return new SearchAllergensResult(page.Items, query.Page, query.PageSize, page.TotalCount);
            },
            cancellationToken);
    }
}
