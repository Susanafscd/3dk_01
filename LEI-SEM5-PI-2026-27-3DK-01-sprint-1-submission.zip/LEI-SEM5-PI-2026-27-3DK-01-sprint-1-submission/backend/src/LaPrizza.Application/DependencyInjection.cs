using LaPrizza.Domain.Products;
using LaPrizza.Application.Allergens.CreateAllergen;
using LaPrizza.Application.Allergens.GetAllergen;
using LaPrizza.Application.Allergens.UpdateAllergen;
using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Application.Catalogue.GetCatalogue;
using LaPrizza.Application.Catalogue.GetCatalogueProduct;
using LaPrizza.Application.ComponentTypes.CreatePizzaSize;
using LaPrizza.Application.ComponentTypes.DeletePizzaSize;
using LaPrizza.Application.ComponentTypes.GetPizzaSize;
using LaPrizza.Application.ComponentTypes.SearchPizzaSizes;
using LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;
using LaPrizza.Application.ComponentTypes.DeletePizzaComponentType;
using LaPrizza.Application.ComponentTypes.GetPizzaComponentType;
using LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;
using LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;
using LaPrizza.Application.Customers.CreateCustomer;
using LaPrizza.Application.Customers.DeactivateCustomer;
using LaPrizza.Application.Customers.GetCustomer;
using LaPrizza.Application.Customers.SearchCustomers;
using LaPrizza.Application.Customers.UpdateCustomer;
using LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;
using LaPrizza.Application.PredefinedPizzas.GetPredefinedPizza;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;
using LaPrizza.Application.ProductCategories.CreateProductCategory;
using LaPrizza.Application.ProductCategories.GetProductCategory;
using LaPrizza.Application.ProductCategories.SearchProductCategories;
using LaPrizza.Application.ProductCategories.RemoveProductCategory;
using LaPrizza.Application.ProductCategories.UpdateProductCategory;
using LaPrizza.Application.Allergens.RemoveAllergen;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Application.SizeConfiguration.CreateSizeConfiguration;
using LaPrizza.Application.SizeConfiguration.ListSizeConfigurations;
using LaPrizza.Application.SizeConfiguration.UpdateSizeConfiguration;
using LaPrizza.Application.Stock.DecreaseStock;
using LaPrizza.Application.Stock.GetProductStock;
using LaPrizza.Application.Stock.IncreaseStock;
using LaPrizza.Application.Stock.SearchStock;
using LaPrizza.Application.Users.CreateUser;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Application.Products.SearchProducts;
using LaPrizza.Application.Products.UpdateProduct;
using LaPrizza.Application.Products.DeactivateProduct;
using Microsoft.Extensions.DependencyInjection;


namespace LaPrizza.Application;

/// <summary>Registers the application layer's use cases.</summary>
public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<CreateUserCommandHandler>();

        services.AddScoped<CreateCustomerCommandHandler>();
        services.AddScoped<GetCustomerQueryHandler>();
        services.AddScoped<SearchCustomersQueryHandler>();
        services.AddScoped<UpdateCustomerCommandHandler>();
        services.AddScoped<DeactivateCustomerCommandHandler>();
        services.AddScoped<CreateProductCategoryCommandHandler>();
        services.AddScoped<GetProductCategoryQueryHandler>();
        services.AddScoped<SearchProductCategoriesQueryHandler>();
        services.AddScoped<IRemoveProductCategoryUseCase, RemoveProductCategoryCommandHandler>();
        services.AddScoped<IUpdateProductCategoryUseCase, UpdateProductCategoryCommandHandler>();
        services.AddScoped<CreateAllergenCommandHandler>();
        services.AddScoped<CreatePizzaComponentTypeCommandHandler>();
        services.AddScoped<GetPizzaComponentTypeQueryHandler>();
        services.AddScoped<UpdatePizzaComponentTypeCommandHandler>();
        services.AddScoped<DeletePizzaComponentTypeCommandHandler>();
        services.AddScoped<SearchPizzaComponentTypesQueryHandler>();
        services.AddScoped<CreatePizzaSizeCommandHandler>();
        services.AddScoped<GetPizzaSizeQueryHandler>();
        services.AddScoped<DeletePizzaSizeCommandHandler>();
        services.AddScoped<SearchPizzaSizesQueryHandler>();

        services.AddScoped<CreateSizeConfigurationCommandHandler>();
        services.AddScoped<ListSizeConfigurationsQueryHandler>();
        services.AddScoped<UpdateSizeConfigurationCommandHandler>();

        services.AddScoped<GetAllergenQueryHandler>();
        services.AddScoped<UpdateAllergenCommandHandler>();
        services.AddScoped<SearchAllergensQueryHandler>();
        services.AddScoped<IRemoveAllergenUseCase, RemoveAllergenCommandHandler>();
        services.AddScoped<UpdateAllergenCommandHandler>();
        services.AddScoped<CreateProductCommandHandler>();
        services.AddScoped<GetProductQueryHandler>();
        services.AddScoped<SearchProductsQueryHandler>();
        services.AddScoped<GetCatalogueQueryHandler>();
        services.AddScoped<GetCatalogueProductQueryHandler>();
        services.AddScoped<IUpdateProductUseCase, UpdateProductCommandHandler>();
        services.AddScoped<IDeactivateProductUseCase, DeactivateProductCommandHandler>();
        services.AddScoped<ProductChangePolicy>();

        services.AddScoped<GetProductStockQueryHandler>();
        services.AddScoped<SearchStockQueryHandler>();
        services.AddScoped<IncreaseStockCommandHandler>();
        services.AddScoped<DecreaseStockCommandHandler>();

        services.AddScoped<CreatePredefinedPizzaCommandHandler>();
        services.AddScoped<GetPredefinedPizzaQueryHandler>();
        services.AddScoped<SearchPredefinedPizzasQueryHandler>();
        services.AddScoped<UpdatePredefinedPizzaCommandHandler>();
        return services;
    }
}
