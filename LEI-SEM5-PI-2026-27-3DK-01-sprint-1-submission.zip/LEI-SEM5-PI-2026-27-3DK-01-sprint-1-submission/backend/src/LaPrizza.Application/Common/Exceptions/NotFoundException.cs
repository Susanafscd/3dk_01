namespace LaPrizza.Application.Common.Exceptions;

/// <summary>Raised when a use case references data that does not exist.</summary>
public sealed class NotFoundException(string message) : Exception(message);
