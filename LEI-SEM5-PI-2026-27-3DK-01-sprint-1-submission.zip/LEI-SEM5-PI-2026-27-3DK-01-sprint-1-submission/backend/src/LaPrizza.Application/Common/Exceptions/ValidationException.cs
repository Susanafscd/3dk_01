namespace LaPrizza.Application.Common.Exceptions;

/// <summary>
/// Raised when a use case receives input it cannot act on, such as an unknown
/// role name or a value that fails a business precondition.
/// </summary>
public sealed class ValidationException(string message) : Exception(message);
