namespace LaPrizza.Application.Common.Exceptions;

/// <summary>
/// Raised when a use case would create a state that conflicts with existing
/// data, such as a duplicate email address.
/// </summary>
public sealed class ConflictException(string message) : Exception(message);
