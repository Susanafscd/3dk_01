using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Application.SizeConfiguration;

/// <summary>
/// One size configuration of a pizza component, ready to be mapped onto a
/// response. A flat read model: the transport layer never depends on the domain
/// aggregate (BCK08).
/// </summary>
/// <param name="SizeId">Identifier of the pizza size the configuration applies to.</param>
/// <param name="Price">Price applicable to the component in a pizza of this size.</param>
/// <param name="StockConsumption">
/// Stock units consumed per pizza of this size, as a whole number; 0 when the
/// product is not stock controlled, where the value has no meaning.
/// </param>
/// <param name="Active">
/// Whether the configuration is applicable. Deactivated configurations are
/// included in consultations, marked as not applicable.
/// </param>
public sealed record SizeConfigurationResult(string SizeId, decimal Price, int StockConsumption, bool Active)
{
    /// <summary>Projects one configured size onto the read model.</summary>
    public static SizeConfigurationResult From(string sizeId, SizeValues values)
    {
        ArgumentNullException.ThrowIfNull(values);

        return new SizeConfigurationResult(sizeId, values.Price, values.StockConsumption, values.Active);
    }
}
