namespace LaPrizza.Application.SizeConfiguration.ListSizeConfigurations;

/// <summary>Consults the size configurations of a pizza component (BCK08).</summary>
/// <param name="ProductId">Identifier of the pizza component whose configurations are consulted.</param>
public sealed record ListSizeConfigurationsQuery(string ProductId);
