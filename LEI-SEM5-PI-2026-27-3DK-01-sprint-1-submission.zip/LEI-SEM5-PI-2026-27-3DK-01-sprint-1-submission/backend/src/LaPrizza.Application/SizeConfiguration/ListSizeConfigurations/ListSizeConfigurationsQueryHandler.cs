using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Product;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Application.SizeConfiguration.ListSizeConfigurations;

/// <summary>
/// Application orchestration for the "consult size configurations" use case (BCK08).
/// A read-only projection of the product's <c>SizeConfiguration</c>, ordered by
/// sizeId. Deactivated configurations are included and marked as not applicable,
/// so the manager can see and reactivate them. The list is not paginated because
/// the number of items is bounded by the number of pizza sizes.
/// </summary>
public sealed class ListSizeConfigurationsQueryHandler(IProductRepository products)
{
    public async Task<IReadOnlyCollection<SizeConfigurationResult>> HandleAsync(
        ListSizeConfigurationsQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var productCode = ProductCodeParser.Parse(query.ProductId);

        var product = await products.GetByCodeAsync(productCode, cancellationToken)
            ?? throw new NotFoundException($"Product '{query.ProductId}' does not exist.");

        // A base product without a configuration — and products of other kinds —
        // simply have no configurations: the consultation is read-only and never
        // turns that absence into an error.
        var mappings = (product as BaseProduct)?.SizeConfiguration?.SizeMappings
            ?? new Dictionary<string, SizeValues>();

        return mappings
            .Select(mapping => SizeConfigurationResult.From(mapping.Key, mapping.Value))
            .OrderBy(item => item.SizeId, StringComparer.Ordinal)
            .ToArray();
    }
}
