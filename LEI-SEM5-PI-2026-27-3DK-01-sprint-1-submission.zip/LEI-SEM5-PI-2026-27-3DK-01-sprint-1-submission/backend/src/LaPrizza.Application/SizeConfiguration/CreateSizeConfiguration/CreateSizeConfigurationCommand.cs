namespace LaPrizza.Application.SizeConfiguration.CreateSizeConfiguration;

/// <summary>
/// Creates one size configuration of a pizza component (BCK08). There must be at
/// most one configuration per (component, size) combination: a deactivated
/// configuration still occupies its size, so the way to make it applicable again
/// is an update, not a new creation.
/// </summary>
/// <param name="ProductId">Identifier of the pizza component to configure.</param>
/// <param name="SizeId">Identifier of an existing pizza size.</param>
/// <param name="Price">The price applicable to the component in a pizza of this size.</param>
/// <param name="StockConsumption">Stock units consumed per pizza of this size, as a whole number.</param>
public sealed record CreateSizeConfigurationCommand(
    string ProductId,
    string SizeId,
    decimal Price,
    int StockConsumption);
