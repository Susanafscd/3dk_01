using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Product;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Application.SizeConfiguration.CreateSizeConfiguration;

/// <summary>
/// Application orchestration for the "create size configuration" use case (BCK08).
/// Loads the product aggregate by its business code, checks that it belongs to a
/// category that allows component types, applies the <see cref="SizeConfiguration"/>
/// value-object operation and commits the unit of work. Only the mapping set
/// grows by one entry: a rejected value never changes the component.
/// </summary>
public sealed class CreateSizeConfigurationCommandHandler(
    IProductRepository products,
    IProductCategoryRepository categories,
    IPizzaSizeRepository sizes,
    IUnitOfWork unitOfWork,
    ICatalogueCacheInvalidator? catalogueCache = null)
{
    public async Task<SizeConfigurationResult> HandleAsync(
        CreateSizeConfigurationCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var productCode = ProductCodeParser.Parse(command.ProductId);

        if (string.IsNullOrWhiteSpace(command.SizeId))
        {
            throw new ValidationException("'sizeId' is required.");
        }

        if (!await sizes.ExistsByName(command.SizeId, cancellationToken))
        {
            throw new ValidationException($"Size '{command.SizeId}' does not exist.");
        }

        var product = await products.GetByCodeAsync(productCode, cancellationToken)
                      ?? throw new NotFoundException($"Product '{command.ProductId}' does not exist.");

        if (product is not BaseProduct component)
        {
            throw new ConflictException(
                $"Product '{product.Code.Value}' is not a pizza component and cannot have size configurations.");
        }

        // Only products of a category that allows component types may be configured.
        var category = await categories.GetLookupByCodeAsync(component.CategoryCode, cancellationToken);
        if (category is null || !category.AllowsComponentTypes)
        {
            throw new ConflictException(
                $"Product '{component.Code.Value}' is not a pizza component and cannot have size configurations.");
        }

        var sizeId = command.SizeId;

        if (component.SizeConfiguration is not null && component.SizeConfiguration.ContainsSize(sizeId))
        {
            // Optionally the configuration exists but is deactivated: either way
            // the (component, size) combination is occupied. Reactivation is an
            // update, never a re-creation.
            throw new ConflictException(
                $"Product '{component.Code.Value}' already has a size configuration for size '{sizeId}'.");
        }

        Domain.SizeConfigurations.SizeConfiguration updated;
        try
        {
            updated = (component.SizeConfiguration ?? Domain.SizeConfigurations.SizeConfiguration.Empty)
                .AddSizeConfiguration(
                    sizeId,
                    command.Price,
                    command.StockConsumption);
        }
        catch (DomainException exception)
        {
            // A rejected value is the caller's mistake and yields a bad request;
            // the (component, size) conflicts above are the explicit 409s.
            throw new ValidationException(exception.Message);
        }

        component.SetSizeConfiguration(updated);

        await unitOfWork.SaveChangesAsync(cancellationToken);

        // The stored projection of the component changed; invalidate so no stale
        // catalogue or detail view keeps serving the previous configuration.
        if (catalogueCache is not null)
        {
            await catalogueCache.InvalidateProductsAsync(cancellationToken);
        }

        return SizeConfigurationResult.From(sizeId, updated.SizeMappings[sizeId]);
    }
}
