namespace LaPrizza.Application.SizeConfiguration.UpdateSizeConfiguration;

/// <summary>
/// Updates one size configuration of a pizza component (BCK08). The size
/// association is not changed; a <c>null</c> <c>Active</c> keeps the current
/// value. It never creates a configuration: a size the component does not have
/// configured returns not-found.
/// </summary>
/// <param name="ProductId">Identifier of the pizza component being configured.</param>
/// <param name="SizeId">Identifier of the existing configuration to update.</param>
/// <param name="Price">The new price applicable to the component in a pizza of this size.</param>
/// <param name="StockConsumption">The new stock units consumed per pizza of this size, as a whole number.</param>
/// <param name="Active">Deactivate/reactivate the configuration; null keeps the current value.</param>
public sealed record UpdateSizeConfigurationCommand(
    string ProductId,
    string SizeId,
    decimal Price,
    int StockConsumption,
    bool? Active);
