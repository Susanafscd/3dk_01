using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Product;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Application.SizeConfiguration.UpdateSizeConfiguration;

/// <summary>
/// Application orchestration for the "update size configuration" use case (BCK08).
/// Loads the product aggregate by its business code, applies the
/// <see cref="SizeConfiguration"/> value-object operation and commits the unit of
/// work. Invalid values are rejected by the domain invariant guards and leave the
/// previous values in place; updating a size the component does not have
/// configured does not create one.
/// </summary>
public sealed class UpdateSizeConfigurationCommandHandler(
    IProductRepository products,
    IProductCategoryRepository categories,
    IPizzaSizeRepository sizes,
    IUnitOfWork unitOfWork,
    ICatalogueCacheInvalidator? catalogueCache = null)
{
    public async Task<SizeConfigurationResult> HandleAsync(
        UpdateSizeConfigurationCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var productCode = ProductCodeParser.Parse(command.ProductId);

        if (string.IsNullOrWhiteSpace(command.SizeId))
        {
            throw new ValidationException("'sizeId' is required.");
        }

        if (!await sizes.ExistsByName(command.SizeId, cancellationToken))
        {
            throw new ValidationException($"Size '{command.SizeId}' does not exist.");
        }

        var product = await products.GetByCodeAsync(productCode, cancellationToken)
                      ?? throw new NotFoundException($"Product '{command.ProductId}' does not exist.");

        if (product is not BaseProduct component)
        {
            throw new ConflictException(
                $"Product '{product.Code.Value}' is not a pizza component and cannot have size configurations.");
        }

        var category = await categories.GetLookupByCodeAsync(component.CategoryCode, cancellationToken);
        if (category is null || !category.AllowsComponentTypes)
        {
            throw new ConflictException(
                $"Product '{component.Code.Value}' is not a pizza component and cannot have size configurations.");
        }

        var sizeId = command.SizeId;

        if (component.SizeConfiguration is null || !component.SizeConfiguration.ContainsSize(sizeId))
        {
            // Updates never create: a size without a configuration stays
            // unconfigured, active or not.
            throw new NotFoundException(
                $"Product '{component.Code.Value}' has no size configuration for size '{sizeId}'.");
        }

        Domain.SizeConfigurations.SizeConfiguration updated;
        try
        {
            updated = component.SizeConfiguration.UpdateSizeConfiguration(
                sizeId,
                command.Price,
                command.StockConsumption,
                command.Active);
        }
        catch (DomainException exception)
        {
            // A rejected value: the previous values are preserved.
            throw new ValidationException(exception.Message);
        }

        component.SetSizeConfiguration(updated);

        await unitOfWork.SaveChangesAsync(cancellationToken);

        // The stored projection of the component changed; invalidate so no stale
        // catalogue or detail view keeps serving the previous configuration.
        if (catalogueCache is not null)
        {
            await catalogueCache.InvalidateProductsAsync(cancellationToken);
        }

        return SizeConfigurationResult.From(sizeId, updated.SizeMappings[sizeId]);
    }
}
