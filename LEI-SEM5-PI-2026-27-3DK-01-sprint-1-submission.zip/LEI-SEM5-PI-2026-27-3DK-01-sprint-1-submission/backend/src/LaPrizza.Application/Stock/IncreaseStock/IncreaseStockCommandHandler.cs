using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Stock.IncreaseStock;

/// <summary>
/// Increases the stock of one product (UC-41). The <c>Product</c> decides whether
/// the increase is allowed; the store then applies it as one atomic conditional
/// update, and the result carries the balance actually stored, so it stays right
/// under concurrent changes. Inactive products may be increased (P8).
/// </summary>
public sealed class IncreaseStockCommandHandler(IProductRepository products, IStockRepository stock)
{
    public async Task<ProductStockResult> HandleAsync(
        IncreaseStockCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = ProductCode.Create(command.ProductCode);
        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code}' was found.");

        try
        {
            product.IncreaseStock(command.Units);
        }
        catch (StockChangeRejectedException exception)
        {
            throw new ConflictException(exception.Message);
        }

        var stored = await stock.IncreaseAsync(product.Id, command.Units, cancellationToken)
            ?? throw new ConflictException(
                $"The stock of product '{code}' changed concurrently and was not increased.");

        return new ProductStockResult(product.Code.Value, product.Name, product.Active, stored);
    }
}
