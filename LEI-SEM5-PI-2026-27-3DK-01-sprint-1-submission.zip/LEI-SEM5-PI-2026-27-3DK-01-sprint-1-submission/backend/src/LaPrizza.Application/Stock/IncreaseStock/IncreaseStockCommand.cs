namespace LaPrizza.Application.Stock.IncreaseStock;

/// <summary>Adds abstract stock units to one product, identified by its business code (UC-41).</summary>
/// <param name="ProductCode">Immutable product business code.</param>
/// <param name="Units">Positive integer number of stock units to add.</param>
public sealed record IncreaseStockCommand(string? ProductCode, int Units);
