namespace LaPrizza.Application.Stock;

/// <summary>Current stock of a stock-controlled product, in abstract stock units (BCK09).</summary>
public sealed record ProductStockResult(
    string ProductCode,
    string ProductName,
    bool Active,
    int QuantityInStock);
