namespace LaPrizza.Application.Stock.DecreaseStock;

/// <summary>Removes abstract stock units from one product, identified by its business code (UC-42).</summary>
/// <param name="ProductCode">Immutable product business code.</param>
/// <param name="Units">Positive integer number of stock units to remove.</param>
public sealed record DecreaseStockCommand(string? ProductCode, int Units);
