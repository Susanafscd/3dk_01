using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Stock.DecreaseStock;

/// <summary>
/// Decreases the stock of one product (UC-42), the generic operation ordering can
/// reuse later (AC-10). The <c>Product</c> decides whether the decrease is
/// allowed; the store then applies it as one atomic conditional update that never
/// makes the stock negative, and the result carries the balance actually stored.
/// Inactive products may be decreased (P8).
/// </summary>
public sealed class DecreaseStockCommandHandler(IProductRepository products, IStockRepository stock)
{
    public async Task<ProductStockResult> HandleAsync(
        DecreaseStockCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = ProductCode.Create(command.ProductCode);
        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code}' was found.");

        try
        {
            product.DecreaseStock(command.Units);
        }
        catch (StockChangeRejectedException exception)
        {
            throw new ConflictException(exception.Message);
        }

        var stored = await stock.DecreaseAsync(product.Id, command.Units, cancellationToken)
            ?? throw new ConflictException(
                $"The stock of product '{code}' changed concurrently and was not decreased.");

        return new ProductStockResult(product.Code.Value, product.Name, product.Active, stored);
    }
}
