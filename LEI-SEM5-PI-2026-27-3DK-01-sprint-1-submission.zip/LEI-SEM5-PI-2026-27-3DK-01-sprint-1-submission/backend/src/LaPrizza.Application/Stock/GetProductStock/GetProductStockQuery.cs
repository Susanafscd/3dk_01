namespace LaPrizza.Application.Stock.GetProductStock;

/// <summary>Identifies the product whose stock is retrieved, by its business code (UC-39).</summary>
/// <param name="ProductCode">Immutable product business code.</param>
public sealed record GetProductStockQuery(string? ProductCode);
