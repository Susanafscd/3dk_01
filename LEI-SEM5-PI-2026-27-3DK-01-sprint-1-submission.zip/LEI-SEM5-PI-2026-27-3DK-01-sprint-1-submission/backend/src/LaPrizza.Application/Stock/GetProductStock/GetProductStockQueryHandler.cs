using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Stock.GetProductStock;

/// <summary>
/// Retrieves the stock of one product (UC-39). The stock is read from PostgreSQL
/// on every request and never cached (ADR-002); inactive products are returned too.
/// </summary>
public sealed class GetProductStockQueryHandler(IProductRepository products)
{
    public async Task<ProductStockResult> HandleAsync(
        GetProductStockQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = ProductCode.Create(query.ProductCode);
        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code}' was found.");

        if (!product.StockControlled || product.StockBalance is not { } quantity)
        {
            throw new ConflictException($"Product '{code}' is not stock-controlled.");
        }

        return new ProductStockResult(product.Code.Value, product.Name, product.Active, quantity);
    }
}
