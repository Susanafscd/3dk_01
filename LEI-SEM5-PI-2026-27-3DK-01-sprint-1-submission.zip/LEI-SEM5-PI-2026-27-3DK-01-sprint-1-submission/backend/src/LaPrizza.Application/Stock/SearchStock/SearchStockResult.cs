using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Stock.SearchStock;

public sealed record SearchStockResult(
    IReadOnlyList<StockSearchItem> Items,
    int Page,
    int PageSize,
    int TotalCount);
