namespace LaPrizza.Application.Stock.SearchStock;

/// <summary>Search term, filters and page of the stock search (UC-40).</summary>
public sealed record SearchStockQuery(
    string? Search = null,
    string? CategoryCode = null,
    bool? Active = null,
    int Page = 1,
    int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
