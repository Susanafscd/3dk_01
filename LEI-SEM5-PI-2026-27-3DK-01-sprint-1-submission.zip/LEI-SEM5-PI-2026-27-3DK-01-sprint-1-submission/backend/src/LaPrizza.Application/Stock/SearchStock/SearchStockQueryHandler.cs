using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Stock.SearchStock;

/// <summary>
/// Validates the stock search input and delegates the read to the stock query
/// port (UC-40), as the product search of BCK05 does.
/// </summary>
public sealed class SearchStockQueryHandler(IStockQueries queries)
{
    public async Task<SearchStockResult> HandleAsync(
        SearchStockQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchStockQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchStockQuery.MaximumPageSize}.");
        }

        var criteria = new StockSearchCriteria(
            query.Search,
            string.IsNullOrWhiteSpace(query.CategoryCode) ? null : ProductCategoryCode.Create(query.CategoryCode.Trim()),
            query.Active,
            query.Page,
            query.PageSize);

        var page = await queries.SearchAsync(criteria, cancellationToken);
        return new SearchStockResult(page.Items, query.Page, query.PageSize, page.TotalCount);
    }
}
