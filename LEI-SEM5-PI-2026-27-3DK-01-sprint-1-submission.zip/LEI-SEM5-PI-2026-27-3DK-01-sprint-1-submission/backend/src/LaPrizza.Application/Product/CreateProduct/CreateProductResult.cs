namespace LaPrizza.Application.Products.CreateProduct;

/// <summary>Response shape. UC-24 returns the same shape.</summary>
public sealed record CreateProductResult(
    Guid Id,
    string Code,
    string Name,
    string Description,
    string CategoryCode,
    bool Sellable,
    decimal? Price,
    bool StockControlled,
    int? StockBalance,
    bool Active,
    IReadOnlyCollection<string> AllergenCodes,
    string? ComponentTypeCode = null);
