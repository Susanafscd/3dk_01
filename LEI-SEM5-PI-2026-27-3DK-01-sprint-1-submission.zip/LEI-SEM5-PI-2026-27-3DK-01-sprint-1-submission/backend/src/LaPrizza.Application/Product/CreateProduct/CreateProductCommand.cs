namespace LaPrizza.Application.Products.CreateProduct;

/// <summary>Input for UC-23. Field names match the request body.</summary>
public sealed record CreateProductCommand(
    string? Code,
    string? Name,
    string? Description,
    string? CategoryCode,
    bool Sellable,
    bool StockControlled,
    decimal? Price,
    IReadOnlyList<string>? AllergenCodes,
    string? ComponentTypeCode = null);
