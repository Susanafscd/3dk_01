using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.CreateProduct;

public sealed class CreateProductCommandHandler(
    IProductRepository products,
    IProductRelationshipQueries relationships,
    ProductChangePolicy policy,
    ICatalogueCacheInvalidator cache)
{
    public async Task<CreateProductResult> HandleAsync(
        CreateProductCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        // PostgreSQL persists numeric(18,2); reject precision loss rather than rounding silently.
        if (command.Price is { } amount &&
            (decimal.Round(amount, 2) != amount || amount > 9999999999999999.99m))
        {
            throw new InvalidProductException("Price must fit numeric(18,2) without rounding.");
        }

        // 1. Parse the references so they can be checked against persisted facts.
        var category = ProductCategoryCode.Create(command.CategoryCode);
        var componentType = command.ComponentTypeCode is null
            ? null
            : PizzaComponentTypeCode.Create(command.ComponentTypeCode);
        var allergens = (command.AllergenCodes ?? throw new InvalidProductException("Allergen codes cannot be null."))
            .Select(AllergenCode.Create)
            .ToList();

        if (allergens.Distinct().Count() != allergens.Count)
        {
            throw new InvalidProductException("Allergen codes must be distinct.");
        }

        // 2. Check references against current persisted facts.
        var context = await relationships.GetChangeContextAsync(
            category, allergens, componentType, cancellationToken);

        // 3. Apply the reference rules, then build the product. The builder validates everything else.
        policy.EnsureReferencesAreValid(context);

        var product = new BaseProductBuilder()
            .WithCode(command.Code)
            .WithName(command.Name)
            .WithDescription(command.Description)
            .InCategory(command.CategoryCode)
            .AsSellable(command.Sellable)
            .WithPrice(command.Price)
            .StockControlled(command.StockControlled)
            .WithAllergens(command.AllergenCodes)
            .WithComponentTypeCode(componentType?.Value)
            .Build();

        // 4. Persist atomically. The repository rechecks uniqueness inside the write.
        try
        {
            await products.AddAndSaveAsync(product, cancellationToken);
        }
        catch (DuplicateProductCodeException exception)
        {
            throw new ConflictException(exception.Message);
        }

        // 5. The transaction has committed: cached product projections can now be invalidated.
        await cache.InvalidateProductsAsync(cancellationToken);

        return ToResult(product);
    }

    private static CreateProductResult ToResult(BaseProduct product) => new(
        product.Id,
        product.Code.Value,
        product.Name,
        product.Description,
        product.CategoryCode.Value,
        product.IsSellable,
        product.Sellable?.Price.Amount,
        product.StockControlled,
        product.StockBalance,
        product.Active,
        product.Allergens.Select(a => a.Value).ToList(),
        product.ComponentTypeCode);
}
