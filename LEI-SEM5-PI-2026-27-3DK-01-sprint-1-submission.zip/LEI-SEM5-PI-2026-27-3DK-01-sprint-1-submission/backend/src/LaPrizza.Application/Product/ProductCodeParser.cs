using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Product;

/// <summary>
/// Parses the<c>'productId'</c> path segment shared by the size-configuration
/// use cases (BCK08): it is the product's business code, which is never
/// normalised, so a badly written code is rejected as the caller's mistake.
/// </summary>
internal static class ProductCodeParser
{
    public static ProductCode Parse(string? productId)
    {
        if (string.IsNullOrWhiteSpace(productId))
        {
            throw new ValidationException("'productId' is required.");
        }

        try
        {
            return ProductCode.Create(productId);
        }
        catch (InvalidProductException exception)
        {
            throw new ValidationException(exception.Message);
        }
    }
}
