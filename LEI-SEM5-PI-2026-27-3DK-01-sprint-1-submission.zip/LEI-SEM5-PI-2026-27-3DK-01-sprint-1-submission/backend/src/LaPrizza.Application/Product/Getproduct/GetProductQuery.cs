namespace LaPrizza.Application.Products.GetProduct;

/// <summary>Identifies the product to retrieve by its business code.</summary>
/// <param name="Code">Immutable product business code.</param>
public sealed record GetProductQuery(string? Code);
