using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.GetProduct;

/// <summary>Retrieves a product projection by its immutable business code.</summary>
public sealed class GetProductQueryHandler(
    IProductRepository products,
    IProductCatalogueCache? cache = null)
{
    public async Task<ProductLookupResult> HandleAsync(
        GetProductQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = ProductCode.Create(query.Code);
        Task<ProductLookupResult> Load(CancellationToken token) => LoadAsync(code, token);

        return cache is null
            ? await Load(cancellationToken)
            : await cache.GetByCodeAsync(code.Value, Load, cancellationToken);
    }

    private async Task<ProductLookupResult> LoadAsync(
        ProductCode code,
        CancellationToken cancellationToken)
    {
        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code}' was found.");

        return new ProductLookupResult(
            product.Id,
            product.Code.Value,
            product.Name,
            product.Description,
            product is BaseProduct ? "Base" : "Composed",
            product.CategoryCode.Value,
            product.IsSellable,
            product.Sellable?.Price.Amount,
            product.ComponentTypeCode,
            product.ComponentTypeCode is not null,
            product.StockControlled,
            product.StockBalance,
            product.Active,
            product.Allergens.Select(a => a.Value).OrderBy(value => value).ToList());
    }
}
