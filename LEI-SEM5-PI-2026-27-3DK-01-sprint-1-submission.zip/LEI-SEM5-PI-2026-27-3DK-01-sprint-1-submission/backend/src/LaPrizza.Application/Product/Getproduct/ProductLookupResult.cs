namespace LaPrizza.Application.Products.GetProduct;

/// <summary>
/// Read-only product projection returned by the repository lookup.
/// </summary>
public sealed record ProductLookupResult(
    Guid Id,
    string Code,
    string Name,
    string Description,
    string Kind,
    string CategoryCode,
    bool Sellable,
    decimal? Price,
    string? ComponentTypeCode,
    bool IsPizzaComponent,
    bool StockControlled,
    int? StockBalance,
    bool Active,
    IReadOnlyCollection<string> AllergenCodes);
