namespace LaPrizza.Application.Customers.UpdateCustomer;

/// <summary>
/// Everything the "update customer" use case needs. The email is the customer's
/// login identifier, so it is not changed here: only the profile and contact
/// details a manager maintains.
/// </summary>
/// <param name="Id">Unique identifier of the customer to update.</param>
/// <param name="Name">New customer name.</param>
/// <param name="PhoneNumber">Required new contact phone number.</param>
/// <param name="VATNumber">Optional VAT identification number; null clears it.</param>
public sealed record UpdateCustomerCommand(
    Guid Id,
    string Name,
    string PhoneNumber,
    string? VATNumber = null);
