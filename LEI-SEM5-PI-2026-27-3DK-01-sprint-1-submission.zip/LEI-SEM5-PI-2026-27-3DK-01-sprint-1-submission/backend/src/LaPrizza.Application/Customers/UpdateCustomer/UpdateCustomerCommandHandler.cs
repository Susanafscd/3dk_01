using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers.UpdateCustomer;

/// <summary>
/// Application controller orchestration for the "update customer" use case. It
/// loads the aggregate, applies the new profile and contact data through the
/// domain behaviour and commits the unit of work.
/// </summary>
public sealed class UpdateCustomerCommandHandler(
    IUserRepository users)
{
    public async Task<CustomerResult> HandleAsync(
        UpdateCustomerCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var user = await users.GetByIdAsync(command.Id, cancellationToken);

        if (user is not Customer customer)
        {
            throw new NotFoundException($"No customer with id '{command.Id}' was found.");
        }

        customer.ChangeName(command.Name);
        customer.ChangePhoneNumber(command.PhoneNumber);
        customer.ChangeVATNumber(command.VATNumber);
        // The customer's name is also the display name of the person, so keep
        // the two in step.
        customer.Rename(command.Name);

        await users.UpdateAsync(customer, cancellationToken);

        return CustomerResult.From(customer);
    }
}
