using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Allergens;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers.CreateCustomer;

/// <summary>
/// Application controller orchestration for the "create customer" use case. It
/// validates the identifying data, builds the <see cref="Customer"/> aggregate,
/// provisions the authentication account behind it and persists both, undoing
/// the account if the aggregate cannot be stored.
/// </summary>
public sealed class CreateCustomerCommandHandler(
    IUserRepository users,
    IAllergenRepository allergenRepo,
    IUserAccountManager accounts)
{
    public async Task<CustomerResult> HandleAsync(
        CreateCustomerCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);
        _ = allergenRepo;

        var email = Email.Create(command.Email);

        if (await users.ExistsByEmailAsync(email, cancellationToken))
        {
            throw new ConflictException($"A user with email '{email.Value}' already exists.");
        }

        var dietaryRestrictions = (command.DietaryRestrictions ?? [])
            .Select(name => DietaryRestriction.Create(name));

        // The customer's name is both its profile name and the display name of
        // the person behind the account, so the two stay in step.
        var customer = Customer.Create(email, command.Name, command.Name, dietaryRestrictions, command.PhoneNumber, command.VATNumber);

        // Credentials are infrastructure, not domain (MD-06), so they are created
        // through the account manager before the aggregate is persisted.
        var accountId = await accounts.CreateAccountAsync(email.Value, command.Password, cancellationToken);

        try
        {
            await users.AddAsync(customer, cancellationToken);
        }
        catch
        {
            // The two stores are not in one transaction: undo the account so a
            // failed creation does not leave a login without a customer.
            await accounts.DeleteAccountAsync(accountId, cancellationToken);
            throw;
        }

        return CustomerResult.From(customer);
    }
}
