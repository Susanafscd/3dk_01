using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Customers.CreateCustomer;

/// <summary>
/// Everything the "create customer" use case needs. It is the application
/// contract: the transport layer maps its own request shape onto it.
/// </summary>
/// <param name="Name">Customer name.</param>
/// <param name="Email">Unique contact email, also the login identifier.</param>
/// <param name="PhoneNumber">Required contact phone number.</param>
/// <param name="VATNumber">Optional VAT identification number.</param>
/// <param name="Password">Initial credential, handled by the account manager.</param>
/// /// <param name="DietaryRestrictions">Dietary restrictions list.</param>
public sealed record CreateCustomerCommand(
    string Name,
    string Email,
    string PhoneNumber,
    string Password,
    IReadOnlyCollection<string> DietaryRestrictions,
    string? VATNumber = null);
