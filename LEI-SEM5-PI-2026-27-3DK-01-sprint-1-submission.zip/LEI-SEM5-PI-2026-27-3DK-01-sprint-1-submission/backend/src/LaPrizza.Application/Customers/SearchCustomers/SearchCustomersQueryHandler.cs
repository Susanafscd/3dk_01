using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers.SearchCustomers;

/// <summary>
/// Searches customers by the identifying information they carry. The actual
/// matching is delegated to the repository, which owns the query translation.
/// </summary>
public sealed class SearchCustomersQueryHandler(IUserRepository users)
{
    public async Task<IReadOnlyList<CustomerResult>> HandleAsync(
        SearchCustomersQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var customers = await users.SearchCustomersAsync(query.Search, cancellationToken);

        return [.. customers.Select(CustomerResult.From)];
    }
}
