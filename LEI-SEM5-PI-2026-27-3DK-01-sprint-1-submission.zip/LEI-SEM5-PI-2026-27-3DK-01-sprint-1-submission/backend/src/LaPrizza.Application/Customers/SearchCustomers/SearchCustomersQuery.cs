namespace LaPrizza.Application.Customers.SearchCustomers;

/// <summary>
/// Query for the customer search. Searching is a query concern, not a domain
/// concept (MD-10), so it lives in the application layer and is served by the
/// repository.
/// </summary>
/// <param name="Search">
/// Term matched against the customer's name, email and phone number. When it is
/// absent or blank, every customer is returned.
/// </param>
public sealed record SearchCustomersQuery(string? Search);
