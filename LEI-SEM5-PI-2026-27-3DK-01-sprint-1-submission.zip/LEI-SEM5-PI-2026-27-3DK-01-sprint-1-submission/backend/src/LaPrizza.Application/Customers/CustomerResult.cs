using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers;

/// <summary>
/// The customer data every customer use case returns, ready to be mapped onto a
/// response. It is deliberately a flat read model: the transport layer never
/// depends on the domain aggregate.
/// </summary>
/// <param name="Id">Unique identifier of the customer.</param>
/// <param name="Name">Customer name.</param>
/// <param name="Email">Contact email, also the customer's login identifier.</param>
/// <param name="PhoneNumber">Contact phone number, when present.</param>
/// <param name="VATNumber">Optional VAT identification number.</param>
/// <param name="Active">Whether the customer can currently be used.</param>
public sealed record CustomerResult(
    Guid Id,
    string Name,
    string Email,
    string PhoneNumber,
    string? VATNumber,
    bool Active,
    IEnumerable<DietaryRestriction> DietaryRestrictions)
{
    /// <summary>Projects a customer aggregate onto the read model.</summary>
    public static CustomerResult From(Customer customer)
    {
        ArgumentNullException.ThrowIfNull(customer);

        return new CustomerResult(
            customer.Id,
            customer.Name,
            customer.Email.Value,
            customer.PhoneNumber.Value,
            customer.VATNumber?.Value,
            customer.Active,
            customer.DietaryRestrictions);
    }
}
