using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers.GetCustomer;

/// <summary>Reads a single customer by its unique identifier.</summary>
public sealed class GetCustomerQueryHandler(IUserRepository users)
{
    public async Task<CustomerResult> HandleAsync(
        GetCustomerQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var user = await users.GetByIdAsync(query.Id, cancellationToken);

        if (user is not Customer customer)
        {
            throw new NotFoundException($"No customer with id '{query.Id}' was found.");
        }

        return CustomerResult.From(customer);
    }
}
