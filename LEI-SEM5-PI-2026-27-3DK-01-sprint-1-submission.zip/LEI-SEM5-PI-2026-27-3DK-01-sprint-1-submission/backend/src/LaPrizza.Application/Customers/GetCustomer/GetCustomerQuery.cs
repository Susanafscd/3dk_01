namespace LaPrizza.Application.Customers.GetCustomer;

/// <summary>Identifies the customer to read.</summary>
/// <param name="Id">Unique identifier of the customer.</param>
public sealed record GetCustomerQuery(Guid Id);
