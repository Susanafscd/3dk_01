namespace LaPrizza.Application.Customers.DeactivateCustomer;

/// <summary>
/// Everything the "deactivate customer" use case needs. Customers are never
/// hard-deleted: deactivation keeps the record so references to it stay
/// consistent.
/// </summary>
/// <param name="Id">Unique identifier of the customer to deactivate.</param>
public sealed record DeactivateCustomerCommand(Guid Id);
