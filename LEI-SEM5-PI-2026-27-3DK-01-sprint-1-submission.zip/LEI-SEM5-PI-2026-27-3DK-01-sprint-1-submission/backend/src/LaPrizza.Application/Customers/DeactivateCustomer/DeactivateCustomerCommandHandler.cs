using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Customers.DeactivateCustomer;

/// <summary>
/// Application controller orchestration for the "deactivate customer" use case.
/// The customer is marked inactive instead of being deleted, so any business
/// information that references it keeps its consistency.
/// </summary>
public sealed class DeactivateCustomerCommandHandler(
    IUserRepository users)
{
    public async Task HandleAsync(
        DeactivateCustomerCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var user = await users.GetByIdAsync(command.Id, cancellationToken);

        if (user is not Customer customer)
        {
            throw new NotFoundException($"No customer with id '{command.Id}' was found.");
        }

        // Deactivating twice has no effect, so the operation is idempotent.
        if (!customer.Active)
        {
            return;
        }

        customer.Deactivate();
        await users.UpdateAsync(customer, cancellationToken);
    }
}
