namespace LaPrizza.Application.ProductCategories;

/// <summary>
/// Inward-facing query port for read-only product-category catalogue queries.
/// Implementations may use database-specific query translation, but callers
/// only depend on the application read model.
/// </summary>
public interface IProductCategoryQueries
{
    /// <summary>
    /// Searches by exact business code or by a case-insensitive name fragment,
    /// orders by name and code, and returns one page plus the unpaged count.
    /// </summary>
    Task<ProductCategorySearchPage> SearchAsync(
        string? search,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);
}
