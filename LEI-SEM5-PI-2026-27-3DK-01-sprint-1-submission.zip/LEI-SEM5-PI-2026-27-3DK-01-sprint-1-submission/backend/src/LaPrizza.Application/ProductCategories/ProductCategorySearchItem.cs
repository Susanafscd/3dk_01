namespace LaPrizza.Application.ProductCategories;

/// <summary>
/// Read-only category projection exposed by catalogue queries. The business
/// code is the public identity; the persistence id is intentionally omitted.
/// </summary>
public sealed record ProductCategorySearchItem(
    string Code,
    string Name,
    string? Description,
    bool AllowsComponentTypes);
