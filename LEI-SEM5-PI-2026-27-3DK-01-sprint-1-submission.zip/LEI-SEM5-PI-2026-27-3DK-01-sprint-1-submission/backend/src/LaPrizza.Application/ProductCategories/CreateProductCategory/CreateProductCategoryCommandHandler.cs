using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ProductCategories.CreateProductCategory;

/// <summary>Validates and registers a product category using the category repository.</summary>
public sealed class CreateProductCategoryCommandHandler(
    IProductCategoryRepository categories,
    ICatalogueCacheInvalidator? catalogueCache = null)
{
    public async Task<CreateProductCategoryResult> HandleAsync(
        CreateProductCategoryCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var category = ProductCategory.Create(
            command.Code,
            command.Name,
            command.Description,
            command.AllowsComponentTypes);

        if (await categories.GetByCodeAsync(category.Code, cancellationToken) is not null)
        {
            throw new ConflictException(
                $"A product category with code '{category.Code.Value}' already exists.");
        }

        try
        {
            await categories.AddAsync(category, cancellationToken);
        }
        catch (DuplicateProductCategoryCodeException exception)
        {
            // The unique index can detect a duplicate inserted after the lookup.
            throw new ConflictException(exception.Message);
        }

        if (catalogueCache is not null)
        {
            await catalogueCache.InvalidateProductCategoriesAsync(cancellationToken);
        }

        return new CreateProductCategoryResult(
            category.Id,
            category.Code.Value,
            category.Name,
            category.Description,
            category.AllowsComponentTypes);
    }
}
