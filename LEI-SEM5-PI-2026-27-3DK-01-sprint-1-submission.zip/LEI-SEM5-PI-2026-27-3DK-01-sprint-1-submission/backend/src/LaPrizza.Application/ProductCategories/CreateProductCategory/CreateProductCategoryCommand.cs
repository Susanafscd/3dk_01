namespace LaPrizza.Application.ProductCategories.CreateProductCategory;

/// <summary>Input for registering a product category through UC-13.</summary>
public sealed record CreateProductCategoryCommand(
    string? Code,
    string? Name,
    string? Description,
    bool AllowsComponentTypes);
