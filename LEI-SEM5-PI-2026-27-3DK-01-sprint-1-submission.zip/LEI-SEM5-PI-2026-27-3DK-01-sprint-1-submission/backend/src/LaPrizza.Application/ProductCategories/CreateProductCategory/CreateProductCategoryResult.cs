namespace LaPrizza.Application.ProductCategories.CreateProductCategory;

/// <summary>The newly registered category.</summary>
public sealed record CreateProductCategoryResult(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    bool AllowsComponentTypes);
