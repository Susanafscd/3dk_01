namespace LaPrizza.Application.ProductCategories.UpdateProductCategory;

public sealed record UpdateProductCategoryCommand(string Code, string Name, string? Description, bool AllowsComponentTypes);

/// <summary>Complete workflow boundary: implementations must protect usage checks and commit atomically,
/// then invalidate affected caches. No production implementation is registered yet.</summary>
public interface IUpdateProductCategoryUseCase
{
    Task<LaPrizza.Domain.ProductCategories.ProductCategoryLookupResult> ExecuteAsync(UpdateProductCategoryCommand command, CancellationToken cancellationToken = default);
}
