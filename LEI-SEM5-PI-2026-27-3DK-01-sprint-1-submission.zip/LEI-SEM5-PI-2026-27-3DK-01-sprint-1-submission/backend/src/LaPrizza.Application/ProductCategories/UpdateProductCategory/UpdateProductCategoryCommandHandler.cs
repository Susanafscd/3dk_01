using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ProductCategories.UpdateProductCategory;

/// <summary>
/// Replaces the editable details of a product category. Its business code is
/// immutable and component-type references are checked before the commit.
/// </summary>
public sealed class UpdateProductCategoryCommandHandler(
    IProductCategoryRepository categories,
    IProductCategoryUsageQueries usage,
    ICatalogueCacheInvalidator cache) : IUpdateProductCategoryUseCase
{
    public async Task<ProductCategoryLookupResult> ExecuteAsync(
        UpdateProductCategoryCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = ProductCategoryCode.Create(command.Code);
        var category = await categories.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product category with code '{code.Value}' was found.");

        var hasComponentTypeReferences = command.AllowsComponentTypes
            || await usage.HasComponentTypeReferencesAsync(code, cancellationToken);

        try
        {
            category.Update(
                command.Name,
                command.Description,
                command.AllowsComponentTypes,
                hasComponentTypeReferences);
            await categories.UpdateAndSaveAsync(category, cancellationToken);
        }
        catch (CategoryComponentTypeReferenceException exception)
        {
            throw new ConflictException(exception.Message);
        }

        await cache.InvalidateProductCategoriesAsync(cancellationToken);

        return new ProductCategoryLookupResult(
            category.Code.Value,
            category.Name,
            category.Description,
            category.AllowsComponentTypes);
    }
}
