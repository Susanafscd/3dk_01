namespace LaPrizza.Application.ProductCategories.GetProductCategory;

/// <summary>Identifies the product category to retrieve by its business code.</summary>
/// <param name="Code">Immutable product-category business code.</param>
public sealed record GetProductCategoryQuery(string? Code);
