using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ProductCategories.GetProductCategory;

/// <summary>Retrieves one product-category projection by business code.</summary>
public sealed class GetProductCategoryQueryHandler(
    IProductCategoryRepository categories,
    IProductCategoryCatalogueCache? cache = null)
{
    public async Task<ProductCategoryLookupResult> HandleAsync(
        GetProductCategoryQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = ProductCategoryCode.Create(query.Code);
        if (cache is null)
        {
            return await categories.GetLookupByCodeAsync(code, cancellationToken)
                ?? throw new NotFoundException($"No product category with code '{code}' was found.");
        }

        return await cache.GetByCodeAsync(
            code.Value,
            async token => await categories.GetLookupByCodeAsync(code, token)
                ?? throw new NotFoundException($"No product category with code '{code}' was found."),
            cancellationToken);
    }
}
