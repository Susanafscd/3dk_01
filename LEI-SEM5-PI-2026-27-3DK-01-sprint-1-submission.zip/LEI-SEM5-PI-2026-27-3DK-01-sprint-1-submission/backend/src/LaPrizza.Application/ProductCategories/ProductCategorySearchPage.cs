namespace LaPrizza.Application.ProductCategories;

/// <summary>A page of category projections and the count before paging.</summary>
public sealed record ProductCategorySearchPage(
    IReadOnlyList<ProductCategorySearchItem> Items,
    int TotalCount);
