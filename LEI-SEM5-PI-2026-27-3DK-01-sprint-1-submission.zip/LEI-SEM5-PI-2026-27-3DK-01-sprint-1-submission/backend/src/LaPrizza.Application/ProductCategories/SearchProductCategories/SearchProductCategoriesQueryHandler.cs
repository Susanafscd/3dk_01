using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;

namespace LaPrizza.Application.ProductCategories.SearchProductCategories;

/// <summary>Validates paging and delegates the read to the category query port.</summary>
public sealed class SearchProductCategoriesQueryHandler(
    IProductCategoryQueries queries,
    IProductCategoryCatalogueCache? cache = null)
{
    public async Task<SearchProductCategoriesResult> HandleAsync(
        SearchProductCategoriesQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchProductCategoriesQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchProductCategoriesQuery.MaximumPageSize}.");
        }

        var normalizedSearch = query.Search?.Trim();
        var cacheKey = $"{Uri.EscapeDataString(normalizedSearch?.ToLowerInvariant() ?? string.Empty)}:{query.Page}:{query.PageSize}";

        if (cache is null)
        {
            var page = await queries.SearchAsync(normalizedSearch, query.Page, query.PageSize, cancellationToken);
            return new SearchProductCategoriesResult(page.Items, query.Page, query.PageSize, page.TotalCount);
        }

        return await cache.SearchAsync(
            cacheKey,
            async token =>
            {
                var page = await queries.SearchAsync(normalizedSearch, query.Page, query.PageSize, token);
                return new SearchProductCategoriesResult(page.Items, query.Page, query.PageSize, page.TotalCount);
            },
            cancellationToken);
    }
}
