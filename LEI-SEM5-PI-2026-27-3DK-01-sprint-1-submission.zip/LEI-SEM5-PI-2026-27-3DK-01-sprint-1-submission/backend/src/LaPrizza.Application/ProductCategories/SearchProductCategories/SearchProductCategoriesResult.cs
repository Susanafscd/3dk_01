namespace LaPrizza.Application.ProductCategories.SearchProductCategories;

/// <summary>UC-15 result, including paging metadata.</summary>
public sealed record SearchProductCategoriesResult(
    IReadOnlyList<ProductCategorySearchItem> Items,
    int Page,
    int PageSize,
    int TotalCount);
