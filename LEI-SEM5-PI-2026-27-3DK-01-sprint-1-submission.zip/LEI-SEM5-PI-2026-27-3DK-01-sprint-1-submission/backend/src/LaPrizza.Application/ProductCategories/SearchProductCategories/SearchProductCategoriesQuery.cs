namespace LaPrizza.Application.ProductCategories.SearchProductCategories;

/// <summary>Input for UC-15 category search.</summary>
public sealed record SearchProductCategoriesQuery(
    string? Search,
    int Page = 1,
    int PageSize = 20)
{
    public const int DefaultPage = 1;
    public const int DefaultPageSize = 20;
    public const int MaximumPageSize = 100;
}
