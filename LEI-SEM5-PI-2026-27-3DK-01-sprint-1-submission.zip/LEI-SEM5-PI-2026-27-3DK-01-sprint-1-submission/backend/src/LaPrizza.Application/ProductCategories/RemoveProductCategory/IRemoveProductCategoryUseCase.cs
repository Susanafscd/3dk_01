using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ProductCategories.RemoveProductCategory;

public sealed record RemoveProductCategoryCommand(string Code);

public interface IRemoveProductCategoryUseCase
{
    Task ExecuteAsync(RemoveProductCategoryCommand command, CancellationToken cancellationToken = default);
}

public sealed class RemoveProductCategoryCommandHandler(
    IProductCategoryRepository categories,
    IProductCategoryUsageQueries usage,
    ICatalogueCacheInvalidator cache) : IRemoveProductCategoryUseCase
{
    public async Task ExecuteAsync(
        RemoveProductCategoryCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = ProductCategoryCode.Create(command.Code);
        var category = await categories.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product category with code '{code.Value}' was found.");

        try
        {
            CategoryRemovalPolicy.EnsureCanRemove(
                await usage.HasProductReferencesAsync(code, cancellationToken),
                await usage.HasComponentTypeReferencesAsync(code, cancellationToken));
            await categories.RemoveAsync(category, cancellationToken);
        }
        catch (ProductCategoryInUseException exception)
        {
            // The restrictive FK closes the race between the usage read and DELETE.
            throw new ConflictException(exception.Message);
        }
        catch (DomainException exception)
        {
            throw new ConflictException(exception.Message);
        }

        await cache.InvalidateProductCategoriesAsync(cancellationToken);
    }
}
