using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Users.CreateUser;

/// <summary>
/// Everything the use case needs to create one user. It is the application
/// contract: the transport layer maps its own request shape onto it.
/// </summary>
/// <param name="Email">Unique email address of the account.</param>
/// <param name="DisplayName">Name shown for the account.</param>
/// <param name="Password">Initial credential, handled by the account manager.</param>
/// <param name="Type">Which profile to attach, a customer or a staff member.</param>
/// <param name="RoleNames">Names of the roles to grant.</param>
/// <param name="Name">Customer name (customers only).</param>
/// <param name="PhoneNumber">Customer phone number (optional).</param>
/// <param name="JobTitle">Staff job title (staff only).</param>
public sealed record CreateUserCommand(
    string Email,
    string DisplayName,
    string Password,
    UserType Type,
    IReadOnlyCollection<string> RoleNames,
    string? Name = null,
    string? PhoneNumber = null,
    string? JobTitle = null);
