using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Users.CreateUser;

/// <summary>The outcome of creating a user, ready to be mapped to a response.</summary>
public sealed record CreateUserResult(
    Guid Id,
    string Email,
    string DisplayName,
    UserType Type,
    bool Active,
    IReadOnlyCollection<string> Roles);
