using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Users.CreateUser;

/// <summary>
/// Application controller orchestration for the "create user" use case. It
/// coordinates the domain aggregate, the repositories and the account manager,
/// and enforces the order of operations and the compensating action.
/// </summary>
public sealed class CreateUserCommandHandler(
    IUserRepository users,
    IUserAccountManager accounts)
{
    public async Task<CreateUserResult> HandleAsync(
        CreateUserCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var email = Email.Create(command.Email);

        if (await users.ExistsByEmailAsync(email, cancellationToken))
        {
            throw new ConflictException($"A user with email '{email.Value}' already exists.");
        }

        var roleNames = (command.RoleNames ?? [])
            .Where(name => !string.IsNullOrWhiteSpace(name))
            .Select(name => name.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        var user = BuildUser(command, email);

        // Credentials are infrastructure, not domain (MD-06), so they are created
        // through the account manager before the aggregate is persisted.
        var accountId = await accounts.CreateAccountAsync(email.Value, command.Password, cancellationToken);

        await accounts.AssignRolesAsync(accountId, roleNames, cancellationToken);

        try
        {
            await users.AddAsync(user, cancellationToken);
        }
        catch
        {
            // The two stores are not in one transaction: undo the account so a
            // failed creation does not leave a login without a user.
            await accounts.DeleteAccountAsync(accountId, cancellationToken);
            throw;
        }

        return new CreateUserResult(
            user.Id,
            user.Email.Value,
            user.DisplayName,
            command.Type,
            user.Active,
            roleNames);
    }

    private static User BuildUser(CreateUserCommand command, Email email)
    {
        return command.Type switch
        {
            UserType.Staff => Staff.Create(
                email,
                command.DisplayName,
                command.JobTitle ?? throw new ValidationException("Job title is required for a staff user.")
                ),
            _ => throw new ValidationException($"Unsupported user type '{command.Type}'."),
        };
    }
}
