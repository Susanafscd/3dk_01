namespace LaPrizza.Application.ComponentTypes;

/// <summary>A page of pizza sizes and the count before paging.</summary>
public sealed record PizzaSizeSearchPage(IReadOnlyList<PizzaSizeResult> Items, int TotalCount);
