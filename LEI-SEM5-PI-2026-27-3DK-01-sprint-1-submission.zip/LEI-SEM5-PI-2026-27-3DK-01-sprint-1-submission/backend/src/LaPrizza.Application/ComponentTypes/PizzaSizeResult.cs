namespace LaPrizza.Application.ComponentTypes;

/// <summary>A pizza size as returned by the use cases.</summary>
public sealed record PizzaSizeResult(Guid Id, string Name, string? Description);
