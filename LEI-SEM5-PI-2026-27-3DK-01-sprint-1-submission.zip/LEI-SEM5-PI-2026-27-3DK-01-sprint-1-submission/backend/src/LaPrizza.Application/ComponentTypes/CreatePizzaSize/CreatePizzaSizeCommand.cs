namespace LaPrizza.Application.ComponentTypes.CreatePizzaSize;

/// <summary>Input for creating a pizza size.</summary>
public sealed record CreatePizzaSizeCommand(string? Name, string? Description);
