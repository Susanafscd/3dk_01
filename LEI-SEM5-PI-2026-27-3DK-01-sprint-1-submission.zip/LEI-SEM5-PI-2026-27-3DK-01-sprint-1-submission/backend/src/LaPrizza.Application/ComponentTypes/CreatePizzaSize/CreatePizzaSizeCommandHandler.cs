using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.CreatePizzaSize;

/// <summary>Validates and registers a pizza size.</summary>
public sealed class CreatePizzaSizeCommandHandler(IPizzaSizeRepository sizes)
{
    public async Task<PizzaSizeResult> HandleAsync(
        CreatePizzaSizeCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var size = PizzaSize.Create(command.Name, command.Description);

        if (await sizes.ExistsByName(size.Name, cancellationToken))
        {
            throw new ConflictException($"A pizza size named '{size.Name}' already exists.");
        }

        try
        {
            await sizes.Add(size, cancellationToken);
        }
        catch (DuplicatePizzaSizeNameException exception)
        {
            // The unique index catches a duplicate inserted after the lookup above.
            throw new ConflictException(exception.Message);
        }

        return new PizzaSizeResult(size.Id, size.Name, size.Description);
    }
}
