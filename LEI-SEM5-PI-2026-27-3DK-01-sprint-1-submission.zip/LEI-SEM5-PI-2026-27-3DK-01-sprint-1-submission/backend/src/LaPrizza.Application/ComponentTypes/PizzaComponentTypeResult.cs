using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes;

/// <summary>
/// A pizza component type as returned by the use cases. It is identified by its
/// business <paramref name="Code"/>; the internal identifier is never exposed.
/// </summary>
public sealed record PizzaComponentTypeResult(
    string Code,
    string CategoryCode,
    string Name,
    string? Description,
    int AssemblyOrder,
    int MinQuantity,
    int? MaxQuantity)
{
    public static PizzaComponentTypeResult From(PizzaComponentType type) => new(
        type.Code.Value,
        type.CategoryCode.Value,
        type.Name,
        type.Description,
        type.AssemblyOrder,
        type.MinQuantity,
        type.MaxQuantity);
}
