namespace LaPrizza.Application.ComponentTypes.GetPizzaComponentType;

/// <summary>Input for retrieving a pizza component type by its business code.</summary>
public sealed record GetPizzaComponentTypeQuery(string? Code);
