using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.GetPizzaComponentType;

/// <summary>Retrieves one pizza component type by its business code.</summary>
public sealed class GetPizzaComponentTypeQueryHandler(IPizzaComponentTypeRepository types)
{
    public async Task<PizzaComponentTypeResult> HandleAsync(
        GetPizzaComponentTypeQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var code = PizzaComponentTypeCode.Create(query.Code);
        var type = await types.GetByCode(code, cancellationToken)
            ?? throw new NotFoundException($"No pizza component type with code '{code}' was found.");

        return PizzaComponentTypeResult.From(type);
    }
}
