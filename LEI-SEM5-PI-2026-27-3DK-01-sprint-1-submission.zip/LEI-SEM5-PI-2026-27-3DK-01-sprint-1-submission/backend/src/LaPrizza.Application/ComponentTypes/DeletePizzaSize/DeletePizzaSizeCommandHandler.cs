﻿using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.DeletePizzaSize;

/// <summary>Removes a pizza size, but only when nothing refers to it.</summary>
public sealed class DeletePizzaSizeCommandHandler(IPizzaSizeRepository sizes)
{
    public async Task HandleAsync(
        DeletePizzaSizeCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var size = await sizes.Get(command.Id, cancellationToken)
            ?? throw new NotFoundException($"No pizza size with id '{command.Id}' was found.");

        if (await sizes.InUse(size.Id, cancellationToken))
        {
            throw new ConflictException($"Pizza size '{size.Id}' is in use and cannot be removed.");
        }

        try
        {
            await sizes.Remove(size, cancellationToken);
        }
        catch (PizzaSizeInUseException exception)
        {
            throw new ConflictException(exception.Message);
        }
    }
}
