namespace LaPrizza.Application.ComponentTypes.DeletePizzaSize;

/// <summary>Identifies the pizza size to remove.</summary>
public sealed record DeletePizzaSizeCommand(Guid Id);
