using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.GetPizzaSize;

/// <summary>Retrieves one pizza size by its identifier.</summary>
public sealed class GetPizzaSizeQueryHandler(IPizzaSizeRepository sizes)
{
    public async Task<PizzaSizeResult> HandleAsync(
        GetPizzaSizeQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        var size = await sizes.Get(query.Id, cancellationToken)
            ?? throw new NotFoundException($"No pizza size with id '{query.Id}' was found.");

        return new PizzaSizeResult(size.Id, size.Name, size.Description);
    }
}
