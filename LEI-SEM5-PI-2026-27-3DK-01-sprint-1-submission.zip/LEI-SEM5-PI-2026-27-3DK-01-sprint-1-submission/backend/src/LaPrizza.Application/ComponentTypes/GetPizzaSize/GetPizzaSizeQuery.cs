namespace LaPrizza.Application.ComponentTypes.GetPizzaSize;

/// <summary>Identifies the pizza size to retrieve.</summary>
public sealed record GetPizzaSizeQuery(Guid Id);
