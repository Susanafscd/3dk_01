namespace LaPrizza.Application.ComponentTypes.SearchPizzaSizes;

/// <summary>Input for searching pizza sizes by identifier or name.</summary>
public sealed record SearchPizzaSizesQuery(string? Search, int Page = 1, int PageSize = 20)
{
    public const int DefaultPage = 1;
    public const int DefaultPageSize = 20;
    public const int MaximumPageSize = 100;
}
