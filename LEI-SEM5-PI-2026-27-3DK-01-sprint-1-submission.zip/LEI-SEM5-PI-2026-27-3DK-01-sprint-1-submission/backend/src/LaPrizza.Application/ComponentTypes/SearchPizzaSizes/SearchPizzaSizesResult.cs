namespace LaPrizza.Application.ComponentTypes.SearchPizzaSizes;

/// <summary>A page of pizza sizes with paging metadata.</summary>
public sealed record SearchPizzaSizesResult(
    IReadOnlyList<PizzaSizeResult> Items,
    int Page,
    int PageSize,
    int TotalCount);
