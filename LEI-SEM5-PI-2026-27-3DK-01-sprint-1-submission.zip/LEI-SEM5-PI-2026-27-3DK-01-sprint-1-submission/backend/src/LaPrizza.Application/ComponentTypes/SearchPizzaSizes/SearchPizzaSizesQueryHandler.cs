using LaPrizza.Application.Common.Exceptions;

namespace LaPrizza.Application.ComponentTypes.SearchPizzaSizes;

/// <summary>Validates paging and delegates the read to the query port.</summary>
public sealed class SearchPizzaSizesQueryHandler(IPizzaSizeQueries queries)
{
    public async Task<SearchPizzaSizesResult> HandleAsync(
        SearchPizzaSizesQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchPizzaSizesQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchPizzaSizesQuery.MaximumPageSize}.");
        }

        var page = await queries.SearchAsync(query.Search, query.Page, query.PageSize, cancellationToken);

        return new SearchPizzaSizesResult(page.Items, query.Page, query.PageSize, page.TotalCount);
    }
}
