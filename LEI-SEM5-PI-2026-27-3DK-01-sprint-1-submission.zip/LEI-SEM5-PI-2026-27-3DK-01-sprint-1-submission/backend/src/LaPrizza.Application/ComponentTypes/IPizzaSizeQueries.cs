namespace LaPrizza.Application.ComponentTypes;

/// <summary>Read-only query port for pizza size searches.</summary>
public interface IPizzaSizeQueries
{
    /// <summary>
    /// Searches by exact identifier or by a case-insensitive name fragment, orders by
    /// name and returns one page plus the unpaged count. A blank term lists everything.
    /// </summary>
    Task<PizzaSizeSearchPage> SearchAsync(
        string? search,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);
}
