namespace LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;

/// <summary>Input for creating a pizza component type.</summary>
public sealed record CreatePizzaComponentTypeCommand(
    string? Code,
    string? CategoryCode,
    string? Name,
    string? Description,
    int AssemblyOrder,
    int MinQuantity,
    int? MaxQuantity)
{
    /// <summary>Compatibility constructor for internal callers being migrated to category codes.</summary>
    public CreatePizzaComponentTypeCommand(
        string? code,
        string? name,
        string? description,
        int assemblyOrder,
        int minQuantity,
        int? maxQuantity)
        : this(code, "pizza-component", name, description, assemblyOrder, minQuantity, maxQuantity) { }
}
