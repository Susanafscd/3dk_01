using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;

/// <summary>Validates and registers a pizza component type.</summary>
public sealed class CreatePizzaComponentTypeCommandHandler(
    IPizzaComponentTypeRepository types,
    IProductCategoryRepository categories)
{
    public async Task<PizzaComponentTypeResult> HandleAsync(
        CreatePizzaComponentTypeCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var type = PizzaComponentType.Create(command.Code, command.CategoryCode, command.Name, command.Description, command.AssemblyOrder, command.MinQuantity, command.MaxQuantity);

        var category = await categories.GetByCodeAsync(type.CategoryCode, cancellationToken)
            ?? throw new NotFoundException($"No product category with code '{type.CategoryCode.Value}' was found.");
        if (!category.AllowsComponentTypes)
        {
            throw new ConflictException($"Product category '{type.CategoryCode.Value}' does not allow component types.");
        }

        if (await types.ExistsByCode(type.Code, cancellationToken))
        {
            throw new ConflictException($"A pizza component type with code '{type.Code}' already exists.");
        }

        if (await types.ExistsByName(type.Name, null, cancellationToken))
        {
            throw new ConflictException($"A pizza component type named '{type.Name}' already exists.");
        }

        if (await types.ExistsByAssemblyOrder(type.AssemblyOrder, null, cancellationToken))
        {
            throw new ConflictException($"A pizza component type with assembly order '{type.AssemblyOrder}' already exists.");
        }

        try
        {
            await types.Add(type, cancellationToken);
        }
        catch (DuplicatePizzaComponentTypeCodeException exception)
        {
            // The unique index can detect a duplicate inserted after the lookup.
            throw new ConflictException(exception.Message);
        }
        catch (DuplicatePizzaComponentTypeNameException exception)
        {
            throw new ConflictException(exception.Message);
        }
        catch (DuplicatePizzaComponentTypeAssemblyOrderException exception)
        {
            throw new ConflictException(exception.Message);
        }

        return PizzaComponentTypeResult.From(type);
    }
}
