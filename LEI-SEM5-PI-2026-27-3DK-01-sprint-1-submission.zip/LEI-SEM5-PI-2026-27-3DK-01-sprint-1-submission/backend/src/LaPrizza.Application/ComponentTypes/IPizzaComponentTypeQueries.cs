namespace LaPrizza.Application.ComponentTypes;

/// <summary>Read-only query port for pizza component type searches.</summary>
public interface IPizzaComponentTypeQueries
{
    /// <summary>
    /// Searches by exact business code or by a case-insensitive name fragment, orders by assembly order and returns one page plus the unpaged count. A blank term lists everything.
    /// </summary>
    Task<PizzaComponentTypeSearchPage> SearchAsync(
        string? search,
        string? categoryCode,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);
}
