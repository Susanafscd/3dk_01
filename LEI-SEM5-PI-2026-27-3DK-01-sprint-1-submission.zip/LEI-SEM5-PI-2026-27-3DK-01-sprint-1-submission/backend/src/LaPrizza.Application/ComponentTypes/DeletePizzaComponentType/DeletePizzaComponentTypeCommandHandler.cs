using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.DeletePizzaComponentType;

/// <summary>Removes a pizza component type when no references exist.</summary>
public sealed class DeletePizzaComponentTypeCommandHandler(IPizzaComponentTypeRepository types)
{
    public async Task HandleAsync(
        DeletePizzaComponentTypeCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = PizzaComponentTypeCode.Create(command.Code);
        var type = await types.GetByCode(code, cancellationToken)
            ?? throw new NotFoundException($"No pizza component type with code '{code}' was found.");

        if (await types.InUse(type.Id, cancellationToken))
        {
            throw new ConflictException($"Pizza component type '{code}' is referenced by other information and cannot be removed.");
        }

        try
        {
            await types.Remove(type, cancellationToken);
        }
        catch (PizzaComponentTypeInUseException exception)
        {
            throw new ConflictException(exception.Message);
        }
    }
}
