namespace LaPrizza.Application.ComponentTypes.DeletePizzaComponentType;

/// <summary>Input for deleting a pizza component type by its business code.</summary>
public sealed record DeletePizzaComponentTypeCommand(string? Code);
