namespace LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;

/// <summary>Input for searching pizza component types.</summary>
public sealed record SearchPizzaComponentTypesQuery(string? Search, string? CategoryCode, int Page = 1, int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
