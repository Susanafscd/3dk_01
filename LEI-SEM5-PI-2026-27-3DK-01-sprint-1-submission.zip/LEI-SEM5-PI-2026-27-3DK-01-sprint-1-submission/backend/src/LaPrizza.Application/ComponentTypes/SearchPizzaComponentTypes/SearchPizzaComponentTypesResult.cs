namespace LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;

/// <summary>A page of pizza component types.</summary>
public sealed record SearchPizzaComponentTypesResult(
    IReadOnlyList<PizzaComponentTypeResult> Items,
    int Page,
    int PageSize,
    int TotalCount);
