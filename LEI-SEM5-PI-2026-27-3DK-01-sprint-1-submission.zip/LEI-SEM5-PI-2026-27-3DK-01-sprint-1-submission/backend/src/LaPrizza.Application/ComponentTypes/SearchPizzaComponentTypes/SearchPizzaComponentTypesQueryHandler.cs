using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;

/// <summary>Validates paging and delegates the read to the query port.</summary>
public sealed class SearchPizzaComponentTypesQueryHandler(IPizzaComponentTypeQueries queries)
{
    public async Task<SearchPizzaComponentTypesResult> HandleAsync(
        SearchPizzaComponentTypesQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchPizzaComponentTypesQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchPizzaComponentTypesQuery.MaximumPageSize}.");
        }

        if (!string.IsNullOrWhiteSpace(query.CategoryCode))
        {
            ProductCategoryCode.Create(query.CategoryCode);
        }

        var page = await queries.SearchAsync(query.Search, query.CategoryCode, query.Page, query.PageSize, cancellationToken);

        return new SearchPizzaComponentTypesResult(page.Items, query.Page, query.PageSize, page.TotalCount);
    }
}
