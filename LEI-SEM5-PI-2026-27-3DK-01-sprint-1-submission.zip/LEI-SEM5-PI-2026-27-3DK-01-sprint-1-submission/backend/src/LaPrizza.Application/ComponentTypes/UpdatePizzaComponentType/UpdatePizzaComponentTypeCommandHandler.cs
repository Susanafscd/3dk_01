using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;

/// <summary>Updates an existing pizza component type. Its code is immutable.</summary>
public sealed class UpdatePizzaComponentTypeCommandHandler(IPizzaComponentTypeRepository types)
{
    public async Task<PizzaComponentTypeResult> HandleAsync(
        UpdatePizzaComponentTypeCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = PizzaComponentTypeCode.Create(command.Code);
        var type = await types.GetByCode(code, cancellationToken)
            ?? throw new NotFoundException($"No pizza component type with code '{code}' was found.");

        if (await types.ExistsByName(command.Name ?? string.Empty, type.Id, cancellationToken))
        {
            throw new ConflictException($"A pizza component type named '{command.Name}' already exists.");
        }

        if (await types.ExistsByAssemblyOrder(command.AssemblyOrder, type.Id, cancellationToken))
        {
            throw new ConflictException($"A pizza component type with assembly order '{command.AssemblyOrder}' already exists.");
        }

        type.UpdateDetails(command.Name, command.Description, command.AssemblyOrder, command.MinQuantity, command.MaxQuantity);

        try
        {
            await types.Update(type, cancellationToken);
        }
        catch (DuplicatePizzaComponentTypeNameException exception)
        {
            throw new ConflictException(exception.Message);
        }
        catch (DuplicatePizzaComponentTypeAssemblyOrderException exception)
        {
            throw new ConflictException(exception.Message);
        }

        return PizzaComponentTypeResult.From(type);
    }
}
