namespace LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;

/// <summary>
/// Input for updating a pizza component type. <paramref name="Code"/> identifies
/// the type to update (it comes from the route) and can never be changed.
/// </summary>
public sealed record UpdatePizzaComponentTypeCommand(string? Code, string? Name, string? Description, int AssemblyOrder, int MinQuantity, int? MaxQuantity);
