namespace LaPrizza.Application.ComponentTypes;

/// <summary>A page of pizza component types and the count before paging.</summary>
public sealed record PizzaComponentTypeSearchPage(IReadOnlyList<PizzaComponentTypeResult> Items, int TotalCount);
