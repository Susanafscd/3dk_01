namespace LaPrizza.Application.Catalogue.GetCatalogueProduct;

/// <summary>Consults the details of an individual sellable product (BCK11).</summary>
/// <param name="ProductId">Identifier of the product being consulted.</param>
public sealed record GetCatalogueProductQuery(Guid ProductId);
