using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;

namespace LaPrizza.Application.Catalogue.GetCatalogueProduct;

/// <summary>
/// Application orchestration for the "consult product details" use case
/// (BCK11). Serves the product through the catalogue cache: on a miss it is
/// loaded through the catalogue query port, which only resolves products that
/// are currently active and sellable. A product that does not exist — or that
/// is inactive or not sellable — reports "not found", indistinguishably from
/// any other absent product. A product deactivated after being cached is
/// invalidated through the shared catalogue tags, so the next consultation
/// reflects the change or reports "not found".
/// </summary>
public sealed class GetCatalogueProductQueryHandler(
    ICatalogueQueries queries,
    IProductCatalogueCache? cache = null)
{
    public async Task<CatalogueProductResult> HandleAsync(
        GetCatalogueProductQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        Task<CatalogueProductResult?> Load(CancellationToken token) => queries.LoadByIdAsync(query.ProductId, token);

        var product = cache is null
            ? await Load(cancellationToken)
            : await cache.GetByIdAsync(query.ProductId, Load, cancellationToken);

        return product
            ?? throw new NotFoundException(
                "The product you are looking for does not exist or is not offered for sale.");
    }
}
