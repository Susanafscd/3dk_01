namespace LaPrizza.Application.Catalogue.GetCatalogue;

/// <summary>Consults the product catalogue, paginated (BCK11).</summary>
/// <param name="Page">Page number, starting at 1.</param>
/// <param name="PageSize">Number of entries per page, at most 100.</param>
public sealed record GetCatalogueQuery(int Page = 1, int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
