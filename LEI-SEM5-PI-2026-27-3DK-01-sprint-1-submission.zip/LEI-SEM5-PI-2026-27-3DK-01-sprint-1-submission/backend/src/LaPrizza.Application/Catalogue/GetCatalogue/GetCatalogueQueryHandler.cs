using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;

namespace LaPrizza.Application.Catalogue.GetCatalogue;

/// <summary>
/// Application orchestration for the "consult product catalogue" use case
/// (BCK11). Validates the pagination and serves the page through the
/// catalogue cache: on a miss the page is loaded through the catalogue query
/// port — which only exposes active and sellable products — and stored in the
/// cache, so business changes never serve stale data and repeated
/// consultations do not reach the database.
/// </summary>
public sealed class GetCatalogueQueryHandler(
    ICatalogueQueries queries,
    IProductCatalogueCache? cache = null)
{
    public async Task<CatalogueResult> HandleAsync(
        GetCatalogueQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > GetCatalogueQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {GetCatalogueQuery.MaximumPageSize}.");
        }

        Task<CatalogueResult> Load(CancellationToken token) => queries.LoadAsync(query.Page, query.PageSize, token);

        return cache is null
            ? await Load(cancellationToken)
            : await cache.GetListAsync(query.Page, query.PageSize, Load, cancellationToken);
    }
}
