namespace LaPrizza.Application.Catalogue;

/// <summary>
/// One catalogue entry of a sellable product offered by the restaurant (BCK11),
/// ready to be mapped onto the public response. A flat read model: the
/// transport layer never depends on the domain aggregates.
/// </summary>
/// <param name="ProductCode">Public business code of the product.</param>
/// <param name="Name">Display name of the product.</param>
/// <param name="Description">Optional display description.</param>
/// <param name="Category">Category of the product (its business code and name), or
/// null when it has none.</param>
/// <param name="UnitPrice">
/// Price of a product that does not depend on size; null when the pricing is
/// expressed in <see cref="Sizes"/>.
/// </param>
/// <param name="Sizes">
/// For products priced by size: one entry per available (active) pizza size
/// with its price, empty otherwise.
/// </param>
/// <param name="Allergens">Names of the allergens, empty when the product has none.</param>
/// <param name="Configuration">
/// Default configuration of a composed pizza. null whenever the product is not
/// a composed pizza — the composed-pizza aggregate does not exist in the domain yet
/// (BCK10/BCK12), so every entry is null until that story lands.
/// </param>
public sealed record CatalogueProductResult(
    string ProductCode,
    string Name,
    string? Description,
    CatalogueCategoryResult? Category,
    decimal? UnitPrice,
    IReadOnlyList<CatalogueSizeResult> Sizes,
    IReadOnlyList<string> Allergens,
    CatalogueConfigurationResult? Configuration);

/// <summary>The category of a catalogue entry.</summary>
public sealed record CatalogueCategoryResult(string Code, string Name);

/// <summary>A pizza size available for a catalogue entry, with its price.</summary>
/// <param name="Name">Display name of the size (its immutable business name).</param>
public sealed record CatalogueSizeResult(string Name, decimal Price);

/// <summary>The default configuration of a composed pizza (future use: BCK10/BCK12).</summary>
public sealed record CatalogueConfigurationResult(IReadOnlyList<CatalogueComponentResult> Components);

/// <summary>One component of a composed pizza's default configuration (future use: BCK10/BCK12).</summary>
public sealed record CatalogueComponentResult(string ProductCode, string Name);

/// <summary>The sellable catalogue page: one entry per active and sellable product.</summary>
public sealed record CatalogueResult(IReadOnlyList<CatalogueProductResult> Items);
