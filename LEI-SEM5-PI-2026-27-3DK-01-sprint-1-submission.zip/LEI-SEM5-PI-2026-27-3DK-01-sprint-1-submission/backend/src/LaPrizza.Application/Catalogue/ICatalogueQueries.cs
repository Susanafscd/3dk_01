namespace LaPrizza.Application.Catalogue;

/// <summary>
/// Read port for the public product catalogue (BCK11): loads only products that
/// are currently active and sellable, already enriched with their category
/// (business code and name), allergen names and, for products priced by size, the
/// available pizza sizes with their prices. Nothing is tracked or modified.
/// </summary>
public interface ICatalogueQueries
{
    /// <summary>
    /// Returns one page of the sellable catalogue, ordered stably by product
    /// name and then identifier so repeated pages are consistent.
    /// </summary>
    Task<CatalogueResult> LoadAsync(
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the catalogue entry of the product with the given identifier, or
    /// null when the product does not exist or is inactive or not sellable —
    /// the catalogue never reveals such products (they report not found).
    /// </summary>
    Task<CatalogueProductResult?> LoadByIdAsync(
        Guid id,
        CancellationToken cancellationToken = default);
}
