namespace LaPrizza.Application.Products.UpdateProduct;

public sealed record UpdateProductCommand(
    string Code,
    string Name,
    string Description,
    string CategoryCode,
    bool Sellable,
    bool StockControlled,
    decimal? Price,
    IReadOnlyList<string> AllergenCodes,
    string? ComponentTypeCode = null);

/// <summary>Complete workflow boundary: implementations must protect usage checks and commit atomically,
/// then invalidate affected caches. No production implementation is registered yet.</summary>
public interface IUpdateProductUseCase
{
    Task<LaPrizza.Application.Products.GetProduct.ProductLookupResult> ExecuteAsync(UpdateProductCommand command, CancellationToken cancellationToken = default);
}
