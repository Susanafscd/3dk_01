using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.UpdateProduct;

/// <summary>
/// Coordinates the protected product replacement. Reference and dependency facts
/// are read before the aggregate is mutated; the repository commits the tracked
/// aggregate and its allergen rows atomically.
/// </summary>
public sealed class UpdateProductCommandHandler(
    IProductRepository products,
    IProductRelationshipQueries relationships,
    IProductUpdateQueries dependencies,
    ICatalogueCacheInvalidator? cache = null) : IUpdateProductUseCase
{
    public async Task<ProductLookupResult> ExecuteAsync(
        UpdateProductCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        if (command.Price is { } amount &&
            (decimal.Round(amount, 2) != amount || amount > 9999999999999999.99m))
        {
            throw new InvalidProductException("Price must fit numeric(18,2) without rounding.");
        }

        var code = ProductCode.Create(command.Code);
        var category = ProductCategoryCode.Create(command.CategoryCode);
        var componentType = command.ComponentTypeCode is null
            ? null
            : PizzaComponentTypeCode.Create(command.ComponentTypeCode);
        var allergenCodes = (command.AllergenCodes ?? throw new InvalidProductException("Allergen codes cannot be null."))
            .Select(AllergenCode.Create)
            .ToList();

        if (allergenCodes.Distinct().Count() != allergenCodes.Count)
        {
            throw new InvalidProductException("Allergen codes must be distinct.");
        }

        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code.Value}' was found.");

        var context = await relationships.GetChangeContextAsync(
            category, allergenCodes, componentType, cancellationToken);
        var facts = await dependencies.GetFactsAsync(code, cancellationToken);

        ProductChangePolicy policy = new();
        policy.EnsureReferencesAreValid(context);

        if (facts.ReferencedByComposedProduct &&
            (product.CategoryCode != category || product.ComponentTypeCode != componentType?.Value))
        {
            throw new ConflictException(
                $"Product '{code.Value}' is used by a composed product and its category/component type cannot change.");
        }

        if (product is BaseProduct baseProduct &&
            baseProduct.SizeConfiguration is not null &&
            product.ComponentTypeCode != componentType?.Value)
        {
            throw new ConflictException(
                $"Product '{code.Value}' has size configurations and its component type cannot change.");
        }

        try
        {
            product.ReplaceEditableDetails(
                command.Name,
                command.Description,
                category,
                command.Sellable,
                command.Price,
                command.StockControlled,
                allergenCodes,
                componentType?.Value);

            await products.SaveAsync(product, cancellationToken);
        }
        catch (StockChangeRejectedException exception)
        {
            throw new ConflictException(exception.Message);
        }
        catch (ProductConcurrencyException exception)
        {
            throw new ConflictException(exception.Message);
        }

        if (cache is not null)
        {
            await cache.InvalidateProductsAsync(cancellationToken);
        }

        return ToResult(product);
    }

    private static ProductLookupResult ToResult(LaPrizza.Domain.Product.Product product) => new(
        product.Id,
        product.Code.Value,
        product.Name,
        product.Description,
        product is BaseProduct ? "Base" : "Composed",
        product.CategoryCode.Value,
        product.IsSellable,
        product.Sellable?.Price.Amount,
        product.ComponentTypeCode,
        product.ComponentTypeCode is not null,
        product.StockControlled,
        product.StockBalance,
        product.Active,
        product.Allergens.Select(a => a.Value).OrderBy(value => value).ToList());
}
