using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.SearchProducts;

public sealed record SearchProductsResult(
    IReadOnlyList<ProductSearchItem> Items,
    int Page,
    int PageSize,
    int TotalCount);
