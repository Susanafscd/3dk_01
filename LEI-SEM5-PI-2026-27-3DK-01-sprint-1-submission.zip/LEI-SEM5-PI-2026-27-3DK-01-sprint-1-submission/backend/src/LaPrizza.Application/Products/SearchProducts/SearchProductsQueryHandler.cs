using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.SearchProducts;

/// <summary>Validates search input and delegates the read to the domain query port.</summary>
public sealed class SearchProductsQueryHandler(IProductQueries queries)
{
    public async Task<SearchProductsResult> HandleAsync(
        SearchProductsQuery query,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(query);

        if (query.Page < 1)
        {
            throw new ValidationException("Page must be a positive integer.");
        }

        if (query.PageSize is < 1 or > SearchProductsQuery.MaximumPageSize)
        {
            throw new ValidationException(
                $"Page size must be between 1 and {SearchProductsQuery.MaximumPageSize}.");
        }

        if (!string.IsNullOrWhiteSpace(query.ComponentTypeCode)
            && string.IsNullOrWhiteSpace(query.CategoryCode))
        {
            throw new ValidationException("Component type filtering requires a category code.");
        }

        var criteria = new ProductSearchCriteria(
            query.Search,
            CreateCategoryCode(query.CategoryCode),
            CreateAllergenCode(query.AllergenCode),
            NormalizeOptional(query.ComponentTypeCode),
            query.Sellable,
            query.StockControlled,
            query.IsPizzaComponent,
            ParseKind(query.Kind),
            query.Active,
            query.Page,
            query.PageSize);

        var page = await queries.SearchAsync(criteria, cancellationToken);
        return new SearchProductsResult(page.Items, query.Page, query.PageSize, page.TotalCount);
    }

    private static ProductCategoryCode? CreateCategoryCode(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : ProductCategoryCode.Create(value.Trim());

    private static AllergenCode? CreateAllergenCode(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : AllergenCode.Create(value.Trim());

    private static string? NormalizeOptional(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static ProductKind? ParseKind(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        if (Enum.TryParse<ProductKind>(value.Trim(), ignoreCase: true, out var kind))
        {
            return kind;
        }

        throw new ValidationException("Kind must be either Base or Composed.");
    }
}
