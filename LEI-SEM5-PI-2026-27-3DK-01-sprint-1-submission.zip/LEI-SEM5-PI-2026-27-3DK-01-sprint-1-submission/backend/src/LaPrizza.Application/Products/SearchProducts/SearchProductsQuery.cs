namespace LaPrizza.Application.Products.SearchProducts;

public sealed record SearchProductsQuery(
    string? Search = null,
    string? CategoryCode = null,
    string? AllergenCode = null,
    string? ComponentTypeCode = null,
    bool? Sellable = null,
    bool? StockControlled = null,
    bool? IsPizzaComponent = null,
    string? Kind = null,
    bool? Active = null,
    int Page = 1,
    int PageSize = 20)
{
    public const int MaximumPageSize = 100;
}
