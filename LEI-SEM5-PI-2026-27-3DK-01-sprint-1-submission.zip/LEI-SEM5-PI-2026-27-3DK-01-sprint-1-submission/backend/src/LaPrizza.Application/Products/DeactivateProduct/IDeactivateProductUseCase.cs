using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Products.DeactivateProduct;

public sealed record DeactivateProductCommand(string Code);

public interface IDeactivateProductUseCase
{
    Task ExecuteAsync(DeactivateProductCommand command, CancellationToken cancellationToken = default);
}

/// <summary>
/// Logically deactivates one product. The tracked aggregate is committed before
/// product and catalogue projections are invalidated.
/// </summary>
public sealed class DeactivateProductCommandHandler(
    IProductRepository products,
    ICatalogueCacheInvalidator cache) : IDeactivateProductUseCase
{
    public async Task ExecuteAsync(
        DeactivateProductCommand command,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(command);

        var code = ProductCode.Create(command.Code);
        var product = await products.GetByCodeAsync(code, cancellationToken)
            ?? throw new NotFoundException($"No product with code '{code.Value}' was found.");

        if (!product.Deactivate())
        {
            return;
        }

        try
        {
            await products.SaveAsync(product, cancellationToken);
        }
        catch (ProductConcurrencyException exception)
        {
            throw new ConflictException(exception.Message);
        }
        await cache.InvalidateProductsAsync(cancellationToken);
    }
}
