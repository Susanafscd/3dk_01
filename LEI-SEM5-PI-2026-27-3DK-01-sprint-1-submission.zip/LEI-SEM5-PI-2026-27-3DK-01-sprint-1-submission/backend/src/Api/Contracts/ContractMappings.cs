using LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;
using LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;
using LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;
using LaPrizza.Application.ComponentTypes;
using LaPrizza.Application.ComponentTypes.CreatePizzaSize;
using LaPrizza.Application.ComponentTypes.SearchPizzaSizes;
using Api.Generated;
using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Customers;
using LaPrizza.Application.Allergens.CreateAllergen;
using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Application.Allergens.UpdateAllergen;
using LaPrizza.Application.Customers.CreateCustomer;
using LaPrizza.Application.Customers.UpdateCustomer;
using LaPrizza.Application.SizeConfiguration;
using LaPrizza.Application.SizeConfiguration.CreateSizeConfiguration;
using LaPrizza.Application.SizeConfiguration.UpdateSizeConfiguration;
using LaPrizza.Application.Stock;
using LaPrizza.Application.Stock.SearchStock;
using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;
using LaPrizza.Application.ProductCategories.CreateProductCategory;
using LaPrizza.Application.ProductCategories.SearchProductCategories;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Application.Products.SearchProducts;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ProductCategories;

namespace Api.Contracts;

/// <summary>
/// Translates between the HTTP contract and the application layer. The request
/// and response types are generated from <c>docs/api/openapi.json</c> (see
/// <c>nswag.json</c>); these extensions are the only place where their shapes are
/// mapped onto the use-case command and result.
/// </summary>
internal static class ContractMappings
{
    public static CreateProductCategoryCommand ToCommand(this CreateProductCategoryRequest request) =>
        new(request.Code, request.Name, request.Description, request.AllowsComponentTypes);

    public static ProductCategoryResponse ToResponse(this CreateProductCategoryResult result) => new()
    {
        Code = result.Code,
        Name = result.Name,
        Description = result.Description,
        AllowsComponentTypes = result.AllowsComponentTypes,
    };

    public static ProductCategoryResponse ToResponse(this ProductCategoryLookupResult result) => new()
    {
        Code = result.Code,
        Name = result.Name,
        Description = result.Description,
        AllowsComponentTypes = result.AllowsComponentTypes,
    };

    public static ProductCategorySearchResponse ToResponse(this SearchProductCategoriesResult result) => new()
    {
        Items = result.Items.Select(item => new ProductCategoryResponse
        {
            Code = item.Code,
            Name = item.Name,
            Description = item.Description,
            AllowsComponentTypes = item.AllowsComponentTypes,
        }).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static CreatePizzaComponentTypeCommand ToCommand(this CreatePizzaComponentTypeRequest request) =>
        new(
            request.Code,
            request.CategoryCode,
            request.Name,
            request.Description,
            request.AssemblyOrder,
            request.MinQuantity,
            request.MaxQuantity);

    public static CreatePizzaSizeCommand ToCommand(this CreatePizzaSizeRequest request) =>
        new(request.Name, request.Description);

    /// <summary>
    /// Maps the update request onto the application command. The code comes from
    /// the route and identifies the type; it is immutable and not part of the body.
    /// </summary>
    public static UpdatePizzaComponentTypeCommand ToCommand(
        this UpdatePizzaComponentTypeRequest request,
        string componentTypeCode) =>
        new(
            componentTypeCode,
            request.Name,
            request.Description,
            request.AssemblyOrder,
            request.MinQuantity,
            request.MaxQuantity);

    public static PizzaComponentTypeResponse ToResponse(this PizzaComponentTypeResult result) => new()
    {
        Code = result.Code,
        CategoryCode = result.CategoryCode,
        Name = result.Name,
        Description = result.Description,
        AssemblyOrder = result.AssemblyOrder,
        MinQuantity = result.MinQuantity,
        MaxQuantity = result.MaxQuantity,
    };

    public static PizzaSizeResponse ToResponse(this PizzaSizeResult result) => new()
    {
        Id = result.Id,
        Name = result.Name,
        Description = result.Description,
    };

    public static PizzaSizeSearchResponse ToResponse(this SearchPizzaSizesResult result) => new()
    {
        Items = result.Items.Select(item => item.ToResponse()).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static PizzaComponentTypeSearchResponse ToResponse(this SearchPizzaComponentTypesResult result) => new()
    {
            Items = result.Items.Select(item => item.ToResponse()).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static CreateAllergenCommand ToCommand(this CreateAllergenRequest request) =>
        new(request.Code, request.Name, request.Description);

    public static AllergenResponse ToResponse(this CreateAllergenResult result) => new()
    {
        Code = result.Code, Name = result.Name, Description = result.Description,
    };

    public static AllergenResponse ToResponse(this AllergenLookupResult result) => new()
    {
        Code = result.Code, Name = result.Name, Description = result.Description,
    };

    public static AllergenSearchResponse ToResponse(this SearchAllergensResult result) => new()
    {
        Items = result.Items
            .Select(item => new AllergenResponse
            {
                Code = item.Code, Name = item.Name, Description = item.Description,
            })
            .ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static UpdateAllergenCommand ToCommand(
        this UpdateAllergenRequest request,
        string allergenCode) =>
        new(allergenCode, request.Name, request.Description);

    public static AllergenResponse ToResponse(this UpdateAllergenResult result) => new()
    {
        Code = result.Code, Name = result.Name, Description = result.Description,
    };

    /// <summary>Maps the create-customer request onto the application command.</summary>
    public static CreateCustomerCommand ToCommand(this CreateCustomerRequest request) =>
        new(request.Name, request.Email, request.PhoneNumber, request.Password, request.DietaryRestrictions ?? [], request.VatNumber);

    /// <summary>
    /// Maps the update-customer request onto the application command. The id
    /// comes from the route, so it is passed separately.
    /// </summary>
    public static UpdateCustomerCommand ToCommand(this UpdateCustomerRequest request, Guid id) =>
        new(id, request.Name, request.PhoneNumber, request.VatNumber);

    /// <summary>Maps the customer read model onto the response body.</summary>
    public static CustomerResponse ToResponse(this CustomerResult result) => new()
    {
        Id = result.Id,
        Name = result.Name,
        Email = result.Email,
        PhoneNumber = result.PhoneNumber,
        VatNumber = result.VATNumber,
        Active = result.Active,
    };

    /// <summary>
    /// Maps the create-size-configuration request onto the application command.
    /// The product comes from the route, so it is passed separately.
    /// </summary>
    public static CreateSizeConfigurationCommand ToCommand(this CreateSizeConfigurationRequest request,
        string productId) =>
        new(productId, request.SizeId, (decimal)request.Price, request.StockConsumption);

    /// <summary>
    /// Maps the update-size-configuration request onto the application command.
    /// The product comes from the route; the size in the body identifies the
    /// configuration to update, and an absent `active` keeps the current value.
    /// </summary>
    public static UpdateSizeConfigurationCommand ToCommand(this UpdateSizeConfigurationRequest request,
        string productId) =>
        new(
            productId,
            request.SizeId,
            (decimal)request.Price,
            request.StockConsumption,
            request.Active);

    /// <summary>Maps the size-configuration read model onto the response body.</summary>
    public static SizeConfigurationResponse ToResponse(this SizeConfigurationResult result) => new()
    {
        SizeId = result.SizeId,
        Price = (double)result.Price,
        StockConsumption = result.StockConsumption,
        Active = result.Active,
    };

    /// <summary>Maps the product stock read model onto the response body (BCK09).</summary>
    public static StockResponse ToResponse(this ProductStockResult result) => new()
    {
        ProductCode = result.ProductCode,
        ProductName = result.ProductName,
        Active = result.Active,
        QuantityInStock = result.QuantityInStock,
    };

    /// <summary>Maps a page of the stock search onto the response body (BCK09).</summary>
    public static StockSearchPage ToResponse(this SearchStockResult result) => new()
    {
        Items = result.Items.Select(item => new StockSearchItem
        {
            ProductCode = item.ProductCode,
            ProductName = item.ProductName,
            Active = item.Active,
            CategoryCode = item.CategoryCode,
            QuantityInStock = item.QuantityInStock,
        }).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static CreateProductCommand ToCommand(this CreateProductRequest request) =>
        new(
            request.Code,
            request.Name,
            request.Description,
            request.CategoryCode,
            request.Sellable,
            request.StockControlled,
            request.Price is null ? null : (decimal)request.Price.Value,
            request.AllergenCodes?.ToList() ?? [],
            request.ComponentTypeCode
        );

    public static ProductResponse ToResponse(this CreateProductResult result)
    {
        return new()
        {
            Id = result.Id,
            Code = result.Code,
            Name = result.Name,
            Description = result.Description,
            CategoryCode = result.CategoryCode,
            Sellable = result.Sellable,
            Price = result.Price is null ? null : (double)result.Price.Value,
            StockControlled = result.StockControlled,
            StockBalance = result.StockBalance,
            Active = result.Active,
            AllergenCodes = result.AllergenCodes.ToList(),
            ComponentTypeCode = result.ComponentTypeCode,
            IsPizzaComponent = result.ComponentTypeCode is not null,
        };
    }

    public static ProductResponse ToResponse(this ProductLookupResult result) => new()
    {
        Id = result.Id,
        Code = result.Code,
        Name = result.Name,
        Description = result.Description,
        Kind = result.Kind == "Composed"
            ? ProductResponseKind.Composed
            : ProductResponseKind.Base,
        CategoryCode = result.CategoryCode,
        Sellable = result.Sellable,
        Price = result.Price is null ? null : (double)result.Price.Value,
        ComponentTypeCode = result.ComponentTypeCode,
        IsPizzaComponent = result.IsPizzaComponent,
        StockControlled = result.StockControlled,
        StockBalance = result.StockBalance,
        Active = result.Active,
        AllergenCodes = result.AllergenCodes.ToList(),
    };

    public static SearchProductsQuery ToQuery(
        string? search,
        string? categoryCode,
        string? allergenCode,
        string? componentTypeCode,
        bool? sellable,
        bool? stockControlled,
        bool? isPizzaComponent,
        string? kind,
        bool? active,
        int page,
        int pageSize) => new(
        search, categoryCode, allergenCode, componentTypeCode,
        sellable, stockControlled, isPizzaComponent, kind, active,
        page, pageSize);

    public static ProductSearchResponse ToResponse(this SearchProductsResult result) => new()
    {
        Items = result.Items.Select(item => new ProductSearchItem
        {
            Code = item.Code,
            Name = item.Name,
            Description = item.Description,
            CategoryCode = item.CategoryCode,
            Sellable = item.Sellable,
            StockControlled = item.StockControlled,
            ComponentTypeCode = item.ComponentTypeCode,
            IsPizzaComponent = item.IsPizzaComponent,
            Kind = item.Kind == LaPrizza.Domain.Products.ProductKind.Composed
                ? ProductSearchItemKind.Composed
                : ProductSearchItemKind.Base,
            Active = item.Active,
            AllergenCodes = item.AllergenCodes.ToList(),
        }).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static CreatePredefinedPizzaCommand ToCommand(this CreatePredefinedPizzaRequest request) =>
        new(
            request.Code,
            request.Name,
            request.Description,
            request.CategoryCode,
            request.ComponentCodes?.ToList(),
            request.SizeIds?.ToList());

    public static PredefinedPizzaResponse ToResponse(this PredefinedPizzaResult result) => new()
    {
        Code = result.Code,
        Name = result.Name,
        Description = result.Description,
        CategoryCode = result.CategoryCode,
        Active = result.Active,
        DefaultConfiguration = result.DefaultConfiguration
            .Select(component => new Api.Generated.PredefinedPizzaComponent
            {
                ProductCode = component.ProductCode,
                Name = component.Name,
                ComponentTypeCode = component.ComponentTypeCode,
                AssemblyOrder = component.AssemblyOrder,
            })
            .ToList(),
        AvailableSizes = result.Sizes
            .Select(size => new PredefinedPizzaSize { SizeId = size.SizeId, Price = (double)size.Price })
            .ToList(),
    };

    public static UpdatePredefinedPizzaCommand ToCommand(this UpdatePredefinedPizzaRequest request, string productCode) =>
        new(
            productCode,
            request.Name,
            request.Description,
            request.ComponentCodes?.ToList(),
            request.SizeIds?.ToList());

    public static PredefinedPizzaSearchResponse ToResponse(this SearchPredefinedPizzasResult result) => new()
    {
        Items = result.Items.Select(item => new Api.Generated.PredefinedPizzaSearchItem
        {
            Code = item.Code,
            Name = item.Name,
            CategoryCode = item.CategoryCode,
            Active = item.Active,
        }).ToList(),
        Page = result.Page,
        PageSize = result.PageSize,
        TotalCount = result.TotalCount,
    };

    public static CatalogueListResponse ToResponse(this CatalogueResult result) => new()
    {
        Items = result.Items.Select(entry => entry.ToResponse()).ToList(),
    };

    public static CatalogueProduct ToResponse(this CatalogueProductResult entry) => new()
    {
        ProductCode = entry.ProductCode,
        Name = entry.Name,
        Description = entry.Description,
        Category = entry.Category is null ? null : new CatalogueCategory
        {
            Code = entry.Category.Code,
            Name = entry.Category.Name,
        },
        UnitPrice = entry.UnitPrice is null ? null : (double)entry.UnitPrice.Value,
        Sizes = entry.Sizes.Select(size => new CatalogueSize
        {
            Name = size.Name,
            Price = (double)size.Price,
        }).ToList(),
        Allergens = entry.Allergens.ToList(),
        // Composed pizzas do not exist in the domain yet, so the default
        // configuration is always null until BCK10/BCK12 land.
        Configuration = entry.Configuration is null ? null : new CatalogueConfiguration
        {
            Components = entry.Configuration.Components.Select(component => new CatalogueComponent
            {
                ProductCode = component.ProductCode,
                Name = component.Name,
            }).ToList(),
        },
    };
}
