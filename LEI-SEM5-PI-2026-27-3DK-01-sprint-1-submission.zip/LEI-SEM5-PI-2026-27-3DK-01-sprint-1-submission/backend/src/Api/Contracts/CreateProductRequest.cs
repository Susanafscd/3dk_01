using System.Text.Json.Serialization;

namespace Api.Generated;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public partial class CreateProductRequest;
