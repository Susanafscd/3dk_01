using System.Text.Json.Serialization;

namespace Api.Generated;

// NSwag supplies the fields/validation. Enforce additionalProperties=false
// during deserialization as well, without hand-editing the generated file.
[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public partial class CreateAllergenRequest;
