namespace Api.OpenApi;

/// <summary>
/// Serves the OpenAPI contract and mounts the Swagger UI that renders it. The
/// contract is the input of this project: it is authored as one fragment per use
/// case under <c>docs/api/contract</c>, bundled into <c>docs/api/openapi.json</c>
/// (see the BundleOpenApiContract target in <c>Api.csproj</c>), copied next to
/// the application, and is the source of the generated controllers and DTOs (see
/// <c>nswag.json</c>). The API serves that very bundled file, so Swagger UI and
/// the generated code can never describe different APIs.
/// </summary>
public static class ApiDocumentation
{
    /// <summary>Name of the document and of the Swagger UI entry.</summary>
    public const string DocumentName = "v1";

    /// <summary>Route at which the contract is served.</summary>
    public const string DocumentRoute = $"/swagger/{DocumentName}/swagger.json";

    /// <summary>Publishes the OpenAPI contract and the Swagger UI that renders it.</summary>
    public static WebApplication UseApiDocumentation(this WebApplication app)
    {
        var contractPath = Path.Combine(AppContext.BaseDirectory, "OpenApi", "openapi.json");

        app.MapGet(DocumentRoute, () => Results.File(contractPath, "application/json"))
            .AllowAnonymous();

        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint(DocumentRoute, "LaPrizza API v1");
            options.DocumentTitle = "LaPrizza API";
        });

        return app;
    }
}
