namespace Api;

/// <summary>
/// Names used by the antiforgery protection. They are constants because the same
/// names are configured on the middleware, checked by the global filter and
/// documented in the OpenAPI contract, and must not drift apart.
/// </summary>
public static class AntiforgeryDefaults
{
    /// <summary>Request header a client must send the antiforgery token in.</summary>
    public const string HeaderName = "X-CSRF-TOKEN";

    /// <summary>Cookie that carries the antiforgery token.</summary>
    public const string CookieName = "Api.Antiforgery";
}
