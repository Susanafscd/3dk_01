using Api.Contracts;
using Api.Generated;
using Api.Authorization;
using System.Security.Claims;
using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Users;
using LaPrizza.Application.Customers.CreateCustomer;
using LaPrizza.Application.Customers.DeactivateCustomer;
using LaPrizza.Application.Customers.GetCustomer;
using LaPrizza.Application.Customers.SearchCustomers;
using LaPrizza.Application.Customers.UpdateCustomer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements the customer management endpoints (BCK02): register, read, search,
/// update and deactivate customers. The routes and the request/response bodies
/// come from the OpenAPI contract; this class only supplies the behaviour.
/// Registering a customer also creates the authentication account behind it. The
/// endpoints are authenticated by default, as every endpoint is unless it opts
/// out with [AllowAnonymous].
/// </summary>
[ApiController]
public sealed class CustomersController(
    CreateCustomerCommandHandler createCustomer,
    GetCustomerQueryHandler getCustomer,
    SearchCustomersQueryHandler searchCustomers,
    UpdateCustomerCommandHandler updateCustomer,
    DeactivateCustomerCommandHandler deactivateCustomer,
    IUserRepository users)
    : CustomersControllerBase
{
    /// <inheritdoc />
    [Authorize(Policy = ManagerRequirement.PolicyName)]
    public override async Task<ActionResult<ICollection<CustomerResponse>>> SearchCustomers(
        string? search,
        CancellationToken cancellationToken = default)
    {
        var results = await searchCustomers.HandleAsync(new SearchCustomersQuery(search), cancellationToken);

        return Ok(results.Select(result => result.ToResponse()).ToArray());
    }

    /// <inheritdoc />
    [AllowAnonymous]
    public override async Task<ActionResult<CustomerResponse>> CreateCustomer(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreateCustomerRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createCustomer.HandleAsync(body.ToCommand(), cancellationToken);

        return Created($"{Request.Path}/{result.Id}", result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<CustomerResponse>> GetCustomer(
        Guid id,
        CancellationToken cancellationToken = default)
    {
        var result = await getCustomer.HandleAsync(new GetCustomerQuery(id), cancellationToken);

        if (!IsManager() && !string.Equals(result.Email, CurrentEmail(), StringComparison.OrdinalIgnoreCase))
        {
            return Forbid();
        }

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<CustomerResponse>> UpdateCustomer(
        Guid id,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdateCustomerRequest body,
        CancellationToken cancellationToken = default)
    {
        if (!IsManager() && !await OwnsCustomerAsync(id, cancellationToken))
        {
            return Forbid();
        }

        var result = await updateCustomer.HandleAsync(body.ToCommand(id), cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    [Authorize(Policy = ManagerRequirement.PolicyName)]
    public override async Task<IActionResult> DeactivateCustomer(
        Guid id,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        await deactivateCustomer.HandleAsync(new DeactivateCustomerCommand(id), cancellationToken);

        return NoContent();
    }

    private bool IsManager() => User.IsInRole(ManagerRequirement.PolicyName);

    private string? CurrentEmail() =>
        User.FindFirstValue(ClaimTypes.Email) ?? User.Identity?.Name;

    private async Task<bool> OwnsCustomerAsync(Guid id, CancellationToken cancellationToken)
    {
        var email = CurrentEmail();
        if (string.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        var user = await users.GetByIdAsync(id, cancellationToken);
        return user is Customer customer
            && string.Equals(customer.Email.Value, email, StringComparison.OrdinalIgnoreCase);
    }
}
