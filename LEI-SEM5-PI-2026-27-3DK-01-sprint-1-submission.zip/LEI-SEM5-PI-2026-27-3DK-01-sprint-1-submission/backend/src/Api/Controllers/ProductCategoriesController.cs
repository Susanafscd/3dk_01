using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.ProductCategories.CreateProductCategory;
using LaPrizza.Application.ProductCategories.GetProductCategory;
using LaPrizza.Application.ProductCategories.RemoveProductCategory;
using LaPrizza.Application.ProductCategories.SearchProductCategories;
using LaPrizza.Application.ProductCategories.UpdateProductCategory;
using LaPrizza.Domain.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class ProductCategoriesController(
    CreateProductCategoryCommandHandler createCategory,
    GetProductCategoryQueryHandler getCategory,
    SearchProductCategoriesQueryHandler searchCategories,
    IRemoveProductCategoryUseCase? removeProductCategoryWorkflow = null,
    IUpdateProductCategoryUseCase? updateProductCategoryWorkflow = null) : ProductCategoriesControllerBase
{
    public override async Task<ActionResult<ProductCategoryResponse>> CreateProductCategory(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreateProductCategoryRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createCategory.HandleAsync(body.ToCommand(), cancellationToken);
        return Created($"{Request.PathBase}/api/v1/product-categories/{result.Code}", result.ToResponse());
    }

    public override async Task<ActionResult<ProductCategoryResponse>> GetProductCategory(
        string categoryCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getCategory.HandleAsync(new GetProductCategoryQuery(categoryCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<ProductCategorySearchResponse>> SearchProductCategories(
        string? search,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchCategories.HandleAsync(
            new SearchProductCategoriesQuery(search, page ?? 1, pageSize ?? 20), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<IActionResult> RemoveProductCategory(
        string categoryCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        LaPrizza.Domain.ProductCategories.ProductCategoryCode code;
        try { code = LaPrizza.Domain.ProductCategories.ProductCategoryCode.Create(categoryCode); }
        catch (DomainException) { return BadRequest(); }
        if (removeProductCategoryWorkflow is null)
            return Problem(statusCode: 501, title: "This operation is awaiting protected persistence integration.");
        await removeProductCategoryWorkflow.ExecuteAsync(
            new RemoveProductCategoryCommand(code.Value), cancellationToken);
        return NoContent();
    }

    public override async Task<ActionResult<ProductCategoryResponse>> UpdateProductCategory(
        string categoryCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdateProductCategoryRequest body,
        CancellationToken cancellationToken = default)
    {
        LaPrizza.Domain.ProductCategories.ProductCategoryCode code;
        try { code = LaPrizza.Domain.ProductCategories.ProductCategoryCode.Create(categoryCode); }
        catch (DomainException) { return BadRequest(); }
        if (updateProductCategoryWorkflow is null)
            return Problem(statusCode: 501, title: "This operation is awaiting protected persistence integration.");
        var result = await updateProductCategoryWorkflow.ExecuteAsync(
            new UpdateProductCategoryCommand(code.Value, body.Name, body.Description, body.AllowsComponentTypes), cancellationToken);
        return Ok(result.ToResponse());
    }
}
