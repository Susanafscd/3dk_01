using Api.Generated;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements <c>GET /api/v1/health</c>, generated from the OpenAPI contract.
/// It reports that the API is running and which version is deployed, and is
/// anonymous because every other endpoint is authenticated by default.
/// </summary>
[ApiController]
[AllowAnonymous]
public sealed class HealthController : HealthControllerBase
{
    private static readonly string ApiVersion =
        typeof(HealthController).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";

    /// <inheritdoc />
    public override Task<ActionResult<HealthResponse>> GetHealth(
        CancellationToken cancellationToken = default)
    {
        ActionResult<HealthResponse> response = Ok(new HealthResponse
        {
            Status = "ok",
            Version = ApiVersion,
            Timestamp = DateTime.UtcNow,
        });

        return Task.FromResult(response);
    }
}
