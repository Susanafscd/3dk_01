﻿using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.SizeConfiguration.CreateSizeConfiguration;
using LaPrizza.Application.SizeConfiguration.ListSizeConfigurations;
using LaPrizza.Application.SizeConfiguration.UpdateSizeConfiguration;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements the size-configuration endpoints of pizza components (BCK08):
/// create, consult and update the size-dependent configuration of a product. The
/// routes and the request/response bodies come from the OpenAPI contract; this
/// class only supplies the behavior by calling the application use cases. There
/// is no read of a single configuration: GET always returns the component's full
/// list, and there is no deletion — a configuration is deactivated through PUT.
/// </summary>
/// <remarks>
/// The endpoints require an authenticated Manager; POST and PUT also carry the
/// antiforgery token in the 'X-CSRF-TOKEN' header.
/// </remarks>
[ApiController]
public sealed class SizeConfigurationController(
    CreateSizeConfigurationCommandHandler createSizeConfiguration,
    ListSizeConfigurationsQueryHandler listSizeConfigurations,
    UpdateSizeConfigurationCommandHandler updateSizeConfiguration)
    : SizeConfigurationControllerBase
{
    /// <inheritdoc />
    public override async Task<ActionResult<SizeConfigurationResponse>> CreateComponentSizeConfiguration(
        string productId,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreateSizeConfigurationRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createSizeConfiguration.HandleAsync(
            body.ToCommand(ValidateProductId(productId)),
            cancellationToken);

        // There is no read endpoint for a single configuration; the Location
        // points at the component's size-configuration collection.
        return Created(Request.Path, result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<SizeConfigurationListResponse>> ListPizzaComponentSizeConfigurations(
        string productId,
        CancellationToken cancellationToken = default)
    {
        var results = await listSizeConfigurations.HandleAsync(
            new ListSizeConfigurationsQuery(ValidateProductId(productId)),
            cancellationToken);

        return Ok(new SizeConfigurationListResponse
        {
            Items = results.Select(result => result.ToResponse()).ToList(),
        });
    }

    /// <inheritdoc />
    public override async Task<ActionResult<SizeConfigurationResponse>> UpdatePizzaComponentSizeConfiguration(
        string productId,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdateSizeConfigurationRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await updateSizeConfiguration.HandleAsync(
            body.ToCommand(ValidateProductId(productId)),
            cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <summary>
    /// Rejects an empty route product identifier as a bad request before any use
    /// case runs (BCK08); product and size identifiers are strings, so anything
    /// beyond that is the domain's and the store's concern.
    /// </summary>
    private static string ValidateProductId(string? productId)
    {
        if (string.IsNullOrWhiteSpace(productId))
        {
            throw new ValidationException("'productId' is not a valid pizza component identifier.");
        }

        return productId;
    }
}
