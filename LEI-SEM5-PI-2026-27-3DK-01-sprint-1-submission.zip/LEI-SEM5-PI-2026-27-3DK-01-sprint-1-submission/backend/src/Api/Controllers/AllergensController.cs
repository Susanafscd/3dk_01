using LaPrizza.Application.Allergens.RemoveAllergen;
using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.Allergens.CreateAllergen;
using LaPrizza.Application.Allergens.GetAllergen;
using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Application.Allergens.UpdateAllergen;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class AllergensController(
    CreateAllergenCommandHandler createAllergen,
    GetAllergenQueryHandler getAllergen,
    SearchAllergensQueryHandler searchAllergens,
    UpdateAllergenCommandHandler updateAllergen,
    IRemoveAllergenUseCase removeAllergenWorkflow) : AllergensControllerBase
{
    public override async Task<ActionResult<AllergenResponse>> UpdateAllergen(
        string allergenCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdateAllergenRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await updateAllergen.HandleAsync(
            body.ToCommand(allergenCode),
            cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<AllergenSearchResponse>> SearchAllergens(
        string? search,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchAllergens.HandleAsync(
            new SearchAllergensQuery(search, page ?? 1, pageSize ?? 20),
            cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<AllergenResponse>> GetAllergen(
        string allergenCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getAllergen.HandleAsync(new GetAllergenQuery(allergenCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<AllergenResponse>> CreateAllergen(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreateAllergenRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createAllergen.HandleAsync(body.ToCommand(), cancellationToken);
        return Created($"{Request.PathBase}/api/v1/allergens/{result.Code}", result.ToResponse());
    }

    public override async Task<IActionResult> RemoveAllergen(
        string allergenCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        var code = LaPrizza.Domain.Allergens.AllergenCode.Create(allergenCode);
        await removeAllergenWorkflow.ExecuteAsync(
            new RemoveAllergenCommand(code.Value), cancellationToken);
        return NoContent();
    }
}
