using Api.Generated;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Provides antiforgery token.
/// </summary>
[ApiController]
[AllowAnonymous]
public sealed class AntiforgeryController(IAntiforgery antiforgery) : AntiforgeryControllerBase
{
    /// <inheritdoc />
    public override Task<ActionResult<Api.Generated.AntiforgeryTokenResponse>> GetAntiforgeryToken(CancellationToken cancellationToken = default)
    {
        var tokens = antiforgery.GetAndStoreTokens(HttpContext);

        var response = new Api.Generated.AntiforgeryTokenResponse { Token = tokens.RequestToken ?? string.Empty };
        return Task.FromResult<ActionResult<Api.Generated.AntiforgeryTokenResponse>>(Ok(response));
    }
}
