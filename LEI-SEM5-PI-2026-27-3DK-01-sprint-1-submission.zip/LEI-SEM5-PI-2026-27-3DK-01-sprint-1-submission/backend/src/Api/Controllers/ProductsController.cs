using LaPrizza.Application.Products.DeactivateProduct;
using LaPrizza.Application.Products.UpdateProduct;
using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Application.Products.SearchProducts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>UC-23: registers base products through the generated OpenAPI contract.</summary>
[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class ProductsController(
    CreateProductCommandHandler createProduct,
    GetProductQueryHandler getProduct,
    SearchProductsQueryHandler searchProducts,
    IUpdateProductUseCase updateProductWorkflow,
    IDeactivateProductUseCase deactivateProductWorkflow) : ProductsControllerBase
{
    public override async Task<ActionResult<ProductResponse>> CreateProduct(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreateProductRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createProduct.HandleAsync(body.ToCommand(), cancellationToken);
        return Created($"{Request.PathBase}/api/v1/products/{result.Code}", result.ToResponse());
    }

    public override async Task<ActionResult<ProductResponse>> GetProduct(
        string productCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getProduct.HandleAsync(
            new GetProductQuery(productCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<ProductSearchResponse>> SearchProducts(
        string? search,
        string? categoryCode,
        string? allergenCode,
        string? componentTypeCode,
        bool? sellable,
        bool? stockControlled,
        bool? isPizzaComponent,
        Kind? kind,
        bool? active,
        int? page,
        int? pageSize,
        CancellationToken cancellationToken = default)
    {
        var result = await searchProducts.HandleAsync(
            ContractMappings.ToQuery(
                search, categoryCode, allergenCode, componentTypeCode,
                sellable, stockControlled, isPizzaComponent,
                kind?.ToString(), active, page ?? 1, pageSize ?? 20),
            cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<ProductResponse>> UpdateProduct(
        string productCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdateProductRequest body,
        CancellationToken cancellationToken = default)
    {
        var code = LaPrizza.Domain.Products.ProductCode.Create(productCode);
        var result = await updateProductWorkflow.ExecuteAsync(
            new UpdateProductCommand(code.Value, body.Name, body.Description, body.CategoryCode, body.Sellable, body.StockControlled, body.Price is null ? null : (decimal)body.Price.Value, body.AllergenCodes.ToList(), body.ComponentTypeCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<IActionResult> DeactivateProduct(
        string productCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        var code = LaPrizza.Domain.Products.ProductCode.Create(productCode);
        await deactivateProductWorkflow.ExecuteAsync(
            new DeactivateProductCommand(code.Value), cancellationToken);
        return NoContent();
    }
}
