using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;
using LaPrizza.Application.PredefinedPizzas.GetPredefinedPizza;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements the predefined pizza endpoints (BCK10). The routes and the
/// request/response bodies come from the OpenAPI contract; this class only
/// supplies the behavior by calling the application use cases, and errors become
/// problem details in the global exception handler.
/// </summary>
[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class PredefinedPizzasController(
    CreatePredefinedPizzaCommandHandler createPredefinedPizza,
    GetPredefinedPizzaQueryHandler getPredefinedPizza,
    SearchPredefinedPizzasQueryHandler searchPredefinedPizzas,
    UpdatePredefinedPizzaCommandHandler updatePredefinedPizza)
    : PredefinedPizzasControllerBase
{
    /// <inheritdoc />
    public override async Task<ActionResult<PredefinedPizzaResponse>> CreatePredefinedPizza(
        [FromHeader(Name = "X-CSRF-TOKEN")] string x_CSRF_TOKEN,
        CreatePredefinedPizzaRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createPredefinedPizza.HandleAsync(body.ToCommand(), cancellationToken);

        return Created($"{Request.PathBase}/api/v1/predefined-pizzas/{result.Code}", result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<PredefinedPizzaResponse>> GetPredefinedPizza(
        string productCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getPredefinedPizza.HandleAsync(new GetPredefinedPizzaQuery(productCode), cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<PredefinedPizzaSearchResponse>> SearchPredefinedPizzas(
        string? search,
        bool? active,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchPredefinedPizzas.HandleAsync(
            new SearchPredefinedPizzasQuery(search, active, page ?? 1, pageSize ?? 20),
            cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<PredefinedPizzaResponse>> UpdatePredefinedPizza(
        string productCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string x_CSRF_TOKEN,
        UpdatePredefinedPizzaRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await updatePredefinedPizza.HandleAsync(body.ToCommand(productCode), cancellationToken);

        return Ok(result.ToResponse());
    }
}
