using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.ComponentTypes.CreatePizzaSize;
using LaPrizza.Application.ComponentTypes.DeletePizzaSize;
using LaPrizza.Application.ComponentTypes.GetPizzaSize;
using LaPrizza.Application.ComponentTypes.SearchPizzaSizes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class PizzaSizesController(
    CreatePizzaSizeCommandHandler createSize,
    GetPizzaSizeQueryHandler getSize,
    SearchPizzaSizesQueryHandler searchSizes,
    DeletePizzaSizeCommandHandler deleteSize) : PizzaSizesControllerBase
{
    public override async Task<ActionResult<PizzaSizeResponse>> CreatePizzaSize(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreatePizzaSizeRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createSize.HandleAsync(body.ToCommand(), cancellationToken);
        return Created($"{Request.PathBase}/api/v1/pizza-sizes/{result.Id}", result.ToResponse());
    }

    public override async Task<ActionResult<PizzaSizeResponse>> GetPizzaSize(
        Guid id,
        CancellationToken cancellationToken = default)
    {
        var result = await getSize.HandleAsync(new GetPizzaSizeQuery(id), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<PizzaSizeSearchResponse>> SearchPizzaSizes(
        string? search,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchSizes.HandleAsync(
            new SearchPizzaSizesQuery(search, page ?? 1, pageSize ?? 20),
            cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<IActionResult> DeletePizzaSize(
        Guid id,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        await deleteSize.HandleAsync(new DeletePizzaSizeCommand(id), cancellationToken);
        return NoContent();
    }
}
