using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;
using LaPrizza.Application.ComponentTypes.DeletePizzaComponentType;
using LaPrizza.Application.ComponentTypes.GetPizzaComponentType;
using LaPrizza.Application.ComponentTypes.SearchPizzaComponentTypes;
using LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class PizzaComponentTypesController(
    CreatePizzaComponentTypeCommandHandler createType,
    GetPizzaComponentTypeQueryHandler getType,
    SearchPizzaComponentTypesQueryHandler searchTypes,
    UpdatePizzaComponentTypeCommandHandler updateType,
    DeletePizzaComponentTypeCommandHandler deleteType) : PizzaComponentTypesControllerBase
{
    public override async Task<ActionResult<PizzaComponentTypeResponse>> CreatePizzaComponentType(
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CreatePizzaComponentTypeRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await createType.HandleAsync(body.ToCommand(), cancellationToken);
        return Created($"{Request.PathBase}/api/v1/pizza-component-types/{result.Code}", result.ToResponse());
    }

    public override async Task<ActionResult<PizzaComponentTypeResponse>> GetPizzaComponentType(
        string componentTypeCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getType.HandleAsync(new GetPizzaComponentTypeQuery(componentTypeCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<PizzaComponentTypeSearchResponse>> SearchPizzaComponentTypes(
        string? search,
        string? categoryCode,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchTypes.HandleAsync(
            new SearchPizzaComponentTypesQuery(search, categoryCode, page ?? 1, pageSize ?? 20),
            cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<ActionResult<PizzaComponentTypeResponse>> UpdatePizzaComponentType(
        string componentTypeCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        UpdatePizzaComponentTypeRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await updateType.HandleAsync(body.ToCommand(componentTypeCode), cancellationToken);
        return Ok(result.ToResponse());
    }

    public override async Task<IActionResult> DeletePizzaComponentType(
        string componentTypeCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string csrfToken,
        CancellationToken cancellationToken = default)
    {
        await deleteType.HandleAsync(new DeletePizzaComponentTypeCommand(componentTypeCode), cancellationToken);
        return NoContent();
    }
}
