using Api.Authorization;
using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.Stock.DecreaseStock;
using LaPrizza.Application.Stock.GetProductStock;
using LaPrizza.Application.Stock.IncreaseStock;
using LaPrizza.Application.Stock.SearchStock;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements the stock endpoints (BCK09): retrieve, search, increase and
/// decrease the stock of stock-controlled products, identified by their business
/// code. The routes and the request/response bodies come from the OpenAPI
/// contract; this class only supplies the behavior by calling the application
/// use cases, and errors become problem details in the global exception handler.
/// </summary>
/// <remarks>
/// Increase and decrease carry the antiforgery token in the 'X-CSRF-TOKEN' header.
/// Every operation requires an authenticated Manager.
/// </remarks>
[ApiController]
[Authorize(Policy = ManagerRequirement.PolicyName)]
public sealed class StockController(
    GetProductStockQueryHandler getProductStock,
    SearchStockQueryHandler searchStock,
    IncreaseStockCommandHandler increaseStock,
    DecreaseStockCommandHandler decreaseStock)
    : StockControllerBase
{
    /// <inheritdoc />
    public override async Task<ActionResult<StockResponse>> GetProductStock(
        string productCode,
        CancellationToken cancellationToken = default)
    {
        var result = await getProductStock.HandleAsync(new GetProductStockQuery(productCode), cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<StockSearchPage>> SearchStock(
        string? search,
        string? categoryCode,
        bool? active,
        int? page = 1,
        int? pageSize = 20,
        CancellationToken cancellationToken = default)
    {
        var result = await searchStock.HandleAsync(
            new SearchStockQuery(search, categoryCode, active, page ?? 1, pageSize ?? 20),
            cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<StockResponse>> IncreaseStock(
        string productCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string x_CSRF_TOKEN,
        StockChangeRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await increaseStock.HandleAsync(
            new IncreaseStockCommand(productCode, body.Units),
            cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<StockResponse>> DecreaseStock(
        string productCode,
        [FromHeader(Name = "X-CSRF-TOKEN")] string x_CSRF_TOKEN,
        StockChangeRequest body,
        CancellationToken cancellationToken = default)
    {
        var result = await decreaseStock.HandleAsync(
            new DecreaseStockCommand(productCode, body.Units),
            cancellationToken);

        return Ok(result.ToResponse());
    }
}
