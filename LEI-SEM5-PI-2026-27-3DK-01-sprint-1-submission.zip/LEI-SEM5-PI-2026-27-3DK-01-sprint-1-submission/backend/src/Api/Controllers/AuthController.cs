using Api.Generated;
using LaPrizza.Domain.Users;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>
/// Implements authentication endpoints.
/// </summary>
[ApiController]
public sealed class AuthController(
    SignInManager<IdentityUser> signInManager,
    UserManager<IdentityUser> userManager,
    IUserRepository userRepository)
    : AuthControllerBase
{
    /// <inheritdoc />
    [AllowAnonymous]
    public override async Task<ActionResult<LoginResponse>> Login(
        [FromBody] LoginRequest body,
        CancellationToken cancellationToken = default)
    {
        var user = await userManager.FindByEmailAsync(body.Email);

        if (user is null)
        {
            return Unauthorized();
        }

        var result = await signInManager.CheckPasswordSignInAsync(user, body.Password, false);

        if (!result.Succeeded)
        {
            return Unauthorized();
        }

        await signInManager.SignInAsync(user, isPersistent: true);

        var domainUser = await userRepository.GetByEmailAsync(Email.Create(body.Email), cancellationToken);
        var roles = await userManager.GetRolesAsync(user);

        if (domainUser is null)
        {
            return NotFound();
        }

        return Ok(new LoginResponse
        {
            Id = domainUser.Id,
            Email = domainUser.Email.Value,
            DisplayName = domainUser.DisplayName,
            Roles = roles.ToList(),
        });
    }

    /// <inheritdoc />
    public override async Task<IActionResult> Logout(CancellationToken cancellationToken = default)
    {
        await signInManager.SignOutAsync();
        return NoContent();
    }

    /// <inheritdoc />
    public override async Task<ActionResult<MeResponse>> GetMe(CancellationToken cancellationToken = default)
    {
        var user = await userManager.GetUserAsync(User);

        if (user is null)
        {
            return Unauthorized();
        }

        var domainUser = await userRepository.GetByEmailAsync(Email.Create(user.Email ?? string.Empty), cancellationToken);
        var roles = await userManager.GetRolesAsync(user);

        if (domainUser is null)
        {
            return NotFound();
        }

        return Ok(new MeResponse
        {
            Id = domainUser.Id,
            Email = domainUser.Email.Value,
            DisplayName = domainUser.DisplayName,
            Roles = roles.ToList(),
        });
    }
}
