using Api.Contracts;
using Api.Generated;
using LaPrizza.Application.Catalogue.GetCatalogue;
using LaPrizza.Application.Catalogue.GetCatalogueProduct;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

/// <summary>BCK11: the public, read-only consultation of the products offered for sale.</summary>
[ApiController]
[AllowAnonymous]
public sealed class CatalogueController(
    GetCatalogueQueryHandler getCatalogue,
    GetCatalogueProductQueryHandler getCatalogueProduct) : CatalogueControllerBase
{
    /// <inheritdoc />
    public override async Task<ActionResult<CatalogueListResponse>> ListCatalogue(
        int? page,
        int? pageSize,
        CancellationToken cancellationToken = default)
    {
        var result = await getCatalogue.HandleAsync(
            new GetCatalogueQuery(page ?? 1, pageSize ?? 20),
            cancellationToken);

        return Ok(result.ToResponse());
    }

    /// <inheritdoc />
    public override async Task<ActionResult<CatalogueProduct>> GetCatalogueProduct(
        Guid productId,
        CancellationToken cancellationToken = default)
    {
        var result = await getCatalogueProduct.HandleAsync(
            new GetCatalogueProductQuery(productId),
            cancellationToken);

        return Ok(result.ToResponse());
    }
}
