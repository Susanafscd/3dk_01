using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Common;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace Api;

/// <summary>
/// Global error handler. Turns any unhandled exception into a problem details
/// response so that every error the API produces has the same JSON shape.
/// </summary>
internal sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetailsService,
    IHostEnvironment environment,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    private const string InternalServerErrorType = "https://tools.ietf.org/html/rfc9110#section-15.6.1";
    private const string BadRequestType = "https://tools.ietf.org/html/rfc9110#section-15.5.1";
    private const string ConflictType = "https://tools.ietf.org/html/rfc9110#section-15.5.10";
    private const string NotFoundType = "https://tools.ietf.org/html/rfc9110#section-15.5.5";

    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // A missing or invalid CSRF token is the caller's mistake, not ours.
        // Application and domain errors carry a message that is safe to show.
        var (status, title, type) = exception switch
        {
            AntiforgeryValidationException => (
                StatusCodes.Status400BadRequest,
                "The antiforgery token is missing or invalid.",
                BadRequestType),
            ConflictException conflictException => (
                StatusCodes.Status409Conflict,
                conflictException.Message,
                ConflictType),
            NotFoundException notFoundException => (
                StatusCodes.Status404NotFound,
                notFoundException.Message,
                NotFoundType),
            ValidationException validationException => (
                StatusCodes.Status400BadRequest,
                validationException.Message,
                BadRequestType),
            DomainException domainException => (
                StatusCodes.Status400BadRequest,
                domainException.Message,
                BadRequestType),
            _ => (
                StatusCodes.Status500InternalServerError,
                "An unexpected error occurred.",
                InternalServerErrorType),
        };

        if (status == StatusCodes.Status500InternalServerError)
        {
            logger.LogError(
                exception,
                "Unhandled exception while processing {Method} {Path}.",
                httpContext.Request.Method,
                httpContext.Request.Path);
        }
        else
        {
            logger.LogWarning(
                exception,
                "Rejected {Method} {Path} while processing the request.",
                httpContext.Request.Method,
                httpContext.Request.Path);
        }

        httpContext.Response.StatusCode = status;

        var problemDetails = new ProblemDetails
        {
            Status = status,
            Title = title,
            Type = type,
            Instance = httpContext.Request.Path,
        };

        // The stack trace stays in the logs and is never echoed to the client.
        // In Development the message is included as a convenience only.
        if (environment.IsDevelopment())
        {
            problemDetails.Detail = exception.Message;
        }

        problemDetails.Extensions["traceId"] = httpContext.TraceIdentifier;

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            ProblemDetails = problemDetails,
            Exception = exception,
        });
    }
}
