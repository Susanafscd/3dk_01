namespace Api;

/// <summary>
/// Cross-origin settings, bound from the 'Cors' configuration section. Allowed
/// origins default to the usual local frontend development servers and are
/// overridden per environment with 'Cors__AllowedOrigins__0', '__1', ...
/// </summary>
public sealed class CorsOptions
{
    public const string SectionName = "Cors";

    public string[] AllowedOrigins { get; set; } =
    [
        "http://localhost:5173",
        "http://localhost:3000",
    ];
}
