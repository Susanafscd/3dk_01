using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Api;

/// <summary>
/// Rejects unsafe requests that do not carry a valid antiforgery token.
/// It is what [AutoValidateAntiforgeryToken] does inside MVC, written against
/// the built-in IAntiforgery service so that the API never has to load the MVC
/// view services. Applied globally; safe verbs are skipped.
/// </summary>
internal sealed class AntiforgeryValidationFilter(IAntiforgery antiforgery) : IAsyncAuthorizationFilter
{
    private static readonly HashSet<string> SafeMethods =
        new(StringComparer.OrdinalIgnoreCase) { "GET", "HEAD", "OPTIONS", "TRACE" };

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        if (SafeMethods.Contains(context.HttpContext.Request.Method))
        {
            return;
        }

        // Throws AntiforgeryValidationException, which the global error handler
        // turns into the same problem+json shape as every other error.
        await antiforgery.ValidateRequestAsync(context.HttpContext);
    }
}
