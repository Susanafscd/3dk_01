using System.Text.Json.Serialization;
using Api;
using Api.Authorization;
using Api.OpenApi;
using dotenv.net;
using LaPrizza.Application;
using LaPrizza.Infrastructure;
using Microsoft.AspNetCore.Authorization;

// ---------------------------------------------------------------------------
// Single entry point. It wires the layers together (Application,
// Infrastructure) and configures transport concerns only: HTTP pipeline,
// configuration, error handling, logging, CORS, authentication and antiforgery.
// The domain rules live in LaPrizza.Domain; the use cases in LaPrizza.Application.
// ---------------------------------------------------------------------------

var builder = WebApplication.CreateBuilder(args);

// Development convenience: load a git-ignored .env file (see .env.example) into
// the process environment. Any variable already present in the real environment
// wins, and the file is never read outside Development.
if (builder.Environment.IsDevelopment())
{
    var envFile = Path.Combine(builder.Environment.ContentRootPath, ".env");

    if (File.Exists(envFile))
    {
        // Values already exported in the shell win over the ones in the file.
        new DotEnvOptions()
            .WithEnvFiles([envFile])
            .WithoutOverwriteExistingVars()
            .WithoutProbeForEnv()
            .Load();

        builder.Configuration.AddEnvironmentVariables();
    }
}

var allowedOrigins = (builder.Configuration
        .GetSection($"{CorsOptions.SectionName}:AllowedOrigins")
        .Get<string[]>() ?? new CorsOptions().AllowedOrigins)
    .SelectMany(origin => origin.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
    .Distinct(StringComparer.OrdinalIgnoreCase)
    .ToArray();

// Controllers. The antiforgery filter is added globally so every state-changing
// endpoint is protected by default; safe verbs (GET/HEAD/OPTIONS/TRACE) are
// skipped automatically. Enums are accepted and returned as their names. The
// controllers themselves are generated from docs/api/openapi.json, so no route
// convention is needed here.
builder.Services
    .AddControllers(options => options.Filters.Add<AntiforgeryValidationFilter>())
    .AddJsonOptions(options => options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

// Application use cases and the outbound adapters (relational store, identity,
// document store). Both read the connection strings from configuration.
builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration, builder.Environment);

// One consistent error contract: any unhandled exception becomes problem+json.
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();

// CORS. Origins come from configuration ('Cors__AllowedOrigins__0', ...) and
// default to the usual local frontend dev servers. Credentials are allowed
// because the API authenticates with cookies.
builder.Services.Configure<CorsOptions>(builder.Configuration.GetSection(CorsOptions.SectionName));
builder.Services.AddCors(options => options.AddDefaultPolicy(policy => policy
    .WithOrigins(allowedOrigins)
    .AllowAnyHeader()
    .AllowAnyMethod()
    .AllowCredentials()));

// Authorization: policies over claims. Endpoints are protected by default and
// opt out with [AllowAnonymous], which is what the health endpoint does.
builder.Services.AddAuthorizationBuilder()
    .AddPolicy(ManagerRequirement.PolicyName, policy => policy
        .RequireAuthenticatedUser()
        .AddRequirements(new ManagerRequirement()))
    .SetFallbackPolicy(new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build());
builder.Services.AddScoped<IAuthorizationHandler, ManagerAuthorizationHandler>();

// Antiforgery: double submit style token delivered in a request header, because
// a browser client cannot attach a form field to a JSON request.
builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = AntiforgeryDefaults.HeaderName;
    options.Cookie.Name = AntiforgeryDefaults.CookieName;
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    // Secure in production; in development follow the request scheme so the API
    // can also be exercised over plain HTTP (for example the Docker stack).
    options.Cookie.SecurePolicy = builder.Environment.IsDevelopment()
        ? CookieSecurePolicy.SameAsRequest
        : CookieSecurePolicy.Always;
});

// The filter behind the global antiforgery check, registered so MVC can build
// it from the container.
builder.Services.AddTransient<AntiforgeryValidationFilter>();

var app = builder.Build();

// Error contract first, so it also covers the middleware below.
app.UseExceptionHandler();
app.UseStatusCodePages();

app.UseMiddleware<RequestLoggingMiddleware>();

// The OpenAPI contract (docs/api/openapi.json, copied next to the application)
// and the Swagger UI that renders it. Remove the next line if you want the
// documentation reachable only in development.
app.UseApiDocumentation();

app.UseHttpsRedirection();

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();

// The routes are declared in the generated controllers, which come from
// docs/api/openapi.json, so the routes the API serves and the routes OpenAPI
// documents are the same by construction.
app.MapControllers();

app.Run();

/// <summary>
/// Named entry point, exposed so the test project can boot the real host with
/// WebApplicationFactory. Do not add behaviour here.
/// </summary>
public partial class Program;
