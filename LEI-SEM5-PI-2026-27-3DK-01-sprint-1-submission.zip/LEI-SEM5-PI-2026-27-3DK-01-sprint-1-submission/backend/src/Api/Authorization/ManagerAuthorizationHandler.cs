using System.Security.Claims;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;

namespace Api.Authorization;

/// <summary>
/// Resolves authorization using ASP.NET Core Identity roles.
/// </summary>
internal sealed class ManagerAuthorizationHandler(
    UserManager<IdentityUser> userManager,
    IUserRepository userRepository)
    : AuthorizationHandler<ManagerRequirement>
{
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context, ManagerRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated != true)
        {
            return;
        }

        if (context.User.IsInRole(ManagerRequirement.PolicyName))
        {
            context.Succeed(requirement);
            return;
        }

        var identifier = context.User.FindFirstValue(ClaimTypes.Email) ?? context.User.Identity.Name;
        Email email;
        try
        {
            email = Email.Create(identifier);
        }
        catch (DomainException)
        {
            return;
        }

        var user = await userManager.GetUserAsync(context.User);

        if (user is null)
        {
            return;
        }

        var domainUser = await userRepository.GetByEmailAsync(email);

        if (domainUser is null || !domainUser.Active)
        {
            return;
        }

        if (await userManager.IsInRoleAsync(user, ManagerRequirement.PolicyName))
        {
            context.Succeed(requirement);
        }
    }
}
