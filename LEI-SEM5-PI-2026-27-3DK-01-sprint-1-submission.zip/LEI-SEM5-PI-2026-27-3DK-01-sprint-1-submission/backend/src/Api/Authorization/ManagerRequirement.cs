using Microsoft.AspNetCore.Authorization;

namespace Api.Authorization;

internal sealed class ManagerRequirement : IAuthorizationRequirement
{
    public const string PolicyName = "Manager";
}
