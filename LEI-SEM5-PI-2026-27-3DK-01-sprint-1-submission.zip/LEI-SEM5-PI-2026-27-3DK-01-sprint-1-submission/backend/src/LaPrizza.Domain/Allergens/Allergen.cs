using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Allergens;

/// <summary>
/// Aggregate root for allergen reference data. The business <see cref="Code"/>
/// is immutable and descriptive data is validated at creation.
/// </summary>
public sealed class Allergen
{
    public const int NameMaxLength = 200;
    public const int DescriptionMaxLength = 1000;

    public Guid Id { get; private set; }
    public AllergenCode Code { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }

    // Required by EF Core.
    private Allergen() { }

    private Allergen(AllergenCode code, string name, string? description)
    {
        Id = Guid.NewGuid();
        Code = code;
        Name = name;
        Description = description;
    }

    public static Allergen Create(string? code, string? name, string? description)
    {
        return new Allergen(
            AllergenCode.Create(code),
            Guard.RequiredText(name, "Name", NameMaxLength),
            Guard.OptionalText(description, "Description", DescriptionMaxLength));
    }

    /// <summary>
    /// Replaces the descriptive information of this allergen. Its technical
    /// identity and business code deliberately remain stable so references held
    /// by other aggregates continue to identify this same allergen.
    /// </summary>
    public void UpdateDetails(string? name, string? description)
    {
        // Validate the complete replacement before assigning either field. This
        // prevents callers from observing a partly changed aggregate when the
        // optional description is invalid.
        var validatedName = Guard.RequiredText(name, "Name", NameMaxLength);
        var validatedDescription = Guard.OptionalText(
            description,
            "Description",
            DescriptionMaxLength);

        Name = validatedName;
        Description = validatedDescription;
    }
}
