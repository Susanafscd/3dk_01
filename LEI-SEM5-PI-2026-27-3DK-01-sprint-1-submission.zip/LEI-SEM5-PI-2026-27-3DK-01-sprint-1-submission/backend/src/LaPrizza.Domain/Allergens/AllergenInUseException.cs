using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Allergens;

public sealed class AllergenInUseException(AllergenCode code)
    : DomainException($"Allergen '{code.Value}' is referenced and cannot be removed.");
