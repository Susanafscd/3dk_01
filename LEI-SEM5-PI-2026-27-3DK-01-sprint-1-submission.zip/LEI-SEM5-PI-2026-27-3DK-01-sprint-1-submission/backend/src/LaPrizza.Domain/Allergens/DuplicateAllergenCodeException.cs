using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Allergens;

public sealed class DuplicateAllergenCodeException(AllergenCode code)
    : DomainException($"An allergen with code '{code.Value}' already exists.");
