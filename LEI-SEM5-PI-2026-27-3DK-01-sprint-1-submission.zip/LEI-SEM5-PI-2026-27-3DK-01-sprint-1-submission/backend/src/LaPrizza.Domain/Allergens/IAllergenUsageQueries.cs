namespace LaPrizza.Domain.Allergens;

public sealed record AllergenUsageFacts(
    bool HasProductReferences,
    bool HasDietaryRestrictions,
    bool HasOtherReferences);

/// <summary>Read port for every persisted business reference to an allergen.</summary>
public interface IAllergenUsageQueries
{
    Task<AllergenUsageFacts> GetUsageAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default);
}
