namespace LaPrizza.Domain.Allergens;

/// <summary>Persistence port for the <see cref="Allergen"/> aggregate.</summary>
public interface IAllergenRepository
{
    /// <summary>Returns the allergen aggregate with the given code, or null when absent.</summary>
    Task<Allergen?> GetByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default);

    Task AddAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Commits an already loaded allergen after its aggregate behaviour has
    /// changed its editable details.
    /// </summary>
    Task UpdateAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default);

    /// <summary>Physically removes an unused allergen.</summary>
    Task RemoveAsync(Allergen allergen, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns a read-only projection of the allergen identified by its business
    /// code, or null when it does not exist. Nothing is tracked or modified.
    /// </summary>
    Task<AllergenLookupResult?> GetLookupByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default);
}
