namespace LaPrizza.Domain.Allergens;

/// <summary>
/// Read-only allergen projection returned by the repository lookup. It exposes
/// the business code and deliberately omits the persistence identifier.
/// </summary>
public sealed record AllergenLookupResult(
    string Code,
    string Name,
    string? Description);
