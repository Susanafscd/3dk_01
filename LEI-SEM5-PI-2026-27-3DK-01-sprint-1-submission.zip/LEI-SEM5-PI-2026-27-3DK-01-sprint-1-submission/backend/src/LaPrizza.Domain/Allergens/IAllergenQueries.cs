namespace LaPrizza.Domain.Allergens;

/// <summary>Inward-facing read port for allergen search.</summary>
public interface IAllergenQueries
{
    Task<AllergenSearchPage> SearchAsync(
        AllergenSearchCriteria criteria,
        CancellationToken cancellationToken = default);
}
