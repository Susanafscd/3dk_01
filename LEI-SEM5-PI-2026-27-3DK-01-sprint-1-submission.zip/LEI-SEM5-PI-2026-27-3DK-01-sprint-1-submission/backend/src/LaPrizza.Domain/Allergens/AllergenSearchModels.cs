namespace LaPrizza.Domain.Allergens;

/// <summary>Read projection returned by the allergen search port.</summary>
public sealed record AllergenSearchItem(
    string Code,
    string Name,
    string? Description);

/// <summary>A page of allergens and the count before pagination.</summary>
public sealed record AllergenSearchPage(
    IReadOnlyList<AllergenSearchItem> Items,
    int TotalCount);
