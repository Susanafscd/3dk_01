namespace LaPrizza.Domain.Allergens;

/// <summary>Domain query criteria for the allergen catalogue.</summary>
public sealed record AllergenSearchCriteria(
    string? Search,
    int Page = 1,
    int PageSize = 20);
