using System.Text.RegularExpressions;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Allergens;

/// <summary>
/// Immutable business identity of an allergen. Codes are canonical lowercase
/// ASCII slugs and are never silently normalised.
/// </summary>
public sealed partial record AllergenCode
{
    public const int MaxLength = 100;

    public const string Pattern = "^[a-z0-9]+(-[a-z0-9]+)*$";

    public string Value { get; }

    private AllergenCode(string value) => Value = value;

    public static AllergenCode Create(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            throw new DomainException("Code is required.");
        }

        if (value.Length > MaxLength)
        {
            throw new DomainException($"Code cannot exceed {MaxLength} characters.");
        }

        if (!CodeRegex().IsMatch(value))
        {
            throw new DomainException(
                "Code must contain only lowercase letters and digits, optionally separated by single hyphens.");
        }

        return new AllergenCode(value);
    }

    public override string ToString() => Value;

    [GeneratedRegex(@"\A[a-z0-9]+(-[a-z0-9]+)*\z", RegexOptions.CultureInvariant)]
    private static partial Regex CodeRegex();
}
