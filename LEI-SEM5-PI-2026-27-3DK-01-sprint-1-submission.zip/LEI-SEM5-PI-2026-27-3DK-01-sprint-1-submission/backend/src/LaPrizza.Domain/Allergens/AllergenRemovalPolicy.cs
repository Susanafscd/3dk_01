using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Allergens;

/// <summary>Usage facts must include inactive records and be checked within the deletion transaction.</summary>
public static class AllergenRemovalPolicy
{
    public static void EnsureCanRemove(bool hasProductReferences, bool hasDietaryRestrictions, bool hasOtherReferences)
    {
        if (hasProductReferences || hasDietaryRestrictions || hasOtherReferences)
            throw new DomainException("Referenced catalogue information cannot be removed.");
    }
}
