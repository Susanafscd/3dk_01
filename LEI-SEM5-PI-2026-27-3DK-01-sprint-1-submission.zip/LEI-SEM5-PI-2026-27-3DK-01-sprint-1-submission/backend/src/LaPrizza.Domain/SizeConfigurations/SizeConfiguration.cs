﻿using LaPrizza.Domain.Common;


namespace LaPrizza.Domain.SizeConfigurations;

/// <summary>
/// The size-dependent characteristics of a product used as a pizza component
/// (BCK08). An immutable value object: every operation returns a new instance
/// that the owning <c>Product</c> holds in place of the previous one. Each pizza
/// size has at most one configuration; a deactivated configuration is retained
/// with its values and keeps occupying its size, so there is no deletion.
/// </summary>
public sealed class SizeConfiguration
{
    private readonly IReadOnlyDictionary<string, SizeValues> _sizeMappings;

    public static SizeConfiguration Empty { get; } =
        new(new Dictionary<string, SizeValues>());

    /// <summary>Rebuilds a configuration from previously stored mappings.</summary>
    public static SizeConfiguration FromSizeMappings(IReadOnlyDictionary<string, SizeValues> sizeMappings)
    {
        ArgumentNullException.ThrowIfNull(sizeMappings);

        return new SizeConfiguration(new Dictionary<string, SizeValues>(sizeMappings));
    }

    private SizeConfiguration(IReadOnlyDictionary<string, SizeValues> sizeMappings)
        => _sizeMappings = sizeMappings;

    /// <summary>All the configured sizes and their values, unordered.</summary>
    public IReadOnlyDictionary<string, SizeValues> SizeMappings => _sizeMappings;

    /// <summary>Whether the size has a configuration, active or deactivated.</summary>
    public bool ContainsSize(string sizeId) => _sizeMappings.ContainsKey(sizeId);

    public SizeConfiguration AddSizeConfiguration(string sizeId, decimal price, int stockConsumption)
    {
        if (sizeId == null || sizeId.Trim() == string.Empty)
        {
            throw new DomainException("The size ID cannot be null or empty.");
        }

        if (ContainsSize(sizeId))
        {
            throw new DomainException($"A size configuration for size '{sizeId}' already exists.");
        }

        if (price <= 0m)
        {
            throw new DomainException("The price cannot be negative or zero.");
        }

        if (stockConsumption < 0)
        {
            throw new DomainException("The stock consumption cannot be negative.");
        }


        var copy = new Dictionary<string, SizeValues>(_sizeMappings)
        {
            [sizeId] = new SizeValues(price, stockConsumption)
        };
        return new SizeConfiguration(copy);
    }

    public SizeConfiguration UpdateSizeConfiguration(
        string sizeId,
        decimal price,
        int stockConsumption,
        bool? active = null)
    {
        if (!_sizeMappings.TryGetValue(sizeId, out var current))
        {
            throw new DomainException($"The size configuration for size '{sizeId}' does not exist.");
        }

        if (price <= 0m)
        {
            throw new DomainException("The price cannot be negative or zero.");
        }

        if (stockConsumption < 0)
        {
            throw new DomainException("The stock consumption cannot be negative.");
        }

        var copy = new Dictionary<string, SizeValues>(_sizeMappings)
        {
            [sizeId] = new SizeValues(price, stockConsumption, active ?? current.Active)
        };
        return new SizeConfiguration(copy);
    }

    /// <summary>The configured price of the size, also on a deactivated configuration.</summary>
    /// <exception cref="DomainException">The size has no configuration.</exception>
    public decimal GetPrice(string sizeId) => KnownValuesOf(sizeId).Price;

    /// <summary>The configured stock consumption of the size.</summary>
    /// <exception cref="DomainException">The size has no configuration.</exception>
    public int GetStockConsumption(string sizeId) => KnownValuesOf(sizeId).StockConsumption;

    /// <summary>
    /// Reads the configured values, rejecting an unconfigured size with the same
    /// <see cref="DomainException"/> the mutators use instead of letting the
    /// dictionary indexer surface a <see cref="KeyNotFoundException"/>.
    /// </summary>
    private SizeValues KnownValuesOf(string sizeId)
    {
        if (!_sizeMappings.TryGetValue(sizeId, out var values))
        {
            throw new DomainException($"The size configuration for size '{sizeId}' does not exist.");
        }

        return values;
    }
}
