﻿namespace LaPrizza.Domain.SizeConfigurations;

/// <summary>
/// The size-dependent characteristics of a pizza component for one pizza size.
/// <see cref="SizeConfiguration"/> keeps every configured size occupied whether
/// it is active or not: a deactivated configuration stays retained with its
/// values for consistency and history, and is brought back through
/// <see cref="SizeConfiguration.UpdateSizeConfiguration"/>, not by re-creation
/// (BCK08).
/// </summary>
public sealed class SizeValues
{
    /// <summary>The price applicable for this component in a pizza of this size; must be positive.</summary>
    public decimal Price { get; }

    /// <summary>
    /// The number of stock units consumed per pizza of this size, as a whole
    /// number. Stored as 0 when the product is not stock controlled, where the
    /// value has no meaning.
    /// </summary>
    public int StockConsumption { get; }

    /// <summary>Whether the configuration is applicable; always true when created.</summary>
    public bool Active { get; }

    public SizeValues(decimal price, int stockConsumption, bool active = true)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(price);

        ArgumentOutOfRangeException.ThrowIfNegative(stockConsumption);

        Price = price;
        StockConsumption = stockConsumption;
        Active = active;
    }
}
