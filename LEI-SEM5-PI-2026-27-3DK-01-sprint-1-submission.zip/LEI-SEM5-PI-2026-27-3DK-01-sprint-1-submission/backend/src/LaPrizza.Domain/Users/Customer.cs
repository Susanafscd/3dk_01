using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>
/// A user profile for someone who orders from the restaurant. Addresses,
/// dietary restrictions are declared by the customer and may be empty.
/// </summary>
public sealed class Customer : User
{
    /// <summary>Maximum length of a customer name.</summary>
    public const int MaxNameLength = 200;

    /// <summary>Maximum length of a phone number.</summary>
    private readonly List<DietaryRestriction> _dietaryRestrictions = [];

    private Customer(Guid id, Email email, string displayName, string name, PhoneNumber phoneNumber, VATNumber? vatNumber, IEnumerable<DietaryRestriction> dietaryRestrictions)
        : base(id, email, displayName)
    {
        Name = Guard.RequiredText(name, "Customer name", MaxNameLength);
        PhoneNumber = phoneNumber;
        VATNumber = vatNumber;
        SetDietaryRestrictions(dietaryRestrictions);
    }

    /// <summary>Parameterless constructor reserved for the persistence layer.</summary>
    private Customer()
    {
        Name = null!;
        PhoneNumber = null!;
    }

    /// <summary>Full name of the customer.</summary>
    public string Name { get; private set; }

    /// <summary>Required contact phone number.</summary>
    public PhoneNumber PhoneNumber { get; private set; }

    /// <summary>Optional Portuguese VAT identification number.</summary>
    public VATNumber? VATNumber { get; private set; }

    public IReadOnlyCollection<DietaryRestriction> DietaryRestrictions => _dietaryRestrictions.AsReadOnly();

    /// <summary>Creates a customer, assigning a new identity.</summary>
    public static Customer Create(
        Email email,
        string displayName,
        string name,
        IEnumerable<DietaryRestriction> dietaryRestrictions,
        string phoneNumber,
        string? vatNumber = null
        ) =>
        new(Guid.NewGuid(), email, displayName, name, PhoneNumber.Create(phoneNumber), VATNumber.Create(vatNumber), dietaryRestrictions);

    /// <summary>Changes the customer's name.</summary>
    public void ChangeName(string name) => Name = Guard.RequiredText(name, "Customer name", MaxNameLength);

    /// <summary>Changes the customer's phone number.</summary>
    public void ChangePhoneNumber(string phoneNumber) =>
        PhoneNumber = PhoneNumber.Create(phoneNumber);

    public void ChangeVATNumber(string? vatNumber) =>
        VATNumber = VATNumber.Create(vatNumber);

    public void ChangeDietaryRestrictions(IEnumerable<DietaryRestriction> dietaryRestrictions) =>
        SetDietaryRestrictions(dietaryRestrictions);

    private void SetDietaryRestrictions(IEnumerable<DietaryRestriction> dietaryRestrictions)
    {
        ArgumentNullException.ThrowIfNull(dietaryRestrictions);

        var values = dietaryRestrictions.ToList();
        if (values.Any(restriction => restriction is null))
        {
            throw new ArgumentException("Dietary restrictions cannot contain null values.", nameof(dietaryRestrictions));
        }

        if (values.Select(restriction => restriction.Id).Distinct().Count() != values.Count)
        {
            throw new ArgumentException("A customer cannot have duplicate dietary restrictions.", nameof(dietaryRestrictions));
        }

        _dietaryRestrictions.Clear();
        _dietaryRestrictions.AddRange(values);
    }
}
