using LaPrizza.Domain.Common;
using System.Text.RegularExpressions;

namespace LaPrizza.Domain.Users;

/// <summary>Value object for a customer's required contact phone number.</summary>
public sealed partial record PhoneNumber
{
    public const int MaxLength = 30;

    [GeneratedRegex(@"^\+?[1-9](?:[0-9 ()-]*[0-9])$")]
    private static partial Regex Pattern();

    private PhoneNumber(string value) => Value = value;

    public string Value { get; }

    public static PhoneNumber Create(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new DomainException("Phone number is required.");
        }

        var normalized = value.Trim();
        if (normalized.Length > MaxLength || !Pattern().IsMatch(normalized))
        {
            throw new DomainException($"Phone number must be a valid phone number of at most {MaxLength} characters.");
        }

        var digitCount = normalized.Count(char.IsDigit);
        if (digitCount is < 7 or > 15)
        {
            throw new DomainException("Phone number must contain between 7 and 15 digits.");
        }

        return new PhoneNumber(normalized);
    }

    public override string ToString() => Value;
}
