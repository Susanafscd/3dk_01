using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>
/// Aggregate root for the identity and access-roles of a person in the system.
/// It keeps the account data only; authentication <em>credentials</em> are not a
/// domain concern (MD-06) and are handled by the authentication infrastructure.
/// </summary>
/// <remarks>
/// <see cref="Customer"/> and <see cref="Staff"/> are the two profiles a user can
/// have. A user owns its role assignments by id through ASP.NET Core Identity.
/// </remarks>
public abstract class User
{

    protected User(Guid id, Email email, string displayName)
    {
        if (id == Guid.Empty)
        {
            throw new DomainException("User id is required.");
        }

        Id = id;
        Email = email ?? throw new DomainException("Email is required.");
        DisplayName = Guard.RequiredText(displayName, "Display name", MaxDisplayNameLength);
        Active = true;

    }

    /// <summary>Parameterless constructor reserved for the persistence layer.</summary>
    protected User()
    {
        Email = null!;
        DisplayName = null!;
    }

    /// <summary>Maximum length of a display name.</summary>
    public const int MaxDisplayNameLength = 200;

    /// <summary>Surrogate key of the aggregate.</summary>
    public Guid Id { get; private set; }

    /// <summary>Unique email address used to identify the account.</summary>
    public Email Email { get; private set; }

    /// <summary>Name shown to people and other systems.</summary>
    public string DisplayName { get; private set; }

    /// <summary>Whether the account can currently be used.</summary>
    public bool Active { get; private set; }

    /// <summary>Activates the account.</summary>
    public void Activate() => Active = true;

    /// <summary>Deactivates the account, keeping its data for history.</summary>
    public void Deactivate() => Active = false;

    /// <summary>Changes the name shown for the account.</summary>
    public void Rename(string displayName) =>
        DisplayName = Guard.RequiredText(displayName, "Display name", MaxDisplayNameLength);
}
