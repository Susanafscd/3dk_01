namespace LaPrizza.Domain.Users;

/// <summary>The kind of profile attached to a user account.</summary>
public enum UserType
{
    /// <summary>A person who buys from the restaurant.</summary>
    Customer = 1,

    /// <summary>A person who works at the restaurant.</summary>
    Staff = 2,
}
