using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>A user profile for someone who works at the restaurant.</summary>
public sealed class Staff : User
{
    /// <summary>Maximum length of a job title.</summary>
    public const int MaxJobTitleLength = 100;

    private Staff(Guid id, Email email, string displayName, string jobTitle)
        : base(id, email, displayName) =>
        JobTitle = Guard.RequiredText(jobTitle, "Job title", MaxJobTitleLength);

    /// <summary>Parameterless constructor reserved for the persistence layer.</summary>
    private Staff() => JobTitle = null!;

    /// <summary>The role the person performs at the restaurant.</summary>
    public string JobTitle { get; private set; }

    /// <summary>Creates a staff member, assigning a new identity.</summary>
    public static Staff Create(
        Email email,
        string displayName,
        string jobTitle,
        IEnumerable<Guid>? roleIds = null) =>
        new(Guid.NewGuid(), email, displayName, jobTitle);

    /// <summary>Changes the job title.</summary>
    public void ChangeJobTitle(string jobTitle) =>
        JobTitle = Guard.RequiredText(jobTitle, "Job title", MaxJobTitleLength);
}
