namespace LaPrizza.Domain.Users;

/// <summary>Persistence port for the <see cref="User"/> aggregate.</summary>
public interface IUserRepository
{
    /// <summary>True when a user with the given email already exists.</summary>
    Task<bool> ExistsByEmailAsync(Email email, CancellationToken cancellationToken = default);

    /// <summary>Returns the user with the given email, if any.</summary>
    Task<User?> GetByEmailAsync(Email email, CancellationToken cancellationToken = default);

    /// <summary>Returns the user with the given id, if any.</summary>
    Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the customers whose name, email or phone number contains the
    /// given term. A blank term matches every customer. Searching is a query
    /// concern (MD-10): it is answered by the store and does not change the
    /// domain model.
    /// </summary>
    Task<IReadOnlyList<Customer>> SearchCustomersAsync(
        string? search,
        CancellationToken cancellationToken = default);

    /// <summary>Adds a new user to the store and commits the change.</summary>
    Task AddAsync(User user, CancellationToken cancellationToken = default);

    /// <summary>Updates an existing user in the store and commits the change.</summary>
    Task UpdateAsync(User user, CancellationToken cancellationToken = default);

    /// <summary>Removes a user from the store and commits the change.</summary>
    Task RemoveAsync(User user, CancellationToken cancellationToken = default);

    /// <summary>Saves pending changes.</summary>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
