using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>
/// Value object for an email address. It is always stored trimmed and
/// lower-cased so that two addresses that differ only in case are the same.
/// </summary>
public sealed partial record Email
{
    /// <summary>Maximum length of the local part plus the "@" plus the domain.</summary>
    public const int MaxLength = 320;

    private Email(string value) => Value = value;

    /// <summary>The normalised address.</summary>
    public string Value { get; }

    /// <summary>Creates a value object, throwing when the address is malformed.</summary>
    public static Email Create(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new DomainException("Email is required.");
        }

        var normalized = value.Trim().ToLowerInvariant();

        if (normalized.Length > MaxLength)
        {
            throw new DomainException($"Email cannot exceed {MaxLength} characters.");
        }

        if (!IsWellFormed(normalized))
        {
            throw new DomainException($"'{value}' is not a valid email address.");
        }

        return new Email(normalized);
    }

    /// <summary>True when the stored value is a well-formed address.</summary>
    public bool IsValid() => Value.Length <= MaxLength && IsWellFormed(Value);

    /// <summary>
    /// Tries to create a value object without throwing. Returns <see langword="false"/>
    /// when the value is missing or malformed, which is useful for input that is
    /// allowed to be something other than an email address (for example a search
    /// term).
    /// </summary>
    public static bool TryCreate(string? value, [NotNullWhen(true)] out Email? email)
    {
        try
        {
            email = Create(value);
            return true;
        }
        catch (DomainException)
        {
            email = null;
            return false;
        }
    }

    public override string ToString() => Value;

    [GeneratedRegex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.CultureInvariant)]
    private static partial Regex EmailPattern();

    [SuppressMessage("Performance", "SYSLIB1045", Justification = "GeneratedRegex is used for the pattern; this helper only invokes it.")]
    private static bool IsWellFormed(string value) => EmailPattern().IsMatch(value);
}
