using System.Text.RegularExpressions;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>Optional Portuguese VAT identification number.</summary>
public sealed partial record VATNumber
{
    public const int MaxLength = 11;

    [GeneratedRegex(@"^(?:PT)?[0-9]{9}$", RegexOptions.IgnoreCase)]
    private static partial Regex Pattern();

    private VATNumber(string value) => Value = value;

    public string Value { get; }

    public static VATNumber? Create(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var normalized = value.Trim().ToUpperInvariant();
        if (!Pattern().IsMatch(normalized))
        {
            throw new DomainException("VAT number must contain 9 digits, optionally prefixed with PT.");
        }

        return new VATNumber(normalized);
    }

    public override string ToString() => Value;
}
