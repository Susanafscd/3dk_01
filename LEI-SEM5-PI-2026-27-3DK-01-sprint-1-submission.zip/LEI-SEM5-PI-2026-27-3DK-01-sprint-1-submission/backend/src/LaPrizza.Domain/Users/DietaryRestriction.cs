using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Users;

/// <summary>
/// A dietary restriction declared by a customer and the allergens it relates to.
/// </summary>
public sealed class DietaryRestriction
{
    public const int MaxNameLength = 200;
    public const int MaxDescriptionLength = 1000;

    private readonly List<Allergen> _allergens = [];

    private DietaryRestriction(string name, string? description, IEnumerable<Allergen> allergens)
    {
        Id = Guid.NewGuid();
        Name = Guard.RequiredText(name, "Dietary restriction name", MaxNameLength);
        Description = Guard.OptionalText(description, "Dietary restriction description", MaxDescriptionLength);
        SetAllergens(allergens);
    }

    private DietaryRestriction()
    {
        Name = null!;
    }

    public Guid Id { get; private set; }
    public string Name { get; private set; }
    public string? Description { get; private set; }
    public IReadOnlyCollection<Allergen> Allergens => _allergens.AsReadOnly();

    public static DietaryRestriction Create(
        string name,
        string? description = null,
        IEnumerable<Allergen>? allergens = null) =>
        new(name, description, allergens ?? []);

    public static DietaryRestriction Create(
        string name,
        IEnumerable<Allergen> allergens) =>
        new(name, null, allergens);

    public void UpdateDetails(string name, string? description) 
    {
        Name = Guard.RequiredText(name, "Dietary restriction name", MaxNameLength);
        Description = Guard.OptionalText(description, "Dietary restriction description", MaxDescriptionLength);
    }

    public void SetAllergens(IEnumerable<Allergen> allergens)
    {
        ArgumentNullException.ThrowIfNull(allergens);

        var values = allergens.ToList();
        if (values.Any(allergen => allergen is null))
        {
            throw new ArgumentException("Allergens cannot contain null values.", nameof(allergens));
        }

        if (values.Select(allergen => allergen.Id).Distinct().Count() != values.Count)
        {
            throw new ArgumentException("A dietary restriction cannot contain duplicate allergens.", nameof(allergens));
        }

        _allergens.Clear();
        _allergens.AddRange(values);
    }
}
