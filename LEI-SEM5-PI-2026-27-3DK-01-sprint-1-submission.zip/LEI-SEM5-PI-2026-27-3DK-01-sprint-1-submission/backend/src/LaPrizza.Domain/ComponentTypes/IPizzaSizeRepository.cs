namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Persistance port for the <see cref="PizzaSize"/> entity </summary>.
public interface IPizzaSizeRepository
{
    /// <summary>Returns the size with the given id, or null when absent</summary>
    Task<PizzaSize?> Get(Guid id, CancellationToken cancellationToken);

    Task<PizzaSize> Add(PizzaSize size, CancellationToken cancellationToken);

    Task<bool> InUse(Guid id, CancellationToken cancellationToken);

    Task Remove(PizzaSize size, CancellationToken cancellationToken);

    Task<bool> ExistsByName(string name, CancellationToken cancellationToken);
}
