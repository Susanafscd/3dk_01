using System.Globalization;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>
/// Aggregate root for pizza component types (BCK07). The business
/// <see cref="Code"/> is its public identity and cannot change after creation;
/// <see cref="Id"/> is an internal persistence key and is never exposed.
/// Each type belongs to one product category through its business code. The
/// category is referenced by value, not by a navigation to another aggregate.
/// </summary>
public sealed class PizzaComponentType
{
    public const int MaxNameLength = 100;
    public const int MaxDescriptionLength = 500;

    public Guid Id { get; private set; }
    public PizzaComponentTypeCode Code { get; private set; } = null!;
    public ProductCategoryCode CategoryCode { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }
    public int AssemblyOrder { get; private set; }
    public int MinQuantity { get; private set; }
    public int? MaxQuantity { get; private set; }

    // Required by EF Core
    private PizzaComponentType() { }

    private PizzaComponentType(Guid id, PizzaComponentTypeCode code, ProductCategoryCode categoryCode, string name, string? description, int assemblyOrder, int minQuantity, int? maxQuantity)
    {
        Id = id;
        Code = code;
        CategoryCode = categoryCode;
        Name = name;
        Description = description;
        AssemblyOrder = assemblyOrder;
        MinQuantity = minQuantity;
        MaxQuantity = maxQuantity;
    }

    public static PizzaComponentType Create(string? code, string? categoryCode, string? name, string? description, int assemblyOrder, int minQuantity, int? maxQuantity)
    {
        var validatedCode = PizzaComponentTypeCode.Create(code);
        var validatedCategoryCode = ProductCategoryCode.Create(categoryCode);
        var validatedName = Guard.RequiredText(name, "Name", MaxNameLength);
        var validatedDescription = Guard.OptionalText(description, "Description", MaxDescriptionLength);

        if (assemblyOrder < 1)
        {
            throw new DomainException("Assembly order must be at least 1.");
        }

        if (minQuantity < 0)
        {
            throw new DomainException("Minimum quantity cannot be negative.");
        }

        if (maxQuantity.HasValue && maxQuantity.Value < minQuantity)
        {
            throw new DomainException("Maximum quantity cannot be lower than the minimum quantity.");
        }

        if (maxQuantity.HasValue && maxQuantity.Value < 1)
        {
            throw new DomainException("Maximum quantity cannot be lower than 1 when bounded.");
        }

        var normalizedName = NormalizeName(validatedName);
        return new PizzaComponentType(Guid.NewGuid(), validatedCode, validatedCategoryCode, normalizedName, validatedDescription, assemblyOrder, minQuantity, maxQuantity);
    }

    private static string NormalizeName(string value) =>
        CultureInfo.InvariantCulture.TextInfo.ToTitleCase(value.Trim().ToLowerInvariant());

    /// <summary>Compatibility overload for existing internal fixtures.</summary>
    public static PizzaComponentType Create(string? code, string? name, string? description, int assemblyOrder, int minQuantity, int? maxQuantity) =>
        Create(code, "pizza-component", name, description, assemblyOrder, minQuantity, maxQuantity);

    /// <summary>Updates the editable details. The <see cref="Code"/> is immutable and is not touched.</summary>
    public void UpdateDetails(string? name, string? description, int assemblyOrder, int minQuantity, int? maxQuantity)
    {
        var validatedName = Guard.RequiredText(name, "Name", MaxNameLength);
        var validatedDescription = Guard.OptionalText(description, "Description", MaxDescriptionLength);

        if (assemblyOrder < 1)
        {
            throw new DomainException("Assembly order must be at least 1.");
        }

        if (minQuantity < 0)
        {
            throw new DomainException("Minimum quantity cannot be negative.");
        }

        if (maxQuantity.HasValue && maxQuantity.Value < minQuantity)
        {
            throw new DomainException("Maximum quantity cannot be lower than the minimum quantity.");
        }

        if (maxQuantity.HasValue && maxQuantity.Value < 1)
        {
            throw new DomainException("Maximum quantity cannot be lower than 1 when bounded.");
        }

        Name = NormalizeName(validatedName);
        Description = validatedDescription;
        AssemblyOrder = assemblyOrder;
        MinQuantity = minQuantity;
        MaxQuantity = maxQuantity;
    }
}
