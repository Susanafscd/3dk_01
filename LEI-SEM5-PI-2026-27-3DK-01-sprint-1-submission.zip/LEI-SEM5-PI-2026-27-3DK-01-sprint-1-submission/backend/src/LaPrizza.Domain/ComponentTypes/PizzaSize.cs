﻿using System.Text.RegularExpressions;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>
/// Aggregate root of the pizza sizes (BCK06).
/// </summary>
public sealed partial class PizzaSize
{
    public const int MaxNameLength = 100;
    public const int MaxDescriptionLength = 500;
    public const string Pattern = "^[a-z0-9]+(-[a-z0-9]+)*$";

    public Guid Id { get; private set; }
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }

    // Required by EF Core
    private PizzaSize() { }

    private PizzaSize(Guid id, string name, string? description)
    {
        Id = id;
        Name = name;
        Description = description;
    }

    public static PizzaSize Create(string? name, string? description)
    {
        var validatedName = ValidateName(name);
        var validatedDescription = Guard.OptionalText(description, "Description", MaxDescriptionLength);
        return new PizzaSize(Guid.NewGuid(), validatedName, validatedDescription);
    }

    public static PizzaSize Create(string? name)
    {
        var validatedName = ValidateName(name);
        return new PizzaSize(Guid.NewGuid(), validatedName, null);
    }

    private static string ValidateName(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            throw new DomainException("Name is required.");
        }

        if (value.Length > MaxNameLength)
        {
            throw new DomainException($"Name cannot exceed {MaxNameLength} characters.");
        }

        if (!NameRegex().IsMatch(value))
        {
            throw new DomainException(
                "Name must contain only lowercase letters and digits, optionally separated by single hyphens.");
        }

        return value;
    }

    [GeneratedRegex(@"\A[a-z0-9]+(-[a-z0-9]+)*\z", RegexOptions.CultureInvariant)]
    private static partial Regex NameRegex();
}
