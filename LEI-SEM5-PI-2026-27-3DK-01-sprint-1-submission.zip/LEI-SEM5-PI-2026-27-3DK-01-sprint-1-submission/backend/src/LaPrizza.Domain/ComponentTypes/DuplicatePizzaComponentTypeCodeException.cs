using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a pizza component type code is already taken (maps to HTTP 409).</summary>
public sealed class DuplicatePizzaComponentTypeCodeException(PizzaComponentTypeCode code)
    : DomainException($"A pizza component type with code '{code}' already exists.");
