using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a referenced pizza component type would be removed (maps to HTTP 409).</summary>
public sealed class PizzaComponentTypeInUseException(PizzaComponentTypeCode code)
    : DomainException($"Pizza component type '{code}' is referenced by other information and cannot be removed.");
