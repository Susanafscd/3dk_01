using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a pizza size name is already taken (maps to HTTP 409).</summary>
public sealed class DuplicatePizzaSizeNameException(string name)
    : DomainException($"A pizza size named '{name}' already exists.");
