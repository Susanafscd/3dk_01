using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Persistance port for the <see cref="PizzaComponentType"/> entity.</summary>
public interface IPizzaComponentTypeRepository
{
    /// <summary>Returns the component type with the given business code, or null when absent.</summary>
    Task<PizzaComponentType?> GetByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default);

    Task<PizzaComponentType> Add(PizzaComponentType type, CancellationToken cancellationToken = default);

    Task Update(PizzaComponentType type, CancellationToken cancellationToken = default);

    Task Remove(PizzaComponentType type, CancellationToken cancellationToken = default);

    Task<bool> ExistsByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default);

    Task<bool> ExistsByName(string name, Guid? excludeId = null, CancellationToken cancellationToken = default);

    Task<bool> ExistsByAssemblyOrder(int assemblyOrder, Guid? excludeId = null, CancellationToken cancellationToken = default);

    Task<bool> InUse(Guid id, CancellationToken cancellationToken = default);
}
