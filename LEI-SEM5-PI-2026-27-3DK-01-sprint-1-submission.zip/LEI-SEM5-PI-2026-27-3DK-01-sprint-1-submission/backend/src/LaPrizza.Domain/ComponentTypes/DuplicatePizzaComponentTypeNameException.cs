using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a pizza component type name is already taken (maps to HTTP 409).</summary>
public sealed class DuplicatePizzaComponentTypeNameException(string name)
    : DomainException($"A pizza component type named '{name}' already exists.");
