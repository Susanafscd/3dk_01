using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a referenced pizza size would be removed (maps to HTTP 409).</summary>
public sealed class PizzaSizeInUseException(Guid id)
    : DomainException($"Pizza size '{id}' is referenced by other information and cannot be removed.");
