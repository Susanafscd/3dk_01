using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ComponentTypes;

/// <summary>Raised when a pizza component type assembly order is already taken (maps to HTTP 409).</summary>
public sealed class DuplicatePizzaComponentTypeAssemblyOrderException(int assemblyOrder)
    : DomainException($"A pizza component type with assembly order '{assemblyOrder}' already exists.");
