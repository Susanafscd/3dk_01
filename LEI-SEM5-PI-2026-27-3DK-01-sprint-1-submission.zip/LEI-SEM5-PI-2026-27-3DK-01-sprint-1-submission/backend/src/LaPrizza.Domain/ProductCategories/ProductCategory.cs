using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

/// <summary>
/// Aggregate root of the product-category catalogue (BCK03). The business
/// <see cref="Code"/> is its public identity and cannot change after creation;
/// <see cref="Id"/> is an internal persistence key and is never exposed.
/// </summary>
public sealed class ProductCategory
{
    public const int NameMaxLength = 200;
    public const int DescriptionMaxLength = 1000;

    public Guid Id { get; private set; }
    public ProductCategoryCode Code { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }
    public bool AllowsComponentTypes { get; private set; }

    /// <summary>Caller must obtain component-type usage inside the protected write.</summary>
    public void Update(string? name, string? description, bool allowsComponentTypes, bool hasComponentTypeReferences)
    {
        var validName = Guard.RequiredText(name, "Name", NameMaxLength);
        var validDescription = Guard.OptionalText(description, "Description", DescriptionMaxLength);
        if (!allowsComponentTypes && hasComponentTypeReferences)
            throw new CategoryComponentTypeReferenceException(Code);

        Name = validName;
        Description = validDescription;
        AllowsComponentTypes = allowsComponentTypes;
    }

    // Required by EF Core.
    private ProductCategory() { }

    private ProductCategory(
        ProductCategoryCode code,
        string name,
        string? description,
        bool allowsComponentTypes)
    {
        Id = Guid.NewGuid();
        Code = code;
        Name = name;
        Description = description;
        AllowsComponentTypes = allowsComponentTypes;
    }

    public static ProductCategory Create(
        string? code,
        string? name,
        string? description,
        bool allowsComponentTypes)
    {
        return new ProductCategory(
            ProductCategoryCode.Create(code),
            Guard.RequiredText(name, "Name", NameMaxLength),
            Guard.OptionalText(description, "Description", DescriptionMaxLength),
            allowsComponentTypes);
    }
}
