namespace LaPrizza.Domain.ProductCategories;

/// <summary>
/// Read port for references that protect a product category from an unsafe
/// update or removal. Implementations include inactive products and component types.
/// </summary>
public interface IProductCategoryUsageQueries
{
    Task<bool> HasProductReferencesAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default);

    Task<bool> HasComponentTypeReferencesAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default);
}
