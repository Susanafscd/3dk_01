﻿namespace LaPrizza.Domain.ProductCategories;

/// <summary>
/// Read-only product-category projection returned by the repository lookup.
/// It exposes the business code and deliberately omits the persistence id.
/// </summary>
public sealed record ProductCategoryLookupResult(
    string Code,
    string Name,
    string? Description,
    bool AllowsComponentTypes);
