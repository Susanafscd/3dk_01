using System.Text.RegularExpressions;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

/// <summary>
/// Immutable business code that identifies a product category in URLs and
/// references. Lowercase ASCII letters and digits, 1-100 characters. The value is never normalised: invalid
/// input is rejected, not silently corrected.
/// </summary>
public sealed partial record ProductCategoryCode : IComparable<ProductCategoryCode>
{
    public const int MaxLength = 100;

    public const string Pattern = "^[a-z0-9]+(-[a-z0-9]+)*$";

    public string Value { get; }

    private ProductCategoryCode(string value) => Value = value;

    public static ProductCategoryCode Create(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            throw new DomainException("Code is required.");
        }

        if (value.Length > MaxLength)
        {
            throw new DomainException($"Code cannot exceed {MaxLength} characters.");
        }

        if (!CodeRegex().IsMatch(value))
        {
            throw new DomainException(
                "Code must contain only lowercase letters and digits, optionally separated by single hyphens.");
        }

        return new ProductCategoryCode(value);
    }

    public override string ToString() => Value;

    /// <summary>Orders business codes deterministically using ordinal semantics.</summary>
    public int CompareTo(ProductCategoryCode? other) =>
        other is null ? 1 : StringComparer.Ordinal.Compare(Value, other.Value);

    [GeneratedRegex(@"\A[a-z0-9]+(-[a-z0-9]+)*\z", RegexOptions.CultureInvariant)]
    private static partial Regex CodeRegex();
}
