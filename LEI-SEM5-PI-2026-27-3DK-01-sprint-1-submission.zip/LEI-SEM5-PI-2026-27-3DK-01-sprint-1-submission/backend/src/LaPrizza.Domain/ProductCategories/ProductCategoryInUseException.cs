using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

public sealed class ProductCategoryInUseException(ProductCategoryCode code)
    : DomainException($"Product category '{code.Value}' is referenced and cannot be removed.");
