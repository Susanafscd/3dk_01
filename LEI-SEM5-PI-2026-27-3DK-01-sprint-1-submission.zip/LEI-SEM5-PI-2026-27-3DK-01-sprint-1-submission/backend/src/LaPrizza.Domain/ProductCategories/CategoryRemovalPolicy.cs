using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

/// <summary>Usage facts must include inactive records and be checked within the deletion transaction.</summary>
public static class CategoryRemovalPolicy
{
    public static void EnsureCanRemove(
        bool hasProductReferences,
        bool hasComponentTypeReferences = false)
    {
        if (hasProductReferences || hasComponentTypeReferences)
            throw new DomainException("Referenced catalogue information cannot be removed.");
    }
}
