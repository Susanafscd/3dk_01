using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

/// <summary>Raised when a category code is already taken (maps to HTTP 409).</summary>
public sealed class DuplicateProductCategoryCodeException(ProductCategoryCode code)
    : DomainException($"A product category with code '{code}' already exists.");
