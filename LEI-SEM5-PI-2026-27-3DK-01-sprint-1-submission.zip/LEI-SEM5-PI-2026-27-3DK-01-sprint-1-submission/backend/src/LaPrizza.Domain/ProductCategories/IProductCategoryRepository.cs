namespace LaPrizza.Domain.ProductCategories;

/// <summary>Persistence port for the <see cref="ProductCategory"/> aggregate.</summary>
public interface IProductCategoryRepository
{
    /// <summary>Returns the category with the given code, or null when absent.</summary>
    Task<ProductCategory?> GetByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default);

    /// <summary>Stages a new category for persistence.</summary>
    Task AddAsync(ProductCategory category, CancellationToken cancellationToken = default);

    /// <summary>Physically removes an unused category.</summary>
    Task RemoveAsync(ProductCategory category, CancellationToken cancellationToken = default);
    /// <summary>Commits editable fields of an already loaded category.</summary>
    Task UpdateAndSaveAsync(ProductCategory category, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns a read-only projection of the category identified by its business
    /// code, or null when it does not exist. Nothing is tracked or modified.
    /// </summary>
    Task<ProductCategoryLookupResult?> GetLookupByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default);
}
