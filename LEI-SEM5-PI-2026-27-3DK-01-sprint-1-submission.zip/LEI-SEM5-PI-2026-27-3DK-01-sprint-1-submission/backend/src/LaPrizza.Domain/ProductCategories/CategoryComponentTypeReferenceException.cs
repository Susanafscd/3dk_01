using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.ProductCategories;

/// <summary>Raised when a category would stop allowing referenced component types.</summary>
public sealed class CategoryComponentTypeReferenceException(ProductCategoryCode code)
    : DomainException($"Category '{code.Value}' is referenced by component types and cannot disallow them.");
