namespace LaPrizza.Domain.Products;

/// <summary>
/// A product offered as a component of a predefined pizza, as resolved by the
/// caller (BCK10). <see cref="ComponentTypeCode"/> is null when the product is
/// not a pizza component.
/// </summary>
public sealed record PizzaComponent(ProductCode Code, bool Active, string? ComponentTypeCode);
