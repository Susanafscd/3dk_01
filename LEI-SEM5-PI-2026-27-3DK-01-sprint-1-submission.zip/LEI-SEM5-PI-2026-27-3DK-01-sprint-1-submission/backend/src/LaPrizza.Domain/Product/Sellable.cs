namespace LaPrizza.Domain.Products;

public sealed class Sellable
{
    // Required by EF Core for materialization
    private Sellable() { }

    public Sellable(Money price)
    {
        Price = price;
    }

    public Money Price { get; private set; }
}
