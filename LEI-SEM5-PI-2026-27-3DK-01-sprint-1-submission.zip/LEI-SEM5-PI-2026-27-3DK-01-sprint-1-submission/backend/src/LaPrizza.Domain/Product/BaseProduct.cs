using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Domain.Product;

/// <summary>A product that is not composed of other products. Create it with <see cref="BaseProductBuilder"/>.</summary>
public sealed class BaseProduct : Product
{
    public SizeConfiguration? SizeConfiguration { get; private set; }

    private BaseProduct()
    {
    }

    internal BaseProduct(
        ProductCode code,
        string name,
        string description,
        ProductCategoryCode categoryCode,
        Sellable? sellable,
        bool stockControlled,
        IEnumerable<AllergenCode> allergenCodes,
        string? componentTypeCode = null)
        : base(code, name, description, categoryCode, sellable, stockControlled, allergenCodes, componentTypeCode)
    {
    }

    /// <summary>
    /// Replaces the size configuration, grown by the size-configuration use
    /// cases (BCK08): callers build the new immutable value object through
    /// <see cref="SizeConfigurations.SizeConfiguration"/> and this aggregate
    /// holds it in place of the previous one. Nullable, because a component may
    /// have no configuration yet.
    /// </summary>
    public void SetSizeConfiguration(SizeConfiguration? sizeConfiguration)
    {
        SizeConfiguration = sizeConfiguration;
    }
}

