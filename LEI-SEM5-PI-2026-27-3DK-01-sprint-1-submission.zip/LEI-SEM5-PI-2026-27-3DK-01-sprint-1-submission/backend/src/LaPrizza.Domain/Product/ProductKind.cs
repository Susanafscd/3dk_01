namespace LaPrizza.Domain.Products;

/// <summary>Business kind used by product catalogue queries.</summary>
public enum ProductKind
{
    Base,
    Composed
}
