using System.Text.RegularExpressions;

namespace LaPrizza.Domain.Products;

/// <summary>Immutable business code identifying a product. Never normalised.</summary>
public sealed partial record ProductCode
{
    public const int MaxLength = 100;

    [GeneratedRegex("^[a-z0-9]+(?:-[a-z0-9]+)*$")]
    private static partial Regex Pattern();

    private ProductCode(string value) => Value = value;

    public string Value { get; }

    public static ProductCode Create(string? value)
    {
        if (string.IsNullOrEmpty(value)
            || value.Length > MaxLength
            || !Pattern().IsMatch(value))
        {
            throw new InvalidProductException(
                $"Product code must be 1-{MaxLength} lowercase letters or digits separated by single hyphens.");
        }

        return new ProductCode(value);
    }

    public override string ToString() => Value;
}
