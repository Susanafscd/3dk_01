namespace LaPrizza.Domain.Products;

/// <summary>
/// A pizza size, by its name (BCK06), in which a predefined pizza is offered (BCK10, BR-13).
/// </summary>
public sealed record AvailableSize(string SizeName);
