namespace LaPrizza.Domain.Products;

/// <summary>Read projection returned by the product search port.</summary>
public sealed record ProductSearchItem(
    string Code,
    string Name,
    string Description,
    string CategoryCode,
    bool Sellable,
    bool StockControlled,
    string? ComponentTypeCode,
    bool IsPizzaComponent,
    ProductKind Kind,
    bool Active,
    IReadOnlyList<string> AllergenCodes);

/// <summary>A page of products together with the count before pagination.</summary>
public sealed record ProductSearchPage(
    IReadOnlyList<ProductSearchItem> Items,
    int TotalCount);
