namespace LaPrizza.Domain.Products;

/// <summary>Immutable monetary value. Zero is allowed; negative values are not.</summary>
public sealed record Money
{
    private Money(decimal amount) => Amount = amount;

    public decimal Amount { get; }

    public static Money Create(decimal? amount)
    {
        if (amount is null)
        {
            throw new InvalidProductException("A price is required for sellable products.");
        }

        if (amount < 0)
        {
            throw new InvalidProductException("Price cannot be negative.");
        }

        return new Money(amount.Value);
    }
}
