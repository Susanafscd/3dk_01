namespace LaPrizza.Domain.Products;

/// <summary>
/// How many components of one pizza component type a pizza configuration may hold
/// (BCK07). A null <see cref="Maximum"/> means unbounded.
/// </summary>
public sealed record ComponentTypeLimit(string TypeCode, int Minimum, int? Maximum);
