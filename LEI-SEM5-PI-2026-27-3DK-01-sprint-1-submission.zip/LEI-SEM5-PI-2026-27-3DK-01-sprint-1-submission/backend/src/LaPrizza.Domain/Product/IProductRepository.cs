using LaPrizza.Domain.Products;

namespace LaPrizza.Domain.Product;

public interface IProductRepository
{
    Task<Product?> GetByCodeAsync(ProductCode code, CancellationToken cancellationToken = default);

    /// <summary>Persists the product and its allergen associations atomically.</summary>
    /// <remarks>
    /// For a product that was built in memory and is not persisted yet. For one
    /// already stored (loaded through this port), use <see cref="SaveAsync"/>:
    /// calling this on a loaded product would write it again from scratch.
    /// </remarks>
    /// <exception cref="DuplicateProductCodeException">The code already exists.</exception>
    Task AddAndSaveAsync(Product product, CancellationToken cancellationToken = default);

    /// <summary>Persists the (possibly changed) state of a product loaded through this port, atomically.</summary>
    /// <remarks>
    /// The aggregate is expected to come from a tracked read, so change detection
    /// writes only what the domain changed — including a whole replaced size
    /// configuration (BCK08).
    /// </remarks>
    Task SaveAsync(Product product, CancellationToken cancellationToken = default);

}
