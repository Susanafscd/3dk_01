using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Product;

public sealed class ProductConcurrencyException(string message) : DomainException(message);
