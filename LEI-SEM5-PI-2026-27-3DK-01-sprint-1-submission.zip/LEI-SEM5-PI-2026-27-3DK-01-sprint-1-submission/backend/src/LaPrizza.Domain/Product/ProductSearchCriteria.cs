using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Domain.Products;

/// <summary>Domain query contract for product catalogue filtering.</summary>
public sealed record ProductSearchCriteria(
    string? Search,
    ProductCategoryCode? CategoryCode,
    AllergenCode? AllergenCode,
    string? ComponentTypeCode,
    bool? Sellable,
    bool? StockControlled,
    bool? IsPizzaComponent,
    ProductKind? Kind,
    bool? Active,
    int Page = 1,
    int PageSize = 20);
