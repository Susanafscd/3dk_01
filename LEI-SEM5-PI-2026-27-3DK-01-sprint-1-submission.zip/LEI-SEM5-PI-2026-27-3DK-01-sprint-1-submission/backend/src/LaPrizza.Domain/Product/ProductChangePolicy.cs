using LaPrizza.Domain.Product;

namespace LaPrizza.Domain.Products;

/// <summary>Checks references only. Roles, price and allergen distinctness are enforced by the builder.</summary>
public sealed class ProductChangePolicy
{
    public void EnsureReferencesAreValid(ProductChangeContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        if (!context.CategoryExists)
        {
            throw new InvalidProductException("The category does not exist.");
        }

        if (context.UnknownAllergens.Count > 0)
        {
            var codes = string.Join(", ", context.UnknownAllergens.Select(a => a.Value));
            throw new InvalidProductException($"Unknown allergen codes: {codes}.");
        }

        if (context.CategoryAllowsComponentTypes && !context.ComponentTypeRequested)
        {
            throw new InvalidProductException("A component type is required for this category.");
        }

        if (!context.CategoryAllowsComponentTypes && context.ComponentTypeRequested)
        {
            throw new InvalidProductException("This category does not allow component types.");
        }

        if (context.ComponentTypeRequested && !context.ComponentTypeExists)
        {
            throw new InvalidProductException("The component type does not exist.");
        }

        if (context.ComponentTypeExists && !context.ComponentTypeCategoryMatches)
        {
            throw new InvalidProductException("The component type belongs to a different category.");
        }
    }
}
