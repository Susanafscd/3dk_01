using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Products;

public sealed class DuplicateProductCodeException(ProductCode code)
    : DomainException($"A product with code '{code.Value}' already exists.");
