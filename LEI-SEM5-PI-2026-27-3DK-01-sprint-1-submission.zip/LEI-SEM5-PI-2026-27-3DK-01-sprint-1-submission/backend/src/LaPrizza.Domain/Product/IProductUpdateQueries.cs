using LaPrizza.Domain.Products;

namespace LaPrizza.Domain.Product;

/// <summary>Read-only dependency facts used before a product replacement.</summary>
public sealed record ProductUpdateFacts(bool ReferencedByComposedProduct);

public interface IProductUpdateQueries
{
    Task<ProductUpdateFacts> GetFactsAsync(
        ProductCode productCode,
        CancellationToken cancellationToken = default);
}
