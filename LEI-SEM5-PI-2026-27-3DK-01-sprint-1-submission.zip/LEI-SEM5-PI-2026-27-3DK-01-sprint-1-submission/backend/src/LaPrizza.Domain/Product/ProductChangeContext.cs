using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Domain.Product;

public interface IProductRelationshipQueries
{
    Task<ProductChangeContext> GetChangeContextAsync(
        ProductCategoryCode category,
        IReadOnlyCollection<AllergenCode> allergens,
        PizzaComponentTypeCode? componentTypeCode = null,
        CancellationToken cancellationToken = default);
}

/// <summary>Current persisted facts about the references a product uses.</summary>
/// <param name="CategoryExists">The requested category exists.</param>
/// <param name="UnknownAllergens">Requested allergen codes that do not exist.</param>
public sealed record ProductChangeContext(
    bool CategoryExists,
    IReadOnlyCollection<AllergenCode> UnknownAllergens,
    bool CategoryAllowsComponentTypes = false,
    bool ComponentTypeRequested = false,
    bool ComponentTypeExists = false,
    bool ComponentTypeCategoryMatches = false);
