namespace LaPrizza.Domain.Products;

/// <summary>
/// Write port for stock changes (BCK09). Each change is one atomic conditional
/// update that commits on its own and returns the balance actually stored, so
/// concurrent changes are never lost and never leave the allowed range.
/// </summary>
public interface IStockRepository
{
    /// <summary>
    /// Adds <paramref name="units"/> to the stock of the product with the internal
    /// key <paramref name="productId"/>, only if it is still stock-controlled and
    /// the result stays within <see cref="Product.Product.MaximumStockBalance"/>.
    /// </summary>
    /// <returns>The stored balance, or <c>null</c> when nothing was changed.</returns>
    Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default);

    /// <summary>
    /// Removes <paramref name="units"/> from the stock of the product with the
    /// internal key <paramref name="productId"/>, only if it is still
    /// stock-controlled and has at least that many units, so it never becomes negative.
    /// </summary>
    /// <returns>The stored balance, or <c>null</c> when nothing was changed.</returns>
    Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default);
}
