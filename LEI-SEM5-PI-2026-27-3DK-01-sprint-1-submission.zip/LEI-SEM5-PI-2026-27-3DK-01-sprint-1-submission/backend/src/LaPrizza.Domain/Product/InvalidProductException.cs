using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Products;

public sealed class InvalidProductException(string message) : DomainException(message);
