namespace LaPrizza.Domain.Products;

/// <summary>Inward-facing read port for the stock search (BCK09, UC-40).</summary>
public interface IStockQueries
{
    Task<StockSearchPage> SearchAsync(
        StockSearchCriteria criteria,
        CancellationToken cancellationToken = default);
}
