using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Domain.Product;

/// <summary>
/// A sellable product composed of pizza components: a predefined pizza (BCK10).
/// Its price is derived per size from its components, so it holds no single
/// <see cref="Sellable"/> price and is never stock-controlled.
/// </summary>
public sealed class ComposedProduct : Product
{
    private readonly List<ProductCode> _components = [];
    private readonly List<AvailableSize> _availableSizes = [];

    private ComposedProduct()
    {
    }

    private ComposedProduct(
        ProductCode code,
        string name,
        string description,
        ProductCategoryCode categoryCode,
        IEnumerable<ProductCode> components,
        IEnumerable<AvailableSize> availableSizes)
        : base(code, name, description, categoryCode)
    {
        _components.AddRange(components);
        _availableSizes.AddRange(availableSizes);
    }

    public override bool IsSellable => true;

    /// <summary>The default configuration: the codes of the pizza components.</summary>
    public IReadOnlyCollection<ProductCode> Components => _components;

    /// <summary>
    /// The sizes the pizza is offered in. Whether every component is configured in
    /// each of them is checked by the caller, because size configurations belong
    /// to the components (BCK08, BR-13).
    /// </summary>
    public IReadOnlyCollection<AvailableSize> AvailableSizes => _availableSizes;

    /// <summary>
    /// Creates a predefined pizza with its default configuration (BR-12) and its
    /// available sizes. The
    /// caller resolves each component's state and type, and the limits of every
    /// component type, because they belong to other aggregates (BCK05, BCK07).
    /// </summary>
    /// <exception cref="InvalidProductException">The code, name, description, category or a size name is invalid.</exception>
    /// <exception cref="InvalidPizzaConfigurationException">The default configuration or the sizes break a rule.</exception>
    public static ComposedProduct Create(
        string? code,
        string? name,
        string? description,
        string? categoryCode,
        IReadOnlyCollection<PizzaComponent> components,
        IReadOnlyCollection<ComponentTypeLimit> typeLimits,
        IReadOnlyCollection<string> availableSizes)
    {
        ArgumentNullException.ThrowIfNull(components);
        ArgumentNullException.ThrowIfNull(typeLimits);
        ArgumentNullException.ThrowIfNull(availableSizes);

        var productCode = ProductCode.Create(code);
        var validName = RequireText(name, "Name", NameMaxLength);
        var validDescription = RequireText(description, "Description", DescriptionMaxLength);
        var category = ProductCategoryCode.Create(categoryCode);

        ValidateConfiguration(components, typeLimits);
        var sizes = ValidateSizes(availableSizes);

        return new ComposedProduct(
            productCode,
            validName,
            validDescription,
            category,
            components.Select(component => component.Code),
            sizes);
    }

    /// <summary>
    /// Replaces the details, the default configuration and the available sizes of
    /// the pizza (UC-46) with the same rules as its creation. Everything is
    /// validated before anything changes, so a rejected replacement leaves the
    /// pizza as it was. The code, the category and the active flag are kept, and
    /// unchanged components and sizes keep their instances, so persistence
    /// replaces only the rows that changed.
    /// </summary>
    /// <exception cref="InvalidProductException">The name, description or a size name is invalid.</exception>
    /// <exception cref="InvalidPizzaConfigurationException">The default configuration or the sizes break a rule.</exception>
    public void ReplaceConfiguration(
        string? name,
        string? description,
        IReadOnlyCollection<PizzaComponent> components,
        IReadOnlyCollection<ComponentTypeLimit> typeLimits,
        IReadOnlyCollection<string> availableSizes)
    {
        ArgumentNullException.ThrowIfNull(components);
        ArgumentNullException.ThrowIfNull(typeLimits);
        ArgumentNullException.ThrowIfNull(availableSizes);

        var validName = RequireText(name, "Name", NameMaxLength);
        var validDescription = RequireText(description, "Description", DescriptionMaxLength);
        ValidateConfiguration(components, typeLimits);
        var sizes = ValidateSizes(availableSizes);

        UpdateDescription(validName, validDescription);

        var codes = components.Select(component => component.Code).ToList();
        _components.RemoveAll(code => !codes.Contains(code));
        _components.AddRange(codes.Where(code => !_components.Contains(code)));

        _availableSizes.RemoveAll(size => !sizes.Contains(size));
        _availableSizes.AddRange(sizes.Where(size => !_availableSizes.Contains(size)));
    }

    private static void ValidateConfiguration(
        IReadOnlyCollection<PizzaComponent> components,
        IReadOnlyCollection<ComponentTypeLimit> typeLimits)
    {
        if (components.Count == 0)
        {
            throw new InvalidPizzaConfigurationException("A predefined pizza needs at least one component.");
        }

        foreach (var component in components)
        {
            if (!component.Active)
            {
                throw new InvalidPizzaConfigurationException($"Component '{component.Code}' is inactive.");
            }

            if (component.ComponentTypeCode is not { } type)
            {
                throw new InvalidPizzaConfigurationException($"Product '{component.Code}' is not a pizza component.");
            }

            if (typeLimits.All(limit => limit.TypeCode != type))
            {
                throw new InvalidPizzaConfigurationException(
                    $"Component '{component.Code}' has the unknown component type '{type}'.");
            }
        }

        var repeated = components.GroupBy(component => component.Code).FirstOrDefault(group => group.Count() > 1);
        if (repeated is not null)
        {
            throw new InvalidPizzaConfigurationException($"Component '{repeated.Key}' occurs more than once.");
        }

        foreach (var limit in typeLimits)
        {
            var count = components.Count(component => component.ComponentTypeCode == limit.TypeCode);
            if (count < limit.Minimum || count > limit.Maximum)
            {
                var range = limit.Maximum is { } maximum ? $"{limit.Minimum} to {maximum}" : $"at least {limit.Minimum}";
                throw new InvalidPizzaConfigurationException(
                    $"A predefined pizza needs {range} components of type '{limit.TypeCode}', not {count}.");
            }
        }
    }

    private static List<AvailableSize> ValidateSizes(IReadOnlyCollection<string> availableSizes)
    {
        if (availableSizes.Count == 0)
        {
            throw new InvalidPizzaConfigurationException("A predefined pizza needs at least one available size.");
        }

        if (availableSizes.Any(string.IsNullOrWhiteSpace))
        {
            throw new InvalidProductException("Size names cannot be blank.");
        }

        var repeated = availableSizes.GroupBy(size => size).FirstOrDefault(group => group.Count() > 1);
        if (repeated is not null)
        {
            throw new InvalidPizzaConfigurationException($"Size '{repeated.Key}' occurs more than once.");
        }

        return availableSizes.Select(size => new AvailableSize(size)).ToList();
    }

    private static string RequireText(string? value, string field, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidProductException($"{field} is required.");
        }

        var text = value.Trim();
        if (text.Length > maxLength)
        {
            throw new InvalidProductException($"{field} cannot exceed {maxLength} characters.");
        }

        return text;
    }
}
