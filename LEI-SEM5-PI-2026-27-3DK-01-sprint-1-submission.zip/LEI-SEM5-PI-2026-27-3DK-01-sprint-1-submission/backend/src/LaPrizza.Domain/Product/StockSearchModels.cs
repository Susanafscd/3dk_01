using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Domain.Products;

/// <summary>Domain query contract for the stock search; only stock-controlled products match.</summary>
public sealed record StockSearchCriteria(
    string? Search,
    ProductCategoryCode? CategoryCode,
    bool? Active,
    int Page = 1,
    int PageSize = 20);

/// <summary>Read projection of one stock-controlled product returned by the stock search.</summary>
public sealed record StockSearchItem(
    string ProductCode,
    string ProductName,
    string CategoryCode,
    bool Active,
    int QuantityInStock);

/// <summary>A page of stock items together with the count before pagination.</summary>
public sealed record StockSearchPage(
    IReadOnlyList<StockSearchItem> Items,
    int TotalCount);
