using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Products;

/// <summary>
/// Raised when the default configuration of a predefined pizza breaks a rule:
/// an inactive, repeated or non-pizza component, or a component type's minimum
/// or maximum (BCK10, BR-12).
/// </summary>
public sealed class InvalidPizzaConfigurationException(string message) : DomainException(message);
