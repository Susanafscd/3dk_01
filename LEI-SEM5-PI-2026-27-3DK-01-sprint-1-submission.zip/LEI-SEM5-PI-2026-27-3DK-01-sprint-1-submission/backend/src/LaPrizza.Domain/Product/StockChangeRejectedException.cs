using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Products;

/// <summary>
/// Raised when a valid stock change conflicts with the product's state: it is not
/// stock-controlled, or the result would leave the allowed range (BCK09).
/// </summary>
public sealed class StockChangeRejectedException(string message) : DomainException(message);
