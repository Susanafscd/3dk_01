using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Domain.Product;

/// <summary>
/// The only way to create a <see cref="BaseProduct"/>. Validates raw input and applies optional
/// configurations before returning the product.
/// </summary>
public sealed class BaseProductBuilder
{
    private readonly List<Action<BaseProduct>> _configurations = [];

    private string? _code;
    private string? _name;
    private string? _description;
    private string? _categoryCode;
    private bool _sellable;
    private bool _stockControlled;
    private decimal? _price;
    private IReadOnlyList<string>? _allergenCodes = [];
    private string? _componentTypeCode;

    public BaseProductBuilder WithCode(string? code)
    {
        _code = code;
        return this;
    }

    public BaseProductBuilder WithName(string? name)
    {
        _name = name;
        return this;
    }

    public BaseProductBuilder WithDescription(string? description)
    {
        _description = description;
        return this;
    }

    public BaseProductBuilder InCategory(string? categoryCode)
    {
        _categoryCode = categoryCode;
        return this;
    }

    public BaseProductBuilder AsSellable(bool sellable = true)
    {
        _sellable = sellable;
        return this;
    }

    public BaseProductBuilder WithPrice(decimal? price)
    {
        _price = price;
        return this;
    }

    public BaseProductBuilder StockControlled(bool stockControlled = true)
    {
        _stockControlled = stockControlled;
        return this;
    }

    public BaseProductBuilder WithAllergens(IReadOnlyList<string>? allergenCodes)
    {
        _allergenCodes = allergenCodes;
        return this;
    }

    public BaseProductBuilder WithComponentTypeCode(string? componentTypeCode)
    {
        _componentTypeCode = componentTypeCode;
        return this;
    }

    public BaseProductBuilder WithConfiguration(Action<BaseProduct> configure)
    {
        ArgumentNullException.ThrowIfNull(configure);
        _configurations.Add(configure);
        return this;
    }

    public BaseProduct Build()
    {
        var code = ProductCode.Create(_code);
        var name = RequireText(_name, "Name", Product.NameMaxLength);
        var description = RequireText(_description, "Description", Product.DescriptionMaxLength);
        var category = ProductCategoryCode.Create(_categoryCode);
        var componentTypeCode = _componentTypeCode is null
            ? null
            : PizzaComponentTypeCode.Create(_componentTypeCode).Value;

        Sellable? sellable = null;
        if (_sellable)
        {
            if (_price is null)
            {
                throw new InvalidProductException("A sellable product requires a price.");
            }

            sellable = new Sellable(Money.Create(_price));
        }
        else if (_price is not null)
        {
            throw new InvalidProductException("Price is only allowed for sellable products.");
        }

        if (_allergenCodes is null)
        {
            throw new InvalidProductException("Allergen codes cannot be null.");
        }

        var allergens = _allergenCodes.Select(AllergenCode.Create).ToList();
        if (allergens.Distinct().Count() != allergens.Count)
        {
            throw new InvalidProductException("Allergen codes must be distinct.");
        }

        var product = new BaseProduct(
            code,
            name,
            description,
            category,
            sellable,
            _stockControlled,
            allergens,
            componentTypeCode);

        foreach (var configure in _configurations)
        {
            configure(product);
        }

        return product;
    }

    private static string RequireText(string? value, string field, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidProductException($"{field} is required.");
        }

        var text = value.Trim();
        if (text.Length > maxLength)
        {
            throw new InvalidProductException($"{field} cannot exceed {maxLength} characters.");
        }

        return text;
    }
}
