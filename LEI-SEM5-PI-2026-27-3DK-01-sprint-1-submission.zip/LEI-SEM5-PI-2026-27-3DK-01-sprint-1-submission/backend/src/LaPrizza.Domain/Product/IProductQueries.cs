namespace LaPrizza.Domain.Products;

/// <summary>Inward-facing read port for product search and filtering.</summary>
public interface IProductQueries
{
    Task<ProductSearchPage> SearchAsync(
        ProductSearchCriteria criteria,
        CancellationToken cancellationToken = default);
}
