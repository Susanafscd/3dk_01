using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Domain.Product;

/// <summary>Common details of products. Constructed through a concrete type and its builder.</summary>
public abstract class Product
{
    public const int NameMaxLength = 200;
    public const int DescriptionMaxLength = 1000;

    /// <summary>
    /// Largest stock balance, the range of the PostgreSQL <c>integer</c> column
    /// (BCK09, P5).
    /// </summary>
    public const int MaximumStockBalance = int.MaxValue;

    private readonly List<AllergenCode> _allergens = [];

    protected Product()
    {
        Code = default!;
        Name = default!;
        Description = default!;
        CategoryCode = default!;
    }

    protected Product(
        ProductCode code,
        string name,
        string description,
        ProductCategoryCode categoryCode,
        Sellable? sellable,
        bool stockControlled,
        IEnumerable<AllergenCode> allergenCodes,
        string? componentTypeCode = null)
    {
        if (sellable is null && !stockControlled)
        {
            throw new InvalidProductException("A product must be sellable.");
        }

        Id = Guid.NewGuid();
        Code = code;
        Name = name;
        Description = description;
        CategoryCode = categoryCode;
        Sellable = sellable;
        StockControlled = stockControlled;
        StockBalance = stockControlled ? 0 : null;
        Active = true;
        ComponentTypeCode = componentTypeCode;
        _allergens.AddRange(allergenCodes);
    }

    /// <summary>
    /// Common details of a composed product (BCK10). It is sold at a price derived
    /// from its components, so it has no <see cref="Sellable"/> and no stock control.
    /// </summary>
    protected Product(
        ProductCode code,
        string name,
        string description,
        ProductCategoryCode categoryCode)
    {
        Id = Guid.NewGuid();
        Code = code;
        Name = name;
        Description = description;
        CategoryCode = categoryCode;
        Active = true;
    }

    public Guid Id { get; private set; }
    public ProductCode Code { get; private set; }
    public string Name { get; private set; }
    public string Description { get; private set; }
    public ProductCategoryCode CategoryCode { get; private set; }
    public Sellable? Sellable { get; private set; }
    public bool StockControlled { get; private set; }
    public int? StockBalance { get; private set; }
    public bool Active { get; private set; }
    public string? ComponentTypeCode { get; private set; }

    /// <summary>
    /// Replaces the common descriptive and allergen details without changing
    /// the product identity, kind, activity, category or role-owned state.
    /// Category/role/stock/configuration changes require the protected UC-26
    /// consistency workflow.
    /// </summary>
    public void UpdateCommonDetails(
        string? name,
        string? description,
        IReadOnlyCollection<AllergenCode> allergenCodes)
    {
        ArgumentNullException.ThrowIfNull(allergenCodes);

        var validName = LaPrizza.Domain.Common.Guard.RequiredText(name, "Name", NameMaxLength);
        var validDescription = LaPrizza.Domain.Common.Guard.RequiredText(description, "Description", DescriptionMaxLength);

        var distinctAllergens = allergenCodes.Distinct().ToArray();
        if (distinctAllergens.Length != allergenCodes.Count)
        {
            throw new InvalidProductException("Allergen codes must be unique.");
        }

        Name = validName;
        Description = validDescription;
        _allergens.Clear();
        _allergens.AddRange(distinctAllergens);
    }

    /// <summary>Updates only descriptive fields, preserving the current allergens.</summary>
    public void UpdateDescription(string? name, string? description) =>
        UpdateCommonDetails(name, description, _allergens);

    /// <summary>
    /// Applies the complete editable product replacement after the application
    /// layer has checked cross-aggregate references and composition usage.
    /// Identity, kind, active state and owned configurations are preserved.
    /// </summary>
    public void ReplaceEditableDetails(
        string? name,
        string? description,
        ProductCategoryCode categoryCode,
        bool sellable,
        decimal? price,
        bool stockControlled,
        IReadOnlyCollection<AllergenCode> allergenCodes,
        string? componentTypeCode)
    {
        ArgumentNullException.ThrowIfNull(categoryCode);
        ArgumentNullException.ThrowIfNull(allergenCodes);

        var validName = LaPrizza.Domain.Common.Guard.RequiredText(name, "Name", NameMaxLength);
        var validDescription = LaPrizza.Domain.Common.Guard.RequiredText(description, "Description", DescriptionMaxLength);
        var distinctAllergens = allergenCodes.Distinct().ToArray();
        if (distinctAllergens.Length != allergenCodes.Count)
        {
            throw new InvalidProductException("Allergen codes must be unique.");
        }

        if (this is ComposedProduct)
        {
            if (categoryCode != CategoryCode || !sellable || stockControlled || price is not null || componentTypeCode is not null)
            {
                throw new InvalidProductException(
                    "A composed product keeps its category, derived sellability and non-stock-controlled state.");
            }

            Name = validName;
            Description = validDescription;
            _allergens.Clear();
            _allergens.AddRange(distinctAllergens);
            return;
        }

        if (sellable && price is null)
        {
            throw new InvalidProductException("A sellable product requires a price.");
        }

        if (!sellable && price is not null)
        {
            throw new InvalidProductException("Price is only allowed for sellable products.");
        }

        if (!sellable && !stockControlled)
        {
            throw new InvalidProductException("A product must be sellable or stock-controlled.");
        }

        // Validate the state-changing stock guard before mutating any other
        // property, so a rejected replacement cannot partially update the row.
        if (!stockControlled && StockControlled && StockBalance is > 0)
        {
            throw new StockChangeRejectedException(
                $"Product '{Code}' must have zero stock before stock control is disabled.");
        }

        var replacementSellable = sellable ? new Sellable(Money.Create(price)) : null;

        Name = validName;
        Description = validDescription;
        CategoryCode = categoryCode;
        Sellable = replacementSellable;
        ComponentTypeCode = componentTypeCode;
        _allergens.Clear();
        _allergens.AddRange(distinctAllergens);
        SetStockControl(stockControlled);
    }

    /// <summary>
    /// Logically deactivates this product and returns whether its state changed.
    /// Deactivation is allowed even when another product currently references this
    /// product as a component. It never cascades to those products: their own
    /// <see cref="Active"/> flag, configuration and business-code references remain
    /// unchanged. Catalogue/application queries must derive their effective
    /// availability from the current component state.
    /// </summary>
    public bool Deactivate()
    {
        if (!Active) return false;
        Active = false;
        return true;
    }

    public virtual bool IsSellable => Sellable is not null;
    public IReadOnlyCollection<AllergenCode> Allergens => _allergens;

    /// <summary>
    /// Changes whether this product is controlled by stock. Disabling control
    /// clears the balance only after the existing balance has reached zero;
    /// enabling control starts at zero or at the supplied initial balance.
    /// </summary>
    /// <remarks>
    /// The balance is deliberately not an editable field when control is already
    /// enabled. Stock movements remain the responsibility of the stock use cases.
    /// </remarks>
    public void SetStockControl(bool stockControlled, int? initialBalance = null)
    {
        if (initialBalance is < 0 or > MaximumStockBalance)
        {
            throw new InvalidProductException(
                $"Initial stock balance must be between 0 and {MaximumStockBalance}.");
        }

        if (!stockControlled)
        {
            if (initialBalance is not null)
            {
                throw new InvalidProductException(
                    "An initial stock balance is only valid when enabling stock control.");
            }

            if (StockControlled && StockBalance is > 0)
            {
                throw new StockChangeRejectedException(
                    $"Product '{Code}' must have zero stock before stock control is disabled.");
            }

            StockControlled = false;
            StockBalance = null;
            return;
        }

        if (StockControlled)
        {
            // A stock update must go through IncreaseStock/DecreaseStock. Keep
            // the current balance when control is retained.
            StockBalance ??= 0;
            return;
        }

        StockControlled = true;
        StockBalance = initialBalance ?? 0;
    }

    /// <summary>
    /// Adds <paramref name="units"/> abstract stock units (BCK09, UC-41). Inactive
    /// products may be increased too: inactivity prevents new sales, not the
    /// administrative management of the stock (P8).
    /// </summary>
    /// <exception cref="InvalidProductException">The units are not a positive integer.</exception>
    /// <exception cref="StockChangeRejectedException">
    /// The product is not stock-controlled, or the result would exceed <see cref="MaximumStockBalance"/>.
    /// </exception>
    public void IncreaseStock(int units)
    {
        var balance = CurrentStockBalance(units);
        if (balance > MaximumStockBalance - units)
        {
            throw new StockChangeRejectedException(
                $"Increasing the stock of product '{Code}' by {units} units would exceed {MaximumStockBalance} units.");
        }

        StockBalance = balance + units;
    }

    /// <summary>
    /// Removes <paramref name="units"/> abstract stock units (BCK09, UC-42); the
    /// stock is never negative. Inactive products may be decreased too (P8).
    /// </summary>
    /// <exception cref="InvalidProductException">The units are not a positive integer.</exception>
    /// <exception cref="StockChangeRejectedException">
    /// The product is not stock-controlled, or it has fewer units than requested.
    /// </exception>
    public void DecreaseStock(int units)
    {
        var balance = CurrentStockBalance(units);
        if (balance < units)
        {
            throw new StockChangeRejectedException(
                $"Product '{Code}' has {balance} units in stock, fewer than the {units} requested.");
        }

        StockBalance = balance - units;
    }

    private int CurrentStockBalance(int units)
    {
        if (units <= 0)
        {
            throw new InvalidProductException("Stock units must be a positive integer.");
        }

        if (!StockControlled || StockBalance is not { } balance)
        {
            throw new StockChangeRejectedException($"Product '{Code}' is not stock-controlled.");
        }

        return balance;
    }
}
