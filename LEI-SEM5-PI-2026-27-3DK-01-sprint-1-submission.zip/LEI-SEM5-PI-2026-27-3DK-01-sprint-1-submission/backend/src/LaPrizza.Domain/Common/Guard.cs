namespace LaPrizza.Domain.Common;

/// <summary>
/// Small helpers for validating the text that enters value objects and
/// aggregates. They keep the invariant checks out of the entities themselves.
/// </summary>
internal static class Guard
{
    /// <summary>Returns the trimmed value, or throws when it is missing or too long.</summary>
    public static string RequiredText(string? value, string field, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new DomainException($"{field} is required.");
        }

        return Truncate(value.Trim(), field, maxLength);
    }

    /// <summary>Returns the trimmed value, null when blank, or throws when too long.</summary>
    public static string? OptionalText(string? value, string field, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        return Truncate(value.Trim(), field, maxLength);
    }

    private static string Truncate(string value, string field, int maxLength)
    {
        if (value.Length > maxLength)
        {
            throw new DomainException($"{field} cannot exceed {maxLength} characters.");
        }

        return value;
    }
}
