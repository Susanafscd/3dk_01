namespace LaPrizza.Domain.Common;

/// <summary>
/// Raised when a business rule or invariant of the domain is broken. It carries
/// a message that is safe to surface to the caller.
/// </summary>
public class DomainException(string message) : Exception(message);
