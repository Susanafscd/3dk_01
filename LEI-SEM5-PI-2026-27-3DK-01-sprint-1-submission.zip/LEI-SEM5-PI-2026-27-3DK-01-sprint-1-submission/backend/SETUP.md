# Backend — setup guide for a new developer

A linear, first-day walkthrough: from a fresh clone to a running API. For
reference material (what each piece does, which decisions were made) see
[README.md](README.md) instead.

---

## 0. What you are aiming for

Two commands and a browser tab:

| URL                                          | What you should see                       |
| -------------------------------------------- | ----------------------------------------- |
| <https://localhost:7192/swagger>            | Swagger UI with the OpenAPI contract: `GET /api/v1/health`, the customer endpoints (`/api/v1/customers`) and authentication |
| <https://localhost:7192/api/v1/health>      | `{"status":"ok","version":"1.0.0", …}`     |

The backend is built and the first slice works end to end. Log in with the seeded
manager (`POST /api/v1/auth/login`) and you can exercise the authenticated
customer endpoints (`/api/v1/customers`) from the browser. Building and testing
need no database.

---

## 1. Install the .NET SDK

You need the **.NET 10 SDK**. This project was built and verified with
**10.0.401**, running on **.NET 10.0.12** and **ASP.NET Core 10.0.12**.

Check what you have:

```bash
dotnet --version
```

It must print `10.0.x`. If the command is not found, install the SDK:

- **Windows / macOS / Linux (GUI):** <https://dotnet.microsoft.com/download/dotnet/10.0>
  — pick the installer for your platform.
- **Linux / macOS (script):**

  ```bash
  curl -sSL https://dot.net/v1/dotnet-install.sh | bash -s -- --channel 10.0
  ```

  Then make sure `~/.dotnet` is on your `PATH`.

Verify again with `dotnet --version`. Every teammate must be on the same major
version — a mismatch produces build errors that have nothing to do with the code.

---

## 2. Get the code and restore the packages

```bash
git clone <repository-url>
cd LEI-SEM5-PI-2026-27-3DK-01/backend
dotnet restore
```

`dotnet restore` downloads the NuGet packages. It takes a minute or two on a
cold cache; later builds are fast. Nothing else is needed at this step.

The build generates the HTTP layer from the contract: the use-case fragments
under [`docs/api/contract/`](../docs/api/contract) are bundled into
[`docs/api/openapi.json`](../docs/api/openapi.json), then NSwag reads the bundle
and writes `src/Api/OpenApi/Generated/Contract.g.cs` (controller bases and DTOs).
You edit the fragment that owns the endpoint and the controllers under
`src/Api/Controllers/`; the bundle and the generated file are rewritten
automatically when a fragment changes. See [README.md](README.md) §5.

Production projects live under `backend/src/` and test projects under
`backend/tests/`; the solution is [`backend/Api.sln`](Api.sln). To work in an IDE,
open the repository root: it loads the back-end through the
[`LaPrizza.slnf`](../LaPrizza.slnf) solution filter (which points to
`backend/Api.sln`). Opening `backend/Api.sln` directly works too.

---

## 3. Configure (optional, but read this)

Configuration is environment-based and layered, later files winning:

| Order | Source                                                       | Holds                                        |
| ----- | ------------------------------------------------------------ | -------------------------------------------- |
| 1     | `src/Api/appsettings.json`                                  | Shared, non-secret defaults                   |
| 2     | `src/Api/appsettings.Development.json`                      | Local development defaults                    |
| 3     | Environment variables (`ConnectionStrings__Postgres`, …)    | Anything secret, and per-machine overrides    |
| 4     | `src/Api/.env`                                              | Same variables, for convenience              |

**You do not have to create a `.env` file.** `appsettings.Development.json`
already contains working local defaults, and they are enough to start the API
and run the tests. Create `.env` only when you need something different:

```bash
cd src/Api
cp .env.example .env    # then edit it — never commit it, it is git-ignored
```

`.env` is read **only** when `ASPNETCORE_ENVIRONMENT=Development`, which the
launch profiles set for you. Variables already exported in your shell always
win over the file.

### Databases

Apply the EF Core migrations that create the schema, and then
run the separate bootstrap project to insert data.


```bash
# From backend/: create the schema, then seed the initial accounts.
dotnet ef database update --project src/LaPrizza.Infrastructure --startup-project src/LaPrizza.Infrastructure --context AppDbContext
dotnet ef database update --project src/LaPrizza.Infrastructure --startup-project src/LaPrizza.Infrastructure --context DomainDbContext
dotnet run --project src/Bootstrapper
```

`dotnet ef` reads the same `.env` as the API (the environment variable
`ConnectionStrings__Postgres` still wins), so it targets whichever host port
your `.env` points at.

See [README.md](README.md) §4.

The API **fails fast on startup** if no relational connection string is
configured at all, so if you see that error, set
`ConnectionStrings__Postgres` in `.env` or `appsettings.Development.json`.

---

## 4. Trust the HTTPS development certificate

Cookies are `Secure` in production. In development they follow the request
scheme, so sign-in works over HTTPS (and, for convenience, over plain HTTP when
you call the API from a tool or the Docker stack). The development certificate
is still recommended so browsers do not warn over HTTPS; trust it once per
machine:

```bash
dotnet dev-certs https --trust
```

Skip this and the browser will warn on every HTTPS request.

---

## 5. Run it

From the `backend/` folder:

```bash
dotnet run --project src/Api
```

Wait for `Application started`, then open
<https://localhost:7192/swagger>.

The default launch profile is `https`. To serve plain HTTP instead — useful when
you are calling the API from a tool that dislikes certificates:

```bash
dotnet run --project src/Api --launch-profile http   # http://localhost:8080
```

In development the cookies follow the request scheme, so authentication and the
antiforgery token work over either `https://localhost:7192` or the plain-HTTP
profile. In production the cookies stay `Secure`, so HTTPS is mandatory there.

| URL                                              | What it is                        |
| ------------------------------------------------ | --------------------------------- |
| <https://localhost:7192/swagger>                | Swagger UI — the OpenAPI contract |
| <https://localhost:7192/api/v1/health>          | Liveness check (anonymous)        |
| <http://localhost:8080/api/v1/health>            | The health check over plain HTTP  |
| <http://localhost:8080/swagger>                  | The same contract over plain HTTP |

Stop the server with `Ctrl+C`.

---

## 6. Verify it works

With the server running, in a second terminal:

```bash
curl http://localhost:8080/api/v1/health
```

```json
{"status":"ok","version":"1.0.0","timestamp":"2026-10-02T16:30:38.7737791Z"}
```

Then confirm CORS is open to the frontend's dev server origin:

```bash
curl -s -D - -o /dev/null -H "Origin: http://localhost:5173" \
  http://localhost:8080/api/v1/health | grep -i access-control
# -> access-control-allow-origin: http://localhost:5173
```

Both `http://localhost:5173` and `http://localhost:3000` are allowed by default,
which are exactly the origins the Angular dev server uses. If you change the
frontend's port, change `Cors:AllowedOrigins` (or `Cors__AllowedOrigins__0`, …)
to match, or the browser will block the frontend's requests.

---

## 7. Run the tests

```bash
dotnet test
```

The suite spans all four layers — domain, application, infrastructure and the
HTTP endpoints — and needs no database or login. The endpoint tests boot the real
host (`WebApplicationFactory`) with in-memory databases and test doubles for
authentication and antiforgery. See [README.md](README.md) §6 for what each test
project covers.

---

## 8. Everyday commands

| Command                                     | What it does                                  |
| ------------------------------------------- | --------------------------------------------- |
| `dotnet restore`                            | Download NuGet packages                        |
| `dotnet build Api.sln`                      | Build the whole solution                       |
| `dotnet run --project src/Api`                  | Run the API (HTTPS, port 7192)                 |
| `dotnet run --project src/Api --launch-profile http` | Run the API (HTTP, port 8080)              |
| `dotnet test Api.sln`                       | Run the test suite                             |
| `dotnet format`                             | Reformat the code                              |
| `dotnet format --verify-no-changes --severity warn` | Fail if anything is off — use this in CI |

Run all three checks before every commit:

```bash
dotnet build Api.sln && dotnet test Api.sln && dotnet format Api.sln --verify-no-changes --severity warn
```

---

## 9. If something goes wrong

| Symptom                                                       | Cause and fix                                                                 |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `dotnet: command not found`                                   | SDK not installed, or not on `PATH`. See §1.                                   |
| `error NU1101` / `Unable to find package`                     | Not restored. Run `dotnet restore`.                                            |
| Build errors about a language or framework version            | SDK major version mismatch. See §1.                                            |
| `No relational connection string is configured`               | No Postgres connection string. See §3.                                         |
| Browser shows a certificate warning at `/swagger`            | Certificate not trusted. Run `dotnet dev-certs https --trust`.                 |
| `Address already in use` / `Failed to bind to port`           | Another process holds 7192 or 8080. Change `ASPNETCORE_URLS` or stop the other process. |
| An unknown URL returns **401**, not 404                        | Expected: every endpoint requires an authenticated user by default. See [README.md](README.md) §10. |
| Swagger loads but lists no paths                              | The build failed or the bundled `docs/api/openapi.json` is empty. The contract lists `/api/v1/health`, `/api/v1/customers`, `/api/v1/auth/*` and `/api/v1/antiforgery/token`; edit the fragments under `docs/api/contract/` and rebuild. |
| Generated controllers/DTOs are missing in the IDE             | The build has not run yet. `dotnet build Api.sln` runs NSwag and writes `src/Api/OpenApi/Generated/Contract.g.cs`. |
| `POST /api/v1/customers` returns **401**                      | Expected: the customer endpoints are authenticated. Log in first (`POST /api/v1/auth/login`). |
| `POST /api/v1/customers` returns **400** about antiforgery    | The `X-CSRF-TOKEN` header is missing; obtain a token from `GET /api/v1/antiforgery/token`. |
| Bootstrap exits non-zero / `Project bootstrap failed`        | The initial manager could not be seeded. Usually the schema is missing (apply the migrations first) or a store is unreachable. See [README.md](README.md) §4. |
| Frontend reports the API as unreachable                        | CORS origin mismatch, or the API is not running. See §6.                        |

---

## 10. Where to go next

1. Read [README.md](README.md) — the architecture, the project layout, the
   cross-cutting behaviour and **what is not implemented yet**.
2. Add the remaining user and role management endpoints (BCK01, UC-05/UC-06);
   the migrations and the role seed already exist.
3. Build the next Sprint 1 stories (product catalogue, allergens, stock, …) the
   same way: fragment first, then the use case and its tests.
