# Backend — LaPrizza API

The backend of LaPrizza: a REST API built with **Clean Architecture** in separate
projects and developed **test-first**. The first slice is implemented end to end —
creating a customer, which provisions both the authentication account and the
domain customer behind it — and every endpoint is described by an **OpenAPI**
contract that **Swagger UI** renders and the server code is generated from.

The API is the integration point for the web application, the 3D visualization
and the AI scheduling component, so the contract is a first-class input rather
than an afterthought: the HTTP endpoints and DTOs are **generated from** it.

> **New to the project?** Start with the [setup guide](SETUP.md) — a linear
> walkthrough from a fresh clone to a running API. This README is the reference
> that the guide links back to.

---

## 1. Requirements

| Requirement | Version                                                        |
| ----------- | -------------------------------------------------------------- |
| .NET SDK    | **10.0.401** (any 10.0.4xx SDK works; the projects target `net10.0`) |
| Runtime     | **.NET 10.0** and **ASP.NET Core 10.0** — long-term support, supported until November 2028 |
| C# language | **C# 14** (the default for `net10.0`)                             |
| Package manager | **NuGet** (`dotnet restore`)                                |
| Databases   | PostgreSQL and MongoDB are wired up, but the tests swap the relational store for an in-memory one, so no database is needed to build or test |

Check your installation:

```bash
dotnet --version     # must print 10.0.x
```

If you do not have it, install the SDK from
<https://dotnet.microsoft.com/download/dotnet/10.0> or, on Linux/macOS:

```bash
curl -sSL https://dot.net/v1/dotnet-install.sh | bash -s -- --channel 10.0
```

> Everyone on the team must use the same major version. A mismatch produces
> confusing build errors that have nothing to do with the code.

## 2. Install

```bash
cd backend
dotnet restore
```

Production projects live under [`src/`](src/) and test projects under
[`tests/`](tests/); the solution is [`Api.sln`](Api.sln) in this folder. There is
also a solution filter at the repository root,
[`LaPrizza.slnf`](../LaPrizza.slnf), that points to it, so opening the repository
root in Rider or Visual Studio loads the back-end without having to open
`backend/src/Api`.

## 3. Configure

Configuration is environment-based: `appsettings.json` holds shared non-secret
defaults, `appsettings.{Environment}.json` holds local development defaults, and
any setting can be overridden with an environment variable using the
`Section__Key` convention.

| Setting                          | Environment variable                    | Default                                     |
| -------------------------------- | --------------------------------------- | ------------------------------------------- |
| Relational connection string     | `ConnectionStrings__Postgres`           | local placeholder in `appsettings.Development.json` |
| Document store connection string | `Mongo__ConnectionString`               | `mongodb://localhost:27017`                 |
| Document store database name     | `Mongo__DatabaseName`                   | `appdb`                                     |
| Allowed CORS origins             | `Cors__AllowedOrigins__0`, `__1`, ...   | `http://localhost:5173`, `http://localhost:3000` |
| Environment name                 | `ASPNETCORE_ENVIRONMENT`                | `Development` (set by the launch profile)   |

To configure the API locally:

```bash
cd backend/src/Api
cp .env.example .env    # then edit it
```

`.env` is **git-ignored** and is loaded automatically, but only when
`ASPNETCORE_ENVIRONMENT=Development`. Values already exported in your shell
always win over the file. `.env.example` contains placeholders only — never put
real credentials in a committed file, and never commit `.env`.

The API refuses to start without `ConnectionStrings__Postgres`; the error
message names the setting to fix. The connection is only opened when a request
queries the database, so the API starts without a running PostgreSQL server.

> **The schema comes from the migrations.** The initial migrations live under
> `src/LaPrizza.Infrastructure/Persistence/Migrations/` — one per context
> (`Identity` for `AppDbContext`, `Domain` for `DomainDbContext`). Apply them from
> `backend/` before running the bootstrap:
>
> ```bash
> dotnet ef database update --project src/LaPrizza.Infrastructure --startup-project src/LaPrizza.Infrastructure --context AppDbContext
> dotnet ef database update --project src/LaPrizza.Infrastructure --startup-project src/LaPrizza.Infrastructure --context DomainDbContext
> ```
>
> `AppDbContextFactory`/`DomainDbContextFactory` let `dotnet ef` build the
> contexts without the API host. They resolve the connection string exactly like
> the API: `ConnectionStrings__Postgres` from the environment wins, otherwise the
> git-ignored `src/Api/.env` is used (so `POSTGRES_HOST_PORT=5433` keeps working
> without exporting anything), and the placeholder is the last resort.

## 4. Run

```bash
cd backend
dotnet run --project src/Api
```

(From `backend/src/Api` you can simply run `dotnet run`. The `--project` flag is only
needed because `backend/` contains several projects. Add `--watch` while
developing.)

This uses the `https` launch profile. Trust the local development certificate
the first time, otherwise browsers will reject it:

```bash
dotnet dev-certs https --trust
```

| URL                                    | What it is                                        |
| -------------------------------------- | ------------------------------------------------- |
| <https://localhost:7192/swagger>       | Swagger UI — the interactive OpenAPI contract     |
| <https://localhost:7192/api/v1/health> | Liveness check (anonymous)                        |
| <http://localhost:8080/api/v1/health>  | The health check over plain HTTP                  |

> Cookies are `Secure` in production. In development they follow the request
> scheme, so cookie-based sign-in works over HTTPS and, for convenience, over the
> plain-HTTP profile too. In production the API must be reached over HTTPS.

Health response:

```json
{ "status": "ok", "version": "1.0.0", "timestamp": "2026-10-02T12:01:29.9047644Z" }
```

`version` comes from the single `<Version>` property in `src/Api/Api.csproj`.

### Project bootstrap (initial manager and sample customers)

The initial manager and three sample customers are seeded by a separate, runnable
project — not by the API at start-up. `src/Bootstrapperper` holds the bootstrap
itself: one idempotent **bootstrapper per DDD aggregate**
(`IAggregateBootstrapper`: the role, then the manager, then the customers and
product categories), each
delegating to the application layer's use cases; `src/Bootstrapper` is a small
console project that composes the same Application and Infrastructure layers as
the API and runs those bootstrappers. The seed data lives in `ProjectBootstrap`,
one section per aggregate (`RoleBootstrap`, `ManagerBootstrap`,
`CustomerBootstrap`, `ProductCategoryBootstrap`).

```bash
dotnet run --project src/Bootstrapper
```

Each seeded entity is reported on its own line as it is created or skipped, and
the SQL the store executes is filtered out of the logs, so a run prints just:

```text
[SKIPPED] Role "Manager" already exists.
[PASS]    Customer "Ana Ferreira" (ana.ferreira@laprizza.local) created.
[PASS]    Product category "Beverages" (beverages) created.
```

Anything missing is created and anything that already exists is left alone, so the
run is safe to repeat.

| Field | Value |
| ----- | ----- |
| Manager email / login | `manager@laprizza.local` |
| Manager password      | `Manager123!`          |
| Manager role          | `Manager`              |
| Manager job title     | `Manager`              |
| Customer emails / logins | `customer@laprizza.local`, `ana.ferreira@laprizza.local`, `miguel.santos@laprizza.local` |
| Customer password     | `Customer123!`         |
| Product category codes | `beverages`, `snacks`, `pizza-component` |
| Pizza component types allowed | `pizza-component` only |

Unlike the API, this run is not best-effort: if the store is unreachable or the
schema is missing it logs the error and exits with a non-zero code. **Change the
password before deploying.**

## 5. The API contract (OpenAPI + Swagger UI)

The OpenAPI contract is the **input** of the HTTP layer, not an artefact derived
from it. It is authored as small files grouped by role under
[`docs/api/contract`](../docs/api/contract) and bundled into
[`docs/api/openapi.json`](../docs/api/openapi.json), which drives code generation:
the controller bases and the request/response DTOs are generated from the bundle,
so the implemented endpoints cannot drift from the contract.

| What | Where |
| ---- | ----- |
| Contract (source of truth) | [`docs/api/contract/`](../docs/api/contract) — small files grouped by role |
| Bundled document | [`docs/api/openapi.json`](../docs/api/openapi.json) — generated, committed |
| Interactive UI   | `/swagger` (`Swagger UI`) |
| Served document  | `/swagger/v1/swagger.json` — the bundled file, copied next to the app |
| Generator config | `src/Api/nswag.json` |
| Bundler          | `backend/tools/OpenApiBundler/bundle.cs` |
| Generated code   | `src/Api/OpenApi/Generated/Contract.g.cs` (NSwag, committed) |

How it fits together:

- **The contract is split by role.** [`docs/api/contract/`](../docs/api/contract)
  groups small files by the part of the document they contribute: one file per
  resource under `paths/`, and one file per named component under
  `components/schemas/`, `components/parameters/`, `components/responses/` and
  `components/securitySchemes/`. `contract/openapi.json` is the root document: it
  holds the API metadata and lists the folders with `x-includes`.
- **Fragments are bundled before generation.** NSwag and Swagger UI need a single
  self-contained document, so the `BundleOpenApiContract` target runs the bundler
  (`dotnet run --file backend/tools/OpenApiBundler/bundle.cs`) and merges the
  fragments into `docs/api/openapi.json`. The bundle is committed but generated.
- **Contract-first generation.** `src/Api/Api.csproj` runs NSwag through
  `NSwag.MSBuild` before every compile. It reads the bundled `docs/api/openapi.json`
  and writes `OpenApi/Generated/Contract.g.cs`: one abstract controller base per
  tag (`HealthControllerBase`, `CustomersControllerBase`, `AuthControllerBase`,
  `AntiforgeryControllerBase`) carrying the routes, verbs and parameters, plus the
  DTOs (`CreateCustomerRequest`, `UpdateCustomerRequest`, `CustomerResponse`,
  `HealthResponse`, `LoginRequest`, ...). Both generated files are committed so the
  IDE can see them; the build rewrites them only when a fragment or `nswag.json`
  changes.
- **Controllers supply only behaviour.** `src/Api/Controllers/` derives from the
  generated bases: `HealthController` overrides `GetHealth`, and
  `CustomersController` overrides `SearchCustomers`, `CreateCustomer`,
  `GetCustomer`, `UpdateCustomer` and `DeactivateCustomer`. Routes, verbs,
  parameter binding and schema validation attributes all come from the contract.
- **The served document is the committed bundle.** `UseApiDocumentation()`
  (`src/Api/OpenApi/ApiDocumentation.cs`) serves `docs/api/openapi.json` verbatim,
  so Swagger UI and the other teams see exactly the contract the code came from.
- **Transport requirements are documented.** The `cookieAuth` security scheme
  describes the session cookie (`Api.Auth`) and unsafe verbs list the
  `X-CSRF-TOKEN` header; the global antiforgery filter and the fallback
  authorization policy enforce them.
- **Validation comes from the contract.** `required`, `minLength`, `maxLength` and
  `nullable` become DataAnnotations on the generated DTOs, so `[ApiController]`
  rejects invalid payloads before the use case runs.

Because the contract is the source, a change starts there:

1. Edit the use-case fragment under [`docs/api/contract/`](../docs/api/contract).
2. Build — the fragments are bundled into `docs/api/openapi.json` and NSwag
   regenerates `OpenApi/Generated/Contract.g.cs`.
3. Implement or adjust the controller that derives from the regenerated base.

`tests/Api.Tests/OpenApiDocumentTests.cs` boots the real application and asserts
that `/swagger/v1/swagger.json` is the committed bundle and that it describes the
endpoints, schemas, enums and security correctly.

## 6. Run the tests

```bash
cd backend
dotnet test
```

The suite covers all four layers and runs without PostgreSQL, MongoDB or a login:

| Test project                    | What it covers                                              |
| ------------------------------- | ----------------------------------------------------------- |
| `LaPrizza.Domain.Tests`         | Domain invariants and value objects (pure unit tests)        |
| `LaPrizza.Application.Tests`    | Use-case handlers against hand-written fakes for the ports   |
| `LaPrizza.Infrastructure.Tests` | EF Core model configuration and a round trip on the in-memory provider |
| `Api.Tests`                     | Endpoints end to end through the real HTTP pipeline (`WebApplicationFactory`) |

`Api.Tests` boots the real host but replaces the two DbContexts with in-memory
databases and swaps authentication/antiforgery for test doubles, so no database
or login is required. **Copy `tests/Api.Tests/Support/ApiTestFactory.cs` when you test
your own endpoints.**

These tests run in-process. For end-to-end coverage over real HTTP — real
cookies, antiforgery validation and persistence — there is also a
[Bruno collection](e2e/README.md) under `e2e/` that drives a running API:
`cd e2e && npm install && npm test` (see the [collection README](e2e/README.md)).

## 7. Format and lint

Formatting and linting are configured in `.editorconfig` and enforced with the
built-in .NET tooling — no external linter, no pre-commit hooks.

```bash
dotnet format                                 # apply the rules
dotnet format --verify-no-changes --severity warn   # fail if anything is off; use this as a gate
```

`EnforceCodeStyleInBuild` is enabled, so style violations also surface as build
warnings. Private fields follow the `_camelCase` convention.

Run all three checks before every commit:

```bash
dotnet build Api.sln && dotnet test Api.sln && dotnet format Api.sln --verify-no-changes --severity warn
```

---

## 8. Architecture and project layout

The backend follows **Clean Architecture**: dependencies point inward, and the
inner layers know nothing about the outer ones.

| Project                  | Layer / responsibility                                              | References |
| ------------------------ | ------------------------------------------------------------------- | ---------- |
| `LaPrizza.Domain`        | Entities, value objects, aggregates and invariants. No dependencies. | — |
| `LaPrizza.Application`   | Use cases and the outbound ports they need (interfaces only).        | Domain |
| `LaPrizza.Infrastructure`| Adapters: EF Core, ASP.NET Core Identity, MongoDB, Redis. Implements the ports. | Application, Domain |
| `Bootstrapper`           | The project bootstrap: one `IAggregateBootstrapper` per DDD aggregate. | Application, Domain |
| `Api`                    | HTTP host: controllers, contracts, composition root, OpenAPI.        | Application, Infrastructure |

Production projects live under `src/`; the matching `<project>.Tests` projects
live under `tests/`. See
[`docs/architecture/SAD.md`](../docs/architecture/SAD.md) and
[`docs/architecture/ADR/ADR-001.md`](../docs/architecture/ADR/ADR-001.md) for the
recorded decisions.

### Where things live

| Concern | Location |
| ------- | -------- |
| Domain model (`User`, `Customer`, `Staff`, `Role`, `Email`, `Permission`) | `src/LaPrizza.Domain/` |
| Customer use cases (`/api/v1/customers`) | `src/LaPrizza.Application/Customers/` |
| Staff user use case (bootstrap) | `src/LaPrizza.Application/Users/CreateUser/` |
| Repository interfaces (`IUserRepository`, `IRoleRepository`) | `src/LaPrizza.Domain/<Aggregate>/` |
| Other outbound ports (`IUserAccountManager`, `IUnitOfWork`, `IDistributedCacheService`, `IBaseRepository`) | `src/LaPrizza.Application/Abstractions/` |
| EF Core contexts and configurations, Identity, MongoDB, Redis, repositories | `src/LaPrizza.Infrastructure/` |
| Repository base classes | `src/LaPrizza.Infrastructure/Persistence/Repositories/BaseRepository.cs`, `BaseAutoSaveRepository.cs` |
| Controllers (behaviour over the generated bases) | `src/Api/Controllers/` |
| Contract → application mapping | `src/Api/Contracts/ContractMappings.cs` |
| OpenAPI contract (source of truth) | `docs/api/contract/` (bundled into `docs/api/openapi.json`) |
| Generator config and generated code | `src/Api/nswag.json`, `src/Api/OpenApi/Generated/` |
| Swagger UI wiring | `src/Api/OpenApi/ApiDocumentation.cs` |
| Composition root | `src/Api/Program.cs` (`AddApplication()`, `AddInfrastructure()`) |
| Project bootstrap (definition + per-aggregate bootstrappers) | `src/Bootstrapper/` |
| Runnable bootstrap entry point | `src/Bootstrapper/Program.cs` |
| End-to-end API tests (Bruno collection) | `e2e/` |

### Cross-cutting behaviour in the host

| Concern          | How it is wired                                                                   |
| ---------------- | --------------------------------------------------------------------------------- |
| Routing          | Routes come from the generated controllers, which come from the bundled `docs/api/openapi.json` |
| OpenAPI / Swagger| `UseApiDocumentation()` serves the committed contract and mounts Swagger UI, in every environment (see §5) |
| Error contract   | `problem+json` (RFC 9457). `GlobalExceptionHandler` maps domain/application exceptions: validation & domain → `400`, not found → `404`, conflict → `409` |
| Request logging  | One structured line per request: method, path, status, duration                   |
| CORS             | Explicit origin list from configuration, credentials allowed (needed for cookies) |
| Authentication   | ASP.NET Core Identity with a session cookie (`Api.Auth`); `POST /api/v1/auth/login`, `POST /api/v1/auth/logout`, `GET /api/v1/auth/me` |
| Authorization    | Endpoints require an authenticated user by default; opt out with `[AllowAnonymous]` |
| Antiforgery      | Token required on every unsafe request, read from the `X-CSRF-TOKEN` header       |
| JSON             | Enums accepted and returned **by name** (`JsonStringEnumConverter`)                |
| Relational store | `AppDbContext` (Identity) and `DomainDbContext` (domain) on EF Core + Npgsql       |
| Document store   | `IMongoClient` / `IMongoDatabase` registered from configuration                     |
| Project bootstrap| Run separately (`dotnet run --project src/Bootstrapper`) to seed the initial manager and sample customers (see §4) |



## Container deployment

Running the API together with its PostgreSQL, MongoDB and Redis containers
through Docker Compose is documented in the
[repository README](../README.md); the API image itself neither
migrates nor seeds on start-up (see §4).
