// Bundles the modular OpenAPI contract into the single document the rest of the
// toolchain consumes.
//
// The contract lives in docs/api/contract, split by role instead of by use case:
//
//   paths/                         one file per resource, keyed by URL
//   components/schemas/            one file per schema, named after the schema
//   components/parameters/         one file per reusable parameter
//   components/responses/          one file per reusable response
//   components/securitySchemes/    one file per security scheme
//
// The root document (openapi.json) holds the parts that describe the API as a
// whole (openapi, info, tags, servers...) and lists the folders to merge under
// "x-includes". The folder path is the destination: every file under paths/
// contributes its entries to the root "paths", and every file under a
// components/<collection>/ folder contributes one entry named after the file.
//
// NSwag and the API both need a single self-contained document, so this tool
// merges the folders into docs/api/openapi.json before the code is generated.
//
// Usage:
//   dotnet run bundle.cs -- <root-contract-file> <output-file>
//
// It is invoked by the BundleOpenApiContract target in src/Api/Api.csproj.

using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;

if (args.Length != 2)
{
    Console.Error.WriteLine("usage: bundle <root-contract-file> <output-file>");
    return 1;
}

var rootPath = Path.GetFullPath(args[0]);
var outputPath = Path.GetFullPath(args[1]);
var contractDirectory = Path.GetDirectoryName(rootPath)!;

var root = JsonNode.Parse(File.ReadAllText(rootPath)) as JsonObject
    ?? throw new InvalidOperationException($"'{rootPath}' must contain a JSON object.");

var includes = root["x-includes"] as JsonArray
    ?? throw new InvalidOperationException($"'{rootPath}' must declare an 'x-includes' array.");

// The fragments are merged on top of anything the root already defines, in the
// order they are listed, so the output is deterministic.
var paths = AsObject(root["paths"]);
var components = AsObject(root["components"]);
var fragmentCount = 0;

foreach (var entry in includes)
{
    var directory = entry?.GetValue<string>()
        ?? throw new InvalidOperationException("'x-includes' must contain folder names.");

    var fragmentDirectory = Path.GetFullPath(Path.Combine(contractDirectory, directory));

    if (!Directory.Exists(fragmentDirectory))
    {
        throw new InvalidOperationException($"'{directory}' is not a folder next to '{rootPath}'.");
    }

    // Sorted so the merged document does not depend on the file system order.
    var fragments = Directory.GetFiles(fragmentDirectory, "*.json", SearchOption.TopDirectoryOnly)
        .OrderBy(file => Path.GetFileName(file), StringComparer.Ordinal);

    foreach (var fragmentPath in fragments)
    {
        var fragment = JsonNode.Parse(File.ReadAllText(fragmentPath)) as JsonObject
            ?? throw new InvalidOperationException($"'{fragmentPath}' must contain a JSON object.");

        if (IsPathFolder(directory))
        {
            MergeUnique(paths, fragment, fragmentPath, "path");
        }
        else
        {
            // A component folder holds one component per file, named after it.
            var collection = CollectionName(directory, fragmentPath);
            var name = Path.GetFileNameWithoutExtension(fragmentPath);
            var target = AsObject(components[collection]);
            components[collection] = target;

            if (!target.TryAdd(name, fragment.DeepClone()))
            {
                throw new InvalidOperationException(
                    $"Duplicate {collection} '{name}' while merging '{fragmentPath}'.");
            }
        }

        fragmentCount++;
    }
}

// Rebuild the document in the conventional OpenAPI order instead of appending
// the merged sections at the end.
var bundle = new JsonObject();
foreach (var (key, value) in root)
{
    if (key is "x-includes" or "paths" or "components" or "tags")
    {
        continue;
    }

    bundle[key] = value?.DeepClone();
}

bundle["paths"] = paths;

if (components.Count > 0)
{
    bundle["components"] = components;
}

if (root["tags"] is JsonArray tags)
{
    bundle["tags"] = tags.DeepClone();
}

var json = bundle.ToJsonString(new JsonSerializerOptions
{
    WriteIndented = true,
    // Keep the document readable: the default encoder escapes characters such as
    // ' and ` that are common in the descriptions.
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
});

// Do not touch the file when nothing changed: keeping the timestamp stable is
// what lets the build skip the code generation step.
if (File.Exists(outputPath) && File.ReadAllText(outputPath) == json)
{
    Console.WriteLine($"{outputPath} is already up to date.");
    return 0;
}

File.WriteAllText(outputPath, json);
Console.WriteLine($"Bundled {fragmentCount} fragment(s) into {outputPath}.");

return 0;

static JsonObject AsObject(JsonNode? node) => node as JsonObject ?? new JsonObject();

static bool IsPathFolder(string directory) => Normalize(directory) is "paths";

static string CollectionName(string directory, string fragmentPath)
{
    var normalized = Normalize(directory);
    const string prefix = "components/";

    if (!normalized.StartsWith(prefix, StringComparison.Ordinal))
    {
        throw new InvalidOperationException(
            $"'{fragmentPath}' is included from '{directory}', which is neither 'paths' nor a folder under 'components/'.");
    }

    return normalized[prefix.Length..];
}

static string Normalize(string directory) => directory.Replace('\\', '/').Trim('/');

static void MergeUnique(JsonObject target, JsonObject source, string sourcePath, string kind)
{
    foreach (var (key, value) in source)
    {
        if (!target.TryAdd(key, value?.DeepClone()))
        {
            throw new InvalidOperationException(
                $"Duplicate {kind} '{key}' while merging '{sourcePath}'.");
        }
    }
}
