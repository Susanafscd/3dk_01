# LaPrizza E2E tests (Bruno)

End-to-end API tests for LaPrizza's authentication (BCK01), customer
management (BCK02), product-category management (BCK03), allergen
management (BCK04), stock information management (BCK09) and predefined pizza
management (BCK10). They are written as a [Bruno](https://www.usebruno.com/)
collection and executed with the Bruno CLI against a **running** API, over real
HTTP. They complement the in-memory unit and API tests under `backend/tests/`
by exercising the deployed contract: real cookies, real antiforgery validation
and real persistence.

## Prerequisites

1. **A database with the schema migrated and the bootstrap applied.** Neither
   the API nor its Docker image migrates or seeds on start-up, so apply the
   migrations and run the bootstrap once against the store the API uses
   (see [`../SETUP.md`](../SETUP.md) §3). The bootstrap creates the `Manager`
   role, the manager account below and three sample customers.
2. **A running API** pointed at that database:
   - Docker: `docker compose up -d` from the repository root (the API is exposed
     on `http://localhost:8080`), **or**
   - Local: `dotnet run --project src/Api` from `backend/`.
3. The seeded manager account, created by the bootstrap:
   `manager@laprizza.local` / `Manager123!`.

The default `baseUrl` is `http://localhost:8080`. Over plain HTTP this works
because the Development environment issues the session and antiforgery cookies
without the `Secure` attribute (see [`../README.md`](../README.md) and
[ADR-004](../../docs/architecture/ADR/ADR-004.md)).

## Running the tests

```bash
cd backend/e2e
npm install        # installs the Bruno CLI (declared in package.json)
npm test           # runs the whole collection against the Local environment
```

To also write a JUnit report (for CI):

```bash
npm run test:junit   # writes reports/junit.xml
```

Other useful ways to run:

```bash
# A single folder
npx bru run auth --env Local

# A single request
npx bru run customers/01-create-customer.bru --env Local

# Point at a different host without editing the environment
npx bru run --env Local --env-var baseUrl=https://localhost:7192
```

## Sprint verification coverage

The requests currently included in this collection cover the implemented API
subtasks below:

| Area | Verification subtask | Bruno folder |
| --- | --- | --- |
| Product categories | SCRUM-34 (UC-13.3), SCRUM-51 (UC-14.3), SCRUM-54 (UC-15.3) | `product-categories/` |
| Allergens | SCRUM-63 (UC-18.3), SCRUM-66 (UC-19.3), SCRUM-69 (UC-20.3), SCRUM-72 (UC-21.3) | `allergens/` |
| Products | SCRUM-78 (UC-23.3), SCRUM-81 (UC-24.3), SCRUM-84 (UC-25.3), SCRUM-87 (UC-26.3) | `Products/` |
| Product deactivation | SCRUM-88 (UC-27.1), SCRUM-89 (UC-27.2), SCRUM-90 (UC-27.3) | `Products/06-10-*` |
| Stock | SCRUM-163 (UC-39.3), SCRUM-166 (UC-40.3), SCRUM-169 (UC-41.3), SCRUM-172 (UC-42.3) | `stock/` |
| Predefined pizzas | SCRUM-208 (UC-43.3), SCRUM-211 (UC-44.3), SCRUM-214 (UC-45.3), SCRUM-217 (UC-46.3) | `predefined-pizzas/` |

Both product update and deactivation requests run after the category and
allergen folders and share the generated product business code.

You can also open `backend/e2e` in the Bruno desktop app (**Open Collection** →
select this folder) and run requests from the UI; pick the `Local` environment.

## Configuration

Environment variables live in `environments/Local.bru`:

| Variable           | Default                    | Purpose                                  |
| ------------------ | -------------------------- | ---------------------------------------- |
| `baseUrl`          | `http://localhost:8080`    | API base URL                             |
| `managerEmail`     | `manager@laprizza.local`   | Seeded manager email                     |
| `managerPassword`  | `Manager123!`              | Seeded manager password                  |
| `customerPassword` | `Customer123!`             | Password for customers created by the tests |

These are development defaults, not production secrets. Override any of them per
run with `--env-var <name>=<value>`, or add another file under `environments/`
for a different target.

## Why the flow fetches the antiforgery token twice

Every state-changing request must echo the antiforgery token in the
`X-CSRF-TOKEN` header. ASP.NET Core binds that token to the current user, so:

- **Before login** the caller is anonymous, and the token fetched in request 01
  is only valid for the two anonymous sign-in requests.
- **After login** the requests carry the `Api.Auth` session cookie, and the
  token no longer matches the authenticated user. Request 04 fetches a fresh
  token bound to the manager, which the customer requests use.

Sending the anonymous token to an authenticated request is what produces the
`400 The provided antiforgery token was meant for a different claims-based user`
error — this is the behaviour the collection is written around.

## Layout

```
backend/e2e/
├── bruno.json            # collection metadata
├── collection.bru        # collection-level docs and auth mode
├── environments/
│   └── Local.bru         # baseUrl and credentials
├── auth/                 # BCK01 - authentication (folder runs first)
│   ├── folder.bru
│   ├── 01-obtain-antiforgery-token.bru
│   ├── 02-reject-wrong-password.bru
│   ├── 03-login-as-manager.bru
│   └── 04-refresh-antiforgery-token.bru
└── customers/            # BCK02 - customer management
    ├── folder.bru
    ├── 01-create-customer.bru
    ├── 02-retrieve-created-customer.bru
    └── 03-reject-duplicate-email.bru
```

Requests run in the order above and share state through collection variables
(`anonymousCsrfToken`, `csrfToken`, `customerId`, ...) and Bruno's cookie jar.
`node_modules/` and `reports/` are ignored locally via `.gitignore`.

## Continuous integration

The collection is a single `npm` project, so it fits any pipeline:

```bash
cd backend/e2e
npm ci
npm run test:junit
```

Run it after the API is up and the manager is seeded (for example, against the
Compose stack). `reports/junit.xml` can be published with any JUnit-compatible
test reporter.
