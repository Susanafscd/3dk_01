using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeProductCategoryRepository : IProductCategoryRepository
{
    private readonly Dictionary<string, ProductCategory> _categories = new(StringComparer.Ordinal);

    public IReadOnlyCollection<ProductCategory> Categories => _categories.Values;

    public int AddCount { get; private set; }

    public int UpdateCount { get; private set; }

    public void Seed(params ProductCategory[] categories)
    {
        foreach (var category in categories)
        {
            _categories.Add(category.Code.Value, category);
        }
    }

    public ProductCategory? ExistingCategoryOnNextAdd { get; set; }

    public Task<ProductCategory?> GetByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _categories.TryGetValue(code.Value, out var category);
        return Task.FromResult(category);
    }

    public async Task AddAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        AddCount++;

        if (ExistingCategoryOnNextAdd is not null)
        {
            _categories.TryAdd(ExistingCategoryOnNextAdd.Code.Value, ExistingCategoryOnNextAdd);
            ExistingCategoryOnNextAdd = null;
            throw new DuplicateProductCategoryCodeException(category.Code);
        }

        if (!_categories.TryAdd(category.Code.Value, category))
        {
            throw new DuplicateProductCategoryCodeException(category.Code);
        }

        return;
    }

    public Task RemoveAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _categories.Remove(category.Code.Value);
        return Task.CompletedTask;
    }

    public Task UpdateAndSaveAsync(
        ProductCategory category,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        UpdateCount++;
        return Task.CompletedTask;
    }

    public Task<ProductCategoryLookupResult?> GetLookupByCodeAsync(
        ProductCategoryCode code,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (!_categories.TryGetValue(code.Value, out var category))
        {
            return Task.FromResult<ProductCategoryLookupResult?>(null);
        }

        return Task.FromResult<ProductCategoryLookupResult?>(new ProductCategoryLookupResult(
            category.Code.Value,
            category.Name,
            category.Description,
            category.AllowsComponentTypes));
    }
}
