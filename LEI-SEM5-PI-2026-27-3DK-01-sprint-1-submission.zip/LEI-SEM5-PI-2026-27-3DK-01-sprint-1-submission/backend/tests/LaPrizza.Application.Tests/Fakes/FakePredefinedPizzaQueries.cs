using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakePredefinedPizzaQueries : IPredefinedPizzaQueries
{
    private readonly Dictionary<string, PizzaComponentFacts> _components = new(StringComparer.Ordinal);

    public List<ComponentTypeLimit> TypeLimits { get; } = [];

    public PredefinedPizzaSearchPage SearchResult { get; set; } = new([], 0);

    public PredefinedPizzaSearchCriteria? LastSearch { get; private set; }

    public void Seed(params PizzaComponentFacts[] components)
    {
        foreach (var component in components)
        {
            _components[component.Code.Value] = component;
        }
    }

    public Task<IReadOnlyList<PizzaComponentFacts>> GetComponentsAsync(
        IReadOnlyCollection<ProductCode> codes,
        CancellationToken cancellationToken = default)
    {
        IReadOnlyList<PizzaComponentFacts> found = codes
            .Distinct()
            .Where(code => _components.ContainsKey(code.Value))
            .Select(code => _components[code.Value])
            .ToList();
        return Task.FromResult(found);
    }

    public Task<IReadOnlyList<ComponentTypeLimit>> GetComponentTypeLimitsAsync(
        CancellationToken cancellationToken = default) =>
        Task.FromResult<IReadOnlyList<ComponentTypeLimit>>(TypeLimits);

    public Task<PredefinedPizzaSearchPage> SearchAsync(
        PredefinedPizzaSearchCriteria criteria,
        CancellationToken cancellationToken = default)
    {
        LastSearch = criteria;
        return Task.FromResult(SearchResult);
    }
}
