using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakePizzaComponentTypeRepository : IPizzaComponentTypeRepository
{
    private readonly Dictionary<Guid, PizzaComponentType> _types = new();
    private readonly Dictionary<string, PizzaComponentType> _typesByCode = new(StringComparer.Ordinal);
    private readonly Dictionary<string, PizzaComponentType> _typesByName = new(StringComparer.Ordinal);
    private readonly Dictionary<int, PizzaComponentType> _typesByOrder = new();

    public IReadOnlyCollection<PizzaComponentType> Types => _types.Values;

    public int AddCount { get; private set; }
    public int UpdateCount { get; private set; }
    public int RemoveCount { get; private set; }

    public Exception? AddFailure { get; set; }
    public Exception? UpdateFailure { get; set; }
    public Exception? RemoveFailure { get; set; }
    public HashSet<Guid> InUseIds { get; } = new();

    public void Seed(params PizzaComponentType[] types)
    {
        foreach (var type in types)
        {
            _types[type.Id] = type;
            _typesByCode[type.Code.Value] = type;
            _typesByName[type.Name] = type;
            _typesByOrder[type.AssemblyOrder] = type;
        }
    }

    public Task<PizzaComponentType?> GetByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _typesByCode.TryGetValue(code.Value, out var type);
        return Task.FromResult(type);
    }

    public Task<PizzaComponentType> Add(PizzaComponentType type, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (AddFailure is not null)
        {
            throw AddFailure;
        }

        if (_typesByCode.ContainsKey(type.Code.Value))
        {
            throw new DuplicatePizzaComponentTypeCodeException(type.Code);
        }

        if (_typesByName.ContainsKey(type.Name))
        {
            throw new DuplicatePizzaComponentTypeNameException(type.Name);
        }

        if (_typesByOrder.ContainsKey(type.AssemblyOrder))
        {
            throw new DuplicatePizzaComponentTypeAssemblyOrderException(type.AssemblyOrder);
        }

        AddCount++;
        _types[type.Id] = type;
        _typesByCode[type.Code.Value] = type;
        _typesByName[type.Name] = type;
        _typesByOrder[type.AssemblyOrder] = type;
        return Task.FromResult(type);
    }

    public Task Update(PizzaComponentType type, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (UpdateFailure is not null)
        {
            throw UpdateFailure;
        }

        UpdateCount++;

        // Remove old entries if needed (simplified)
        _types[type.Id] = type;
        _typesByName[type.Name] = type;
        _typesByOrder[type.AssemblyOrder] = type;
        return Task.CompletedTask;
    }

    public Task Remove(PizzaComponentType type, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (RemoveFailure is not null)
        {
            throw RemoveFailure;
        }

        if (InUseIds.Contains(type.Id))
        {
            throw new PizzaComponentTypeInUseException(type.Code);
        }

        RemoveCount++;
        _types.Remove(type.Id);
        _typesByCode.Remove(type.Code.Value);
        _typesByName.Remove(type.Name);
        _typesByOrder.Remove(type.AssemblyOrder);
        return Task.CompletedTask;
    }

    public Task<bool> ExistsByCode(PizzaComponentTypeCode code, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(_typesByCode.ContainsKey(code.Value));
    }

    public Task<bool> ExistsByName(string name, Guid? excludeId = null, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(name))
        {
            return Task.FromResult(false);
        }

        var normalized = name.Trim();
        foreach (var kv in _typesByName)
        {
            if (!string.Equals(kv.Key, normalized, StringComparison.Ordinal))
                continue;
            if (excludeId.HasValue && kv.Value.Id == excludeId.Value)
                continue;
            return Task.FromResult(true);
        }
        return Task.FromResult(false);
    }

    public Task<bool> ExistsByAssemblyOrder(int assemblyOrder, Guid? excludeId = null, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (!_typesByOrder.TryGetValue(assemblyOrder, out var existing))
            return Task.FromResult(false);
        if (excludeId.HasValue && existing.Id == excludeId.Value)
            return Task.FromResult(false);
        return Task.FromResult(true);
    }

    public Task<bool> InUse(Guid id, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(InUseIds.Contains(id));
    }
}
