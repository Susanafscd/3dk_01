using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Products.GetProduct;

namespace LaPrizza.Application.Tests.Fakes;

/// <summary>
/// Per-instance, in-memory stand-in for the catalogue cache: misses call the
/// factory and store the value, so handler tests can assert cache-first
/// behavior by counting the factory invocations.
/// </summary>
internal sealed class FakeProductCatalogueCache : IProductCatalogueCache
{
    private readonly Dictionary<string, ProductLookupResult> _details = new(StringComparer.Ordinal);
    private readonly Dictionary<(int Page, int PageSize), CatalogueResult> _lists = [];
    private readonly Dictionary<Guid, CatalogueProductResult?> _byId = [];

    public int FactoryCalls { get; private set; }

    public async Task<ProductLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<ProductLookupResult>> factory,
        CancellationToken cancellationToken = default)
    {
        if (_details.TryGetValue(code, out var cached))
        {
            return cached;
        }

        FactoryCalls++;
        var created = await factory(cancellationToken);
        _details[code] = created;
        return created;
    }

    public async Task<CatalogueResult> GetListAsync(
        int page,
        int pageSize,
        Func<CancellationToken, Task<CatalogueResult>> factory,
        CancellationToken cancellationToken = default)
    {
        if (_lists.TryGetValue((page, pageSize), out var cached))
        {
            return cached;
        }

        FactoryCalls++;
        var created = await factory(cancellationToken);
        _lists[(page, pageSize)] = created;
        return created;
    }

    public async Task<CatalogueProductResult?> GetByIdAsync(
        Guid id,
        Func<CancellationToken, Task<CatalogueProductResult?>> factory,
        CancellationToken cancellationToken = default)
    {
        if (_byId.TryGetValue(id, out var cached))
        {
            return cached;
        }

        FactoryCalls++;
        var created = await factory(cancellationToken);
        _byId[id] = created;
        return created;
    }
}
