using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeProductRelationshipQueries : IProductRelationshipQueries
{
    private bool _categoryExists = true;
    private bool _categoryAllowsComponentTypes;
    private IReadOnlyCollection<AllergenCode> _unknownAllergens = [];

    public void SimulateInvalidReferences()
    {
        _categoryExists = false;
    }

    public void SimulateMissingCategory()
    {
        _categoryExists = false;
    }

    public void SimulateUnknownAllergens(params AllergenCode[] unknownAllergens)
    {
        _unknownAllergens = unknownAllergens;
    }

    public void AllowComponentTypes() => _categoryAllowsComponentTypes = true;

    public Task<ProductChangeContext> GetChangeContextAsync(
        ProductCategoryCode category,
        IReadOnlyCollection<AllergenCode> allergens,
        PizzaComponentTypeCode? componentTypeCode = null,
        CancellationToken cancellationToken = default)
    {
        var context = new ProductChangeContext(
            _categoryExists,
            _unknownAllergens,
            CategoryAllowsComponentTypes: _categoryAllowsComponentTypes,
            ComponentTypeRequested: componentTypeCode is not null,
            ComponentTypeExists: componentTypeCode is not null,
            ComponentTypeCategoryMatches: true);
        return Task.FromResult(context);
    }
}

