using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeProductUpdateQueries : IProductUpdateQueries
{
    public bool ReferencedByComposedProduct { get; set; }

    public Task<ProductUpdateFacts> GetFactsAsync(
        ProductCode productCode,
        CancellationToken cancellationToken = default) =>
        Task.FromResult(new ProductUpdateFacts(ReferencedByComposedProduct));
}
