using LaPrizza.Application.Abstractions;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeCatalogueCacheInvalidator : ICatalogueCacheInvalidator
{
    public int Invalidations { get; private set; }
    public Action? BeforeInvalidation { get; set; }

    public Task InvalidateAllergensAsync(CancellationToken cancellationToken = default)
    {
        BeforeInvalidation?.Invoke();
        Invalidations++;
        return Task.CompletedTask;
    }

    public Task InvalidateProductCategoriesAsync(CancellationToken cancellationToken = default)
    {
        Invalidations++;
        return Task.CompletedTask;
    }

    public Task InvalidateProductsAsync(CancellationToken cancellationToken = default)
    {
        BeforeInvalidation?.Invoke();
        Invalidations++;
        return Task.CompletedTask;
    }
}
