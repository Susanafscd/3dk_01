using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeAllergenRepository : IAllergenRepository
{
    private readonly Dictionary<string, Allergen> _allergens = new(StringComparer.Ordinal);

    public IReadOnlyCollection<Allergen> Allergens => _allergens.Values;
    public Exception? AddFailure { get; set; }

    public void Seed(params Allergen[] allergens)
    {
        foreach (var allergen in allergens)
        {
            _allergens.Add(allergen.Code.Value, allergen);
        }
    }

    public Task<Allergen?> GetByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _allergens.TryGetValue(code.Value, out var allergen);
        return Task.FromResult(allergen);
    }

    public Task AddAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (AddFailure is not null)
        {
            throw AddFailure;
        }

        if (!_allergens.TryAdd(allergen.Code.Value, allergen))
        {
            throw new DuplicateAllergenCodeException(allergen.Code);
        }

        return Task.CompletedTask;
    }

    public int UpdateCount { get; private set; }

    public Task UpdateAndSaveAsync(
        Allergen allergen,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (!_allergens.ContainsKey(allergen.Code.Value))
        {
            throw new InvalidOperationException("The allergen must be loaded before it is updated.");
        }

        UpdateCount++;
        return Task.CompletedTask;
    }

    public Task RemoveAsync(Allergen allergen, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _allergens.Remove(allergen.Code.Value);
        return Task.CompletedTask;
    }

    public Task<AllergenLookupResult?> GetLookupByCodeAsync(
        AllergenCode code,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        return Task.FromResult(
            _allergens.TryGetValue(code.Value, out var allergen)
                ? new AllergenLookupResult(
                    allergen.Code.Value,
                    allergen.Name,
                    allergen.Description)
                : null);
    }
}
