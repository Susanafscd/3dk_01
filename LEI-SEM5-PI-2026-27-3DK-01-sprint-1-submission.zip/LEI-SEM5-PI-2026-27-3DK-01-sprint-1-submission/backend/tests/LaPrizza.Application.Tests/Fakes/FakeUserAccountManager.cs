using LaPrizza.Application.Abstractions;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeUserAccountManager : IUserAccountManager
{
    public List<(string Email, string Password)> Created { get; } = [];

    public List<string> Deleted { get; } = [];

    public Exception? FailCreateWith { get; set; }

    public Task<string> CreateAccountAsync(
        string email,
        string password,
        CancellationToken cancellationToken = default)
    {
        if (FailCreateWith is not null)
        {
            throw FailCreateWith;
        }

        var accountId = $"account-{Created.Count + 1}";
        Created.Add((email, password));
        return Task.FromResult(accountId);
    }

    public Task DeleteAccountAsync(string accountId, CancellationToken cancellationToken = default)
    {
        Deleted.Add(accountId);
        return Task.CompletedTask;
    }

    public Task AssignRolesAsync(string accountId, IEnumerable<string> roleNames, CancellationToken cancellationToken = default) => Task.CompletedTask;
}
