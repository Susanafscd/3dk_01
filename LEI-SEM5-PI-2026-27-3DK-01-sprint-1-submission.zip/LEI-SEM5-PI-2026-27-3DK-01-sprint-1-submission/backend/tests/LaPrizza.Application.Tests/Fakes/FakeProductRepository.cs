using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeProductRepository : IProductRepository
{
    private readonly List<Domain.Product.Product> _products = [];

    public IReadOnlyCollection<Domain.Product.Product> Products => _products.AsReadOnly();

    public void Seed(params Domain.Product.Product[] products)
    {
        foreach (var product in products)
        {
            if (_products.Any(p => p.Code.Value == product.Code.Value))
            {
                throw new InvalidOperationException($"Product with code '{product.Code.Value}' already exists in seed data.");
            }
            _products.Add(product);
        }
    }

    public Task<Domain.Product.Product?> GetByCodeAsync(ProductCode code, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(code);
        var product = _products.FirstOrDefault(p => p.Code.Value == code.Value);
        return Task.FromResult(product);
    }

    public Task AddAndSaveAsync(Domain.Product.Product product, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(product);

        if (_products.Any(existing => existing.Code.Value == product.Code.Value))
        {
            throw new DuplicateProductCodeException(product.Code);
        }

        _products.Add(product);
        return Task.CompletedTask;
    }

    public Task SaveAsync(Domain.Product.Product product, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(product);
        return Task.CompletedTask;
    }

    public Task<Domain.Product.Product?> GetByCodeAsync(string code, CancellationToken cancellationToken = default)
    {
        Domain.Product.Product? match = null;

        try
        {
            var parsed = ProductCode.Create(code);
            match = _products.FirstOrDefault(p => p.Code.Value == parsed.Value);
        }
        catch (InvalidProductException)
        {
        }

        return Task.FromResult(match);
    }

    public void SeedExisting(string code) =>
        Seed(new BaseProductBuilder()
            .WithCode(code)
            .WithName(code)
            .WithDescription(code)
            .InCategory("pizza-component")
            .WithAllergens([])
            .Build());
}
