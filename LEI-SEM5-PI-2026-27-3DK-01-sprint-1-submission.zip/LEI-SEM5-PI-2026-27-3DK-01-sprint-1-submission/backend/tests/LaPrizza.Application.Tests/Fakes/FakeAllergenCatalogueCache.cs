using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeAllergenCatalogueCache : IAllergenCatalogueCache
{
    private readonly Dictionary<string, AllergenLookupResult> _entries = new(StringComparer.Ordinal);
    private readonly Dictionary<string, SearchAllergensResult> _searchEntries = new(StringComparer.Ordinal);

    public int FactoryCalls { get; private set; }

    public async Task<AllergenLookupResult> GetByCodeAsync(
        string code,
        Func<CancellationToken, Task<AllergenLookupResult>> factory,
        CancellationToken cancellationToken = default)
    {
        if (_entries.TryGetValue(code, out var cached))
        {
            return cached;
        }

        FactoryCalls++;
        var created = await factory(cancellationToken);
        _entries[code] = created;
        return created;
    }

    public async Task<SearchAllergensResult> SearchAsync(
        string cacheKey,
        Func<CancellationToken, Task<SearchAllergensResult>> factory,
        CancellationToken cancellationToken = default)
    {
        if (_searchEntries.TryGetValue(cacheKey, out var cached))
        {
            return cached;
        }

        FactoryCalls++;
        var created = await factory(cancellationToken);
        _searchEntries[cacheKey] = created;
        return created;
    }
}
