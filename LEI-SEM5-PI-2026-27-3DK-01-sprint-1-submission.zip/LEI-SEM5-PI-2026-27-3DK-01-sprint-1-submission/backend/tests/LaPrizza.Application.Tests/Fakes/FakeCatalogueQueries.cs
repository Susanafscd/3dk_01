using LaPrizza.Application.Catalogue;

namespace LaPrizza.Application.Tests.Fakes;

/// <summary>
/// In-memory stand-in for the catalogue query port (BCK11): serves a fixed set
/// of enriched entries in place of the database.
/// </summary>
internal sealed class FakeCatalogueQueries : ICatalogueQueries
{
    private readonly List<CatalogueProductResult> _entries;

    public FakeCatalogueQueries(params CatalogueProductResult[] entries)
    {
        _entries = [.. entries];
    }

    /// <summary>Simulates the database rejecting the detail load (external failure).</summary>
    public Exception? LoadByIdFailure { get; set; }

    public int LoadCalls { get; private set; }

    public Task<CatalogueResult> LoadAsync(int page, int pageSize, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        LoadCalls++;
        var items = _entries
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToList();
        return Task.FromResult(new CatalogueResult(items));
    }

    public Task<CatalogueProductResult?> LoadByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        LoadCalls++;

        if (LoadByIdFailure is not null)
        {
            throw LoadByIdFailure;
        }

        var entry = _entries.FirstOrDefault();
        return Task.FromResult(entry);
    }
}
