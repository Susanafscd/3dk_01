using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakePizzaSizeRepository : IPizzaSizeRepository
{
    private readonly Dictionary<Guid, PizzaSize> _sizes = new();
    private readonly Dictionary<string, PizzaSize> _sizesByName = new(StringComparer.Ordinal);

    public IReadOnlyCollection<PizzaSize> Sizes => _sizes.Values;

    public int AddCount { get; private set; }

    public int RemoveCount { get; private set; }

    public Exception? AddFailure { get; set; }
    public Exception? RemoveFailure { get; set; }
    public HashSet<Guid> InUseIds { get; } = new();

    public void Seed(params PizzaSize[] sizes)
    {
        foreach (var size in sizes)
        {
            _sizes[size.Id] = size;
            _sizesByName[size.Name] = size;
        }
    }

    public Task<PizzaSize?> Get(Guid id, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _sizes.TryGetValue(id, out var size);
        return Task.FromResult(size);
    }

    public Task<PizzaSize> Add(PizzaSize size, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (AddFailure is not null)
        {
            throw AddFailure;
        }

        AddCount++;
        if (!_sizesByName.TryAdd(size.Name, size))
        {
            throw new DuplicatePizzaSizeNameException(size.Name);
        }

        _sizes[size.Id] = size;
        _sizesByName[size.Name] = size;
        return Task.FromResult(size);
    }

    public Task<bool> InUse(Guid id, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(InUseIds.Contains(id));
    }

    public Task Remove(PizzaSize size, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (RemoveFailure is not null)
        {
            throw RemoveFailure;
        }

        RemoveCount++;
        _sizes.Remove(size.Id);
        _sizesByName.Remove(size.Name);
        return Task.CompletedTask;
    }

    public Task<bool> ExistsByName(string name, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(_sizesByName.ContainsKey(name));
    }
}
