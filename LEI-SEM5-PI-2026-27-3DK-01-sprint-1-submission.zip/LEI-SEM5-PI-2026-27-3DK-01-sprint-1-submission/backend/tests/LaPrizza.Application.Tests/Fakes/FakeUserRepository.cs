using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Fakes;

internal sealed class FakeUserRepository(IUnitOfWork? unitOfWork = null) : IUserRepository
{
    private readonly List<Email> _existingEmails = [];
    private readonly IUnitOfWork? _unitOfWork = unitOfWork;

    public List<User> Added { get; } = [];

    public void SeedExisting(Email email) => _existingEmails.Add(email);

    public void Seed(User user) => Added.Add(user);

    public Task<bool> ExistsByEmailAsync(Email email, CancellationToken cancellationToken = default) =>
        Task.FromResult(_existingEmails.Contains(email) || Added.Any(user => user.Email == email));

    public Task<User?> GetByEmailAsync(Email email, CancellationToken cancellationToken = default) =>
        Task.FromResult(Added.FirstOrDefault(user => user.Email == email));

    public Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default) =>
        Task.FromResult(Added.FirstOrDefault(user => user.Id == id));

    public Task<IReadOnlyList<Customer>> SearchCustomersAsync(
        string? search,
        CancellationToken cancellationToken = default)
    {
        IEnumerable<Customer> customers = Added.OfType<Customer>();
        var term = search?.Trim();

        if (!string.IsNullOrEmpty(term))
        {
            var lowered = term.ToLowerInvariant();

            customers = customers.Where(customer =>
                customer.Name.ToLowerInvariant().Contains(lowered)
                || customer.PhoneNumber.Value.ToLowerInvariant().Contains(lowered)
                || customer.Email.Value.Contains(lowered));
        }

        return Task.FromResult<IReadOnlyList<Customer>>([.. customers.OrderBy(customer => customer.Name)]);
    }

    public async Task AddAsync(User user, CancellationToken cancellationToken = default)
    {
        Added.Add(user);
        if (_unitOfWork is not null)
        {
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
    }

    public async Task UpdateAsync(User user, CancellationToken cancellationToken = default)
    {
        var index = Added.FindIndex(u => u.Id == user.Id);
        if (index >= 0)
        {
            Added[index] = user;
        }
        else
        {
            Added.Add(user);
        }

        if (_unitOfWork is not null)
        {
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
    }

    public async Task RemoveAsync(User user, CancellationToken cancellationToken = default)
    {
        var index = Added.FindIndex(u => u.Id == user.Id);
        if (index >= 0)
        {
            Added.RemoveAt(index);
        }

        if (_unitOfWork is not null)
        {
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
    }

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        _unitOfWork?.SaveChangesAsync(cancellationToken) ?? Task.FromResult(0);
}
