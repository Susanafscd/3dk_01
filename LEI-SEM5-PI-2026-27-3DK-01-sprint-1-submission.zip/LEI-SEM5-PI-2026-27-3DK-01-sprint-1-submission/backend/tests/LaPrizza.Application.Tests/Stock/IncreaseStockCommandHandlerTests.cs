using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Stock;
using LaPrizza.Application.Stock.IncreaseStock;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Stock;

[TestFixture]
public sealed class IncreaseStockCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private StubStockRepository _stock = null!;
    private IncreaseStockCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _stock = new StubStockRepository();
        _handler = new IncreaseStockCommandHandler(_products, _stock);
    }

    [Test]
    public async Task HandleAsync_persists_the_increase_and_returns_the_balance_stored_in_the_database()
    {
        var mozzarella = Product("mozzarella", "Mozzarella", stockControlled: true);
        _products.Seed(mozzarella);
        _stock.Result = 42;

        var result = await _handler.HandleAsync(new IncreaseStockCommand("mozzarella", 5));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.EqualTo(new ProductStockResult("mozzarella", "Mozzarella", true, 42)));
            Assert.That(_stock.Calls, Is.EqualTo(new[] { (mozzarella.Id, 5) }));
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_business_code()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("unknown", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_a_malformed_business_code()
    {
        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("Mozzarella", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [TestCase(0)]
    [TestCase(-3)]
    public void HandleAsync_rejects_units_that_are_not_positive(int units)
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true));

        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("mozzarella", units)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_a_product_without_stock_control_as_a_conflict()
    {
        _products.Seed(Product("napkin", "Napkin", stockControlled: false));

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("napkin", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_an_increase_above_the_upper_limit_as_a_conflict()
    {
        var full = Product("mozzarella", "Mozzarella", stockControlled: true);
        full.IncreaseStock(int.MaxValue);
        _products.Seed(full);

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("mozzarella", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_reports_a_conflict_when_the_store_applied_nothing()
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true));
        _stock.Result = null;

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new IncreaseStockCommand("mozzarella", 1)));
    }

    [Test]
    public void HandleAsync_rejects_a_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }

    private static BaseProduct Product(string code, string name, bool stockControlled) =>
        new BaseProductBuilder().WithCode(code).WithName(name).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).WithAllergens([]).Build();

    /// <summary>Records the stock changes and answers with a configured stored balance.</summary>
    private sealed class StubStockRepository : IStockRepository
    {
        public int? Result { get; set; }

        public List<(Guid ProductId, int Units)> Calls { get; } = [];

        public Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default)
        {
            Calls.Add((productId, units));
            return Task.FromResult(Result);
        }

        public Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default) =>
            throw new NotSupportedException("The increase use case never decreases the stock.");
    }
}
