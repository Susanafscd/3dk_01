using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Stock.SearchStock;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Stock;

[TestFixture]
public sealed class SearchStockQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_forwards_the_filters_and_returns_the_page_with_its_metadata()
    {
        var item = new StockSearchItem("mozzarella", "Mozzarella", "cheese", true, 12);
        var queries = new StubQueries(new StockSearchPage([item], 21));
        var handler = new SearchStockQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchStockQuery("mozza", "cheese", false, 2, 10));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.EqualTo(new[] { item }));
            Assert.That(result.Page, Is.EqualTo(2));
            Assert.That(result.PageSize, Is.EqualTo(10));
            Assert.That(result.TotalCount, Is.EqualTo(21));
            Assert.That(queries.Criteria.Search, Is.EqualTo("mozza"));
            Assert.That(queries.Criteria.CategoryCode!.Value, Is.EqualTo("cheese"));
            Assert.That(queries.Criteria.Active, Is.False);
            Assert.That(queries.Criteria.Page, Is.EqualTo(2));
            Assert.That(queries.Criteria.PageSize, Is.EqualTo(10));
        });
    }

    [Test]
    public async Task HandleAsync_uses_the_defaults_and_no_category_when_none_is_given()
    {
        var queries = new StubQueries(new StockSearchPage([], 0));
        var handler = new SearchStockQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchStockQuery(CategoryCode: " "));

        Assert.Multiple(() =>
        {
            Assert.That(queries.Criteria.CategoryCode, Is.Null);
            Assert.That(queries.Criteria.Active, Is.Null);
            Assert.That(result.Page, Is.EqualTo(1));
            Assert.That(result.PageSize, Is.EqualTo(20));
        });
    }

    [TestCase(0, 20)]
    [TestCase(1, 0)]
    [TestCase(1, 101)]
    public void HandleAsync_rejects_invalid_paging(int page, int pageSize)
    {
        var handler = new SearchStockQueryHandler(new StubQueries(new StockSearchPage([], 0)));

        Assert.ThrowsAsync<ValidationException>(() => handler.HandleAsync(
            new SearchStockQuery(Page: page, PageSize: pageSize)));
    }

    [Test]
    public void HandleAsync_rejects_a_malformed_category_code()
    {
        var handler = new SearchStockQueryHandler(new StubQueries(new StockSearchPage([], 0)));

        Assert.ThrowsAsync<DomainException>(() => handler.HandleAsync(
            new SearchStockQuery(CategoryCode: "Not A Code")));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        var handler = new SearchStockQueryHandler(new StubQueries(new StockSearchPage([], 0)));

        Assert.ThrowsAsync<ArgumentNullException>(() => handler.HandleAsync(null!));
    }

    private sealed class StubQueries(StockSearchPage page) : IStockQueries
    {
        public StockSearchCriteria Criteria { get; private set; } = null!;

        public Task<StockSearchPage> SearchAsync(
            StockSearchCriteria criteria,
            CancellationToken cancellationToken = default)
        {
            Criteria = criteria;
            return Task.FromResult(page);
        }
    }
}
