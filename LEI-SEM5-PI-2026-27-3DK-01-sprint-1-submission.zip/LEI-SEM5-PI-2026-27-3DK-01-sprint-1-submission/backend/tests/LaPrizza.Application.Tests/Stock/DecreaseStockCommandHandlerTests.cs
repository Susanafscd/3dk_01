using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Stock;
using LaPrizza.Application.Stock.DecreaseStock;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Stock;

[TestFixture]
public sealed class DecreaseStockCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private StubStockRepository _stock = null!;
    private DecreaseStockCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _stock = new StubStockRepository();
        _handler = new DecreaseStockCommandHandler(_products, _stock);
    }

    [Test]
    public async Task HandleAsync_persists_the_decrease_and_returns_the_balance_stored_in_the_database()
    {
        var mozzarella = Product("mozzarella", "Mozzarella", stockControlled: true, balance: 10);
        _products.Seed(mozzarella);
        _stock.Result = 1;

        var result = await _handler.HandleAsync(new DecreaseStockCommand("mozzarella", 4));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.EqualTo(new ProductStockResult("mozzarella", "Mozzarella", true, 1)));
            Assert.That(_stock.Calls, Is.EqualTo(new[] { (mozzarella.Id, 4) }));
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_business_code()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("unknown", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_a_malformed_business_code()
    {
        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("Mozzarella", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [TestCase(0)]
    [TestCase(-3)]
    public void HandleAsync_rejects_units_that_are_not_positive(int units)
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true, balance: 10));

        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("mozzarella", units)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_a_product_without_stock_control_as_a_conflict()
    {
        _products.Seed(Product("napkin", "Napkin", stockControlled: false, balance: 0));

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("napkin", 1)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_more_units_than_the_stock_as_a_conflict()
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true, balance: 3));

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("mozzarella", 4)));
        Assert.That(_stock.Calls, Is.Empty);
    }

    [Test]
    public void HandleAsync_reports_a_conflict_when_a_concurrent_change_consumed_the_stock()
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true, balance: 10));
        _stock.Result = null;

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new DecreaseStockCommand("mozzarella", 4)));
    }

    [Test]
    public void HandleAsync_rejects_a_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }

    private static BaseProduct Product(string code, string name, bool stockControlled, int balance)
    {
        var product = new BaseProductBuilder().WithCode(code).WithName(name).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).WithAllergens([]).Build();
        if (stockControlled && balance > 0)
        {
            product.IncreaseStock(balance);
        }

        return product;
    }

    /// <summary>Records the stock changes and answers with a configured stored balance.</summary>
    private sealed class StubStockRepository : IStockRepository
    {
        public int? Result { get; set; }

        public List<(Guid ProductId, int Units)> Calls { get; } = [];

        public Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default) =>
            throw new NotSupportedException("The decrease use case never increases the stock.");

        public Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default)
        {
            Calls.Add((productId, units));
            return Task.FromResult(Result);
        }
    }
}
