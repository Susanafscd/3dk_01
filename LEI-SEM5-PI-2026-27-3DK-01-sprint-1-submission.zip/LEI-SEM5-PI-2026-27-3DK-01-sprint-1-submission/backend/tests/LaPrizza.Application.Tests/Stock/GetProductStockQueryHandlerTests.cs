using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Stock.GetProductStock;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Stock;

[TestFixture]
public sealed class GetProductStockQueryHandlerTests
{
    private FakeProductRepository _products = null!;
    private GetProductStockQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _handler = new GetProductStockQueryHandler(_products);
    }

    [Test]
    public async Task HandleAsync_returns_the_stock_of_a_stock_controlled_product()
    {
        _products.Seed(Product("mozzarella", "Mozzarella", stockControlled: true));

        var result = await _handler.HandleAsync(new GetProductStockQuery("mozzarella"));

        Assert.Multiple(() =>
        {
            Assert.That(result.ProductCode, Is.EqualTo("mozzarella"));
            Assert.That(result.ProductName, Is.EqualTo("Mozzarella"));
            Assert.That(result.Active, Is.True);
            Assert.That(result.QuantityInStock, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_business_code()
    {
        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new GetProductStockQuery("unknown")));

        Assert.That(exception!.Message, Does.Contain("unknown"));
    }

    [Test]
    public void HandleAsync_rejects_a_product_without_stock_control()
    {
        _products.Seed(Product("napkin", "Napkin", stockControlled: false));

        var exception = Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new GetProductStockQuery("napkin")));

        Assert.That(exception!.Message, Does.Contain("napkin"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Mozzarella")]
    [TestCase("mozza_rella")]
    [TestCase("mozza--rella")]
    [TestCase("-mozzarella")]
    public void HandleAsync_rejects_a_malformed_business_code(string? code)
    {
        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(new GetProductStockQuery(code)));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }

    private static BaseProduct Product(string code, string name, bool stockControlled) =>
        new BaseProductBuilder().WithCode(code).WithName(name).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).WithAllergens([]).Build();
}
