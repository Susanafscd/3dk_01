using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;

namespace LaPrizza.Application.Tests.Allergens;

[TestFixture]
public sealed class SearchAllergensQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_forwards_search_and_paging_and_returns_metadata()
    {
        var item = new AllergenSearchItem("milk", "Milk", "Contains milk.");
        var queries = new StubQueries(new AllergenSearchPage([item], 7));
        var handler = new SearchAllergensQueryHandler(queries, new FakeAllergenCatalogueCache());

        var result = await handler.HandleAsync(new SearchAllergensQuery("MIL", 2, 10));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.EqualTo(new[] { item }));
            Assert.That(result.Page, Is.EqualTo(2));
            Assert.That(result.PageSize, Is.EqualTo(10));
            Assert.That(result.TotalCount, Is.EqualTo(7));
            Assert.That(queries.Criteria.Search, Is.EqualTo("MIL"));
            Assert.That(queries.Criteria.Page, Is.EqualTo(2));
            Assert.That(queries.Criteria.PageSize, Is.EqualTo(10));
        });
    }

    [TestCase(0, 20)]
    [TestCase(-1, 20)]
    [TestCase(1, 0)]
    [TestCase(1, 101)]
    public void HandleAsync_rejects_invalid_paging(int page, int pageSize)
    {
        var handler = new SearchAllergensQueryHandler(
            new StubQueries(new AllergenSearchPage([], 0)),
            new FakeAllergenCatalogueCache());

        Assert.ThrowsAsync<ValidationException>(() => handler.HandleAsync(
            new SearchAllergensQuery(null, page, pageSize)));
    }

    [Test]
    public async Task HandleAsync_reuses_cache_for_equivalent_searches()
    {
        var queries = new StubQueries(new AllergenSearchPage([], 0));
        var cache = new FakeAllergenCatalogueCache();
        var handler = new SearchAllergensQueryHandler(queries, cache);

        await handler.HandleAsync(new SearchAllergensQuery(" Milk ", 1, 20));
        await handler.HandleAsync(new SearchAllergensQuery("milk", 1, 20));

        Assert.That(queries.Calls, Is.EqualTo(1));
    }

    private sealed class StubQueries(AllergenSearchPage page) : IAllergenQueries
    {
        public AllergenSearchCriteria Criteria { get; private set; } = null!;
        public int Calls { get; private set; }

        public Task<AllergenSearchPage> SearchAsync(
            AllergenSearchCriteria criteria,
            CancellationToken cancellationToken = default)
        {
            Calls++;
            Criteria = criteria;
            return Task.FromResult(page);
        }
    }
}
