using LaPrizza.Application.Allergens.RemoveAllergen;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using Moq;

namespace LaPrizza.Application.Tests.Allergens;

[TestFixture]
public sealed class RemoveAllergenCommandHandlerTests
{
    private FakeAllergenRepository _allergens = null!;
    private Mock<IAllergenUsageQueries> _usage = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private RemoveAllergenCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _allergens = new FakeAllergenRepository();
        _usage = new Mock<IAllergenUsageQueries>();
        _usage.Setup(query => query.GetUsageAsync(It.IsAny<AllergenCode>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AllergenUsageFacts(false, false, false));
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new RemoveAllergenCommandHandler(_allergens, _usage.Object, _cache);
    }

    [Test]
    public async Task ExecuteAsync_removes_an_unused_allergen_and_invalidates_afterwards()
    {
        _allergens.Seed(Allergen.Create("unused", "Unused", null));

        await _handler.ExecuteAsync(new RemoveAllergenCommand("unused"));

        Assert.Multiple(() =>
        {
            Assert.That(_allergens.Allergens, Is.Empty);
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void ExecuteAsync_rejects_a_referenced_allergen_without_mutating_or_invalidating()
    {
        var allergen = Allergen.Create("milk", "Milk", null);
        _allergens.Seed(allergen);
        _usage.Setup(query => query.GetUsageAsync(allergen.Code, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AllergenUsageFacts(true, false, false));

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.ExecuteAsync(new RemoveAllergenCommand("milk")));

        Assert.Multiple(() =>
        {
            Assert.That(_allergens.Allergens, Has.Count.EqualTo(1));
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void ExecuteAsync_returns_not_found_for_an_unknown_business_code()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.ExecuteAsync(new RemoveAllergenCommand("unknown")));
        Assert.That(_cache.Invalidations, Is.Zero);
    }
}
