using LaPrizza.Application.Allergens.CreateAllergen;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;

namespace LaPrizza.Application.Tests.Allergens;

[TestFixture]
public sealed class CreateAllergenCommandHandlerTests
{
    [Test]
    public async Task Invalidates_only_after_the_allergen_is_committed()
    {
        var repository = new FakeAllergenRepository();
        var cache = new FakeCatalogueCacheInvalidator
        {
            BeforeInvalidation = () => Assert.That(repository.Allergens.Single().Code.Value, Is.EqualTo("milk")),
        };
        var result = await new CreateAllergenCommandHandler(repository, cache)
            .HandleAsync(new("milk", " Milk ", " Dairy "));
        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Milk"));
            Assert.That(result.Description, Is.EqualTo("Dairy"));
            Assert.That(cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void Invalid_input_does_not_write_or_invalidate()
    {
        var repository = new FakeAllergenRepository();
        var cache = new FakeCatalogueCacheInvalidator();
        Assert.ThrowsAsync<DomainException>(() => new CreateAllergenCommandHandler(repository, cache)
            .HandleAsync(new("Milk", "Milk", null)));
        Assert.Multiple(() =>
        {
            Assert.That(repository.Allergens, Is.Empty);
            Assert.That(cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void Existing_code_is_not_replaced_and_does_not_invalidate()
    {
        var repository = new FakeAllergenRepository();
        repository.Seed(Allergen.Create("milk", "Original", null));
        var cache = new FakeCatalogueCacheInvalidator();
        Assert.ThrowsAsync<ConflictException>(() => new CreateAllergenCommandHandler(repository, cache)
            .HandleAsync(new("milk", "Replacement", null)));
        Assert.Multiple(() =>
        {
            Assert.That(repository.Allergens.Single().Name, Is.EqualTo("Original"));
            Assert.That(cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void Concurrent_duplicate_does_not_invalidate()
    {
        var repository = new FakeAllergenRepository
        {
            AddFailure = new DuplicateAllergenCodeException(AllergenCode.Create("milk")),
        };
        var cache = new FakeCatalogueCacheInvalidator();
        Assert.ThrowsAsync<ConflictException>(() => new CreateAllergenCommandHandler(repository, cache)
            .HandleAsync(new("milk", "Milk", null)));
        Assert.That(cache.Invalidations, Is.Zero);
    }

    [Test]
    public void Persistence_failure_does_not_invalidate()
    {
        var repository = new FakeAllergenRepository { AddFailure = new InvalidOperationException("Database unavailable") };
        var cache = new FakeCatalogueCacheInvalidator();
        Assert.ThrowsAsync<InvalidOperationException>(() => new CreateAllergenCommandHandler(repository, cache)
            .HandleAsync(new("milk", "Milk", null)));
        Assert.Multiple(() =>
        {
            Assert.That(repository.Allergens, Is.Empty);
            Assert.That(cache.Invalidations, Is.Zero);
        });
    }
}
