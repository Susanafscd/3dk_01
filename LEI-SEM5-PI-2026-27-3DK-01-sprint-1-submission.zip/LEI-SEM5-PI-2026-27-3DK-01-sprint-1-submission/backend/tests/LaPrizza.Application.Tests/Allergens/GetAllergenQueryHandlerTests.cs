using LaPrizza.Application.Allergens.GetAllergen;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;

namespace LaPrizza.Application.Tests.Allergens;

[TestFixture]
public sealed class GetAllergenQueryHandlerTests
{
    private FakeAllergenRepository _allergens = null!;
    private FakeAllergenCatalogueCache _cache = null!;
    private GetAllergenQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _allergens = new FakeAllergenRepository();
        _cache = new FakeAllergenCatalogueCache();
        _handler = new GetAllergenQueryHandler(_allergens, _cache);
    }

    [Test]
    public async Task HandleAsync_returns_all_public_fields_for_the_requested_code()
    {
        _allergens.Seed(
            Allergen.Create("milk", "Milk", "Milk and milk products."),
            Allergen.Create("tree-nuts", "Tree nuts", "Nuts from trees."));

        var result = await _handler.HandleAsync(new GetAllergenQuery("tree-nuts"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("tree-nuts"));
            Assert.That(result.Name, Is.EqualTo("Tree nuts"));
            Assert.That(result.Description, Is.EqualTo("Nuts from trees."));
        });
    }

    [Test]
    public async Task HandleAsync_preserves_a_null_description()
    {
        _allergens.Seed(Allergen.Create("milk", "Milk", null));

        var result = await _handler.HandleAsync(new GetAllergenQuery("milk"));

        Assert.That(result.Description, Is.Null);
    }

    [Test]
    public async Task HandleAsync_reuses_the_cached_projection()
    {
        _allergens.Seed(Allergen.Create("milk", "Milk", null));

        var first = await _handler.HandleAsync(new GetAllergenQuery("milk"));
        var second = await _handler.HandleAsync(new GetAllergenQuery("milk"));

        Assert.Multiple(() =>
        {
            Assert.That(second, Is.EqualTo(first));
            Assert.That(_cache.FactoryCalls, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_business_code()
    {
        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new GetAllergenQuery("unknown")));

        Assert.That(exception!.Message, Does.Contain("unknown"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Tree-Nuts")]
    [TestCase("tree_nuts")]
    [TestCase("tree--nuts")]
    [TestCase("-tree-nuts")]
    [TestCase("tree-nuts-")]
    public void HandleAsync_rejects_a_malformed_business_code(string? code)
    {
        Assert.ThrowsAsync<DomainException>(() =>
            _handler.HandleAsync(new GetAllergenQuery(code)));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
