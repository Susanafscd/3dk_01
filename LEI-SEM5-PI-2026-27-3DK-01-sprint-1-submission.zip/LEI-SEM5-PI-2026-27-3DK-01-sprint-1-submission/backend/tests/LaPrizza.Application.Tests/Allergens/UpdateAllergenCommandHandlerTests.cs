using LaPrizza.Application.Allergens.UpdateAllergen;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;

namespace LaPrizza.Application.Tests.Allergens;

[TestFixture]
public sealed class UpdateAllergenCommandHandlerTests
{
    private FakeAllergenRepository _allergens = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private UpdateAllergenCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _allergens = new FakeAllergenRepository();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new UpdateAllergenCommandHandler(_allergens, _cache);
    }

    [Test]
    public async Task HandleAsync_replaces_descriptive_fields_and_preserves_identity()
    {
        var allergen = Allergen.Create("milk", "Milk", "Milk products.");
        var identity = allergen.Id;
        _allergens.Seed(allergen);

        var result = await _handler.HandleAsync(
            new UpdateAllergenCommand("milk", "  Dairy  ", "  Includes milk.  "));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.EqualTo(identity));
            Assert.That(result.Code, Is.EqualTo("milk"));
            Assert.That(result.Name, Is.EqualTo("Dairy"));
            Assert.That(result.Description, Is.EqualTo("Includes milk."));
            Assert.That(allergen.Id, Is.EqualTo(identity));
            Assert.That(allergen.Code.Value, Is.EqualTo("milk"));
            Assert.That(_allergens.UpdateCount, Is.EqualTo(1));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task HandleAsync_allows_clearing_the_optional_description()
    {
        var allergen = Allergen.Create("milk", "Milk", "Milk products.");
        _allergens.Seed(allergen);

        var result = await _handler.HandleAsync(
            new UpdateAllergenCommand("milk", "Milk", null));

        Assert.Multiple(() =>
        {
            Assert.That(result.Description, Is.Null);
            Assert.That(allergen.Description, Is.Null);
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_code_without_persisting()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(
            new UpdateAllergenCommand("unknown", "Unknown", null)));

        Assert.That(_allergens.UpdateCount, Is.Zero);
        Assert.That(_cache.Invalidations, Is.Zero);
    }

    [Test]
    public void HandleAsync_rejects_invalid_details_without_persisting()
    {
        var allergen = Allergen.Create("milk", "Milk", "Milk products.");
        _allergens.Seed(allergen);

        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(
            new UpdateAllergenCommand("milk", " ", null)));

        Assert.Multiple(() =>
        {
            Assert.That(allergen.Name, Is.EqualTo("Milk"));
            Assert.That(allergen.Description, Is.EqualTo("Milk products."));
            Assert.That(_allergens.UpdateCount, Is.Zero);
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public async Task HandleAsync_invalidates_only_after_the_update_is_persisted()
    {
        var allergen = Allergen.Create("milk", "Milk", null);
        _allergens.Seed(allergen);
        _cache.BeforeInvalidation = () =>
        {
            Assert.That(_allergens.UpdateCount, Is.EqualTo(1));
        };

        await _handler.HandleAsync(new UpdateAllergenCommand("milk", "Dairy", null));

        Assert.That(_cache.Invalidations, Is.EqualTo(1));
    }
}
