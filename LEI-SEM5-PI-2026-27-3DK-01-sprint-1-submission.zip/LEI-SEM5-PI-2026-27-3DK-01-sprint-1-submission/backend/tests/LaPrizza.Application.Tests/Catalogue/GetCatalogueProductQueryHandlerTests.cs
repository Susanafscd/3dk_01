using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Catalogue.GetCatalogueProduct;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;

namespace LaPrizza.Application.Tests.Catalogue;

[TestFixture]
public sealed class GetCatalogueProductQueryHandlerTests
{
    private static CatalogueProductResult Entry(string productCode, string name) => new(
        productCode,
        name,
        null,
        null,
        9.50m,
        [],
        [],
        null);

    [Test]
    public async Task HandleAsync_returns_the_details_of_a_sellable_product()
    {
        var id = Guid.NewGuid();
        var queries = new FakeCatalogueQueries(
            Entry("PIZZA-MARGHERITA", "Margherita"),
            Entry("DRINK-WATER", "Not priced by size"));

        var result = await new GetCatalogueProductQueryHandler(queries).HandleAsync(new GetCatalogueProductQuery(id));

        Assert.Multiple(() =>
        {
            Assert.That(result.ProductCode, Is.EqualTo("PIZZA-MARGHERITA"));
            Assert.That(result.Name, Is.EqualTo("Margherita"));
            Assert.That(result.Category, Is.Null);
            Assert.That(result.UnitPrice, Is.EqualTo(9.50m));
            Assert.That(result.Sizes, Is.Empty);
            Assert.That(result.Allergens, Is.Empty);
            Assert.That(result.Configuration, Is.Null);
        });
    }

    [Test]
    public async Task HandleAsync_returns_a_product_priced_by_size_without_a_unit_price()
    {
        var id = Guid.NewGuid();
        var size = new CatalogueSizeResult("Medium", 8.50m);
        var entry = new CatalogueProductResult(
            "PIZZA-MARGHERITA",
            "Margherita",
            null,
            null,
            null,
            [size],
            [],
            null);

        var result = await new GetCatalogueProductQueryHandler(new FakeCatalogueQueries(entry))
            .HandleAsync(new GetCatalogueProductQuery(id));

        Assert.Multiple(() =>
        {
            Assert.That(result.UnitPrice, Is.Null);
            Assert.That(result.Sizes, Is.EqualTo(new[] { size }));
        });
    }

    [Test]
    public void HandleAsync_reports_not_found_for_an_product_absent_from_the_catalogue()
    {
        var query = new GetCatalogueProductQuery(Guid.NewGuid());

        Assert.ThrowsAsync<NotFoundException>(() =>
            new GetCatalogueProductQueryHandler(new FakeCatalogueQueries())
                .HandleAsync(query));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() =>
            new GetCatalogueProductQueryHandler(new FakeCatalogueQueries())
                .HandleAsync(null!));
    }

    [Test]
    public async Task HandleAsync_serves_the_cached_details_without_touching_the_queries_twice()
    {
        var cache = new FakeProductCatalogueCache();
        var id = Guid.NewGuid();
        var queries = new FakeCatalogueQueries(Entry("PIZZA-MARGHERITA", "Margherita"));

        var first = await new GetCatalogueProductQueryHandler(queries, cache)
            .HandleAsync(new GetCatalogueProductQuery(id));
        var second = await new GetCatalogueProductQueryHandler(queries, cache)
            .HandleAsync(new GetCatalogueProductQuery(id));

        Assert.Multiple(() =>
        {
            Assert.That(first.ProductCode, Is.EqualTo("PIZZA-MARGHERITA"));
            Assert.That(second.ProductCode, Is.EqualTo("PIZZA-MARGHERITA"));
            Assert.That(cache.FactoryCalls, Is.EqualTo(1));
            Assert.That(queries.LoadCalls, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_reports_not_found_twice_and_only_loads_through_the_port_once()
    {
        var cache = new FakeProductCatalogueCache();
        var id = Guid.NewGuid();
        var queries = new FakeCatalogueQueries();
        var handler = new GetCatalogueProductQueryHandler(queries, cache);
        var query = new GetCatalogueProductQuery(id);

        Assert.ThrowsAsync<NotFoundException>(() => handler.HandleAsync(query));
        Assert.ThrowsAsync<NotFoundException>(() => handler.HandleAsync(query));

        Assert.That(cache.FactoryCalls, Is.EqualTo(1));
    }
}
