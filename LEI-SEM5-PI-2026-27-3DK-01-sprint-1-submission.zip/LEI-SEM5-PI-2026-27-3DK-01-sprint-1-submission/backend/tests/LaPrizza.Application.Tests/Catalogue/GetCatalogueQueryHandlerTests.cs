using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Catalogue.GetCatalogue;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Tests.Fakes;

namespace LaPrizza.Application.Tests.Catalogue;

[TestFixture]
public sealed class GetCatalogueQueryHandlerTests
{
    private static CatalogueProductResult Entry(string productCode, string name) => new(
        productCode,
        name,
        null,
        null,
        9.50m,
        [],
        [],
        null);

    [Test]
    public async Task HandleAsync_returns_the_whole_page_of_sellable_entries()
    {
        var entries = new[]
        {
            Entry("PIZZA-MARGHERITA", "Margherita"),
            Entry("DRINK-WATER", "Sparkling water"),
        };

        var result = await new GetCatalogueQueryHandler(new FakeCatalogueQueries(entries))
            .HandleAsync(new GetCatalogueQuery(1, 20));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Has.Count.EqualTo(2));
            Assert.That(result.Items.Select(item => item.Name).ToList(), Is.EqualTo(new[] { "Margherita", "Sparkling water" }));
        });
    }

    [Test]
    public void HandleAsync_rejects_a_page_that_is_not_a_positive_integer()
    {
        var query = new GetCatalogueQuery(0, 20);

        Assert.ThrowsAsync<ValidationException>(() =>
            new GetCatalogueQueryHandler(new FakeCatalogueQueries()).HandleAsync(query));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() =>
            new GetCatalogueQueryHandler(new FakeCatalogueQueries())
                .HandleAsync(null!));
    }

    [TestCase(0)]
    [TestCase(101)]
    public void HandleAsync_rejects_a_page_size_outside_the_contract_range(int pageSize)
    {
        var query = new GetCatalogueQuery(1, pageSize);

        Assert.ThrowsAsync<ValidationException>(() =>
            new GetCatalogueQueryHandler(new FakeCatalogueQueries()).HandleAsync(query));
    }

    [Test]
    public async Task HandleAsync_serves_the_cached_page_without_touching_the_queries_twice()
    {
        var cache = new FakeProductCatalogueCache();
        var queries = new FakeCatalogueQueries(Entry("PIZZA-MARGHERITA", "Margherita"));

        var first = await new GetCatalogueQueryHandler(queries, cache).HandleAsync(new GetCatalogueQuery(1, 20));
        var second = await new GetCatalogueQueryHandler(queries, cache).HandleAsync(new GetCatalogueQuery(1, 20));

        Assert.That(queries.LoadCalls, Is.EqualTo(1), "the page is loaded through the query port exactly once");
        Assert.That(cache.FactoryCalls, Is.EqualTo(1), "the cache loads the factory exactly once, then serves the cache");

        Assert.That(first.Items, Is.Not.Null);
        Assert.That(first.Items, Has.Count.EqualTo(1));
        Assert.That(second.Items, Has.Count.EqualTo(1));
    }

    [Test]
    public async Task HandleAsync_treats_each_page_size_as_its_own_cached_page()
    {
        var cache = new FakeProductCatalogueCache();
        var queries = new FakeCatalogueQueries(Entry("PIZZA-MARGHERITA", "Margherita"));

        await new GetCatalogueQueryHandler(queries, cache).HandleAsync(new GetCatalogueQuery(1, 20));
        await new GetCatalogueQueryHandler(queries, cache).HandleAsync(new GetCatalogueQuery(1, 50));

        Assert.That(queries.LoadCalls, Is.EqualTo(2), "each page size is its own load");
        Assert.That(cache.FactoryCalls, Is.EqualTo(2), "each page size has its own cache entry");
    }
}
