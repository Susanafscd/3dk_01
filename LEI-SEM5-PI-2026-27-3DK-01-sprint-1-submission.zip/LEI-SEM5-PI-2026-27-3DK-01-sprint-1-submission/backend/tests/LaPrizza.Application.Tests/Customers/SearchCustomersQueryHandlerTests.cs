using LaPrizza.Application.Customers.SearchCustomers;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Customers;

[TestFixture]
public sealed class SearchCustomersQueryHandlerTests
{
    private FakeUserRepository _users = null!;
    private SearchCustomersQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _users = new FakeUserRepository();
        _handler = new SearchCustomersQueryHandler(_users);
        _users.Seed(NewCustomer("Ada Lovelace", "ada@example.com", "+351 910 000 000"));
        _users.Seed(NewCustomer("Grace Hopper", "grace@example.com", "+1 202 555 0100"));
    }

    [TestCase("ada")]
    [TestCase("ADA")]
    public async Task HandleAsync_matches_the_name_case_insensitively(string term)
    {
        var results = await _handler.HandleAsync(new SearchCustomersQuery(term));

        Assert.That(results.Select(result => result.Name), Is.EqualTo(new[] { "Ada Lovelace" }));
    }

    [Test]
    public async Task HandleAsync_matches_the_email()
    {
        var result = await _handler.HandleAsync(new SearchCustomersQuery("grace@example.com"));

        Assert.That(result.Select(customer => result[0].Name), Is.EqualTo(new[] { "Grace Hopper" }));
    }

    [Test]
    public async Task HandleAsync_matches_the_phone_number()
    {
        var result = await _handler.HandleAsync(new SearchCustomersQuery("910 000"));

        Assert.That(result.Single().Name, Is.EqualTo("Ada Lovelace"));
    }

    [Test]
    public async Task HandleAsync_returns_every_customer_when_no_term_is_given()
    {
        var result = await _handler.HandleAsync(new SearchCustomersQuery(null));

        Assert.That(result, Has.Count.EqualTo(2));
    }

    [Test]
    public async Task HandleAsync_returns_an_empty_list_when_nothing_matches()
    {
        var result = await _handler.HandleAsync(new SearchCustomersQuery("nobody"));

        Assert.That(result, Is.Empty);
    }

    private static Customer NewCustomer(string name, string email, string phoneNumber)
    {
        return Customer.Create(Email.Create(email), name, name, [],phoneNumber);
    }
}
