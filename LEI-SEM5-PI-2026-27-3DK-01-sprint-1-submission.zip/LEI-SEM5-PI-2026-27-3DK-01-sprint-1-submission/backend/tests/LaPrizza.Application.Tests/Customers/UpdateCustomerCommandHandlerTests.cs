using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Customers.UpdateCustomer;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Customers;

[TestFixture]
public sealed class UpdateCustomerCommandHandlerTests
{
    private FakeUserRepository _users = null!;
    private UpdateCustomerCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _users = new FakeUserRepository();
        _handler = new UpdateCustomerCommandHandler(_users);
    }

    [Test]
    public async Task HandleAsync_updates_the_name_and_contact_details()
    {
        var customer = NewCustomer();
        _users.Seed(customer);

        var result = await _handler.HandleAsync(new UpdateCustomerCommand(customer.Id, "Ada King", "210 000 000"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Ada King"));
            Assert.That(result.PhoneNumber, Is.EqualTo("210 000 000"));
            Assert.That(customer.Name, Is.EqualTo("Ada King"));
            Assert.That(customer.DisplayName, Is.EqualTo("Ada King"));
            Assert.That(customer.PhoneNumber.Value, Is.EqualTo("210 000 000"));
            Assert.That(customer.Email.Value, Is.EqualTo("ada@example.com"));
        });
    }

    [Test]
    public async Task HandleAsync_trims_values()
    {
        var customer = NewCustomer();
        _users.Seed(customer);

        var result = await _handler.HandleAsync(new UpdateCustomerCommand(customer.Id, "  Ada King  ", "  210 000 000  "));

        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Ada King"));
            Assert.That(result.PhoneNumber, Is.EqualTo("210 000 000"));
            Assert.That(customer.Name, Is.EqualTo("Ada King"));
            Assert.That(customer.DisplayName, Is.EqualTo("Ada King"));
        });
    }

    [Test]
    public void HandleAsync_rejects_removing_the_phone_number()
    {
        var customer = NewCustomer();
        _users.Seed(customer);

        Assert.ThrowsAsync<DomainException>(() =>
            _handler.HandleAsync(new UpdateCustomerCommand(customer.Id, "Ada King", null!)));
    }

    [Test]
    public async Task HandleAsync_throws_when_the_customer_does_not_exist()
    {
        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new UpdateCustomerCommand(Guid.NewGuid(), "Ada King", null)));

        Assert.That(exception!.Message, Does.Contain("No customer with id"));
    }

    [Test]
    public async Task HandleAsync_throws_when_the_user_is_not_a_customer()
    {
        var staff = Staff.Create(Email.Create("staff@example.com"), "João Silva", "Manager", []);
        _users.Seed(staff);

        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new UpdateCustomerCommand(staff.Id, "Ada King", null)));

        Assert.That(exception!.Message, Does.Contain("No customer with id"));
    }

    private static Customer NewCustomer() =>
        Customer.Create(Email.Create("ada@example.com"), "Ada Lovelace", "Ada Lovelace", [],"+351 910 000 000");
}
