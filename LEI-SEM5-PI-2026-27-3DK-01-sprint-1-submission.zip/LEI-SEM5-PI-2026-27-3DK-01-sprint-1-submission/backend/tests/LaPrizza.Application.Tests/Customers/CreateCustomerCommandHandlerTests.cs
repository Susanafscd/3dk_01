using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Customers.CreateCustomer;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Customers;

[TestFixture]
public sealed class CreateCustomerCommandHandlerTests
{
    private FakeUserRepository _users = null!;
    private FakeAllergenRepository _allergens = null!;
    private FakeUserAccountManager _accounts = null!;
    private CreateCustomerCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _users = new FakeUserRepository();
        _accounts = new FakeUserAccountManager();
        _handler = new CreateCustomerCommandHandler(_users, _allergens, _accounts);
    }

    [Test]
    public async Task HandleAsync_creates_the_customer_and_its_login_account()
    {
        var result = await _handler.HandleAsync(Command());

        var stored = (Customer)_users.Added.Single();

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(result.Name, Is.EqualTo("Ada Lovelace"));
            Assert.That(result.Email, Is.EqualTo("ada@example.com"));
            Assert.That(result.PhoneNumber, Is.EqualTo("+351 910 000 000"));
            Assert.That(result.VATNumber, Is.EqualTo("501964843"));
            Assert.That(result.Active, Is.True);

            Assert.That(stored.Name, Is.EqualTo("Ada Lovelace"));
            Assert.That(stored.DisplayName, Is.EqualTo("Ada Lovelace"));
            Assert.That(stored.Email.Value, Is.EqualTo("ada@example.com"));

            Assert.That(_accounts.Created, Has.Count.EqualTo(1));
            Assert.That(_accounts.Created[0].Email, Is.EqualTo("ada@example.com"));
        });
    }

    [Test]
    public async Task HandleAsync_trims_the_name_and_keeps_the_display_name_in_step()
    {
        await _handler.HandleAsync(Command(name: "  Ada Lovelace  "));

        var stored = (Customer)_users.Added.Single();

        Assert.Multiple(() =>
        {
            Assert.That(stored.Name, Is.EqualTo("Ada Lovelace"));
            Assert.That(stored.DisplayName, Is.EqualTo("Ada Lovelace"));
        });
    }

    [Test]
    public void HandleAsync_rejects_a_customer_without_a_phone_number()
    {
        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(Command(phoneNumber: null!)));
    }

    [Test]
    public async Task HandleAsync_rejects_a_duplicate_email()
    {
        _users.SeedExisting(Email.Create("ada@example.com"));

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(Command()));

        Assert.That(exception!.Message, Is.EqualTo("A user with email 'ada@example.com' already exists."));
        Assert.That(_users.Added, Is.Empty);
        Assert.That(_accounts.Created, Is.Empty);
    }

    [Test]
    public async Task HandleAsync_deletes_the_account_if_persistence_fails()
    {
        var failingUsers = new ThrowingOnAddUserRepository();
        _handler = new CreateCustomerCommandHandler(failingUsers, _allergens, _accounts);

        var exception = Assert.ThrowsAsync<InvalidOperationException>(() => _handler.HandleAsync(Command()));

        Assert.That(exception, Is.Not.Null);
        Assert.That(_accounts.Deleted, Has.Count.EqualTo(1));
    }

    private static CreateCustomerCommand Command(
        string name = "Ada Lovelace",
        string phoneNumber = "+351 910 000 000") =>
        new(
            Name: name,
            Email: "ada@example.com",
            DietaryRestrictions: [],
            PhoneNumber: phoneNumber,
            Password: "Customer123!",
            VATNumber: "501964843");
}

internal sealed class ThrowingOnAddUserRepository : IUserRepository
{
    public Task<bool> ExistsByEmailAsync(Email email, CancellationToken cancellationToken = default) => Task.FromResult(false);
    public Task<User?> GetByEmailAsync(Email email, CancellationToken cancellationToken = default) => Task.FromResult<User?>(null);
    public Task<User?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default) => Task.FromResult<User?>(null);
    public Task<IReadOnlyList<Customer>> SearchCustomersAsync(string? search, CancellationToken cancellationToken = default) => Task.FromResult<IReadOnlyList<Customer>>([]);
    public Task AddAsync(User user, CancellationToken cancellationToken = default) => throw new InvalidOperationException("Persistence failed.");
    public Task UpdateAsync(User user, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task RemoveAsync(User user, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) => Task.FromResult(0);
}
