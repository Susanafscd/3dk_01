using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Customers.DeactivateCustomer;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Customers;

[TestFixture]
public sealed class DeactivateCustomerCommandHandlerTests
{
    private FakeUserRepository _users = null!;
    private DeactivateCustomerCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _users = new FakeUserRepository();
        _handler = new DeactivateCustomerCommandHandler(_users);
    }

    [Test]
    public async Task HandleAsync_marks_the_customer_inactive_and_keeps_its_data()
    {
        var customer = NewCustomer();
        _users.Seed(customer);

        await _handler.HandleAsync(new DeactivateCustomerCommand(customer.Id));

        Assert.Multiple(() =>
        {
            Assert.That(customer.Active, Is.False);
            Assert.That(_users.Added, Has.Count.EqualTo(1));
        });
    }

    [Test]
    public async Task HandleAsync_is_idempotent()
    {
        var customer = NewCustomer();
        customer.Deactivate();
        _users.Seed(customer);

        Assert.DoesNotThrowAsync(() => _handler.HandleAsync(new DeactivateCustomerCommand(customer.Id)));
        Assert.That(customer.Active, Is.False);
    }

    [Test]
    public async Task HandleAsync_throws_when_the_customer_does_not_exist()
    {
        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new DeactivateCustomerCommand(Guid.NewGuid())));

        Assert.That(exception!.Message, Does.Contain("No customer with id"));
    }

    [Test]
    public async Task HandleAsync_throws_when_the_user_is_not_a_customer()
    {
        var staff = Staff.Create(Email.Create("staff@example.com"), "João Silva", "Manager", []);
        _users.Seed(staff);

        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new DeactivateCustomerCommand(staff.Id)));

        Assert.That(exception!.Message, Does.Contain("No customer with id"));
    }

    private static Customer NewCustomer() =>
        Customer.Create(Email.Create("ada@example.com"), "Ada Lovelace", "Ada Lovelace", [],"+351 910 000 000");
}
