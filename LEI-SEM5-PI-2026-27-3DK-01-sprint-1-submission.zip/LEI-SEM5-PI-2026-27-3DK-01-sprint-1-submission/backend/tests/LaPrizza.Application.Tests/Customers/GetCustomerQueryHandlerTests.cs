using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Customers.GetCustomer;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;

namespace LaPrizza.Application.Tests.Customers;

[TestFixture]
public sealed class GetCustomerQueryHandlerTests
{
    private FakeUserRepository _users = null!;
    private GetCustomerQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _users = new FakeUserRepository();
        _handler = new GetCustomerQueryHandler(_users);
    }

    [Test]
    public async Task HandleAsync_returns_the_customer_projection()
    {
        var customer = NewCustomer();
        _users.Seed(customer);

        var result = await _handler.HandleAsync(new GetCustomerQuery(customer.Id));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.EqualTo(customer.Id));
            Assert.That(result.Name, Is.EqualTo("Ada Lovelace"));
            Assert.That(result.Email, Is.EqualTo("ada@example.com"));
            Assert.That(result.PhoneNumber, Is.EqualTo("+351 910 000 000"));
            Assert.That(result.Active, Is.True);
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_id()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(new GetCustomerQuery(Guid.NewGuid())));
    }

    [Test]
    public void HandleAsync_rejects_an_id_that_is_not_a_customer()
    {
        var staff = Staff.Create(Email.Create("grace@example.com"), "Grace Hopper", "Head Chef");
        _users.Seed(staff);

        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(new GetCustomerQuery(staff.Id)));
    }

    private static Customer NewCustomer() =>
        Customer.Create(Email.Create("ada@example.com"), "Ada Lovelace", "Ada Lovelace", [],"+351 910 000 000");
}
