using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Application.Tests.Fakes;

namespace LaPrizza.Application.Tests.PredefinedPizzas;

[TestFixture]
public sealed class SearchPredefinedPizzasQueryHandlerTests
{
    private FakePredefinedPizzaQueries _queries = null!;
    private SearchPredefinedPizzasQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _queries = new FakePredefinedPizzaQueries();
        _handler = new SearchPredefinedPizzasQueryHandler(_queries);
    }

    [Test]
    public async Task Passes_the_trimmed_search_the_filter_and_the_page_to_the_query()
    {
        _queries.SearchResult = new PredefinedPizzaSearchPage(
            [new PredefinedPizzaSearchItem("margherita", "Margherita", "pizzas", true)],
            TotalCount: 3);

        var result = await _handler.HandleAsync(new SearchPredefinedPizzasQuery("  marg ", true, 2, 1));

        Assert.Multiple(() =>
        {
            Assert.That(_queries.LastSearch, Is.EqualTo(new PredefinedPizzaSearchCriteria("marg", true, 2, 1)));
            Assert.That(result.Items.Single().Code, Is.EqualTo("margherita"));
            Assert.That((result.Page, result.PageSize, result.TotalCount), Is.EqualTo((2, 1, 3)));
        });
    }

    [Test]
    public async Task Treats_a_blank_search_as_no_search()
    {
        await _handler.HandleAsync(new SearchPredefinedPizzasQuery("   "));

        Assert.That(_queries.LastSearch!.Search, Is.Null);
    }

    [TestCase(0, 20)]
    [TestCase(1, 0)]
    [TestCase(1, 101)]
    public void Rejects_an_invalid_page(int page, int pageSize)
    {
        Assert.ThrowsAsync<ValidationException>(() =>
            _handler.HandleAsync(new SearchPredefinedPizzasQuery(null, null, page, pageSize)));
        Assert.That(_queries.LastSearch, Is.Null);
    }
}
