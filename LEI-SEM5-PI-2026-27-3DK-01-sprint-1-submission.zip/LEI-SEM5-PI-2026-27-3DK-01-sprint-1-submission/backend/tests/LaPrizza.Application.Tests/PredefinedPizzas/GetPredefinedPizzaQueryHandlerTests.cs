using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.GetPredefinedPizza;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.PredefinedPizzas;

[TestFixture]
public sealed class GetPredefinedPizzaQueryHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakePredefinedPizzaQueries _queries = null!;
    private GetPredefinedPizzaQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _queries = new FakePredefinedPizzaQueries();
        _handler = new GetPredefinedPizzaQueryHandler(_products, _queries);

        _queries.Seed(
            Facts("mozzarella", "Mozzarella", "cheese", 3, ("small", 1.00m), ("medium", 1.50m)),
            Facts("classic-dough", "Classic dough", "base-dough", 1, ("small", 2.00m), ("medium", 3.00m)));
        _products.Seed(Margherita());
    }

    [Test]
    public async Task Returns_the_pizza_with_its_ordered_configuration_and_price_per_size()
    {
        var result = await _handler.HandleAsync(new GetPredefinedPizzaQuery("margherita"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("margherita"));
            Assert.That(result.Active, Is.True);
            Assert.That(
                result.DefaultConfiguration.Select(c => c.ProductCode),
                Is.EqualTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(
                result.Sizes.Select(size => (size.SizeId, size.Price)),
                Is.EquivalentTo(new[] { ("small", 3.00m), ("medium", 4.50m) }));
        });
    }

    [Test]
    public async Task Leaves_out_a_size_in_which_a_component_no_longer_has_an_active_size_configuration()
    {
        // The medium configuration of the mozzarella was deactivated after the pizza was created (P8).
        _queries.Seed(Facts("mozzarella", "Mozzarella", "cheese", 3, ("small", 1.00m)));

        var result = await _handler.HandleAsync(new GetPredefinedPizzaQuery("margherita"));

        Assert.That(result.Sizes.Select(size => size.SizeId), Is.EqualTo(new[] { "small" }));
    }

    [Test]
    public async Task Returns_an_inactive_pizza_with_active_false()
    {
        _products.Products.Single().Deactivate();

        var result = await _handler.HandleAsync(new GetPredefinedPizzaQuery("margherita"));

        Assert.That(result.Active, Is.False);
    }

    [Test]
    public void Reports_an_unknown_code_as_not_found()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(new GetPredefinedPizzaQuery("calzone")));
    }

    [Test]
    public void Reports_a_base_product_as_not_found()
    {
        _products.Seed(new BaseProductBuilder()
            .WithCode("cola")
            .WithName("Cola")
            .WithDescription("A drink")
            .InCategory("beverages")
            .StockControlled()
            .Build());

        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(new GetPredefinedPizzaQuery("cola")));
    }

    [Test]
    public void Rejects_a_malformed_code()
    {
        Assert.ThrowsAsync<InvalidProductException>(() => _handler.HandleAsync(new GetPredefinedPizzaQuery("Margherita!")));
    }

    private static ComposedProduct Margherita() => ComposedProduct.Create(
        "margherita",
        "Margherita",
        "Tomato and mozzarella",
        "pizzas",
        [
            new PizzaComponent(ProductCode.Create("mozzarella"), true, "cheese"),
            new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough"),
        ],
        [new ComponentTypeLimit("base-dough", 1, 1), new ComponentTypeLimit("cheese", 0, 1)],
        ["small", "medium"]);

    private static PizzaComponentFacts Facts(
        string code,
        string name,
        string type,
        int assemblyOrder,
        params (string Size, decimal Price)[] prices) =>
        new(
            ProductCode.Create(code),
            name,
            true,
            true,
            true,
            type,
            assemblyOrder,
            prices.ToDictionary(price => price.Size, price => price.Price));
}
