using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.UpdatePredefinedPizza;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.PredefinedPizzas;

[TestFixture]
public sealed class UpdatePredefinedPizzaCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakePizzaSizeRepository _sizes = null!;
    private FakePredefinedPizzaQueries _queries = null!;
    private UpdatePredefinedPizzaCommandHandler _handler = null!;
    private ComposedProduct _margherita = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _sizes = new FakePizzaSizeRepository();
        _queries = new FakePredefinedPizzaQueries();
        _handler = new UpdatePredefinedPizzaCommandHandler(_products, _sizes, _queries);

        _sizes.Seed(PizzaSize.Create("small"), PizzaSize.Create("medium"));
        _queries.TypeLimits.AddRange([new("base-dough", 1, 1), new("cheese", 0, 1), new("topping", 0, null)]);
        _queries.Seed(
            Facts("classic-dough", "base-dough", 1, ("small", 2.00m), ("medium", 3.00m)),
            Facts("mozzarella", "cheese", 3, ("small", 1.00m), ("medium", 1.50m)),
            Facts("basil", "topping", 4, ("small", 0.25m)));

        _margherita = ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            [
                new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough"),
                new PizzaComponent(ProductCode.Create("mozzarella"), true, "cheese"),
            ],
            _queries.TypeLimits,
            ["small", "medium"]);
        _products.Seed(_margherita);
    }

    [Test]
    public async Task Replaces_the_pizza_and_returns_its_new_configuration_and_prices()
    {
        var result = await _handler.HandleAsync(
            Command(["basil", "classic-dough", "mozzarella"], ["small"], name: "Margherita Basil"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Margherita Basil"));
            Assert.That(
                result.DefaultConfiguration.Select(c => c.ProductCode),
                Is.EqualTo(new[] { "classic-dough", "mozzarella", "basil" }));
            Assert.That(result.Sizes.Select(s => (s.SizeId, s.Price)), Is.EqualTo(new[] { ("small", 3.25m) }));
            Assert.That(_margherita.Name, Is.EqualTo("Margherita Basil"));
            Assert.That(_margherita.Components, Has.Count.EqualTo(3));
        });
    }

    [Test]
    public void Reports_an_unknown_pizza_as_not_found()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(Command(["classic-dough"], ["small"], code: "calzone")));
    }

    [Test]
    public void Rejects_a_malformed_pizza_code()
    {
        Assert.ThrowsAsync<InvalidProductException>(() =>
            _handler.HandleAsync(Command(["classic-dough"], ["small"], code: "Calzone!")));
    }

    [Test]
    public void Rejects_an_unknown_component_and_changes_nothing()
    {
        AssertRejected<ValidationException>(Command(["classic-dough", "ghost"], ["small"]));
    }

    [Test]
    public void Rejects_an_unknown_size_and_changes_nothing()
    {
        AssertRejected<ValidationException>(Command(["classic-dough"], ["huge"]));
    }

    [Test]
    public void Rejects_a_broken_configuration_and_changes_nothing()
    {
        AssertRejected<ConflictException>(Command(["mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_size_in_which_a_component_has_no_active_size_configuration_and_changes_nothing()
    {
        // Basil is configured only in small.
        AssertRejected<ConflictException>(Command(["classic-dough", "basil"], ["small", "medium"]));
    }

    private void AssertRejected<TException>(UpdatePredefinedPizzaCommand command)
        where TException : Exception
    {
        Assert.ThrowsAsync<TException>(() => _handler.HandleAsync(command));
        Assert.Multiple(() =>
        {
            Assert.That(_margherita.Name, Is.EqualTo("Margherita"));
            Assert.That(_margherita.Components.Select(c => c.Value), Is.EquivalentTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(_margherita.AvailableSizes.Select(s => s.SizeName), Is.EquivalentTo(new[] { "small", "medium" }));
        });
    }

    private static UpdatePredefinedPizzaCommand Command(
        IReadOnlyList<string> componentCodes,
        IReadOnlyList<string> sizeIds,
        string code = "margherita",
        string name = "Margherita") =>
        new(code, name, "Tomato and mozzarella", componentCodes, sizeIds);

    private static PizzaComponentFacts Facts(
        string code,
        string type,
        int assemblyOrder,
        params (string Size, decimal Price)[] prices) =>
        new(
            ProductCode.Create(code),
            code,
            true,
            true,
            true,
            type,
            assemblyOrder,
            prices.ToDictionary(price => price.Size, price => price.Price));
}
