using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.PredefinedPizzas;
using LaPrizza.Application.PredefinedPizzas.CreatePredefinedPizza;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.PredefinedPizzas;

[TestFixture]
public sealed class CreatePredefinedPizzaCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakeProductRelationshipQueries _relationships = null!;
    private FakePizzaSizeRepository _sizes = null!;
    private FakePredefinedPizzaQueries _queries = null!;
    private CreatePredefinedPizzaCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _relationships = new FakeProductRelationshipQueries();
        _sizes = new FakePizzaSizeRepository();
        _queries = new FakePredefinedPizzaQueries();
        _handler = new CreatePredefinedPizzaCommandHandler(_products, _relationships, _sizes, _queries);

        _sizes.Seed(PizzaSize.Create("small"), PizzaSize.Create("medium"));
        _queries.TypeLimits.AddRange([new("base-dough", 1, 1), new("cheese", 0, 1), new("topping", 0, null)]);
        _queries.Seed(
            Component("classic-dough", "base-dough", [("small", 2.00m), ("medium", 3.00m)], name: "Classic Dough", assemblyOrder: 1),
            Component("mozzarella", "cheese", [("small", 1.00m), ("medium", 1.50m)], name: "Mozzarella", assemblyOrder: 3),
            Component("basil", "topping", [("small", 0.25m)], name: "Basil", assemblyOrder: 4));
    }

    [Test]
    public async Task Creates_the_pizza_and_returns_its_price_in_each_size()
    {
        var result = await _handler.HandleAsync(Command(["mozzarella", "classic-dough"], ["small", "medium"]));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("margherita"));
            Assert.That(result.Active, Is.True);
            // Ordered by the assembly order of the component types, not by the request.
            Assert.That(
                result.DefaultConfiguration.Select(c => (c.ProductCode, c.Name, c.ComponentTypeCode, c.AssemblyOrder)),
                Is.EqualTo(new[] { ("classic-dough", "Classic Dough", "base-dough", 1), ("mozzarella", "Mozzarella", "cheese", 3) }));
            Assert.That(
                result.Sizes.Select(size => (size.SizeId, size.Price)),
                Is.EquivalentTo(new[] { ("small", 3.00m), ("medium", 4.50m) }));
            Assert.That(_products.Products.Single(), Is.InstanceOf<ComposedProduct>());
        });
    }

    [Test]
    public void Rejects_an_unknown_category()
    {
        _relationships.SimulateMissingCategory();

        AssertRejected<ValidationException>(Command(["classic-dough"], ["small"]));
    }

    [Test]
    public void Rejects_an_unknown_component()
    {
        AssertRejected<ValidationException>(Command(["classic-dough", "ghost"], ["small"]));
    }

    [Test]
    public void Rejects_an_unknown_size()
    {
        AssertRejected<ValidationException>(Command(["classic-dough"], ["huge"]));
    }

    [Test]
    public void Rejects_a_malformed_component_code()
    {
        AssertRejected<InvalidProductException>(Command(["Classic Dough!"], ["small"]));
    }

    [Test]
    public void Rejects_an_inactive_component()
    {
        _queries.Seed(Component("mozzarella", "cheese", [("small", 1.00m)], active: false));

        AssertRejected<ConflictException>(Command(["classic-dough", "mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_component_whose_category_does_not_allow_component_types()
    {
        _queries.Seed(Component("mozzarella", "cheese", [("small", 1.00m)], categoryAllowsTypes: false));

        AssertRejected<ConflictException>(Command(["classic-dough", "mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_component_without_a_component_type()
    {
        _queries.Seed(Component("mozzarella", type: null, [("small", 1.00m)]));

        AssertRejected<ConflictException>(Command(["classic-dough", "mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_composed_product_as_a_component()
    {
        _queries.Seed(Component("mozzarella", "cheese", [("small", 1.00m)], isBaseProduct: false));

        AssertRejected<ConflictException>(Command(["classic-dough", "mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_configuration_that_breaks_a_component_type_minimum()
    {
        AssertRejected<ConflictException>(Command(["mozzarella"], ["small"]));
    }

    [Test]
    public void Rejects_a_size_in_which_a_component_has_no_active_size_configuration()
    {
        // Basil is configured only in small.
        AssertRejected<ConflictException>(Command(["classic-dough", "basil"], ["small", "medium"]));
    }

    [Test]
    public void Rejects_a_code_already_in_use()
    {
        _products.Seed(new BaseProductBuilder()
            .WithCode("margherita")
            .WithName("Margherita")
            .WithDescription("Another product with the same code")
            .InCategory("pizzas")
            .StockControlled()
            .Build());

        Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(Command(["classic-dough"], ["small"])));
        Assert.That(_products.Products, Has.Count.EqualTo(1));
    }

    private void AssertRejected<TException>(CreatePredefinedPizzaCommand command)
        where TException : Exception
    {
        Assert.ThrowsAsync<TException>(() => _handler.HandleAsync(command));
        Assert.That(_products.Products, Is.Empty);
    }

    private static CreatePredefinedPizzaCommand Command(
        IReadOnlyList<string> componentCodes,
        IReadOnlyList<string> sizeIds) =>
        new("margherita", "Margherita", "Tomato and mozzarella", "pizzas", componentCodes, sizeIds);

    private static PizzaComponentFacts Component(
        string code,
        string? type,
        (string Size, decimal Price)[] prices,
        bool active = true,
        bool categoryAllowsTypes = true,
        bool isBaseProduct = true,
        string? name = null,
        int? assemblyOrder = null) =>
        new(
            ProductCode.Create(code),
            name ?? code,
            isBaseProduct,
            active,
            categoryAllowsTypes,
            type,
            assemblyOrder,
            prices.ToDictionary(price => price.Size, price => price.Price));
}
