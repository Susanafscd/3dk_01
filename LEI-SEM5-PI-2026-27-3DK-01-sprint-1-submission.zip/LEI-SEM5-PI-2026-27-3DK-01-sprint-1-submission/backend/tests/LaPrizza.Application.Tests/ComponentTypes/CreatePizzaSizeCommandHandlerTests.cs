using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.CreatePizzaSize;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class CreatePizzaSizeCommandHandlerTests
{
    private FakePizzaSizeRepository _sizes = null!;
    private CreatePizzaSizeCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _sizes = new FakePizzaSizeRepository();
        _handler = new CreatePizzaSizeCommandHandler(_sizes);
    }

    [Test]
    public async Task HandleAsync_creates_size_and_returns_its_data()
    {
        var result = await _handler.HandleAsync(
            new CreatePizzaSizeCommand("xl", "Extra large, 40 cm."));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(result.Name, Is.EqualTo("xl"));
            Assert.That(result.Description, Is.EqualTo("Extra large, 40 cm."));
            Assert.That(_sizes.Sizes, Has.Count.EqualTo(1));
            Assert.That(_sizes.Sizes.Single().Id, Is.EqualTo(result.Id));
            Assert.That(_sizes.AddCount, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task HandleAsync_stores_a_blank_description_as_null()
    {
        var result = await _handler.HandleAsync(new CreatePizzaSizeCommand("m", "   "));

        Assert.That(result.Description, Is.Null);
    }

    [Test]
    public void HandleAsync_throws_conflict_without_overwriting_an_existing_name()
    {
        var existing = PizzaSize.Create("xl", "Keep");
        _sizes.Seed(existing);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaSizeCommand("xl", "Replacement")));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("xl"));
            Assert.That(_sizes.Sizes, Has.Count.EqualTo(1));
            Assert.That(_sizes.Sizes.Single().Description, Is.EqualTo("Keep"));
            Assert.That(_sizes.AddCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_maps_a_duplicate_insert_race_to_conflict()
    {
        _sizes.AddFailure = new DuplicatePizzaSizeNameException("xl");

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaSizeCommand("xl", null)));

        Assert.That(exception!.Message, Does.Contain("xl"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Extra Large")]
    [TestCase("x--l")]
    public void HandleAsync_rejects_invalid_domain_data_before_adding(string? name)
    {
        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(
            new CreatePizzaSizeCommand(name, null)));

        Assert.That(_sizes.AddCount, Is.Zero);
    }

    [Test]
    public void HandleAsync_rejects_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
