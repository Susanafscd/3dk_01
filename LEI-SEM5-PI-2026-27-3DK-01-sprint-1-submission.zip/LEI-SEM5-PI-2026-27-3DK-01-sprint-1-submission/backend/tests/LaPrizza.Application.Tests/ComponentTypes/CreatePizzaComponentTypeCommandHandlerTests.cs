using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.CreatePizzaComponentType;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class CreatePizzaComponentTypeCommandHandlerTests
{
    private FakePizzaComponentTypeRepository _types = null!;
    private FakeProductCategoryRepository _categories = null!;
    private CreatePizzaComponentTypeCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _types = new FakePizzaComponentTypeRepository();
        _categories = new FakeProductCategoryRepository();
        _categories.Seed(ProductCategory.Create("pizza-component", "Pizza Components", null, true));
        _handler = new CreatePizzaComponentTypeCommandHandler(_types, _categories);
    }

    [Test]
    public async Task HandleAsync_creates_type_and_returns_its_data()
    {
        var result = await _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", "Topping", "Extra toppings", 4, 0, null));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("topping"));
            Assert.That(result.CategoryCode, Is.EqualTo("pizza-component"));
            Assert.That(result.Name, Is.EqualTo("Topping"));
            Assert.That(result.Description, Is.EqualTo("Extra toppings"));
            Assert.That(result.AssemblyOrder, Is.EqualTo(4));
            Assert.That(result.MinQuantity, Is.EqualTo(0));
            Assert.That(result.MaxQuantity, Is.Null);
            Assert.That(_types.Types, Has.Count.EqualTo(1));
            Assert.That(_types.Types.Single().Code.Value, Is.EqualTo(result.Code));
            Assert.That(_types.AddCount, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task HandleAsync_stores_a_blank_description_as_null()
    {
        var result = await _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("dough", "Dough", "   ", 1, 1, 1));

        Assert.That(result.Description, Is.Null);
    }

    [Test]
    public void HandleAsync_throws_conflict_without_overwriting_an_existing_name()
    {
        var existing = PizzaComponentType.Create("topping", "Topping", "Keep", 4, 0, null);
        _types.Seed(existing);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("other-topping", "Topping", "Replacement", 1, 0, null)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("Topping"));
            Assert.That(_types.Types, Has.Count.EqualTo(1));
            Assert.That(_types.Types.Single().Description, Is.EqualTo("Keep"));
            Assert.That(_types.AddCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_throws_conflict_when_assembly_order_already_exists()
    {
        var existing = PizzaComponentType.Create("dough", "Dough", null, 1, 1, 1);
        _types.Seed(existing);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("sauce", "Sauce", null, 1, 0, 1)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("1"));
            Assert.That(_types.AddCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_maps_duplicate_name_race_to_conflict()
    {
        _types.AddFailure = new DuplicatePizzaComponentTypeNameException("Topping");

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", "Topping", null, 4, 0, null)));

        Assert.That(exception!.Message, Does.Contain("Topping"));
    }

    [Test]
    public void HandleAsync_maps_duplicate_order_race_to_conflict()
    {
        _types.AddFailure = new DuplicatePizzaComponentTypeAssemblyOrderException(1);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("sauce", "Sauce", null, 1, 0, 1)));

        Assert.That(exception!.Message, Does.Contain("1"));
    }

    [Test]
    public void HandleAsync_throws_conflict_without_overwriting_an_existing_code()
    {
        var existing = PizzaComponentType.Create("topping", "Topping", "Keep", 4, 0, null);
        _types.Seed(existing);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", "Another name", "Replacement", 5, 0, null)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("topping"));
            Assert.That(_types.Types, Has.Count.EqualTo(1));
            Assert.That(_types.Types.Single().Description, Is.EqualTo("Keep"));
            Assert.That(_types.AddCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_maps_duplicate_code_race_to_conflict()
    {
        _types.AddFailure = new DuplicatePizzaComponentTypeCodeException(PizzaComponentTypeCode.Create("topping"));

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", "Topping", null, 4, 0, null)));

        Assert.That(exception!.Message, Does.Contain("topping"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Topping")]
    [TestCase("base dough")]
    [TestCase("base--dough")]
    [TestCase("-topping")]
    public void HandleAsync_rejects_invalid_code_before_adding(string? code)
    {
        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand(code, "Topping", null, 1, 0, null)));

        Assert.That(_types.AddCount, Is.Zero);
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void HandleAsync_rejects_invalid_domain_data_before_adding(string? name)
    {
        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", name, null, 1, 0, null)));

        Assert.That(_types.AddCount, Is.Zero);
    }

    [Test]
    public void HandleAsync_rejects_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_category_before_adding()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(
            new CreatePizzaComponentTypeCommand("topping", "missing-category", "Topping", null, 4, 0, null)));

        Assert.That(_types.AddCount, Is.Zero);
    }
}
