using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.GetPizzaComponentType;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class GetPizzaComponentTypeQueryHandlerTests
{
    private FakePizzaComponentTypeRepository _types = null!;
    private GetPizzaComponentTypeQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _types = new FakePizzaComponentTypeRepository();
        _handler = new GetPizzaComponentTypeQueryHandler(_types);
    }

    [Test]
    public async Task HandleAsync_returns_the_type_when_found()
    {
        var type = PizzaComponentType.Create("topping", "Topping", "Extra", 4, 0, null);
        _types.Seed(type);

        var result = await _handler.HandleAsync(new GetPizzaComponentTypeQuery("topping"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("topping"));
            Assert.That(result.Name, Is.EqualTo("Topping"));
            Assert.That(result.Description, Is.EqualTo("Extra"));
            Assert.That(result.AssemblyOrder, Is.EqualTo(4));
            Assert.That(result.MinQuantity, Is.EqualTo(0));
            Assert.That(result.MaxQuantity, Is.Null);
        });
    }

    [Test]
    public void HandleAsync_throws_not_found_when_missing()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(
            new GetPizzaComponentTypeQuery("missing")));
    }

    [Test]
    public void HandleAsync_rejects_an_invalid_code()
    {
        Assert.ThrowsAsync<LaPrizza.Domain.Common.DomainException>(() => _handler.HandleAsync(
            new GetPizzaComponentTypeQuery("Not A Code")));
    }

    [Test]
    public void HandleAsync_rejects_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
