using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.DeletePizzaSize;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class DeletePizzaSizeCommandHandlerTests
{
    private FakePizzaSizeRepository _sizes = null!;
    private DeletePizzaSizeCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _sizes = new FakePizzaSizeRepository();
        _handler = new DeletePizzaSizeCommandHandler(_sizes);
    }

    [Test]
    public async Task HandleAsync_removes_only_the_requested_size()
    {
        var removed = PizzaSize.Create("xl");
        var kept = PizzaSize.Create("m");
        _sizes.Seed(removed, kept);

        await _handler.HandleAsync(new DeletePizzaSizeCommand(removed.Id));

        Assert.Multiple(() =>
        {
            Assert.That(_sizes.Sizes, Is.EquivalentTo(new[] { kept }));
            Assert.That(_sizes.RemoveCount, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_throws_not_found_for_an_unknown_id()
    {
        var id = Guid.NewGuid();

        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new DeletePizzaSizeCommand(id)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain(id.ToString()));
            Assert.That(_sizes.RemoveCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_throws_conflict_without_removing_a_size_in_use()
    {
        var size = PizzaSize.Create("xl");
        _sizes.Seed(size);
        _sizes.InUseIds.Add(size.Id);

        var exception = Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new DeletePizzaSizeCommand(size.Id)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain(size.Id.ToString()));
            Assert.That(_sizes.Sizes, Has.Count.EqualTo(1));
            Assert.That(_sizes.RemoveCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_maps_a_reference_added_concurrently_to_conflict()
    {
        var size = PizzaSize.Create("xl");
        _sizes.Seed(size);
        _sizes.RemoveFailure = new PizzaSizeInUseException(size.Id);

        var exception = Assert.ThrowsAsync<ConflictException>(() =>
            _handler.HandleAsync(new DeletePizzaSizeCommand(size.Id)));

        Assert.That(exception!.Message, Does.Contain(size.Id.ToString()));
    }

    [Test]
    public void HandleAsync_rejects_a_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
