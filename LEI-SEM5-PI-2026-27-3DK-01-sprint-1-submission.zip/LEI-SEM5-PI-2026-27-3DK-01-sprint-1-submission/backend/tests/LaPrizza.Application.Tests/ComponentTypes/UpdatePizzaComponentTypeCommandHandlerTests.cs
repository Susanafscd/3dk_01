using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.UpdatePizzaComponentType;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class UpdatePizzaComponentTypeCommandHandlerTests
{
    private FakePizzaComponentTypeRepository _types = null!;
    private UpdatePizzaComponentTypeCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _types = new FakePizzaComponentTypeRepository();
        _handler = new UpdatePizzaComponentTypeCommandHandler(_types);
    }

    [Test]
    public async Task HandleAsync_updates_the_type_and_returns_its_data()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        _types.Seed(type);

        var result = await _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("topping", "Sauce", "Red", 2, 0, 1));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("topping"));
            Assert.That(result.Name, Is.EqualTo("Sauce"));
            Assert.That(result.Description, Is.EqualTo("Red"));
            Assert.That(result.AssemblyOrder, Is.EqualTo(2));
            Assert.That(result.MinQuantity, Is.EqualTo(0));
            Assert.That(result.MaxQuantity, Is.EqualTo(1));
            Assert.That(_types.UpdateCount, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_throws_not_found_when_missing()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("missing", "Sauce", null, 1, 0, 1)));
    }

    [Test]
    public void HandleAsync_throws_conflict_when_name_taken_by_another_type()
    {
        var existing = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        var other = PizzaComponentType.Create("sauce", "Sauce", null, 2, 0, 1);
        _types.Seed(existing, other);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("topping", "Sauce", null, 4, 0, null)));

        Assert.That(exception!.Message, Does.Contain("Sauce"));
    }

    [Test]
    public void HandleAsync_throws_conflict_when_assembly_order_taken_by_another_type()
    {
        var existing = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        var other = PizzaComponentType.Create("sauce", "Sauce", null, 2, 0, 1);
        _types.Seed(existing, other);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("topping", "Topping", null, 2, 0, null)));

        Assert.That(exception!.Message, Does.Contain("2"));
    }

    [Test]
    public async Task HandleAsync_never_changes_the_code()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        _types.Seed(type);

        var result = await _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("topping", "Sauce", null, 2, 0, 1));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("topping"));
            Assert.That(type.Code.Value, Is.EqualTo("topping"));
        });
    }

    [Test]
    public void HandleAsync_rejects_an_invalid_code()
    {
        Assert.ThrowsAsync<LaPrizza.Domain.Common.DomainException>(() => _handler.HandleAsync(
            new UpdatePizzaComponentTypeCommand("Not A Code", "Sauce", null, 1, 0, 1)));
    }

    [Test]
    public void HandleAsync_rejects_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
