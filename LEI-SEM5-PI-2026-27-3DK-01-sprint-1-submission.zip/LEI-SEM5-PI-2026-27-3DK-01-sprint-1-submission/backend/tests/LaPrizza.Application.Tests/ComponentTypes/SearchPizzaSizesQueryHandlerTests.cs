using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes;
using LaPrizza.Application.ComponentTypes.SearchPizzaSizes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class SearchPizzaSizesQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_returns_items_and_paging_metadata_from_the_query_port()
    {
        var item = new PizzaSizeResult(Guid.NewGuid(), "xl", "Extra large.");
        var queries = new StubQueries(new PizzaSizeSearchPage([item], 37));
        var handler = new SearchPizzaSizesQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchPizzaSizesQuery("x", 2, 10));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.EqualTo(new[] { item }));
            Assert.That(result.Page, Is.EqualTo(2));
            Assert.That(result.PageSize, Is.EqualTo(10));
            Assert.That(result.TotalCount, Is.EqualTo(37));
            Assert.That(queries.LastSearch, Is.EqualTo("x"));
            Assert.That(queries.LastPage, Is.EqualTo(2));
            Assert.That(queries.LastPageSize, Is.EqualTo(10));
        });
    }

    [Test]
    public async Task HandleAsync_uses_the_default_page_and_page_size()
    {
        var queries = new StubQueries(new PizzaSizeSearchPage([], 0));
        var handler = new SearchPizzaSizesQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchPizzaSizesQuery(null));

        Assert.Multiple(() =>
        {
            Assert.That(result.Page, Is.EqualTo(SearchPizzaSizesQuery.DefaultPage));
            Assert.That(result.PageSize, Is.EqualTo(SearchPizzaSizesQuery.DefaultPageSize));
            Assert.That(queries.LastSearch, Is.Null);
            Assert.That(queries.LastPage, Is.EqualTo(1));
            Assert.That(queries.LastPageSize, Is.EqualTo(20));
        });
    }

    [TestCase(0, 20)]
    [TestCase(-1, 20)]
    [TestCase(1, 0)]
    [TestCase(1, -1)]
    [TestCase(1, 101)]
    public void HandleAsync_rejects_out_of_range_paging(int page, int pageSize)
    {
        var queries = new StubQueries(new PizzaSizeSearchPage([], 0));
        var handler = new SearchPizzaSizesQueryHandler(queries);

        Assert.ThrowsAsync<ValidationException>(async () =>
            await handler.HandleAsync(new SearchPizzaSizesQuery(null, page, pageSize)));
        Assert.That(queries.Calls, Is.Zero);
    }

    [TestCase(1)]
    [TestCase(100)]
    public async Task HandleAsync_accepts_page_size_boundaries(int pageSize)
    {
        var queries = new StubQueries(new PizzaSizeSearchPage([], 0));
        var handler = new SearchPizzaSizesQueryHandler(queries);

        await handler.HandleAsync(new SearchPizzaSizesQuery(null, 1, pageSize));

        Assert.That(queries.LastPageSize, Is.EqualTo(pageSize));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        var handler = new SearchPizzaSizesQueryHandler(
            new StubQueries(new PizzaSizeSearchPage([], 0)));

        Assert.ThrowsAsync<ArgumentNullException>(() => handler.HandleAsync(null!));
    }

    private sealed class StubQueries(PizzaSizeSearchPage result) : IPizzaSizeQueries
    {
        public string? LastSearch { get; private set; }
        public int LastPage { get; private set; }
        public int LastPageSize { get; private set; }
        public int Calls { get; private set; }

        public Task<PizzaSizeSearchPage> SearchAsync(
            string? search,
            int page,
            int pageSize,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Calls++;
            LastSearch = search;
            LastPage = page;
            LastPageSize = pageSize;
            return Task.FromResult(result);
        }
    }
}
