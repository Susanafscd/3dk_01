using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.DeletePizzaComponentType;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class DeletePizzaComponentTypeCommandHandlerTests
{
    private FakePizzaComponentTypeRepository _types = null!;
    private DeletePizzaComponentTypeCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _types = new FakePizzaComponentTypeRepository();
        _handler = new DeletePizzaComponentTypeCommandHandler(_types);
    }

    [Test]
    public async Task HandleAsync_removes_the_type()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        _types.Seed(type);

        await _handler.HandleAsync(new DeletePizzaComponentTypeCommand("topping"));

        Assert.Multiple(() =>
        {
            Assert.That(_types.Types, Is.Empty);
            Assert.That(_types.RemoveCount, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_throws_not_found_when_missing()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.HandleAsync(
            new DeletePizzaComponentTypeCommand("missing")));
    }

    [Test]
    public void HandleAsync_throws_conflict_when_in_use()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        _types.Seed(type);
        _types.InUseIds.Add(type.Id);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new DeletePizzaComponentTypeCommand("topping")));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("topping"));
            Assert.That(exception.Message, Does.Not.Contain(type.Id.ToString()));
        });
    }

    [Test]
    public void HandleAsync_rejects_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
