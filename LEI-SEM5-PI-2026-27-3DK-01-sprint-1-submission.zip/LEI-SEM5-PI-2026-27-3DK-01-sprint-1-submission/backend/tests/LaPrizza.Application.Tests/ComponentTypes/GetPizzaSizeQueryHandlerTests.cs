using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ComponentTypes.GetPizzaSize;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ComponentTypes;

namespace LaPrizza.Application.Tests.ComponentTypes;

[TestFixture]
public sealed class GetPizzaSizeQueryHandlerTests
{
    private FakePizzaSizeRepository _sizes = null!;
    private GetPizzaSizeQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _sizes = new FakePizzaSizeRepository();
        _handler = new GetPizzaSizeQueryHandler(_sizes);
    }

    [Test]
    public async Task HandleAsync_returns_the_requested_size()
    {
        var requested = PizzaSize.Create("xl", "Extra large, 40 cm.");
        _sizes.Seed(PizzaSize.Create("m", "Medium."), requested);

        var result = await _handler.HandleAsync(new GetPizzaSizeQuery(requested.Id));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.EqualTo(requested.Id));
            Assert.That(result.Name, Is.EqualTo("xl"));
            Assert.That(result.Description, Is.EqualTo("Extra large, 40 cm."));
        });
    }

    [Test]
    public async Task HandleAsync_preserves_a_null_description()
    {
        var size = PizzaSize.Create("m");
        _sizes.Seed(size);

        var result = await _handler.HandleAsync(new GetPizzaSizeQuery(size.Id));

        Assert.That(result.Description, Is.Null);
    }

    [Test]
    public void HandleAsync_throws_not_found_for_an_unknown_id()
    {
        var id = Guid.NewGuid();

        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new GetPizzaSizeQuery(id)));

        Assert.That(exception!.Message, Does.Contain(id.ToString()));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
