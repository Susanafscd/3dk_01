using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.CreateProduct;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Product;

[TestFixture]
public sealed class CreateProductCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakeProductRelationshipQueries _relationships = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private ProductChangePolicy _policy = null!;
    private CreateProductCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _relationships = new FakeProductRelationshipQueries();
        _policy = new ProductChangePolicy();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new CreateProductCommandHandler(_products, _relationships, _policy, _cache);
    }

    [Test]
    public async Task HandleAsync_creates_and_returns_product_projection()
    {
        var command = ValidCommand();

        var result = await _handler.HandleAsync(command);

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("mozzarella"));
            Assert.That(result.Name, Is.EqualTo("Mozzarella"));
            Assert.That(result.Description, Is.EqualTo("Fresh cheese used in preparation"));
            Assert.That(result.CategoryCode, Is.EqualTo("pizza-ingredients"));
            // Adjust property names below if your CreateProductResult record defines them differently (e.g., Sellable / Price)
            Assert.That(result.StockControlled, Is.True);
            Assert.That(result.Active, Is.True);
            Assert.That(result.AllergenCodes, Does.Contain("milk"));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void HandleAsync_rejects_duplicate_product_code()
    {
        _products.Seed(NewProduct());

        var command = ValidCommand();

        Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(command));
    }

    [Test]
    public void HandleAsync_rejects_invalid_references()
    {
        _relationships.SimulateInvalidReferences();

        var command = ValidCommand();

        Assert.ThrowsAsync<InvalidProductException>(() => _handler.HandleAsync(command));
    }

    [Test]
    public async Task HandleAsync_initializes_stock_at_zero_for_stock_controlled_product()
    {
        var result = await _handler.HandleAsync(ValidCommand());
        Assert.That(result.StockBalance, Is.Zero);
    }

    [Test]
    public void HandleAsync_rejects_duplicate_allergen_codes()
    {
        var cmd = ValidCommand() with { AllergenCodes = ["milk", "milk"] };
        Assert.ThrowsAsync<InvalidProductException>(() => _handler.HandleAsync(cmd));
        Assert.That(_products.Products, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_excess_price_precision()
    {
        var cmd = ValidCommand() with { Price = 1.234m };
        Assert.ThrowsAsync<InvalidProductException>(() => _handler.HandleAsync(cmd));
        Assert.That(_products.Products, Is.Empty);
    }

    [Test]
    public void HandleAsync_rejects_null_allergen_codes()
    {
        var cmd = ValidCommand() with { AllergenCodes = null };
        Assert.ThrowsAsync<InvalidProductException>(() => _handler.HandleAsync(cmd));
        Assert.That(_products.Products, Is.Empty);
    }

    [Test]
    public void HandleAsync_requires_a_component_type_for_a_component_category()
    {
        _relationships.AllowComponentTypes();

        Assert.ThrowsAsync<InvalidProductException>(
            () => _handler.HandleAsync(ValidCommand() with { CategoryCode = "pizza-component" }));
        Assert.That(_products.Products, Is.Empty);
    }

    [Test]
    public async Task HandleAsync_persists_the_explicit_component_type_code()
    {
        _relationships.AllowComponentTypes();

        var result = await _handler.HandleAsync(ValidCommand() with
        {
            CategoryCode = "pizza-component",
            ComponentTypeCode = "base-dough"
        });

        Assert.Multiple(() =>
        {
            Assert.That(result.ComponentTypeCode, Is.EqualTo("base-dough"));
            Assert.That(_products.Products.Single().ComponentTypeCode, Is.EqualTo("base-dough"));
        });
    }

    private static CreateProductCommand ValidCommand() => new(
        Code: "mozzarella",
        Name: "Mozzarella",
        Description: "Fresh cheese used in preparation",
        CategoryCode: "pizza-ingredients",
        Sellable: true,
        Price: 4.50m,
        StockControlled: true,
        AllergenCodes: ["milk"]
    );

    private static BaseProduct NewProduct() => new BaseProductBuilder()
        .WithCode("mozzarella")
        .WithName("Mozzarella")
        .WithDescription("Fresh cheese")
        .InCategory("pizza-ingredients")
        .AsSellable()
        .WithPrice(4.50m)
        .StockControlled()
        .WithAllergens(["milk"])
        .Build();
}
