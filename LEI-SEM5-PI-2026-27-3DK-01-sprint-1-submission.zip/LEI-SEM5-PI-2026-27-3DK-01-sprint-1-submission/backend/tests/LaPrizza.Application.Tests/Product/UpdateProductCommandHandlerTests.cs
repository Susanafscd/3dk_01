using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.UpdateProduct;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;

namespace LaPrizza.Application.Tests.Product;

[TestFixture]
public sealed class UpdateProductCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakeProductRelationshipQueries _relationships = null!;
    private FakeProductUpdateQueries _dependencies = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private UpdateProductCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _relationships = new FakeProductRelationshipQueries();
        _dependencies = new FakeProductUpdateQueries();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new UpdateProductCommandHandler(_products, _relationships, _dependencies, _cache);
    }

    [Test]
    public async Task ExecuteAsync_updates_details_and_invalidates_products_after_save()
    {
        var product = Product();
        _products.Seed(product);

        var result = await _handler.ExecuteAsync(Command());

        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Updated"));
            Assert.That(result.Description, Is.EqualTo("Updated description"));
            Assert.That(result.Code, Is.EqualTo("sample"));
            Assert.That(result.AllergenCodes, Is.EqualTo(new[] { "milk" }));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
            Assert.That(product.Active, Is.True);
        });
    }

    [Test]
    public async Task ExecuteAsync_disables_stock_control_and_clears_zero_balance()
    {
        var product = Product();
        _products.Seed(product);

        var result = await _handler.ExecuteAsync(Command() with { StockControlled = false });

        Assert.Multiple(() =>
        {
            Assert.That(result.StockControlled, Is.False);
            Assert.That(result.StockBalance, Is.Null);
            Assert.That(product.StockBalance, Is.Null);
        });
    }

    [Test]
    public void ExecuteAsync_rejects_nonzero_stock_without_mutating_details()
    {
        var product = Product();
        product.IncreaseStock(2);
        _products.Seed(product);

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.ExecuteAsync(Command() with { StockControlled = false }));
        Assert.Multiple(() =>
        {
            Assert.That(product.Name, Is.EqualTo("Original"));
            Assert.That(product.StockBalance, Is.EqualTo(2));
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void ExecuteAsync_rejects_a_product_used_by_a_composed_product_when_category_changes()
    {
        var product = Product();
        _products.Seed(product);
        _dependencies.ReferencedByComposedProduct = true;

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.ExecuteAsync(Command() with { CategoryCode = "other-category" }));
        Assert.That(product.CategoryCode.Value, Is.EqualTo("ingredients"));
    }

    [Test]
    public void ExecuteAsync_rejects_unknown_product_without_writing()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.ExecuteAsync(Command()));
        Assert.That(_cache.Invalidations, Is.Zero);
    }

    private static UpdateProductCommand Command() => new(
        "sample", "Updated", "Updated description", "ingredients", true, true, 3.50m, ["milk"]);

    private static BaseProduct Product() => new BaseProductBuilder()
        .WithCode("sample")
        .WithName("Original")
        .WithDescription("Original description")
        .InCategory("ingredients")
        .AsSellable()
        .WithPrice(2.50m)
        .StockControlled()
        .WithAllergens([])
        .Build();
}
