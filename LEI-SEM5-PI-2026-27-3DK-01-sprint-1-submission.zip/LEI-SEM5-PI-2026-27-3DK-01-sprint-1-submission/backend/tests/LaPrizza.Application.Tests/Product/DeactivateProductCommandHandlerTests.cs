using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.DeactivateProduct;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Product;

[TestFixture]
public sealed class DeactivateProductCommandHandlerTests
{
    private FakeProductRepository _products = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private DeactivateProductCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _products = new FakeProductRepository();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new DeactivateProductCommandHandler(_products, _cache);
    }

    [Test]
    public async Task Active_product_is_deactivated_without_losing_aggregate_state()
    {
        var product = Product();
        product.IncreaseStock(5);
        _products.Seed(product);

        await _handler.ExecuteAsync(new DeactivateProductCommand("cheese"));

        Assert.Multiple(() =>
        {
            Assert.That(product.Active, Is.False);
            Assert.That(product.Code.Value, Is.EqualTo("cheese"));
            Assert.That(product.StockBalance, Is.EqualTo(5));
            Assert.That(product.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "milk" }));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Repeated_deactivation_is_idempotent()
    {
        var product = Product();
        _products.Seed(product);

        await _handler.ExecuteAsync(new DeactivateProductCommand("cheese"));
        await _handler.ExecuteAsync(new DeactivateProductCommand("cheese"));

        Assert.Multiple(() =>
        {
            Assert.That(product.Active, Is.False);
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void Unknown_product_is_reported_without_cache_invalidation()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.ExecuteAsync(new DeactivateProductCommand("missing")));
        Assert.That(_cache.Invalidations, Is.Zero);
    }

    [Test]
    public async Task Deactivating_one_product_does_not_change_another_product()
    {
        var selected = Product("cheese");
        var other = Product("tomato");
        _products.Seed(selected, other);

        await _handler.ExecuteAsync(new DeactivateProductCommand("cheese"));

        Assert.Multiple(() =>
        {
            Assert.That(selected.Active, Is.False);
            Assert.That(other.Active, Is.True);
        });
    }

    [Test]
    public async Task Deactivating_a_composed_product_preserves_its_component_codes()
    {
        var pizza = ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
            [new ComponentTypeLimit("base-dough", 1, 1)],
            ["small"]);
        _products.Seed(pizza);

        await _handler.ExecuteAsync(new DeactivateProductCommand("margherita"));

        Assert.Multiple(() =>
        {
            Assert.That(pizza.Active, Is.False);
            Assert.That(pizza.Components.Select(component => component.Value), Is.EqualTo(new[] { "classic-dough" }));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Deactivating_a_component_does_not_deactivate_a_composed_product_that_references_it()
    {
        var component = Product("classic-dough");
        var pizza = ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
            [new ComponentTypeLimit("base-dough", 1, 1)],
            ["small"]);
        _products.Seed(component, pizza);

        await _handler.ExecuteAsync(new DeactivateProductCommand("classic-dough"));

        Assert.Multiple(() =>
        {
            Assert.That(component.Active, Is.False);
            Assert.That(pizza.Active, Is.True);
            Assert.That(pizza.Components.Select(code => code.Value), Is.EqualTo(new[] { "classic-dough" }));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    private static BaseProduct Product(string code = "cheese") => new BaseProductBuilder()
        .WithCode(code)
        .WithName(code)
        .WithDescription("Test product")
        .InCategory("ingredients")
        .AsSellable()
        .WithPrice(2.50m)
        .StockControlled()
        .WithAllergens(["milk"])
        .Build();
}
