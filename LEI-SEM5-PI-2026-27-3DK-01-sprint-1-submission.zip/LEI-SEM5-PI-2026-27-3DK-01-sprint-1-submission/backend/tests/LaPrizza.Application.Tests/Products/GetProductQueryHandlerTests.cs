using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Catalogue;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Products;

[TestFixture]
public sealed class GetProductQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_returns_the_complete_base_product_projection()
    {
        var product = new BaseProductBuilder()
            .WithCode("margherita")
            .WithName("Margherita")
            .WithDescription("Tomato and cheese")
            .InCategory("pizza")
            .AsSellable()
            .WithPrice(9.50m)
            .StockControlled()
            .WithAllergens(["milk", "gluten"])
            .Build();
        var products = new FakeProductRepository();
        products.Seed(product);

        var result = await new GetProductQueryHandler(products)
            .HandleAsync(new GetProductQuery("margherita"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.EqualTo(product.Id));
            Assert.That(result.Code, Is.EqualTo("margherita"));
            Assert.That(result.Name, Is.EqualTo("Margherita"));
            Assert.That(result.CategoryCode, Is.EqualTo("pizza"));
            Assert.That(result.Sellable, Is.True);
            Assert.That(result.Price, Is.EqualTo(9.50m));
            Assert.That(result.StockControlled, Is.True);
            Assert.That(result.StockBalance, Is.EqualTo(0));
            Assert.That(result.AllergenCodes, Is.EqualTo(new[] { "gluten", "milk" }));
        });
    }

    [Test]
    public void HandleAsync_returns_not_found_for_an_unknown_code()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            new GetProductQueryHandler(new FakeProductRepository())
                .HandleAsync(new GetProductQuery("unknown")));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Pizza-Component")]
    [TestCase("pizza_component")]
    public void HandleAsync_rejects_a_malformed_business_code(string? code)
    {
        Assert.ThrowsAsync<InvalidProductException>(() =>
            new GetProductQueryHandler(new FakeProductRepository())
                .HandleAsync(new GetProductQuery(code)));
    }

    [Test]
    public async Task HandleAsync_preserves_the_stored_active_flag_without_mutating_the_product()
    {
        var product = new BaseProductBuilder()
            .WithCode("retired")
            .WithName("Retired")
            .WithDescription("Currently sold")
            .InCategory("pizza")
            .AsSellable()
            .WithPrice(5m)
            .WithAllergens([])
            .Build();
        var products = new FakeProductRepository();
        products.Seed(product);

        var result = await new GetProductQueryHandler(products)
            .HandleAsync(new GetProductQuery("retired"));

        Assert.That(result.Active, Is.True);
        Assert.That(product.Code.Value, Is.EqualTo("retired"));
    }

    [Test]
    public async Task HandleAsync_uses_the_catalogue_cache_port_with_the_business_code_key()
    {
        var products = new FakeProductRepository();
        products.Seed(new BaseProductBuilder()
            .WithCode("cached")
            .WithName("Cached")
            .WithDescription("Cached product")
            .InCategory("pizza")
            .AsSellable()
            .WithPrice(1m)
            .WithAllergens([])
            .Build());
        var cache = new RecordingProductCache();

        var result = await new GetProductQueryHandler(products, cache)
            .HandleAsync(new GetProductQuery("cached"));

        Assert.That(result.Code, Is.EqualTo("cached"));
        Assert.That(cache.Code, Is.EqualTo("cached"));
        Assert.That(cache.Calls, Is.EqualTo(1));
    }

    private sealed class RecordingProductCache : IProductCatalogueCache
    {
        public string? Code { get; private set; }
        public int Calls { get; private set; }

        public async Task<ProductLookupResult> GetByCodeAsync(
            string code,
            Func<CancellationToken, Task<ProductLookupResult>> factory,
            CancellationToken cancellationToken = default)
        {
            Code = code;
            Calls++;
            return await factory(cancellationToken);
        }

        public Task<CatalogueResult> GetListAsync(
            int page,
            int pageSize,
            Func<CancellationToken, Task<CatalogueResult>> factory,
            CancellationToken cancellationToken = default) =>
            factory(cancellationToken);

        public Task<CatalogueProductResult?> GetByIdAsync(
            Guid id,
            Func<CancellationToken, Task<CatalogueProductResult?>> factory,
            CancellationToken cancellationToken = default) =>
            factory(cancellationToken);
    }
}
