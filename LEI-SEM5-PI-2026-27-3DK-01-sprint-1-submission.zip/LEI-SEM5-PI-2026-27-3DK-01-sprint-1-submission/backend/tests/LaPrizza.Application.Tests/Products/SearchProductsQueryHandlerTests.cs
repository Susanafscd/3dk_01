using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Products.SearchProducts;
using LaPrizza.Domain.Products;

namespace LaPrizza.Application.Tests.Products;

[TestFixture]
public sealed class SearchProductsQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_forwards_all_filters_and_returns_metadata()
    {
        var queries = new StubQueries(new ProductSearchPage([], 12));
        var handler = new SearchProductsQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchProductsQuery(
            "mar", "pizza", "milk", "pizza-base", true, false, true,
            "Base", true, 2, 10));

        Assert.Multiple(() =>
        {
            Assert.That(result.Page, Is.EqualTo(2));
            Assert.That(result.PageSize, Is.EqualTo(10));
            Assert.That(result.TotalCount, Is.EqualTo(12));
            Assert.That(queries.Criteria.Search, Is.EqualTo("mar"));
            Assert.That(queries.Criteria.CategoryCode!.Value, Is.EqualTo("pizza"));
            Assert.That(queries.Criteria.AllergenCode!.Value, Is.EqualTo("milk"));
            Assert.That(queries.Criteria.ComponentTypeCode, Is.EqualTo("pizza-base"));
            Assert.That(queries.Criteria.Kind, Is.EqualTo(ProductKind.Base));
        });
    }

    [Test]
    public void HandleAsync_rejects_component_type_without_category()
    {
        var handler = new SearchProductsQueryHandler(new StubQueries(new ProductSearchPage([], 0)));

        Assert.ThrowsAsync<ValidationException>(() => handler.HandleAsync(
            new SearchProductsQuery(ComponentTypeCode: "pizza-base")));
    }

    [TestCase(0, 20)]
    [TestCase(1, 101)]
    public void HandleAsync_rejects_invalid_paging(int page, int pageSize)
    {
        var handler = new SearchProductsQueryHandler(new StubQueries(new ProductSearchPage([], 0)));

        Assert.ThrowsAsync<ValidationException>(() => handler.HandleAsync(
            new SearchProductsQuery(Page: page, PageSize: pageSize)));
    }

    private sealed class StubQueries(ProductSearchPage page) : IProductQueries
    {
        public ProductSearchCriteria Criteria { get; private set; } = null!;

        public Task<ProductSearchPage> SearchAsync(
            ProductSearchCriteria criteria,
            CancellationToken cancellationToken = default)
        {
            Criteria = criteria;
            return Task.FromResult(page);
        }
    }
}
