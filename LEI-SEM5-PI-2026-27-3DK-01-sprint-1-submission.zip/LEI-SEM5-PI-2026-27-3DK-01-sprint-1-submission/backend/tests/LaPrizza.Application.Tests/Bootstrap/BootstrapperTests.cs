using LaPrizza.Application.Abstractions;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Bootstrap.Domain.Allergens;
using LaPrizza.Bootstrap.Domain.Customers;
using LaPrizza.Bootstrap.Domain.ProductCategories;
using LaPrizza.Bootstrap.Domain.Products;
using LaPrizza.Bootstrap.Orchestration;
using LaPrizza.Bootstrap.Roles;
using LaPrizza.Bootstrapper;
using LaPrizza.Bootstrapper.Orchestration;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Users;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;

namespace LaPrizza.Application.Tests.Bootstrap;

[TestFixture]
public sealed class BootstrapperTests
{
    private FakeUserRepository _users = null!;
    private Mock<RoleManager<IdentityRole>> _roleManager = null!;
    private FakeProductCategoryRepository _productCategories = null!;
    private FakeAllergenRepository _allergens = null!;
    private FakePizzaSizeRepository _pizzaSizes = null!;
    private FakeProductRepository _products = null!;
    private FakeProductRelationshipQueries _productRelationships = null!;
    private FakeUserAccountManager _accounts = null!;
    private FakeUnitOfWork _unitOfWork = null!;
    private FakeCatalogueCacheInvalidator _cacheInvalidator = null!;
    private ServiceProvider _provider = null!;
    private IServiceScope _scope = null!;
    private BootstrapRunner _bootstrapper = null!;

    [SetUp]
    public void SetUp()
    {
        _unitOfWork = new FakeUnitOfWork();
        _users = new FakeUserRepository(_unitOfWork);
        var store = new Mock<IRoleStore<IdentityRole>>();
        _roleManager = new Mock<RoleManager<IdentityRole>>(
            store.Object, null, null, null, null);
        _productCategories = new FakeProductCategoryRepository();
        _allergens = new FakeAllergenRepository();
        _pizzaSizes = new FakePizzaSizeRepository();
        _products = new FakeProductRepository();
        _productRelationships = new FakeProductRelationshipQueries();
        _productRelationships.AllowComponentTypes();
        _accounts = new FakeUserAccountManager();
        _cacheInvalidator = new FakeCatalogueCacheInvalidator();

        var services = new ServiceCollection();
        services.AddSingleton<IUserRepository>(_users);
        services.AddSingleton<RoleManager<IdentityRole>>(_roleManager.Object);
        services.AddSingleton<LaPrizza.Domain.ProductCategories.IProductCategoryRepository>(_productCategories);
        services.AddSingleton<IAllergenRepository>(_allergens);
        services.AddSingleton<LaPrizza.Domain.ComponentTypes.IPizzaSizeRepository>(_pizzaSizes);
        services.AddSingleton<LaPrizza.Domain.Product.IProductRepository>(_products);
        services.AddSingleton<LaPrizza.Domain.Product.IProductRelationshipQueries>(_productRelationships);
        services.AddSingleton<IUserAccountManager>(_accounts);
        services.AddSingleton<IUnitOfWork>(_unitOfWork);
        services.AddSingleton<ICatalogueCacheInvalidator>(_cacheInvalidator);
        services.AddApplication();

        services.AddScoped<IDataSeeder, RoleBootstrap>();
        services.AddScoped<IDataSeeder, ManagerBootstrap>();
        services.AddScoped<IDataSeeder, CustomerBootstrap>();
        services.AddScoped<IDataSeeder, ProductCategoryBootstrap>();
        services.AddScoped<IDataSeeder, AllergenBootstrap>();
        services.AddScoped<IDataSeeder, LaPrizza.Bootstrap.Domain.Sizes.PizzaSizeBootstrap>();
        services.AddScoped<IDataSeeder, ProductBootstrap>();

        _provider = services.BuildServiceProvider();
        _scope = _provider.CreateScope();
        _bootstrapper = new BootstrapRunner(
            _scope.ServiceProvider.GetRequiredService<IEnumerable<IDataSeeder>>(),
            new BootstrapReporter(),
            NullLogger<BootstrapRunner>.Instance);
    }

    [TearDown]
    public void TearDown()
    {
        _scope.Dispose();
        _provider.Dispose();
    }

    [Test]
    public async Task RunAsync_creates_the_default_roles_manager_customers_categories_and_allergens()
    {
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(false);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(false);
        _roleManager.Setup(r => r.CreateAsync(It.IsAny<IdentityRole>())).ReturnsAsync(IdentityResult.Success);

        var result = await _bootstrapper.RunAsync(BootstrapScenario.Default);

        var manager = (Staff)_users.Added.OfType<Staff>().Single();
        var customers = _users.Added.OfType<Customer>().ToList();

        Assert.Multiple(() =>
        {
            Assert.That(result, Has.Count.EqualTo(29));

            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)), Has.Count.EqualTo(2));
            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            _roleManager.Verify(r => r.CreateAsync(It.Is<IdentityRole>(role => role.Name == "Manager")), Times.Once);
            _roleManager.Verify(r => r.CreateAsync(It.Is<IdentityRole>(role => role.Name == "Customer")), Times.Once);

            var userStep = Step(result, "User");
            Assert.That(userStep.Outcome, Is.EqualTo(BootstrapResult.Created));
            Assert.That(manager.Email, Is.EqualTo(Email.Create("manager@laprizza.local")));
            Assert.That(manager.DisplayName, Is.EqualTo("LaPrizza Manager"));
            Assert.That(manager.JobTitle, Is.EqualTo("Manager"));

            Assert.That(Steps(result, "Customer"), Has.Count.EqualTo(3));
            Assert.That(Steps(result, "Customer").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(customers, Has.Count.EqualTo(3));
            Assert.That(
                customers.Select(customer => customer.Email.Value),
                Is.EqualTo(new[]
                {
                    "customer@laprizza.local",
                    "maria.santos@example.com",
                    "joao.oliveira@example.com"
                }));

            Assert.That(Steps(result, "ProductCategory"), Has.Count.EqualTo(3));
            Assert.That(Steps(result, "ProductCategory").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(_productCategories.Categories, Has.Count.EqualTo(3));

            Assert.That(Steps(result, "Allergen"), Has.Count.EqualTo(14));
            Assert.That(Steps(result, "Allergen").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(_allergens.Allergens, Has.Count.EqualTo(14));

            Assert.That(Steps(result, nameof(PizzaSize)), Has.Count.EqualTo(3));
            Assert.That(Steps(result, nameof(PizzaSize)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(_pizzaSizes.Sizes, Has.Count.EqualTo(3));

            Assert.That(Steps(result, nameof(LaPrizza.Domain.Product.Product)), Has.Count.EqualTo(3));
            Assert.That(Steps(result, nameof(LaPrizza.Domain.Product.Product)).All(step => step.Outcome == BootstrapResult.Created), Is.True);

            Assert.That(_accounts.Created, Has.Count.EqualTo(4));
            Assert.That(_accounts.Created[0].Email, Is.EqualTo("manager@laprizza.local"));
            Assert.That(_accounts.Created[0].Password, Is.EqualTo("Manager123!"));
            Assert.That(
                _accounts.Created.Skip(1).Select(account => account.Email),
                Is.EqualTo(customers.Select(customer => customer.Email.Value)));

            Assert.That(_unitOfWork.SaveCount, Is.EqualTo(4));
        });
    }

    [Test]
    public async Task RunAsync_creates_the_manager_and_customers_when_the_roles_already_exist()
    {
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(true);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(true);

        var result = await _bootstrapper.RunAsync(BootstrapScenario.Default);

        Assert.Multiple(() =>
        {
            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)).All(step => step.Outcome == BootstrapResult.Skipped), Is.True);
            Assert.That(Step(result, "User").Outcome, Is.EqualTo(BootstrapResult.Created));
            Assert.That(Steps(result, "Customer"), Has.Count.EqualTo(3));
            Assert.That(Steps(result, "Customer").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, "ProductCategory").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, "Allergen").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, nameof(PizzaSize)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, nameof(LaPrizza.Domain.Product.Product)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(_users.Added, Has.Count.EqualTo(4));
            Assert.That(_accounts.Created, Has.Count.EqualTo(4));
            Assert.That(_unitOfWork.SaveCount, Is.EqualTo(4));
        });
    }

    [Test]
    public async Task RunAsync_persists_new_roles_and_customers_when_only_the_manager_exists()
    {
        _users.SeedExisting(Email.Create("manager@laprizza.local"));
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(false);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(false);
        _roleManager.Setup(r => r.CreateAsync(It.IsAny<IdentityRole>())).ReturnsAsync(IdentityResult.Success);

        var result = await _bootstrapper.RunAsync(BootstrapScenario.Default);

        Assert.Multiple(() =>
        {
            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Step(result, "User").Outcome, Is.EqualTo(BootstrapResult.Skipped));
            Assert.That(Steps(result, "Customer").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, "ProductCategory").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, "Allergen").All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, nameof(PizzaSize)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Steps(result, nameof(LaPrizza.Domain.Product.Product)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            _roleManager.Verify(r => r.CreateAsync(It.IsAny<IdentityRole>()), Times.Exactly(2));
            Assert.That(_users.Added.OfType<Staff>(), Is.Empty);
            Assert.That(_users.Added.OfType<Customer>(), Has.Exactly(3).Items);
            Assert.That(_accounts.Created, Has.Count.EqualTo(3));
            Assert.That(_unitOfWork.SaveCount, Is.EqualTo(3));
        });
    }

    [Test]
    public async Task RunAsync_is_a_no_op_when_everything_already_exists()
    {
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(false);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(false);
        _roleManager.Setup(r => r.CreateAsync(It.IsAny<IdentityRole>())).ReturnsAsync(IdentityResult.Success);

        await _bootstrapper.RunAsync(BootstrapScenario.Default);

        var accountsAfterFirstRun = _accounts.Created.Count;
        var savesAfterFirstRun = _unitOfWork.SaveCount;

        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(true);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(true);

        var result = await _bootstrapper.RunAsync(BootstrapScenario.Default);

        Assert.Multiple(() =>
        {
            Assert.That(result, Has.Count.EqualTo(29));
            Assert.That(result.All(step => step.Outcome == BootstrapResult.Skipped), Is.True);
            Assert.That(_users.Added, Has.Count.EqualTo(4));
            Assert.That(_accounts.Created, Has.Count.EqualTo(accountsAfterFirstRun));
            Assert.That(_unitOfWork.SaveCount, Is.EqualTo(savesAfterFirstRun));
        });
    }

    [Test]
    public async Task RunAsync_minimal_creates_only_the_roles_and_manager()
    {
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(false);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(false);
        _roleManager.Setup(r => r.CreateAsync(It.IsAny<IdentityRole>())).ReturnsAsync(IdentityResult.Success);
        var result = await _bootstrapper.RunAsync(BootstrapScenario.Minimal);

        Assert.Multiple(() =>
        {
            Assert.That(result, Has.Count.EqualTo(3));
            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)), Has.Count.EqualTo(2));
            Assert.That(Steps(result, nameof(Microsoft.AspNetCore.Identity.IdentityRole)).All(step => step.Outcome == BootstrapResult.Created), Is.True);
            Assert.That(Step(result, "User").Outcome, Is.EqualTo(BootstrapResult.Created));
            Assert.That(_users.Added.OfType<Customer>(), Is.Empty);
            Assert.That(_productCategories.Categories, Is.Empty);
            Assert.That(_allergens.Allergens, Is.Empty);
            Assert.That(_pizzaSizes.Sizes, Is.Empty);
            Assert.That(Steps(result, nameof(LaPrizza.Domain.Product.Product)), Is.Empty);
        });
    }

    [Test]
    public void RunAsync_deletes_the_account_when_the_manager_cannot_be_persisted()
    {
        _roleManager.Setup(r => r.RoleExistsAsync("Manager")).ReturnsAsync(true);
        _roleManager.Setup(r => r.RoleExistsAsync("Customer")).ReturnsAsync(true);
        _unitOfWork.FailWith = new InvalidOperationException("The database is unavailable.");

        Assert.ThrowsAsync<InvalidOperationException>(
            () => _bootstrapper.RunAsync(BootstrapScenario.Default));

        Assert.Multiple(() =>
        {
            Assert.That(_accounts.Created, Has.Count.EqualTo(1));
            Assert.That(_accounts.Deleted, Has.Count.EqualTo(1));
        });
    }

    private static BootstrapStepResult Step(IReadOnlyList<BootstrapStepResult> results, string entityType) =>
        results.Single(step => step.EntityType == entityType);

    private static List<BootstrapStepResult> Steps(IReadOnlyList<BootstrapStepResult> results, string entityType) =>
        [.. results.Where(step => step.EntityType == entityType)];
}
