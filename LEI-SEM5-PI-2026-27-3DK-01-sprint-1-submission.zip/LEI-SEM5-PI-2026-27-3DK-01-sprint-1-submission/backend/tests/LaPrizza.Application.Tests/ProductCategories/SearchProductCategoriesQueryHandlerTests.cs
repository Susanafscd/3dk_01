using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories;
using LaPrizza.Application.ProductCategories.SearchProductCategories;

namespace LaPrizza.Application.Tests.ProductCategories;

[TestFixture]
public sealed class SearchProductCategoriesQueryHandlerTests
{
    [Test]
    public async Task HandleAsync_returns_items_and_paging_metadata_from_the_query_port()
    {
        var item = new ProductCategorySearchItem(
            "pizza-component", "Pizza Component", null, true);
        var queries = new StubQueries(new ProductCategorySearchPage([item], 37));
        var handler = new SearchProductCategoriesQueryHandler(queries);

        var result = await handler.HandleAsync(
            new SearchProductCategoriesQuery("pizza", 2, 10));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.EqualTo(new[] { item }));
            Assert.That(result.Page, Is.EqualTo(2));
            Assert.That(result.PageSize, Is.EqualTo(10));
            Assert.That(result.TotalCount, Is.EqualTo(37));
            Assert.That(queries.LastSearch, Is.EqualTo("pizza"));
            Assert.That(queries.LastPage, Is.EqualTo(2));
            Assert.That(queries.LastPageSize, Is.EqualTo(10));
        });
    }

    [Test]
    public async Task HandleAsync_uses_the_default_page_and_page_size()
    {
        var queries = new StubQueries(new ProductCategorySearchPage([], 0));
        var handler = new SearchProductCategoriesQueryHandler(queries);

        var result = await handler.HandleAsync(new SearchProductCategoriesQuery(null));

        Assert.Multiple(() =>
        {
            Assert.That(result.Page, Is.EqualTo(1));
            Assert.That(result.PageSize, Is.EqualTo(20));
            Assert.That(queries.LastPage, Is.EqualTo(1));
            Assert.That(queries.LastPageSize, Is.EqualTo(20));
        });
    }

    [TestCase(0, 20)]
    [TestCase(-1, 20)]
    [TestCase(1, 0)]
    [TestCase(1, -1)]
    [TestCase(1, 101)]
    public void HandleAsync_rejects_out_of_range_paging(int page, int pageSize)
    {
        var handler = new SearchProductCategoriesQueryHandler(
            new StubQueries(new ProductCategorySearchPage([], 0)));

        Assert.ThrowsAsync<ValidationException>(async () =>
            await handler.HandleAsync(new SearchProductCategoriesQuery(null, page, pageSize)));
    }

    [TestCase(1)]
    [TestCase(100)]
    public async Task HandleAsync_accepts_page_size_boundaries(int pageSize)
    {
        var queries = new StubQueries(new ProductCategorySearchPage([], 0));
        var handler = new SearchProductCategoriesQueryHandler(queries);

        await handler.HandleAsync(new SearchProductCategoriesQuery(null, 1, pageSize));

        Assert.That(queries.LastPageSize, Is.EqualTo(pageSize));
    }

    private sealed class StubQueries(ProductCategorySearchPage result) : IProductCategoryQueries
    {
        public string? LastSearch { get; private set; }
        public int LastPage { get; private set; }
        public int LastPageSize { get; private set; }

        public Task<ProductCategorySearchPage> SearchAsync(
            string? search,
            int page,
            int pageSize,
            CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            LastSearch = search;
            LastPage = page;
            LastPageSize = pageSize;
            return Task.FromResult(result);
        }
    }
}
