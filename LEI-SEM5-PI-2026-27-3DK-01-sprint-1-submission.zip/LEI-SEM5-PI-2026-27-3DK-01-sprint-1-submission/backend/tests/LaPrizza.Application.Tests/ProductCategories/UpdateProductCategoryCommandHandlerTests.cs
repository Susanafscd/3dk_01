using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories.UpdateProductCategory;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;
using Moq;

namespace LaPrizza.Application.Tests.ProductCategories;

[TestFixture]
public sealed class UpdateProductCategoryCommandHandlerTests
{
    private FakeProductCategoryRepository _categories = null!;
    private Mock<IProductCategoryUsageQueries> _usage = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private UpdateProductCategoryCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _categories = new FakeProductCategoryRepository();
        _usage = new Mock<IProductCategoryUsageQueries>();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new UpdateProductCategoryCommandHandler(
            _categories, _usage.Object, _cache);
    }

    [Test]
    public async Task Updates_editable_fields_and_preserves_business_code()
    {
        var category = ProductCategory.Create("pizza-component", "Old", "Old description", true);
        _categories.Seed(category);

        var result = await _handler.ExecuteAsync(new UpdateProductCategoryCommand(
            "pizza-component", "New", "New description", true));

        Assert.Multiple(() =>
        {
            Assert.That(category.Code.Value, Is.EqualTo("pizza-component"));
            Assert.That(category.Name, Is.EqualTo("New"));
            Assert.That(category.Description, Is.EqualTo("New description"));
            Assert.That(result.Code, Is.EqualTo("pizza-component"));
            Assert.That(_categories.UpdateCount, Is.EqualTo(1));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void Rejects_disabling_component_types_when_the_category_is_referenced()
    {
        var category = ProductCategory.Create("pizza-component", "Old", null, true);
        _categories.Seed(category);
        _usage.Setup(query => query.HasComponentTypeReferencesAsync(
                category.Code, It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        Assert.ThrowsAsync<ConflictException>(() => _handler.ExecuteAsync(
            new UpdateProductCategoryCommand("pizza-component", "New", null, false)));

        Assert.Multiple(() =>
        {
            Assert.That(category.AllowsComponentTypes, Is.True);
            Assert.That(category.Name, Is.EqualTo("Old"));
            Assert.That(_categories.UpdateCount, Is.Zero);
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void Invalid_name_does_not_persist_or_invalidate()
    {
        var category = ProductCategory.Create("pizza-component", "Old", null, true);
        _categories.Seed(category);

        Assert.ThrowsAsync<DomainException>(() => _handler.ExecuteAsync(
            new UpdateProductCategoryCommand("pizza-component", "", null, true)));

        Assert.Multiple(() =>
        {
            Assert.That(category.Name, Is.EqualTo("Old"));
            Assert.That(_categories.UpdateCount, Is.Zero);
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void Unknown_code_is_not_found()
    {
        Assert.ThrowsAsync<NotFoundException>(() => _handler.ExecuteAsync(
            new UpdateProductCategoryCommand("missing", "Name", null, false)));
    }
}
