using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories.RemoveProductCategory;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.ProductCategories;
using Moq;

namespace LaPrizza.Application.Tests.ProductCategories;

[TestFixture]
public sealed class RemoveProductCategoryCommandHandlerTests
{
    private FakeProductCategoryRepository _categories = null!;
    private Mock<IProductCategoryUsageQueries> _usage = null!;
    private FakeCatalogueCacheInvalidator _cache = null!;
    private RemoveProductCategoryCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _categories = new FakeProductCategoryRepository();
        _usage = new Mock<IProductCategoryUsageQueries>();
        _cache = new FakeCatalogueCacheInvalidator();
        _handler = new RemoveProductCategoryCommandHandler(_categories, _usage.Object, _cache);
    }

    [Test]
    public async Task ExecuteAsync_removes_an_unused_category_and_invalidates_afterwards()
    {
        _categories.Seed(ProductCategory.Create("unused", "Unused", null, false));

        await _handler.ExecuteAsync(new RemoveProductCategoryCommand("unused"));

        Assert.Multiple(() =>
        {
            Assert.That(_categories.Categories, Is.Empty);
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public void ExecuteAsync_rejects_a_referenced_category_without_mutating_or_invalidating()
    {
        var category = ProductCategory.Create("used", "Used", null, false);
        _categories.Seed(category);
        _usage.Setup(query => query.HasProductReferencesAsync(category.Code, It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.ExecuteAsync(new RemoveProductCategoryCommand("used")));

        Assert.Multiple(() =>
        {
            Assert.That(_categories.Categories, Has.Count.EqualTo(1));
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void ExecuteAsync_rejects_a_category_referenced_by_component_types()
    {
        var category = ProductCategory.Create("pizza-component", "Pizza component", null, true);
        _categories.Seed(category);
        _usage.Setup(query => query.HasComponentTypeReferencesAsync(
                category.Code, It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        Assert.ThrowsAsync<ConflictException>(() =>
            _handler.ExecuteAsync(new RemoveProductCategoryCommand("pizza-component")));

        Assert.Multiple(() =>
        {
            Assert.That(_categories.Categories, Has.Count.EqualTo(1));
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public void ExecuteAsync_returns_not_found_for_an_unknown_business_code()
    {
        Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.ExecuteAsync(new RemoveProductCategoryCommand("unknown")));
        Assert.That(_cache.Invalidations, Is.Zero);
    }
}
