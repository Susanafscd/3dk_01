using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories.CreateProductCategory;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.Tests.ProductCategories;

[TestFixture]
public sealed class CreateProductCategoryCommandHandlerTests
{
    private FakeProductCategoryRepository _categories = null!;
    private CreateProductCategoryCommandHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _categories = new FakeProductCategoryRepository();
        _handler = new CreateProductCategoryCommandHandler(_categories);
    }

    [Test]
    public async Task HandleAsync_creates_category_with_requested_association_option()
    {
        var result = await _handler.HandleAsync(
            new CreateProductCategoryCommand("pizza-component", "Pizza Component", null, true));

        Assert.Multiple(() =>
        {
            Assert.That(result.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(result.Code, Is.EqualTo("pizza-component"));
            Assert.That(result.AllowsComponentTypes, Is.True);
            Assert.That(_categories.Categories, Has.Count.EqualTo(1));
            Assert.That(_categories.AddCount, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task HandleAsync_throws_conflict_without_overwriting_an_existing_code()
    {
        var existing = ProductCategory.Create("beverages", "Existing", "Keep", false);
        _categories.Seed(existing);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreateProductCategoryCommand("beverages", "Replacement", null, true)));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("beverages"));
            Assert.That(_categories.Categories, Has.Count.EqualTo(1));
            Assert.That(_categories.Categories.Single().Name, Is.EqualTo("Existing"));
            Assert.That(_categories.AddCount, Is.Zero);
        });
    }

    [Test]
    public void HandleAsync_maps_a_duplicate_insert_race_to_conflict()
    {
        _categories.ExistingCategoryOnNextAdd = ProductCategory.Create(
            "beverages", "Concurrent category", null, false);

        var exception = Assert.ThrowsAsync<ConflictException>(() => _handler.HandleAsync(
            new CreateProductCategoryCommand("beverages", "Beverages", null, false)));

        Assert.That(exception!.Message, Does.Contain("beverages"));
    }

    [Test]
    public void HandleAsync_rejects_invalid_domain_data_before_adding()
    {
        Assert.ThrowsAsync<DomainException>(() => _handler.HandleAsync(
            new CreateProductCategoryCommand("Beverages", "Beverages", null, false)));

        Assert.That(_categories.AddCount, Is.Zero);
    }

    [Test]
    public void HandleAsync_rejects_null_command()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
