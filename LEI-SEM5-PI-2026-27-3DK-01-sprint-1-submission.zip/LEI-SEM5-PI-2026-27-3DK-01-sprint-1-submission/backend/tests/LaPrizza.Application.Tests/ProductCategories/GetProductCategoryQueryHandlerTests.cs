using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.ProductCategories.GetProductCategory;
using LaPrizza.Application.Tests.Fakes;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Application.Tests.ProductCategories;

[TestFixture]
public sealed class GetProductCategoryQueryHandlerTests
{
    private FakeProductCategoryRepository _categories = null!;
    private GetProductCategoryQueryHandler _handler = null!;

    [SetUp]
    public void SetUp()
    {
        _categories = new FakeProductCategoryRepository();
        _handler = new GetProductCategoryQueryHandler(_categories);
    }

    [Test]
    public async Task HandleAsync_returns_all_four_public_fields_for_the_requested_code()
    {
        _categories.Seed(
            ProductCategory.Create("beverages", "Beverages", "Cold drinks.", false),
            ProductCategory.Create("pizza-component", "Pizza Component", "Pizza parts.", true));

        var result = await _handler.HandleAsync(
            new GetProductCategoryQuery("pizza-component"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Code, Is.EqualTo("pizza-component"));
            Assert.That(result.Name, Is.EqualTo("Pizza Component"));
            Assert.That(result.Description, Is.EqualTo("Pizza parts."));
            Assert.That(result.AllowsComponentTypes, Is.True);
        });
    }

    [Test]
    public async Task HandleAsync_preserves_a_null_description_and_false_flag()
    {
        _categories.Seed(ProductCategory.Create("beverages", "Beverages", null, false));

        var result = await _handler.HandleAsync(new GetProductCategoryQuery("beverages"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Description, Is.Null);
            Assert.That(result.AllowsComponentTypes, Is.False);
        });
    }

    [Test]
    public void HandleAsync_rejects_an_unknown_business_code()
    {
        var exception = Assert.ThrowsAsync<NotFoundException>(() =>
            _handler.HandleAsync(new GetProductCategoryQuery("unknown")));

        Assert.That(exception!.Message, Does.Contain("unknown"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Pizza-Component")]
    [TestCase("pizza_component")]
    [TestCase("pizza--component")]
    public void HandleAsync_rejects_a_malformed_business_code(string? code)
    {
        Assert.ThrowsAsync<DomainException>(() =>
            _handler.HandleAsync(new GetProductCategoryQuery(code)));
    }

    [Test]
    public void HandleAsync_rejects_a_null_query()
    {
        Assert.ThrowsAsync<ArgumentNullException>(() => _handler.HandleAsync(null!));
    }
}
