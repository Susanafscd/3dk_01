using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class PhoneNumberTests
{
    [Test]
    public void Create_trims_and_preserves_the_phone_number()
    {
        var phoneNumber = PhoneNumber.Create("  +351 910 000 000  ");

        Assert.That(phoneNumber.Value, Is.EqualTo("+351 910 000 000"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_rejects_a_missing_phone_number(string? value)
    {
        Assert.Throws<DomainException>(() => PhoneNumber.Create(value));
    }

    [Test]
    public void Create_rejects_a_phone_number_that_is_too_long()
    {
        Assert.Throws<DomainException>(() => PhoneNumber.Create(new string('1', PhoneNumber.MaxLength + 1)));
    }

    [TestCase("1234567")]
    [TestCase("+351 910 000 000")]
    public void Create_accepts_phone_numbers_with_a_valid_structure(string value)
    {
        Assert.That(PhoneNumber.Create(value).Value, Is.EqualTo(value));
    }

    [TestCase("12345")]
    [TestCase("+351 ABC 000 000")]
    [TestCase("+351 910 000 000x")]
    public void Create_rejects_phone_numbers_with_an_invalid_structure(string value)
    {
        Assert.Throws<DomainException>(() => PhoneNumber.Create(value));
    }
}
