using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class DietaryRestrictionTests
{
    [Test]
    public void Create_accepts_an_empty_allergen_list()
    {
        var restriction = DietaryRestriction.Create("Vegan");

        Assert.Multiple(() =>
        {
            Assert.That(restriction.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(restriction.Name, Is.EqualTo("Vegan"));
            Assert.That(restriction.Description, Is.Null);
            Assert.That(restriction.Allergens, Is.Empty);
        });
    }

    [Test]
    public void Create_trims_details_and_keeps_allergens()
    {
        var allergen = Allergen.Create("milk", "Milk", null);
        var restriction = DietaryRestriction.Create("  Lactose intolerance  ", "  No dairy  ", [allergen]);

        Assert.Multiple(() =>
        {
            Assert.That(restriction.Name, Is.EqualTo("Lactose intolerance"));
            Assert.That(restriction.Description, Is.EqualTo("No dairy"));
            Assert.That(restriction.Allergens, Is.EquivalentTo([allergen]));
        });
    }

    [TestCase("")]
    [TestCase("   ")]
    public void Create_rejects_a_missing_name(string name)
    {
        Assert.Throws<DomainException>(() => DietaryRestriction.Create(name));
    }

    [Test]
    public void SetAllergens_replaces_the_current_associations()
    {
        var milk = Allergen.Create("milk", "Milk", null);
        var egg = Allergen.Create("egg", "Egg", null);
        var restriction = DietaryRestriction.Create("Allergy", allergens: [milk]);

        restriction.SetAllergens([egg]);

        Assert.That(restriction.Allergens, Is.EquivalentTo([egg]));
    }

    [Test]
    public void Create_rejects_duplicate_allergen_associations()
    {
        var allergen = Allergen.Create("milk", "Milk", null);

        Assert.Throws<ArgumentException>(() =>
            DietaryRestriction.Create("Lactose intolerance", allergens: [allergen, allergen]));
    }

    [Test]
    public void UpdateDetails_replaces_and_normalizes_the_description()
    {
        var restriction = DietaryRestriction.Create("Vegan", "Initial");

        restriction.UpdateDetails("  Vegetarian  ", "  No meat  ");

        Assert.Multiple(() =>
        {
            Assert.That(restriction.Name, Is.EqualTo("Vegetarian"));
            Assert.That(restriction.Description, Is.EqualTo("No meat"));
        });
    }
}
