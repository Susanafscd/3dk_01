using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class CustomerTests
{
    private static Customer CreateCustomer(
        string displayName = "Ada Lovelace",
        string name = "Ada Lovelace",
        string phoneNumber = "+351 910 000 000",
        IEnumerable<Guid>? roleIds = null) =>
        Customer.Create(
            Email.Create("ada@example.com"),
            displayName,
            name,
            [],
            phoneNumber);

    [Test]
    public void Create_populates_the_profile_and_starts_active()
    {
        var roleId = Guid.NewGuid();

        var customer = CreateCustomer(roleIds: [roleId]);

        Assert.Multiple(() =>
        {
            Assert.That(customer.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(customer.Email.Value, Is.EqualTo("ada@example.com"));
            Assert.That(customer.DisplayName, Is.EqualTo("Ada Lovelace"));
            Assert.That(customer.Name, Is.EqualTo("Ada Lovelace"));
            Assert.That(customer.PhoneNumber.Value, Is.EqualTo("+351 910 000 000"));
            Assert.That(customer.Active, Is.True);
        });
    }

    [Test]
    public void Create_trims_the_text_fields()
    {
        var customer = CreateCustomer(displayName: "  Ada Lovelace  ", name: "  Ada  ");

        Assert.Multiple(() =>
        {
            Assert.That(customer.DisplayName, Is.EqualTo("Ada Lovelace"));
            Assert.That(customer.Name, Is.EqualTo("Ada"));
        });
    }

    [Test]
    public void Create_rejects_a_blank_phone_number()
    {
        Assert.Throws<DomainException>(() => CreateCustomer(phoneNumber: "   "));
    }

    [TestCase("")]
    [TestCase("   ")]
    public void Create_rejects_a_missing_name(string name)
    {
        Assert.Throws<DomainException>(() => CreateCustomer(name: name));
    }

    [TestCase("")]
    [TestCase("   ")]
    public void Create_rejects_a_missing_display_name(string displayName)
    {
        Assert.Throws<DomainException>(() => CreateCustomer(displayName: displayName));
    }

    [Test]
    public void Create_rejects_a_phone_number_that_is_too_long()
    {
        Assert.Throws<DomainException>(() => CreateCustomer(phoneNumber: new string('9', 31)));
    }

    [Test]
    public void The_account_can_be_deactivated_and_activated()
    {
        var customer = CreateCustomer();

        customer.Deactivate();
        Assert.That(customer.Active, Is.False);

        customer.Activate();
        Assert.That(customer.Active, Is.True);
    }

    [Test]
    public void Rename_updates_the_display_name()
    {
        var customer = CreateCustomer();

        customer.Rename("  Augusta Ada King  ");

        Assert.That(customer.DisplayName, Is.EqualTo("Augusta Ada King"));
    }

    [Test]
    public void ChangeName_updates_the_customer_name()
    {
        var customer = CreateCustomer();

        customer.ChangeName("  Augusta Ada King  ");

        Assert.That(customer.Name, Is.EqualTo("Augusta Ada King"));
    }

    [Test]
    public void A_customer_can_have_multiple_dietary_restrictions()
    {
        var restrictions = new[]
        {
            DietaryRestriction.Create("Vegan"),
            DietaryRestriction.Create("Gluten-free")
        };

        var customer = Customer.Create(
            Email.Create("ada@example.com"),
            "Ada Lovelace",
            "Ada Lovelace",
            restrictions,
            "+351 910 000 000");

        Assert.That(customer.DietaryRestrictions, Is.EquivalentTo(restrictions));
    }

    [Test]
    public void A_customer_can_have_no_dietary_restrictions()
    {
        var customer = CreateCustomer();

        Assert.That(customer.DietaryRestrictions, Is.Empty);
    }

    [Test]
    public void ChangeDietaryRestrictions_replaces_the_customer_restrictions()
    {
        var customer = CreateCustomer();
        var restriction = DietaryRestriction.Create("Nut-free");

        customer.ChangeDietaryRestrictions([restriction]);

        Assert.That(customer.DietaryRestrictions, Is.EquivalentTo([restriction]));
    }

    [Test]
    public void A_customer_cannot_have_the_same_dietary_restriction_twice()
    {
        var restriction = DietaryRestriction.Create("Vegan");

        Assert.Throws<ArgumentException>(() =>
            Customer.Create(
                Email.Create("ada@example.com"),
                "Ada Lovelace",
                "Ada Lovelace",
                [restriction, restriction],
                "+351 910 000 000"));
    }

    [Test]
    public void Each_customer_receives_a_unique_identifier()
    {
        var first = CreateCustomer();
        var second = CreateCustomer();

        Assert.That(second.Id, Is.Not.EqualTo(first.Id));
    }
}
