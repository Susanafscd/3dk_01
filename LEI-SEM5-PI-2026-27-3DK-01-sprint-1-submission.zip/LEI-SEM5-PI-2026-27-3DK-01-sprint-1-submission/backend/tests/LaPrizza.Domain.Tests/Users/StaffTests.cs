using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class StaffTests
{
    private static Staff CreateStaff(
        string displayName = "Grace Hopper",
        string jobTitle = "Head Chef",
        IEnumerable<Guid>? roleIds = null) =>
        Staff.Create(
            Email.Create("grace@example.com"),
            displayName,
            jobTitle,
            roleIds);

    [Test]
    public void Create_populates_the_profile_and_starts_active()
    {
        var roleId = Guid.NewGuid();

        var staff = CreateStaff(roleIds: [roleId]);

        Assert.Multiple(() =>
        {
            Assert.That(staff.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(staff.Email.Value, Is.EqualTo("grace@example.com"));
            Assert.That(staff.DisplayName, Is.EqualTo("Grace Hopper"));
            Assert.That(staff.JobTitle, Is.EqualTo("Head Chef"));
            Assert.That(staff.Active, Is.True);
        });
    }

    [TestCase("")]
    [TestCase("   ")]
    public void Create_rejects_a_missing_job_title(string jobTitle)
    {
        Assert.Throws<DomainException>(() => CreateStaff(jobTitle: jobTitle));
    }

    [Test]
    public void ChangeJobTitle_updates_the_job_title()
    {
        var staff = CreateStaff();

        staff.ChangeJobTitle("  Sous Chef  ");

        Assert.That(staff.JobTitle, Is.EqualTo("Sous Chef"));
    }

    [Test]
    public void ChangeJobTitle_rejects_a_missing_value()
    {
        var staff = CreateStaff();

        Assert.Throws<DomainException>(() => staff.ChangeJobTitle("  "));
    }
}
