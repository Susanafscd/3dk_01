using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class EmailTests
{
    [Test]
    public void Create_trims_and_lowercases_the_address()
    {
        var email = Email.Create("  Ada.Lovelace@Example.COM  ");

        Assert.That(email.Value, Is.EqualTo("ada.lovelace@example.com"));
    }

    [Test]
    public void Addresses_that_differ_only_in_case_are_equal()
    {
        var first = Email.Create("ada@example.com");
        var second = Email.Create("ADA@EXAMPLE.COM");

        Assert.That(first, Is.EqualTo(second));
        Assert.That(first.GetHashCode(), Is.EqualTo(second.GetHashCode()));
    }

    [TestCase("")]
    [TestCase("   ")]
    [TestCase("not-an-email")]
    [TestCase("missing@domain")]
    [TestCase("@example.com")]
    [TestCase("ada@.com")]
    public void Create_rejects_a_malformed_address(string value)
    {
        var exception = Assert.Throws<DomainException>(() => Email.Create(value));

        Assert.That(exception!.Message, Does.Contain("email").IgnoreCase);
    }

    [Test]
    public void Create_rejects_a_null_address()
    {
        Assert.Throws<DomainException>(() => Email.Create(null));
    }

    [Test]
    public void Create_rejects_an_address_that_is_too_long()
    {
        var value = new string('a', Email.MaxLength) + "@example.com";

        Assert.Throws<DomainException>(() => Email.Create(value));
    }

    [Test]
    public void A_created_address_is_valid()
    {
        Assert.That(Email.Create("ada@example.com").IsValid(), Is.True);
    }

    [Test]
    public void TryCreate_returns_the_normalised_address_for_a_well_formed_value()
    {
        var created = Email.TryCreate("  Ada.Lovelace@Example.COM  ", out var email);

        Assert.Multiple(() =>
        {
            Assert.That(created, Is.True);
            Assert.That(email, Is.Not.Null);
            Assert.That(email!.Value, Is.EqualTo("ada.lovelace@example.com"));
        });
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    [TestCase("not-an-email")]
    [TestCase("missing@domain")]
    public void TryCreate_returns_false_for_a_malformed_value(string? value)
    {
        var created = Email.TryCreate(value, out var email);

        Assert.Multiple(() =>
        {
            Assert.That(created, Is.False);
            Assert.That(email, Is.Null);
        });
    }
}
