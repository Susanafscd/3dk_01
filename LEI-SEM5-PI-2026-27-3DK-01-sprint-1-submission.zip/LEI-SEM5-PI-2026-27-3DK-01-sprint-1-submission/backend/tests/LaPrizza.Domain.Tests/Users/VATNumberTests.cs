using LaPrizza.Domain.Common;
using LaPrizza.Domain.Users;

namespace LaPrizza.Domain.Tests.Users;

[TestFixture]
public sealed class VATNumberTests
{
    [Test]
    public void Create_accepts_and_normalises_a_portuguese_vat_number()
    {
        var vatNumber = VATNumber.Create(" pt501964843 ");

        Assert.That(vatNumber!.Value, Is.EqualTo("PT501964843"));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_returns_null_when_no_vat_number_is_given(string? value)
    {
        Assert.That(VATNumber.Create(value), Is.Null);
    }

    [TestCase("123")]
    [TestCase("PT12345678")]
    [TestCase("PT1234567890")]
    [TestCase("PT12345678A")]
    public void Create_rejects_an_invalid_vat_number(string value)
    {
        Assert.Throws<DomainException>(() => VATNumber.Create(value));
    }
}
