using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Tests.ComponentTypes;

[TestFixture]
public class PizzaSizeTests
{
    [TestCase("xl")]
    [TestCase("l")]
    [TestCase("m")]
    [TestCase("banana")]
    [TestCase("30cm")]
    [TestCase("xl-ll-lx")]
    public void Create_AcceptsValidNames(string name)
    {
        var pizzaSize = PizzaSize.Create(name);

        Assert.That(pizzaSize.Name, Is.EqualTo(name));
    }

    [Test]
    public void Create_AcceptsNameOfExactMaxLength()
    {
        var name = new string('x', PizzaSize.MaxNameLength);
        var pizzaSize = PizzaSize.Create(name);

        Assert.That(pizzaSize.Name, Is.EqualTo(name));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    [TestCase("Sizes")]
    [TestCase("XL")]
    [TestCase(" xl")]
    [TestCase("xl ")]
    [TestCase("x l")]
    [TestCase("x--l")]
    [TestCase("x-")]
    [TestCase("x- l")]
    [TestCase("x\nl")]
    [TestCase("-l")]
    [TestCase("x_")]
    [TestCase("x.l")]
    [TestCase("xéw")]
    public void Create_RejectsInvalidNames(string? name)
    {
        Assert.Throws<DomainException>(() =>
            PizzaSize.Create(name));
    }

    [Test]
    public void Create_RejectsNameLongerThanMaxLength()
    {
        var name = new string('a', PizzaSize.MaxNameLength + 1);

        Assert.Throws<DomainException>(() =>
            PizzaSize.Create(name));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    [TestCase("Large")]
    public void Create_WithDescription_RejectsInvalidName(string? name)
    {
        Assert.Throws<DomainException>(() =>
            PizzaSize.Create(name, "A valid description."));
    }

    [Test]
    public void Create_WithoutDescription_LeavesDescriptionNull()
    {
        var pizzaSize = PizzaSize.Create("xl");

        Assert.That(pizzaSize.Description, Is.Null);
    }

    [Test]
    public void Create_StoresNameAndDescription()
    {
        var pizzaSize = PizzaSize.Create("xl", "Extra large, 40 cm.");

        Assert.Multiple(() =>
        {
            Assert.That(pizzaSize.Name, Is.EqualTo("xl"));
            Assert.That(pizzaSize.Description, Is.EqualTo("Extra large, 40 cm."));
        });
    }

    [Test]
    public void Create_TrimsDescription()
    {
        var pizzaSize = PizzaSize.Create("xl", "  Extra large.  ");

        Assert.That(pizzaSize.Description, Is.EqualTo("Extra large."));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("  ")]
    public void Create_StoresBlankDescriptionAsNull(string? description)
    {
        var pizzaSize = PizzaSize.Create("xl", description);

        Assert.That(pizzaSize.Description, Is.Null);
    }

    [Test]
    public void Create_AcceptsDescriptionOfExactMaxLength()
    {
        var description = new string('a', PizzaSize.MaxDescriptionLength);
        var pizzaSize = PizzaSize.Create("xl", description);

        Assert.That(pizzaSize.Description, Is.EqualTo(description));
    }

    [Test]
    public void Create_RejectsDescriptionLongerThanMaxLength()
    {
        var description = new string('a', PizzaSize.MaxDescriptionLength + 1);

        Assert.Throws<DomainException>(() =>
            PizzaSize.Create("xl", description));
    }

    [Test]
    public void Create_AssignsADistinctNonEmptyId()
    {
        var first = PizzaSize.Create("m");
        var second = PizzaSize.Create("m");

        Assert.Multiple(() =>
        {
            Assert.That(first.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(second.Id, Is.Not.EqualTo(first.Id));
        });
    }
}
