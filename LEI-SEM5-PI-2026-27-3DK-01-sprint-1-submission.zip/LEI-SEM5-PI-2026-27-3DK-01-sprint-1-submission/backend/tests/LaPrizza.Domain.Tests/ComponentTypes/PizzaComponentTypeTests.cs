using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Common;

namespace LaPrizza.Domain.Tests.ComponentTypes;

[TestFixture]
public class PizzaComponentTypeTests
{
    [Test]
    public void Create_CreatesTypeWithValidValues()
    {
        var type = PizzaComponentType.Create("topping", "Topping", "Desc", 4, 0, null);

        Assert.Multiple(() =>
        {
            Assert.That(type.Id, Is.Not.EqualTo(Guid.Empty));
            Assert.That(type.Code.Value, Is.EqualTo("topping"));
            Assert.That(type.Name, Is.EqualTo("Topping"));
            Assert.That(type.Description, Is.EqualTo("Desc"));
            Assert.That(type.AssemblyOrder, Is.EqualTo(4));
            Assert.That(type.MinQuantity, Is.EqualTo(0));
            Assert.That(type.MaxQuantity, Is.Null);
        });
    }

    [Test]
    public void Create_TrimsNameAndStoresBlankDescriptionAsNull()
    {
        var type = PizzaComponentType.Create("dough", "  Dough  ", "   ", 1, 1, 1);

        Assert.Multiple(() =>
        {
            Assert.That(type.Name, Is.EqualTo("Dough"));
            Assert.That(type.Description, Is.Null);
        });
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_RejectsMissingName(string? name)
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", name, null, 1, 0, null));
    }

    [Test]
    public void Create_RejectsNameLongerThanMaxLength()
    {
        var name = new string('a', PizzaComponentType.MaxNameLength + 1);
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", name, null, 1, 0, null));
    }

    [Test]
    public void Create_RejectsDescriptionLongerThanMaxLength()
    {
        var description = new string('a', PizzaComponentType.MaxDescriptionLength + 1);
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", "Topping", description, 1, 0, null));
    }

    [TestCase(0)]
    [TestCase(-1)]
    public void Create_RejectsAssemblyOrderBelowOne(int assemblyOrder)
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", "Topping", null, assemblyOrder, 0, null));
    }

    [TestCase(-1)]
    public void Create_RejectsNegativeMinQuantity(int minQuantity)
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", "Topping", null, 1, minQuantity, null));
    }

    [Test]
    public void Create_RejectsMaxLowerThanMin()
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", "Topping", null, 1, 2, 1));
    }

    [Test]
    public void Create_RejectsBoundedMaxLessThanOne()
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create("topping", "Topping", null, 1, 0, 0));
    }

    [Test]
    public void UpdateDetails_UpdatesValues()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        type.UpdateDetails("Sauce", "Red", 2, 0, 1);

        Assert.Multiple(() =>
        {
            Assert.That(type.Name, Is.EqualTo("Sauce"));
            Assert.That(type.Description, Is.EqualTo("Red"));
            Assert.That(type.AssemblyOrder, Is.EqualTo(2));
            Assert.That(type.MinQuantity, Is.EqualTo(0));
            Assert.That(type.MaxQuantity, Is.EqualTo(1));
        });
    }

    [TestCase("a")]
    [TestCase("topping")]
    [TestCase("base-dough")]
    [TestCase("a1-b2-c3")]
    public void Create_AcceptsValidCodes(string code)
    {
        var type = PizzaComponentType.Create(code, "Name", null, 1, 0, null);

        Assert.That(type.Code.Value, Is.EqualTo(code));
    }

    [Test]
    public void Create_AcceptsCodeOfExactlyMaxLength()
    {
        var code = new string('a', PizzaComponentTypeCode.MaxLength);
        var type = PizzaComponentType.Create(code, "Name", null, 1, 0, null);

        Assert.That(type.Code.Value, Is.EqualTo(code));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Topping")]
    [TestCase("base dough")]
    [TestCase("base--dough")]
    [TestCase("-topping")]
    [TestCase("topping-")]
    [TestCase("base_dough")]
    [TestCase("café")]
    [TestCase("top\nping")]
    public void Create_RejectsInvalidCodes(string? code)
    {
        Assert.Throws<DomainException>(() => PizzaComponentType.Create(code, "Name", null, 1, 0, null));
    }

    [Test]
    public void Create_RejectsCodeLongerThanMaxLength()
    {
        var code = new string('a', PizzaComponentTypeCode.MaxLength + 1);
        Assert.Throws<DomainException>(() => PizzaComponentType.Create(code, "Name", null, 1, 0, null));
    }

    [Test]
    public void UpdateDetails_NeverChangesTheCode()
    {
        var type = PizzaComponentType.Create("topping", "Topping", null, 4, 0, null);
        type.UpdateDetails("Sauce", null, 2, 0, 1);

        Assert.That(type.Code.Value, Is.EqualTo("topping"));
    }

    [Test]
    public void ComponentType_RequiresCategoryBusinessCode()
    {
        var type = PizzaComponentType.Create("topping", "pizza-components", "Topping", null, 4, 0, null);

        Assert.That(type.CategoryCode.Value, Is.EqualTo("pizza-components"));
        Assert.Throws<DomainException>(() =>
            PizzaComponentType.Create("sauce", "", "Sauce", null, 2, 0, 1));
    }

    [Test]
    public void UpdateDetails_ClearsDescriptionWhenBlank()
    {
        var type = PizzaComponentType.Create("topping", "Topping", "Desc", 4, 0, null);
        type.UpdateDetails("Topping", "   ", 4, 0, null);

        Assert.That(type.Description, Is.Null);
    }
}
