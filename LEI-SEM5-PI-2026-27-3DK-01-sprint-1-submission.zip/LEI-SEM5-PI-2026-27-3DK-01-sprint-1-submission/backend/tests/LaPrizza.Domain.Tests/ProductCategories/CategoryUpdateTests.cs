using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.ProductCategories;

public class CategoryUpdateTests
{
    [Test]
    public void Update_preserves_identity_and_clears_description()
    {
        var category = ProductCategory.Create("cheese", "Cheese", "Old", true);
        var id = category.Id;
        category.Update(" Dairy ", null, true, true);
        Assert.That(category.Id, Is.EqualTo(id));
        Assert.That(category.Code.Value, Is.EqualTo("cheese"));
        Assert.That(category.Name, Is.EqualTo("Dairy"));
        Assert.That(category.Description, Is.Null);
    }

    [TestCase("", null, false)]
    [TestCase("Changed", "Old", true)]
    public void Rejection_does_not_partially_mutate(string name, string? description, bool linked)
    {
        var category = ProductCategory.Create("cheese", "Cheese", "Original", true);
        Assert.That(() => category.Update(name, description, false, linked),
            Throws.InstanceOf<DomainException>());
        Assert.That(category.Name, Is.EqualTo("Cheese"));
        Assert.That(category.Description, Is.EqualTo("Original"));
        Assert.That(category.AllowsComponentTypes, Is.True);
    }

    [Test]
    public void Unreferenced_category_can_disable_component_types()
    {
        var category = ProductCategory.Create("cheese", "Cheese", null, true);
        category.Update("Cheese", null, false, false);
        Assert.That(category.AllowsComponentTypes, Is.False);
    }
}
