using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.ProductCategories;

public class CategoryRemovalPolicyTests
{
    [Test]
    public void A_product_reference_blocks_removal()
    {
        Assert.Throws<DomainException>(() => CategoryRemovalPolicy.EnsureCanRemove(true));
    }

    [Test]
    public void Unused_record_can_be_removed()
    {
        Assert.DoesNotThrow(() => CategoryRemovalPolicy.EnsureCanRemove(false));
    }
}
