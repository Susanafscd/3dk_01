using LaPrizza.Domain.Common;
using LaPrizza.Domain.ProductCategories;

namespace LaPrizza.Domain.Tests.ProductCategories;

[TestFixture]
public class ProductCategoryTests
{
    [TestCase("a")]
    [TestCase("pizzas")]
    [TestCase("softdrinks2")]
    [TestCase("soft-drinks")]
    [TestCase("a1-b2-c3")]
    public void Create_AcceptsValidCodes(string code)
    {
        var category = ProductCategory.Create(code, "Name", null, false);

        Assert.That(category.Code.Value, Is.EqualTo(code));
    }

    [Test]
    public void Create_AcceptsCodeOfExactlyMaxLength()
    {
        var code = new string('a', 100);
        var category = ProductCategory.Create(code, "Name", null, true);

        Assert.That(category.Code.Value, Is.EqualTo(code));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Pizzas")]
    [TestCase("soft drinks")]
    [TestCase("soft--drinks")]
    [TestCase("soft-")]
    [TestCase("soft- drinks")]
    [TestCase("soft\ndrink")]
    [TestCase("-drinks")]
    [TestCase("drinks-")]
    [TestCase("bebidas_")]
    [TestCase("café")]
    public void Create_RejectsInvalidCodes(string? code)
    {
        Assert.Throws<DomainException>(() =>
            ProductCategory.Create(code, "Name", null, true));
    }

    [Test]
    public void Create_RejectsCodeLongerThanMaxLength()
    {
        var code = new string('a', 101);

        Assert.Throws<DomainException>(() =>
            ProductCategory.Create(code, "Name", null, true));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_RejectsBlankName(string? name)
    {
        Assert.Throws<DomainException>(() =>
            ProductCategory.Create("pizzas", name, null, true));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("  ")]
    public void Create_StoresBlankDescriptionAsNull(string? description)
    {
        var category = ProductCategory.Create(
            "pizzas", "Pizzas", description, false);

        Assert.That(category.Description, Is.Null);
    }

    [TestCase(true)]
    [TestCase(false)]
    public void Create_PreservesAllowsComponentTypes(bool allowsComponentTypes)
    {
        var category = ProductCategory.Create(
            "pizzas", "Pizzas", null, allowsComponentTypes);

        Assert.That(category.AllowsComponentTypes, Is.EqualTo(allowsComponentTypes));
    }

    [Test]
    public void Create_RejectsNameLongerThanMaxLength()
    {
        var name = new string('a', ProductCategory.NameMaxLength + 1);

        Assert.Throws<DomainException>(() =>
            ProductCategory.Create("pizzas", name, null, true));
    }

    [Test]
    public void Create_RejectsDescriptionLongerThanMaxLength()
    {
        var description = new string('a', ProductCategory.DescriptionMaxLength + 1);

        Assert.Throws<DomainException>(() =>
            ProductCategory.Create("pizzas", "Pizzas", description, true));
    }

    [Test]
    public void Create_KeepsExplicitFalseAndTrimsText()
    {
        var category = ProductCategory.Create(
            "pizzas", "  Pizzas ", " Main dishes ", false);

        Assert.Multiple(() =>
        {
            Assert.That(category.AllowsComponentTypes, Is.False);
            Assert.That(category.Name, Is.EqualTo("Pizzas"));
            Assert.That(category.Description, Is.EqualTo("Main dishes"));
        });
    }
}
