using LaPrizza.Domain.Common;
using LaPrizza.Domain.Allergens;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Allergens;

public class AllergenRemovalPolicyTests
{
    [TestCase(true, false, false)]
    [TestCase(false, true, false)]
    [TestCase(false, false, true)]
    [TestCase(true, true, true)]
    public void Each_reference_source_independently_blocks_removal(bool products, bool second, bool other)
    {
        Assert.Throws<DomainException>(() => AllergenRemovalPolicy.EnsureCanRemove(products, second, other));
    }

    [Test]
    public void Unused_record_can_be_removed()
    {
        Assert.DoesNotThrow(() => AllergenRemovalPolicy.EnsureCanRemove(false, false, false));
    }
}
