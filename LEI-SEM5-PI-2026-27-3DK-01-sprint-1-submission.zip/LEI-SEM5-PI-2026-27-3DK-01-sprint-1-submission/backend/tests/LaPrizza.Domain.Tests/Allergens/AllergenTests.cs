using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Common;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Allergens;

[TestFixture]
public sealed class AllergenTests
{
    [TestCase("a")]
    [TestCase("milk")]
    [TestCase("tree-nuts")]
    [TestCase("allergen2")]
    [TestCase("a1-b2-c3")]
    public void Create_AcceptsCanonicalBusinessCodes(string code)
    {
        var allergen = Allergen.Create(code, "Name", null);

        Assert.That(allergen.Code.Value, Is.EqualTo(code));
    }

    [Test]
    public void Create_AcceptsCodeAtMaximumLength()
    {
        var code = new string('a', AllergenCode.MaxLength);

        var allergen = Allergen.Create(code, "Name", null);

        Assert.That(allergen.Code.Value, Is.EqualTo(code));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("Milk")]
    [TestCase("tree nuts")]
    [TestCase("tree--nuts")]
    [TestCase("tree-")]
    [TestCase("-tree")]
    [TestCase("café")]
    [TestCase("milk\n")]
    public void Create_RejectsNonCanonicalBusinessCodes(string? code)
    {
        Assert.Throws<DomainException>(() => Allergen.Create(code, "Name", null));
    }

    [Test]
    public void Create_RejectsCodeOverMaximumLength()
    {
        var code = new string('a', AllergenCode.MaxLength + 1);

        Assert.Throws<DomainException>(() => Allergen.Create(code, "Name", null));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_RejectsMissingName(string? name)
    {
        Assert.Throws<DomainException>(() => Allergen.Create("milk", name, null));
    }

    [TestCase(null)]
    [TestCase("")]
    [TestCase("   ")]
    public void Create_StoresMissingDescriptionAsNull(string? description)
    {
        var allergen = Allergen.Create("milk", "Milk", description);

        Assert.That(allergen.Description, Is.Null);
    }

    [Test]
    public void Create_TrimsDescriptiveText()
    {
        var allergen = Allergen.Create("milk", "  Milk  ", "  Milk products  ");

        Assert.Multiple(() =>
        {
            Assert.That(allergen.Name, Is.EqualTo("Milk"));
            Assert.That(allergen.Description, Is.EqualTo("Milk products"));
        });
    }

    [Test]
    public void Create_RejectsOverlongDescriptiveText()
    {
        Assert.Multiple(() =>
        {
            Assert.Throws<DomainException>(() => Allergen.Create(
                "milk", new string('a', Allergen.NameMaxLength + 1), null));
            Assert.Throws<DomainException>(() => Allergen.Create(
                "milk", "Milk", new string('a', Allergen.DescriptionMaxLength + 1)));
        });
    }

    [Test]
    public void Codes_CompareByBusinessValue()
    {
        var first = AllergenCode.Create("milk");
        var second = AllergenCode.Create("milk");

        Assert.That(first, Is.EqualTo(second));
    }

    [Test]
    public void UpdateDetails_replaces_descriptive_information_and_preserves_identity()
    {
        var allergen = Allergen.Create("milk", "Milk", "Milk products.");
        var id = allergen.Id;

        allergen.UpdateDetails("  Dairy  ", "  Includes milk.  ");

        Assert.Multiple(() =>
        {
            Assert.That(allergen.Id, Is.EqualTo(id));
            Assert.That(allergen.Code.Value, Is.EqualTo("milk"));
            Assert.That(allergen.Name, Is.EqualTo("Dairy"));
            Assert.That(allergen.Description, Is.EqualTo("Includes milk."));
        });
    }

    [Test]
    public void UpdateDetails_validates_everything_before_changing_the_aggregate()
    {
        var allergen = Allergen.Create("milk", "Milk", "Milk products.");

        Assert.Throws<DomainException>(() => allergen.UpdateDetails(
            "Dairy",
            new string('a', Allergen.DescriptionMaxLength + 1)));

        Assert.Multiple(() =>
        {
            Assert.That(allergen.Name, Is.EqualTo("Milk"));
            Assert.That(allergen.Description, Is.EqualTo("Milk products."));
        });
    }
}
