using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Domain.Tests.SizeConfigurations;

[TestFixture]
public sealed class SizeValuesTests
{
    [Test]
    public void Stores_the_given_price_and_stock_consumption()
    {
        var values = new SizeValues(1.50m, 1);

        Assert.Multiple(() =>
        {
            Assert.That(values.Price, Is.EqualTo(1.50m));
            Assert.That(values.StockConsumption, Is.EqualTo(1));
        });
    }


    [Test]
    public void Is_active_by_default()
    {
        // The default argument value itself: the flag is omitted, not passed.
        var values = new SizeValues(1.50m, 1);

        Assert.That(values.Active, Is.True);
    }

    [Test]
    public void Keeps_an_explicitly_deactivated_flag()
    {
        var values = new SizeValues(1.50m, 1, false);

        Assert.That(values.Active, Is.False);
    }

    [Test]
    public void Accepts_a_zero_stock_consumption()
    {
        // The value a product that is not stock controlled carries (BCK08).
        var values = new SizeValues(1.50m, 0);

        Assert.That(values.StockConsumption, Is.EqualTo(0));
    }

    [Test]
    public void Rejects_a_zero_price()
    {
        // Same rule the aggregate enforces, so the persistence path (which
        // constructs values directly from stored data) cannot bypass it.
        var exception = Assert.Throws<ArgumentOutOfRangeException>(
            () => new SizeValues(0m, 1));

        Assert.That(exception!.ParamName, Is.EqualTo("price"));
    }

    [Test]
    public void Rejects_a_negative_price()
    {
        var exception = Assert.Throws<ArgumentOutOfRangeException>(
            () => new SizeValues(-0.01m, 0));

        Assert.That(exception!.ParamName, Is.EqualTo("price"));
    }

    [Test]
    public void Rejects_a_negative_stock_consumption()
    {
        var exception = Assert.Throws<ArgumentOutOfRangeException>(
            () => new SizeValues(1.50m, -1));

        Assert.That(exception!.ParamName, Is.EqualTo("stockConsumption"));
    }
}
