using LaPrizza.Domain.Common;
using LaPrizza.Domain.SizeConfigurations;

namespace LaPrizza.Domain.Tests.SizeConfigurations;

[TestFixture]
public sealed class SizeConfigurationTests
{
    private static readonly string SizeA = "small";
    private static readonly string SizeB = "medium";

    [Test]
    public void Empty_has_no_configured_sizes()
    {
        Assert.That(SizeConfiguration.Empty.SizeMappings, Is.Empty);
    }

    [Test]
    public void AddSizeConfiguration_adds_the_size_as_active_with_the_given_values()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var values = configuration.SizeMappings[SizeA];

        Assert.Multiple(() =>
        {
            Assert.That(values.Price, Is.EqualTo(1.50m));
            Assert.That(values.StockConsumption, Is.EqualTo(1));
            Assert.That(values.Active, Is.True);
        });
    }

    [Test]
    public void AddSizeConfiguration_rejects_a_negative_price()
    {
        var configuration = SizeConfiguration.Empty;

        var exception = Assert.Throws<DomainException>(
            () => configuration.AddSizeConfiguration(SizeA, -0.01m, 1));

        // The rule — not the argument position — is the violation being reported.
        Assert.That(exception!.Message, Does.Contain("price").And.Contain("negative"));
    }

    [Test]
    public void AddSizeConfiguration_rejects_a_zero_price()
    {
        var configuration = SizeConfiguration.Empty;

        var exception = Assert.Throws<DomainException>(
            () => configuration.AddSizeConfiguration(SizeA, 0m, 1));

        // The rule — not the argument position — is the violation being reported.
        Assert.That(exception!.Message, Does.Contain("price").And.Contain("negative"));
    }

    [Test]
    public void AddSizeConfiguration_rejects_a_negative_stock()
    {
        var configuration = SizeConfiguration.Empty;

        var exception = Assert.Throws<DomainException>(
            () => configuration.AddSizeConfiguration(SizeA, 1.50m, -1));

        // The rule — not the argument position — is the violation being reported.
        Assert.That(exception!.Message, Does.Contain("stock").And.Contain("negative"));
    }

    [Test]
    public void AddSizeConfiguration_returns_a_new_instance_and_keeps_the_previous_one_unchanged()
    {
        var original = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var updated = original.AddSizeConfiguration(SizeB, 2.25m, 2);

        Assert.Multiple(() =>
        {
            Assert.That(updated, Is.Not.SameAs(original));
            Assert.That(original.SizeMappings, Does.Not.ContainKey(SizeB));
            Assert.That(updated.SizeMappings, Does.ContainKey(SizeB));
            Assert.That(updated.SizeMappings[SizeA].Price, Is.EqualTo(1.50m));
        });
    }

    [Test]
    public void AddSizeConfiguration_rejects_a_size_that_is_already_configured()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() => configuration.AddSizeConfiguration(SizeA, 2.00m, 2));

        Assert.That(exception!.Message, Does.Contain(SizeA));
    }

    [Test]
    public void A_deactivated_configuration_keeps_occupying_its_size()
    {
        // Reactivation is an update: there is no deletion and no re-creation (BCK08).
        var configuration = SizeConfiguration.Empty
            .AddSizeConfiguration(SizeA, 1.50m, 1)
            .UpdateSizeConfiguration(SizeA, 1.50m, 1, active: false);

        var exception = Assert.Throws<DomainException>(() => configuration.AddSizeConfiguration(SizeA, 1.50m, 1));

        Assert.Multiple(() =>
        {
            Assert.That(configuration.ContainsSize(SizeA), Is.True);
            Assert.That(exception!.Message, Does.Contain("already exists"));
        });
    }

    [Test]
    public void UpdateSizeConfiguration_replaces_the_values_and_keeps_the_size_association()
    {
        var configuration = SizeConfiguration.Empty
            .AddSizeConfiguration(SizeA, 1.50m, 1)
            .AddSizeConfiguration(SizeB, 2.25m, 2);

        var updated = configuration.UpdateSizeConfiguration(SizeA, 1.75m, 1);

        Assert.Multiple(() =>
        {
            Assert.That(updated.ContainsSize(SizeA), Is.True);
            Assert.That(updated.ContainsSize(SizeB), Is.True);
            Assert.That(updated.SizeMappings[SizeA].Price, Is.EqualTo(1.75m));
            Assert.That(updated.SizeMappings[SizeA].StockConsumption, Is.EqualTo(1));
            Assert.That(updated.SizeMappings[SizeB].Price, Is.EqualTo(2.25m));
        });
    }

    [Test]
    public void UpdateSizeConfiguration_without_an_active_flag_keeps_the_current_value()
    {
        // Absent active keeps the current value, so a plain price update never
        // silently reactivates a deactivated configuration.
        var configuration = SizeConfiguration.Empty
            .AddSizeConfiguration(SizeA, 1.50m, 1)
            .UpdateSizeConfiguration(SizeA, 1.50m, 1, active: false);

        var updated = configuration.UpdateSizeConfiguration(SizeA, 1.75m, 1);

        Assert.Multiple(() =>
        {
            Assert.That(updated.SizeMappings[SizeA].Price, Is.EqualTo(1.75m));
            Assert.That(updated.SizeMappings[SizeA].Active, Is.False);
        });
    }

    [Test]
    public void UpdateSizeConfiguration_can_deactivate_a_configuration()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var deactivated = configuration.UpdateSizeConfiguration(SizeA, 1.50m, 1, active: false);

        Assert.Multiple(() =>
        {
            // The configuration is retained with its values (BCK08).
            Assert.That(deactivated.SizeMappings[SizeA].Active, Is.False);
            Assert.That(deactivated.SizeMappings[SizeA].Price, Is.EqualTo(1.50m));
            Assert.That(deactivated.SizeMappings[SizeA].StockConsumption, Is.EqualTo(1));
        });
    }

    [Test]
    public void UpdateSizeConfiguration_can_reactivate_a_deactivated_configuration()
    {
        var configuration = SizeConfiguration.Empty
            .AddSizeConfiguration(SizeA, 1.50m, 1)
            .UpdateSizeConfiguration(SizeA, 1.50m, 1, active: false);

        var reactivated = configuration.UpdateSizeConfiguration(SizeA, 1.50m, 1, active: true);

        Assert.Multiple(() =>
        {
            Assert.That(reactivated.SizeMappings[SizeA].Active, Is.True);
            Assert.That(reactivated.SizeMappings[SizeA].Price, Is.EqualTo(1.50m));
        });
    }

    [Test]
    public void UpdateSizeConfiguration_rejects_a_size_without_a_configuration()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception =
            Assert.Throws<DomainException>(() => configuration.UpdateSizeConfiguration(SizeB, 1.75m, 1));

        Assert.Multiple(() =>
        {
            // An update never creates (BCK08).
            Assert.That(configuration.ContainsSize(SizeB), Is.False);
            Assert.That(exception!.Message, Does.Contain(SizeB));
        });
    }

    [Test]
    public void GetPrice_and_GetStockConsumption_return_the_configured_values()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        Assert.Multiple(() =>
        {
            Assert.That(configuration.GetPrice(SizeA), Is.EqualTo(1.50m));
            Assert.That(configuration.GetStockConsumption(SizeA), Is.EqualTo(1));
        });
    }

    [Test]
    public void GetPrice_rejects_a_size_without_a_configuration()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() => configuration.GetPrice(SizeB));

        Assert.Multiple(() =>
        {
            // The same condition the mutators reject: no configuration, not a
            // missing dictionary entry (BCK08 reads never create).
            Assert.That(exception!.Message, Does.Contain(SizeB));
            Assert.That(exception.Message, Does.Contain("does not exist"));
        });
    }

    [Test]
    public void GetStockConsumption_rejects_a_size_without_a_configuration()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() => configuration.GetStockConsumption(SizeB));

        Assert.That(exception!.Message, Does.Contain(SizeB));
    }

    [Test]
    public void GetPrice_returns_the_stored_values_even_when_deactivated()
    {
        var configuration = SizeConfiguration.Empty
            .AddSizeConfiguration(SizeA, 1.50m, 1)
            .UpdateSizeConfiguration(SizeA, 1.50m, 1, active: false);

        Assert.That(configuration.GetPrice(SizeA), Is.EqualTo(1.50m));
    }

    [Test]
    public void AddSizeConfiguration_rejects_a_negative_stock_consumption()
    {
        var exception = Assert.Throws<DomainException>(() =>
            SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, -1));

        Assert.That(exception!.Message, Does.Contain("stock consumption"));
    }

    [Test]
    public void UpdateSizeConfiguration_rejects_a_zero_price_and_keeps_the_stored_values()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() =>
            configuration.UpdateSizeConfiguration(SizeA, 0m, 1));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain("price"));
            // A rejected value leaves the previous configuration in place.
            Assert.That(configuration.SizeMappings[SizeA].Price, Is.EqualTo(1.50m));
            Assert.That(configuration.SizeMappings[SizeA].Active, Is.True);
        });
    }

    [Test]
    public void UpdateSizeConfiguration_rejects_a_negative_price()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() =>
            configuration.UpdateSizeConfiguration(SizeA, -0.01m, 1));

        Assert.That(exception!.Message, Does.Contain("price"));
    }

    [Test]
    public void UpdateSizeConfiguration_rejects_a_negative_stock_consumption()
    {
        var configuration = SizeConfiguration.Empty.AddSizeConfiguration(SizeA, 1.50m, 1);

        var exception = Assert.Throws<DomainException>(() =>
            configuration.UpdateSizeConfiguration(SizeA, 1.50m, -1));

        Assert.That(exception!.Message, Does.Contain("stock consumption"));
    }

    [Test]
    public void FromSizeMappings_rejects_null_mappings()
    {
        Assert.Throws<ArgumentNullException>(() => SizeConfiguration.FromSizeMappings(null!));
    }

    [Test]
    public void FromSizeMappings_rehydrates_the_stored_values_verbatim()
    {
        // The persistence layer (ef jsonb column) rebuilds the value object
        // through this factory, so deactivated configurations must survive the
        // round-trip exactly as they were stored.
        var configuration = SizeConfiguration.FromSizeMappings(new Dictionary<string, SizeValues>
        {
            [SizeA] = new(1.50m, 1),
            [SizeB] = new(2.25m, 2, false),
        });

        Assert.Multiple(() =>
        {
            Assert.That(configuration.SizeMappings, Has.Count.EqualTo(2));
            Assert.That(configuration.GetPrice(SizeA), Is.EqualTo(1.50m));
            Assert.That(configuration.GetStockConsumption(SizeA), Is.EqualTo(1));
            Assert.That(configuration.SizeMappings[SizeA].Active, Is.True);
            // A deactivated configuration is stored and comes back deactivated.
            Assert.That(configuration.SizeMappings[SizeB].Active, Is.False);
            Assert.That(configuration.SizeMappings[SizeB].Price, Is.EqualTo(2.25m));
            Assert.That(configuration.SizeMappings[SizeB].StockConsumption, Is.EqualTo(2));
        });
    }

    [Test]
    public void FromSizeMappings_enforces_the_one_configuration_per_size_invariant()
    {
        // Rehydration and interactive creation share the same invariant: an
        // occupied size — even a deactivated one — cannot be re-added.
        var configuration = SizeConfiguration.FromSizeMappings(new Dictionary<string, SizeValues>
        {
            [SizeA] = new(1.50m, 1, false),
        });

        var exception = Assert.Throws<DomainException>(() =>
            configuration.AddSizeConfiguration(SizeA, 2.00m, 2));

        Assert.Multiple(() =>
        {
            Assert.That(configuration.ContainsSize(SizeA), Is.True);
            Assert.That(exception!.Message, Does.Contain("already exists"));
        });
    }
}
