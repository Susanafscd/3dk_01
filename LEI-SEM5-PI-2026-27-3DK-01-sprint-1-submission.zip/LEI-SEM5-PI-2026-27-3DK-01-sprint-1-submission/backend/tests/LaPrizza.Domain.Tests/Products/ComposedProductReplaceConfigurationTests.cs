using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

[TestFixture]
public sealed class ComposedProductReplaceConfigurationTests
{
    private static readonly IReadOnlyCollection<ComponentTypeLimit> TypeLimits =
    [
        new("base-dough", 1, 1),
        new("cheese", 0, 1),
        new("topping", 0, null),
    ];

    private static PizzaComponent Component(string code, string? type, bool active = true) =>
        new(ProductCode.Create(code), active, type);

    private static readonly PizzaComponent Dough = Component("classic-dough", "base-dough");
    private static readonly PizzaComponent Mozzarella = Component("mozzarella", "cheese");
    private static readonly PizzaComponent Basil = Component("basil", "topping");

    private static ComposedProduct Margherita() => ComposedProduct.Create(
        "margherita", "Margherita", "Tomato and mozzarella", "pizzas", [Dough, Mozzarella], TypeLimits, ["small", "medium"]);

    [Test]
    public void Replaces_the_details_the_configuration_and_the_sizes()
    {
        var pizza = Margherita();

        pizza.ReplaceConfiguration("Margherita Basil", "With basil", [Dough, Mozzarella, Basil], TypeLimits, ["large"]);

        Assert.Multiple(() =>
        {
            Assert.That(pizza.Code.Value, Is.EqualTo("margherita"));
            Assert.That(pizza.Name, Is.EqualTo("Margherita Basil"));
            Assert.That(pizza.Description, Is.EqualTo("With basil"));
            Assert.That(pizza.Components.Select(c => c.Value), Is.EquivalentTo(new[] { "classic-dough", "mozzarella", "basil" }));
            Assert.That(pizza.AvailableSizes.Select(s => s.SizeName), Is.EqualTo(new[] { "large" }));
            Assert.That(pizza.Active, Is.True);
        });
    }

    [Test]
    public void Keeps_the_unchanged_component_and_size_instances()
    {
        var pizza = Margherita();
        var dough = pizza.Components.Single(c => c.Value == "classic-dough");
        var small = pizza.AvailableSizes.Single(s => s.SizeName == "small");

        pizza.ReplaceConfiguration("Margherita", "Tomato and mozzarella", [Dough, Basil], TypeLimits, ["small", "large"]);

        // Persistence replaces only the rows that changed.
        Assert.Multiple(() =>
        {
            Assert.That(pizza.Components, Has.Some.SameAs(dough));
            Assert.That(pizza.AvailableSizes, Has.Some.SameAs(small));
        });
    }

    [Test]
    public void Rejects_a_broken_configuration_and_changes_nothing()
    {
        var pizza = Margherita();

        // Base Dough requires exactly one component.
        Assert.Throws<InvalidPizzaConfigurationException>(() =>
            pizza.ReplaceConfiguration("Changed", "Changed", [Mozzarella], TypeLimits, ["large"]));
        AssertUnchanged(pizza);
    }

    [Test]
    public void Rejects_an_inactive_component_and_changes_nothing()
    {
        var pizza = Margherita();

        Assert.Throws<InvalidPizzaConfigurationException>(() =>
            pizza.ReplaceConfiguration("Changed", "Changed", [Dough, Component("mozzarella", "cheese", active: false)], TypeLimits, ["small"]));
        AssertUnchanged(pizza);
    }

    [Test]
    public void Rejects_a_repeated_size_and_changes_nothing()
    {
        var pizza = Margherita();

        Assert.Throws<InvalidPizzaConfigurationException>(() =>
            pizza.ReplaceConfiguration("Changed", "Changed", [Dough], TypeLimits, ["small", "small"]));
        AssertUnchanged(pizza);
    }

    [Test]
    public void Rejects_a_blank_name_and_changes_nothing()
    {
        var pizza = Margherita();

        Assert.Throws<InvalidProductException>(() =>
            pizza.ReplaceConfiguration(" ", "Changed", [Dough, Basil], TypeLimits, ["large"]));
        AssertUnchanged(pizza);
    }

    private static void AssertUnchanged(ComposedProduct pizza)
    {
        Assert.Multiple(() =>
        {
            Assert.That(pizza.Name, Is.EqualTo("Margherita"));
            Assert.That(pizza.Description, Is.EqualTo("Tomato and mozzarella"));
            Assert.That(pizza.Components.Select(c => c.Value), Is.EquivalentTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(pizza.AvailableSizes.Select(s => s.SizeName), Is.EquivalentTo(new[] { "small", "medium" }));
        });
    }
}
