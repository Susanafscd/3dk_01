using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.Allergens;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

[TestFixture]
public sealed class ComposedProductTests
{
    // The initial component types of the requirements (BCK07).
    private static readonly IReadOnlyCollection<ComponentTypeLimit> TypeLimits =
    [
        new("base-dough", 1, 1),
        new("base-sauce", 0, 1),
        new("cheese", 0, 1),
        new("topping", 0, null),
    ];

    private static PizzaComponent Component(string code, string? type, bool active = true) =>
        new(ProductCode.Create(code), active, type);

    private static readonly PizzaComponent Dough = Component("classic-dough", "base-dough");
    private static readonly PizzaComponent Sauce = Component("tomato-sauce", "base-sauce");
    private static readonly PizzaComponent Mozzarella = Component("mozzarella", "cheese");

    private static readonly IReadOnlyCollection<string> Sizes = ["small", "medium"];

    private static ComposedProduct Create(params PizzaComponent[] components) =>
        ComposedProduct.Create("margherita", "Margherita", "Tomato and mozzarella", "pizzas", components, TypeLimits, Sizes);

    private static ComposedProduct CreateInSizes(params string[] sizes) =>
        ComposedProduct.Create("margherita", "Margherita", "Tomato and mozzarella", "pizzas", [Dough], TypeLimits, sizes);

    [Test]
    public void Creates_active_sellable_pizza_with_its_default_components()
    {
        var pizza = Create(Dough, Sauce, Mozzarella);

        Assert.Multiple(() =>
        {
            Assert.That(pizza.Code.Value, Is.EqualTo("margherita"));
            Assert.That(pizza.Active, Is.True);
            Assert.That(pizza.IsSellable, Is.True);
            Assert.That(pizza.StockControlled, Is.False);
            Assert.That(pizza.StockBalance, Is.Null);
            Assert.That(
                pizza.Components.Select(code => code.Value),
                Is.EquivalentTo(new[] { "classic-dough", "tomato-sauce", "mozzarella" }));
            Assert.That(
                pizza.AvailableSizes.Select(size => size.SizeName),
                Is.EquivalentTo(new[] { "small", "medium" }));
        });
    }

    [Test]
    public void Common_update_preserves_composed_product_sellability_and_configuration()
    {
        var pizza = Create(Dough, Sauce, Mozzarella);
        var id = pizza.Id;
        var components = pizza.Components.ToArray();

        pizza.UpdateCommonDetails("Updated Margherita", "Updated description", [AllergenCode.Create("milk")]);

        Assert.Multiple(() =>
        {
            Assert.That(pizza.Id, Is.EqualTo(id));
            Assert.That(pizza.IsSellable, Is.True);
            Assert.That(pizza.Active, Is.True);
            Assert.That(pizza.Name, Is.EqualTo("Updated Margherita"));
            Assert.That(pizza.Description, Is.EqualTo("Updated description"));
            Assert.That(pizza.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "milk" }));
            Assert.That(pizza.Components, Is.EqualTo(components));
        });
    }

    [Test]
    public void Accepts_any_number_of_components_of_an_unbounded_type()
    {
        var toppings = Enumerable.Range(1, 5).Select(i => Component($"topping-{i}", "topping"));

        var pizza = Create([Dough, .. toppings]);

        Assert.That(pizza.Components, Has.Count.EqualTo(6));
    }

    [Test]
    public void Rejects_an_empty_configuration()
    {
        // No type requires a component, so only the empty-configuration rule rejects this.
        IReadOnlyCollection<ComponentTypeLimit> noMinimum = [new("topping", 0, null)];

        Assert.Throws<InvalidPizzaConfigurationException>(() =>
            ComposedProduct.Create("margherita", "Margherita", "Tomato", "pizzas", [], noMinimum, Sizes));
    }

    [Test]
    public void Rejects_an_inactive_component()
    {
        var inactiveCheese = Component("mozzarella", "cheese", active: false);

        Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Dough, inactiveCheese));
    }

    [Test]
    public void Rejects_a_product_that_is_not_a_pizza_component()
    {
        var notAComponent = Component("cola", type: null);

        var exception = Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Dough, notAComponent));
        Assert.That(exception!.Message, Does.Contain("not a pizza component"));
    }

    [Test]
    public void Rejects_a_component_of_an_unknown_type()
    {
        var unknownType = Component("pineapple", "fruit");

        Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Dough, unknownType));
    }

    [Test]
    public void Rejects_a_repeated_component()
    {
        // Toppings are unbounded, so only the repetition rule rejects this.
        var basil = Component("basil", "topping");

        Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Dough, basil, basil));
    }

    [Test]
    public void Rejects_fewer_components_than_the_type_minimum()
    {
        // Base Dough requires exactly one component.
        Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Sauce, Mozzarella));
    }

    [Test]
    public void Rejects_more_components_than_the_type_maximum()
    {
        var cheddar = Component("cheddar", "cheese");

        Assert.Throws<InvalidPizzaConfigurationException>(() => Create(Dough, Mozzarella, cheddar));
    }

    [Test]
    public void Rejects_a_malformed_code_like_other_products()
    {
        Assert.Throws<InvalidProductException>(() =>
            ComposedProduct.Create("Margherita!", "Margherita", "Tomato", "pizzas", [Dough], TypeLimits, Sizes));
    }

    [Test]
    public void Rejects_a_blank_name_like_other_products()
    {
        Assert.Throws<InvalidProductException>(() =>
            ComposedProduct.Create("margherita", " ", "Tomato", "pizzas", [Dough], TypeLimits, Sizes));
    }

    [Test]
    public void Rejects_a_pizza_without_available_sizes()
    {
        Assert.Throws<InvalidPizzaConfigurationException>(() => CreateInSizes());
    }

    [Test]
    public void Rejects_a_repeated_available_size()
    {
        Assert.Throws<InvalidPizzaConfigurationException>(() => CreateInSizes("small", "small"));
    }

    [Test]
    public void Rejects_a_blank_size_name()
    {
        Assert.Throws<InvalidProductException>(() => CreateInSizes("small", " "));
    }
}
