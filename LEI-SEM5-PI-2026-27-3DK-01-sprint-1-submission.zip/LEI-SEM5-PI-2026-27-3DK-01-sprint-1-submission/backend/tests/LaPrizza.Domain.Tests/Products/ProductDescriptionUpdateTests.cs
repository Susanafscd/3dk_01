using LaPrizza.Domain.Common;
using LaPrizza.Domain.Product;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

public class ProductDescriptionUpdateTests
{
    private static BaseProduct Product() => new BaseProductBuilder()
        .WithCode("cheese").WithName("Cheese").WithDescription("Original")
        .InCategory("ingredients").AsSellable().WithPrice(2m)
        .StockControlled().WithAllergens(["milk"]).Build();

    [Test]
    public void Descriptive_update_preserves_business_state()
    {
        var product = Product();
        var id = product.Id;
        var price = product.Sellable;
        product.UpdateDescription(" New name ", " New description ");
        Assert.That(product.Name, Is.EqualTo("New name"));
        Assert.That(product.Description, Is.EqualTo("New description"));
        Assert.That(product.Id, Is.EqualTo(id));
        Assert.That(product.Code.Value, Is.EqualTo("cheese"));
        Assert.That(product.CategoryCode.Value, Is.EqualTo("ingredients"));
        Assert.That(product.Sellable, Is.SameAs(price));
        Assert.That(product.Allergens.Select(a => a.Value), Is.EqualTo(new[] { "milk" }));
        Assert.That(product.Active, Is.True);
        Assert.That(product.StockBalance, Is.Zero);
    }

    [TestCase("")]
    [TestCase(null)]
    [TestCase("overlong")]
    public void Invalid_description_does_not_change_name(string? description)
    {
        var product = Product();
        if (description == "overlong") description = new string('x', 1001);
        Assert.Throws<DomainException>(() => product.UpdateDescription("New name", description));
        Assert.That(product.Name, Is.EqualTo("Cheese"));
        Assert.That(product.Description, Is.EqualTo("Original"));
    }

    [Test]
    public void Common_update_replaces_allergens_and_preserves_identity_and_activity()
    {
        var product = Product();
        var id = product.Id;
        product.UpdateCommonDetails("Updated", "Updated description", [
            LaPrizza.Domain.Allergens.AllergenCode.Create("wheat")
        ]);

        Assert.Multiple(() =>
        {
            Assert.That(product.Id, Is.EqualTo(id));
            Assert.That(product.Code.Value, Is.EqualTo("cheese"));
            Assert.That(product.Name, Is.EqualTo("Updated"));
            Assert.That(product.Description, Is.EqualTo("Updated description"));
            Assert.That(product.Active, Is.True);
            Assert.That(product.StockBalance, Is.Zero);
            Assert.That(product.Allergens.Select(a => a.Value), Is.EqualTo(new[] { "wheat" }));
        });
    }

    [Test]
    public void Duplicate_allergens_are_rejected_without_partial_mutation()
    {
        var product = Product();

        Assert.Throws<LaPrizza.Domain.Products.InvalidProductException>(() => product.UpdateCommonDetails(
            "Updated",
            "Updated description",
            [
                LaPrizza.Domain.Allergens.AllergenCode.Create("wheat"),
                LaPrizza.Domain.Allergens.AllergenCode.Create("wheat")
            ]));

        Assert.Multiple(() =>
        {
            Assert.That(product.Name, Is.EqualTo("Cheese"));
            Assert.That(product.Description, Is.EqualTo("Original"));
            Assert.That(product.Allergens.Select(a => a.Value), Is.EqualTo(new[] { "milk" }));
        });
    }
}
