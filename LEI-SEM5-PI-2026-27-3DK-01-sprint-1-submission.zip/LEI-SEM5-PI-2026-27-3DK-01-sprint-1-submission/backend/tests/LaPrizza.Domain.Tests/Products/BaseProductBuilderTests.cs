using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

[TestFixture]
public sealed class BaseProductBuilderTests
{
    private static BaseProductBuilder Valid() => new BaseProductBuilder()
        .WithCode("mozzarella")
        .WithName("Mozzarella")
        .WithDescription("Mozzarella used in preparation")
        .InCategory("pizza-ingredients");

    [Test]
    public void Builds_active_sellable_product_with_zero_stock_when_controlled()
    {
        var product = Valid()
            .AsSellable()
            .WithPrice(4.50m)
            .StockControlled()
            .Build();

        Assert.That(product.Active, Is.True);
        Assert.That(product.IsSellable, Is.True);
        Assert.That(product.StockBalance, Is.EqualTo(0));
    }

    [Test]
    public void Rejects_price_when_not_sellable()
    {
        Assert.Throws<InvalidProductException>(() =>
            Valid().WithPrice(1m).Build());
    }

    [TestCase(1, 1)]
    [TestCase(199, 999)]
    [TestCase(200, 1000)]
    public void Builds_with_valid_text_lengths_after_trimming(int nameLength, int descriptionLength)
    {
        var name = new string('n', nameLength);
        var description = new string('d', descriptionLength);

        var product = Valid()
            .WithName($"  {name}  ")
            .WithDescription($"  {description}  ")
            .AsSellable()
            .WithPrice(1m)
            .Build();

        Assert.Multiple(() =>
        {
            Assert.That(product.Name, Is.EqualTo(name));
            Assert.That(product.Description, Is.EqualTo(description));
        });
    }

    [TestCase(201, 1000, "Name")]
    [TestCase(200, 1001, "Description")]
    public void Rejects_overlong_trimmed_text_before_applying_configurations(
        int nameLength, int descriptionLength, string field)
    {
        var configurationApplied = false;
        var builder = Valid()
            .WithName($"  {new string('n', nameLength)}  ")
            .WithDescription($"  {new string('d', descriptionLength)}  ")
            .AsSellable()
            .WithPrice(1m)
            .WithConfiguration(_ => configurationApplied = true);

        var exception = Assert.Throws<InvalidProductException>(() => builder.Build());

        Assert.Multiple(() =>
        {
            Assert.That(exception!.Message, Does.Contain(field));
            Assert.That(configurationApplied, Is.False);
        });
    }

    [Test]
    public void Rejects_sellable_product_without_price()
    {
        Assert.Throws<InvalidProductException>(() =>
            Valid().AsSellable().WithPrice(null).Build());
    }

    [Test]
    public void Rejects_duplicate_allergen_codes()
    {
        Assert.Throws<InvalidProductException>(() =>
            Valid().AsSellable().WithPrice(1m).WithAllergens(["milk", "milk"]).Build());
    }

    [Test]
    public void Rejects_null_allergen_collection()
    {
        Assert.Throws<InvalidProductException>(() =>
            Valid().AsSellable().WithPrice(1m).WithAllergens(null).Build());
    }

    [Test]
    public void Applies_configurations_registered_by_other_stories()
    {
        var applied = false;

        Valid()
            .AsSellable()
            .WithPrice(1m)
            .WithConfiguration(_ => applied = true)
            .Build();

        Assert.That(applied, Is.True);
    }
}
