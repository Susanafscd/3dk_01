using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

/// <summary>Stock rules of the <c>Product</c> aggregate (BCK09).</summary>
[TestFixture]
public sealed class ProductStockTests
{
    private static BaseProduct StockControlled() => new BaseProductBuilder()
        .WithCode("mozzarella")
        .WithName("Mozzarella")
        .WithDescription("Mozzarella used in preparation")
        .InCategory("pizza-ingredients")
        .StockControlled()
        .Build();

    private static BaseProduct NotStockControlled() => new BaseProductBuilder()
        .WithCode("napkin")
        .WithName("Napkin")
        .WithDescription("Paper napkin")
        .InCategory("supplies")
        .AsSellable()
        .WithPrice(0.10m)
        .Build();

    [Test]
    public void IncreaseStock_adds_the_units_to_the_balance()
    {
        var product = StockControlled();

        product.IncreaseStock(5);
        product.IncreaseStock(3);

        Assert.That(product.StockBalance, Is.EqualTo(8));
    }

    [Test]
    public void IncreaseStock_may_reach_exactly_the_upper_limit()
    {
        var product = StockControlled();

        product.IncreaseStock(int.MaxValue);

        Assert.That(product.StockBalance, Is.EqualTo(int.MaxValue));
    }

    [TestCase(0)]
    [TestCase(-1)]
    [TestCase(int.MinValue)]
    public void IncreaseStock_rejects_units_that_are_not_positive(int units)
    {
        var product = StockControlled();

        Assert.Throws<InvalidProductException>(() => product.IncreaseStock(units));
        Assert.That(product.StockBalance, Is.Zero);
    }

    [Test]
    public void IncreaseStock_rejects_a_product_without_stock_control()
    {
        var product = NotStockControlled();

        Assert.Throws<StockChangeRejectedException>(() => product.IncreaseStock(1));
        Assert.That(product.StockBalance, Is.Null);
    }

    [Test]
    public void IncreaseStock_rejects_a_result_above_the_upper_limit_and_keeps_the_balance()
    {
        var product = StockControlled();
        product.IncreaseStock(int.MaxValue);

        Assert.Throws<StockChangeRejectedException>(() => product.IncreaseStock(1));
        Assert.That(product.StockBalance, Is.EqualTo(int.MaxValue));
    }

    [Test]
    public void DecreaseStock_removes_the_units_from_the_balance()
    {
        var product = StockControlled();
        product.IncreaseStock(10);

        product.DecreaseStock(4);

        Assert.That(product.StockBalance, Is.EqualTo(6));
    }

    [Test]
    public void DecreaseStock_may_use_up_the_whole_balance()
    {
        var product = StockControlled();
        product.IncreaseStock(10);

        product.DecreaseStock(10);

        Assert.That(product.StockBalance, Is.Zero);
    }

    [TestCase(0)]
    [TestCase(-1)]
    [TestCase(int.MinValue)]
    public void DecreaseStock_rejects_units_that_are_not_positive(int units)
    {
        var product = StockControlled();
        product.IncreaseStock(10);

        Assert.Throws<InvalidProductException>(() => product.DecreaseStock(units));
        Assert.That(product.StockBalance, Is.EqualTo(10));
    }

    [Test]
    public void DecreaseStock_rejects_a_product_without_stock_control()
    {
        var product = NotStockControlled();

        Assert.Throws<StockChangeRejectedException>(() => product.DecreaseStock(1));
        Assert.That(product.StockBalance, Is.Null);
    }

    [Test]
    public void DecreaseStock_rejects_more_units_than_the_balance_and_keeps_it()
    {
        var product = StockControlled();
        product.IncreaseStock(3);

        Assert.Throws<StockChangeRejectedException>(() => product.DecreaseStock(4));
        Assert.That(product.StockBalance, Is.EqualTo(3));
    }

    [Test]
    public void SetStockControl_disabling_at_zero_clears_the_balance()
    {
        var product = StockControlled();

        product.SetStockControl(false);

        Assert.Multiple(() =>
        {
            Assert.That(product.StockControlled, Is.False);
            Assert.That(product.StockBalance, Is.Null);
        });
    }

    [Test]
    public void SetStockControl_disabling_with_remaining_stock_is_rejected_without_mutation()
    {
        var product = StockControlled();
        product.IncreaseStock(2);

        Assert.Throws<StockChangeRejectedException>(() => product.SetStockControl(false));
        Assert.Multiple(() =>
        {
            Assert.That(product.StockControlled, Is.True);
            Assert.That(product.StockBalance, Is.EqualTo(2));
        });
    }

    [Test]
    public void SetStockControl_enabling_initialises_zero_by_default()
    {
        var product = NotStockControlled();

        product.SetStockControl(true);

        Assert.Multiple(() =>
        {
            Assert.That(product.StockControlled, Is.True);
            Assert.That(product.StockBalance, Is.Zero);
        });
    }

    [Test]
    public void SetStockControl_enabling_accepts_an_initial_balance()
    {
        var product = NotStockControlled();

        product.SetStockControl(true, 12);

        Assert.That(product.StockBalance, Is.EqualTo(12));
    }

    [Test]
    public void SetStockControl_rejects_an_invalid_initial_balance_without_mutation()
    {
        var product = NotStockControlled();

        Assert.Throws<InvalidProductException>(() => product.SetStockControl(true, -1));
        Assert.Multiple(() =>
        {
            Assert.That(product.StockControlled, Is.False);
            Assert.That(product.StockBalance, Is.Null);
        });
    }
}
