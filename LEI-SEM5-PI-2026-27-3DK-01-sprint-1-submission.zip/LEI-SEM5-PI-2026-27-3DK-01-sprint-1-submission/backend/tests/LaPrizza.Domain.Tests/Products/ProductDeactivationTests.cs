using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using NUnit.Framework;

namespace LaPrizza.Domain.Tests.Products;

public class ProductDeactivationTests
{
    private static BaseProduct Product(string code) => new BaseProductBuilder()
        .WithCode(code).WithName("Cheese").WithDescription("Original")
        .InCategory("ingredients").AsSellable().WithPrice(2m)
        .StockControlled().WithAllergens(["milk"]).Build();

    [Test]
    public void Deactivation_is_idempotent_and_preserves_all_common_data()
    {
        var product = Product("cheese");
        var other = Product("other-cheese");
        var id = product.Id;
        var price = product.Sellable;
        Assert.That(product.Deactivate(), Is.True);
        Assert.That(product.Deactivate(), Is.False);
        Assert.That(product.Active, Is.False);
        Assert.That(other.Active, Is.True);
        Assert.That(product.Id, Is.EqualTo(id));
        Assert.That(product.Code.Value, Is.EqualTo("cheese"));
        Assert.That(product.Name, Is.EqualTo("Cheese"));
        Assert.That(product.Description, Is.EqualTo("Original"));
        Assert.That(product.CategoryCode.Value, Is.EqualTo("ingredients"));
        Assert.That(product.Sellable, Is.SameAs(price));
        Assert.That(product.StockControlled, Is.True);
        Assert.That(product.StockBalance, Is.Zero);
        Assert.That(product.Allergens.Select(a => a.Value), Is.EqualTo(new[] { "milk" }));
    }

    [Test]
    public void Composed_product_deactivation_preserves_its_components()
    {
        var pizza = ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
            [new ComponentTypeLimit("base-dough", 1, 1)],
            ["small"]);
        var components = pizza.Components.ToArray();
        var id = pizza.Id;

        Assert.That(pizza.Deactivate(), Is.True);
        Assert.That(pizza.Deactivate(), Is.False);

        Assert.Multiple(() =>
        {
            Assert.That(pizza.Active, Is.False);
            Assert.That(pizza.Id, Is.EqualTo(id));
            Assert.That(pizza.Components, Is.EqualTo(components));
            Assert.That(pizza.IsSellable, Is.True);
        });
    }

    [Test]
    public void Deactivating_a_referenced_component_does_not_deactivate_the_composed_product()
    {
        var component = Product("classic-dough");
        var pizza = ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
            [new ComponentTypeLimit("base-dough", 1, 1)],
            ["small"]);

        Assert.That(component.Deactivate(), Is.True);

        Assert.Multiple(() =>
        {
            Assert.That(component.Active, Is.False);
            Assert.That(pizza.Active, Is.True);
            Assert.That(pizza.Components.Select(code => code.Value), Is.EqualTo(new[] { "classic-dough" }));
        });
    }
}
