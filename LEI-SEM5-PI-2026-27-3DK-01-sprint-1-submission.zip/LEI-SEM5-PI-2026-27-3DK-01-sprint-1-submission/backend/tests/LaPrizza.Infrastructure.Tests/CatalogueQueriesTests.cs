using LaPrizza.Domain.Allergens;
using LaPrizza.Application.Catalogue;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.SizeConfigurations;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class CatalogueQueriesTests
{
    private DomainDbContext _context = null!;
    private CatalogueQueries _queries = null!;

    [SetUp]
    public async Task SetUp()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"catalogue-{Guid.NewGuid():N}")
            .Options;

        _context = new DomainDbContext(options);
        var category = ProductCategory.Create("pizza", "Pizza", "Pizzas", false);
        var allergen = Allergen.Create("milk", "Milk", "Milk products");
        var sellable = BaseProduct("margherita", "Margherita", "pizza", true, ["milk"]);
        var nonSellable = BaseProduct("component", "Component", "pizza", false, []);
        var inactive = BaseProduct("inactive", "Inactive", "pizza", true, []);

        _context.ProductCategories.Add(category);
        _context.Allergens.Add(allergen);
        _context.Products.AddRange(sellable, nonSellable, inactive);
        _context.Entry(inactive).Property(product => product.Active).CurrentValue = false;
        await _context.SaveChangesAsync();
        _queries = new CatalogueQueries(_context);
    }

    [TearDown]
    public async Task TearDown() => await _context.DisposeAsync();

    [Test]
    public async Task LoadAsync_returns_only_active_sellable_products_with_business_identifiers()
    {
        var result = await _queries.LoadAsync(1, 20);

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Has.Count.EqualTo(1));
            Assert.That(result.Items.Single().ProductCode, Is.EqualTo("margherita"));
            Assert.That(result.Items.Single().Category, Is.EqualTo(new CatalogueCategoryResult("pizza", "Pizza")));
            Assert.That(result.Items.Single().Allergens, Is.EqualTo(new[] { "Milk" }));
            Assert.That(result.Items.Single().UnitPrice, Is.EqualTo(10m));
        });
    }

    [Test]
    public async Task LoadAsync_paginates_catalogue_entries_without_exposing_persistence_identifiers()
    {
        var second = BaseProduct("pepperoni", "Pepperoni", "pizza", true, []);
        _context.Products.Add(second);
        await _context.SaveChangesAsync();

        var result = await _queries.LoadAsync(2, 1);

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Has.Count.EqualTo(1));
            Assert.That(result.Items.Single().ProductCode, Is.EqualTo("pepperoni"));
            Assert.That(result.Items.Single().GetType().GetProperties().Select(property => property.PropertyType),
                Has.None.EqualTo(typeof(Guid)));
        });
    }

    [Test]
    public async Task LoadByIdAsync_returns_not_found_for_inactive_or_non_sellable_products()
    {
        var products = await _context.Products.ToListAsync();
        var inactive = products.Single(product => product.Code.Value == "inactive");
        var nonSellable = products.Single(product => product.Code.Value == "component");

        var inactiveResult = await _queries.LoadByIdAsync(inactive.Id);
        var nonSellableResult = await _queries.LoadByIdAsync(nonSellable.Id);

        Assert.Multiple(() =>
        {
            Assert.That(inactiveResult, Is.Null);
            Assert.That(nonSellableResult, Is.Null);
        });
    }

    [Test]
    public async Task LoadAsync_exposes_active_size_names_and_prices_without_size_guids()
    {
        var size = PizzaSize.Create("medium");
        _context.PizzaSizes.Add(size);
        var product = BaseProduct("sized-pizza", "Sized pizza", "pizza", true, []);
        product.SetSizeConfiguration(SizeConfiguration.Empty.AddSizeConfiguration("medium", 12.50m, 1));
        _context.Products.Add(product);
        await _context.SaveChangesAsync();

        var result = await _queries.LoadAsync(1, 20);
        var sized = result.Items.Single(item => item.ProductCode == "sized-pizza");

        Assert.Multiple(() =>
        {
            Assert.That(sized.UnitPrice, Is.Null);
            Assert.That(sized.Sizes, Is.EqualTo(new[] { new CatalogueSizeResult("medium", 12.50m) }));
        });
    }

    private static BaseProduct BaseProduct(
        string code,
        string name,
        string category,
        bool sellable,
        IReadOnlyList<string> allergens)
        => new BaseProductBuilder()
            .WithCode(code)
            .WithName(name)
            .WithDescription($"{name} description")
            .InCategory(category)
            .AsSellable(sellable)
            .WithPrice(sellable ? 10m : null)
            .StockControlled(!sellable)
            .WithAllergens(allergens)
            .Build();
}
