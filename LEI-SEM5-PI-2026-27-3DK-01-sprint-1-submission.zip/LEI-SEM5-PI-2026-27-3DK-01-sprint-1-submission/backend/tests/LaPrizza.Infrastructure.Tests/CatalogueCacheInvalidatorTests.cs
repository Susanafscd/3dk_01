using LaPrizza.Application.Allergens.SearchAllergens;
using LaPrizza.Application.Catalogue;
using LaPrizza.Domain.Allergens;
using LaPrizza.Application.Products.GetProduct;
using LaPrizza.Infrastructure.Redis;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class CatalogueCacheInvalidatorTests
{
    [Test]
    public async Task Allergen_search_pages_are_cached_and_invalidated_together()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var hybrid = provider.GetRequiredService<HybridCache>();
        var cache = new HybridAllergenCatalogueCache(hybrid);
        var calls = 0;

        Task<SearchAllergensResult> Factory(CancellationToken _)
        {
            calls++;
            return Task.FromResult(new SearchAllergensResult([], 1, 20, calls));
        }

        var first = await cache.SearchAsync("milk:1:20", Factory);
        var second = await cache.SearchAsync("milk:1:20", Factory);
        await new HybridCatalogueCacheInvalidator(
            hybrid,
            NullLogger<HybridCatalogueCacheInvalidator>.Instance).InvalidateAllergensAsync();
        var refreshed = await cache.SearchAsync("milk:1:20", Factory);

        Assert.Multiple(() =>
        {
            Assert.That(first.TotalCount, Is.EqualTo(1));
            Assert.That(second.TotalCount, Is.EqualTo(1));
            Assert.That(refreshed.TotalCount, Is.EqualTo(2));
            Assert.That(calls, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task Allergen_detail_is_cached_and_removed_by_the_shared_allergen_tag()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var hybrid = provider.GetRequiredService<HybridCache>();
        var cache = new HybridAllergenCatalogueCache(hybrid);
        var calls = 0;

        Task<AllergenLookupResult> Factory(CancellationToken _)
        {
            calls++;
            return Task.FromResult(new AllergenLookupResult("milk", $"Milk {calls}", null));
        }

        var first = await cache.GetByCodeAsync("milk", Factory);
        var second = await cache.GetByCodeAsync("milk", Factory);
        await new HybridCatalogueCacheInvalidator(
            hybrid,
            NullLogger<HybridCatalogueCacheInvalidator>.Instance).InvalidateAllergensAsync();
        var refreshed = await cache.GetByCodeAsync("milk", Factory);

        Assert.Multiple(() =>
        {
            Assert.That(first.Name, Is.EqualTo("Milk 1"));
            Assert.That(second.Name, Is.EqualTo("Milk 1"));
            Assert.That(refreshed.Name, Is.EqualTo("Milk 2"));
            Assert.That(calls, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task Invalidates_all_allergen_pages_and_catalogue_projections_but_preserves_unrelated_entries()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var cache = provider.GetRequiredService<HybridCache>();
        await cache.SetAsync("laprizza:v1:allergens:page:1", "old1", tags: [CatalogueCacheTags.Allergens]);
        await cache.SetAsync("laprizza:v1:allergens:page:2", "old2", tags: [CatalogueCacheTags.Allergens]);
        await cache.SetAsync("laprizza:v1:catalogue", "old-catalogue", tags: [CatalogueCacheTags.Catalogue]);
        await cache.SetAsync("laprizza:v1:unrelated", "keep");

        var invalidator = new HybridCatalogueCacheInvalidator(cache, NullLogger<HybridCatalogueCacheInvalidator>.Instance);
        using var cancelled = new CancellationTokenSource();
        await cancelled.CancelAsync();
        await invalidator.InvalidateAllergensAsync(cancelled.Token);

        var first = await cache.GetOrCreateAsync("laprizza:v1:allergens:page:1", _ => ValueTask.FromResult("new1"), tags: [CatalogueCacheTags.Allergens]);
        var second = await cache.GetOrCreateAsync("laprizza:v1:allergens:page:2", _ => ValueTask.FromResult("new2"), tags: [CatalogueCacheTags.Allergens]);
        var catalogue = await cache.GetOrCreateAsync("laprizza:v1:catalogue", _ => ValueTask.FromResult("new-catalogue"), tags: [CatalogueCacheTags.Catalogue]);
        var unrelated = await cache.GetOrCreateAsync("laprizza:v1:unrelated", _ => ValueTask.FromResult("unexpected"));
        Assert.Multiple(() =>
        {
            Assert.That(first, Is.EqualTo("new1"));
            Assert.That(second, Is.EqualTo("new2"));
            Assert.That(catalogue, Is.EqualTo("new-catalogue"));
            Assert.That(unrelated, Is.EqualTo("keep"));
        });
    }

    [Test]
    public async Task Catalogue_pages_are_cached_and_invalidated_with_the_product_changes()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var hybrid = provider.GetRequiredService<HybridCache>();
        var cache = new HybridProductCatalogueCache(hybrid);
        var calls = 0;

        Task<CatalogueResult> Factory(CancellationToken _)
        {
            calls++;
            return Task.FromResult(new CatalogueResult([new CatalogueProductResult(
                "PIZZA-MARGHERITA", $"Page {calls}", null, null, null, [], [], null)]));
        }

        var first = await cache.GetListAsync(1, 20, Factory);
        var second = await cache.GetListAsync(1, 20, Factory);
        await new HybridCatalogueCacheInvalidator(
            hybrid,
            NullLogger<HybridCatalogueCacheInvalidator>.Instance).InvalidateProductsAsync();
        var refreshed = await cache.GetListAsync(1, 20, Factory);

        Assert.Multiple(() =>
        {
            Assert.That(first.Items[0].Name, Is.EqualTo("Page 1"));
            Assert.That(second.Items[0].Name, Is.EqualTo("Page 1"));
            Assert.That(refreshed.Items[0].Name, Is.EqualTo("Page 2"));
            Assert.That(calls, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task Catalogue_details_are_cached_by_identifier_and_invalidated_with_the_product_changes()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var hybrid = provider.GetRequiredService<HybridCache>();
        var cache = new HybridProductCatalogueCache(hybrid);
        var id = Guid.NewGuid();
        var calls = 0;

        Task<CatalogueProductResult?> Factory(CancellationToken _)
        {
            calls++;
            return Task.FromResult<CatalogueProductResult?>(new CatalogueProductResult(
                "PIZZA-MARGHERITA", $"Version {calls}", null, null, null, [], [], null));
        }

        var first = await cache.GetByIdAsync(id, Factory);
        var second = await cache.GetByIdAsync(id, Factory);
        await new HybridCatalogueCacheInvalidator(
            hybrid,
            NullLogger<HybridCatalogueCacheInvalidator>.Instance).InvalidateProductsAsync();
        var refreshed = await cache.GetByIdAsync(id, Factory);

        Assert.Multiple(() =>
        {
            Assert.That(first!.Name, Is.EqualTo("Version 1"));
            Assert.That(second!.Name, Is.EqualTo("Version 1"));
            Assert.That(refreshed!.Name, Is.EqualTo("Version 2"));
            Assert.That(calls, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task Product_detail_is_removed_by_the_shared_product_tag()
    {
        var services = new ServiceCollection();
        services.AddHybridCache();
        await using var provider = services.BuildServiceProvider();
        var hybrid = provider.GetRequiredService<HybridCache>();
        var cache = new HybridProductCatalogueCache(hybrid);
        var calls = 0;

        Task<ProductLookupResult> Factory(CancellationToken _)
        {
            calls++;
            return Task.FromResult(new ProductLookupResult(
                Guid.NewGuid(), "cheese", $"Cheese {calls}", "Test", "Base",
                "ingredients", true, 2.50m, null, false, true, 0, calls == 1, ["milk"]));
        }

        var first = await cache.GetByCodeAsync("cheese", Factory);
        var second = await cache.GetByCodeAsync("cheese", Factory);
        await new HybridCatalogueCacheInvalidator(
            hybrid,
            NullLogger<HybridCatalogueCacheInvalidator>.Instance).InvalidateProductsAsync();
        var refreshed = await cache.GetByCodeAsync("cheese", Factory);

        Assert.Multiple(() =>
        {
            Assert.That(first.Name, Is.EqualTo("Cheese 1"));
            Assert.That(second.Name, Is.EqualTo("Cheese 1"));
            Assert.That(refreshed.Name, Is.EqualTo("Cheese 2"));
            Assert.That(calls, Is.EqualTo(2));
        });
    }
}
