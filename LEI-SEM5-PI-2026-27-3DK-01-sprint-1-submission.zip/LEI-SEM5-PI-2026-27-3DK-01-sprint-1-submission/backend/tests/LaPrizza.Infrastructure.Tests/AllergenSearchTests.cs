using LaPrizza.Domain.Allergens;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class AllergenSearchTests
{
    private DomainDbContext _context = null!;
    private AllergenQueries _queries = null!;

    [SetUp]
    public async Task SetUp()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"allergen-search-{Guid.NewGuid():N}")
            .Options;

        _context = new DomainDbContext(options);
        _context.Allergens.AddRange(
            Allergen.Create("milk", "Milk", "Milk and dairy products."),
            Allergen.Create("peanut", "Peanut", null),
            Allergen.Create("tree-nut", "Tree Nut", null),
            Allergen.Create("special-percent", "100% Vegan", null),
            Allergen.Create("special-underscore", "Under_score", null));
        await _context.SaveChangesAsync();
        _context.ChangeTracker.Clear();
        _queries = new AllergenQueries(_context);
    }

    [TearDown]
    public async Task TearDown() => await _context.DisposeAsync();

    [TestCase("milk")]
    [TestCase("PEAN")]
    public async Task SearchAsync_matches_exact_code_or_name_fragment(string search)
    {
        var result = await _queries.SearchAsync(new AllergenSearchCriteria(search));

        Assert.That(result.Items.Select(item => item.Code), Is.EqualTo(
            search.Equals("milk", StringComparison.OrdinalIgnoreCase)
                ? new[] { "milk" }
                : new[] { "peanut" }));
    }

    [Test]
    public async Task SearchAsync_does_not_match_partial_code()
    {
        var result = await _queries.SearchAsync(new AllergenSearchCriteria("tree-"));

        Assert.That(result.Items, Is.Empty);
        Assert.That(result.TotalCount, Is.Zero);
    }

    [Test]
    public async Task SearchAsync_orders_pages_and_preserves_total_count()
    {
        var first = await _queries.SearchAsync(new AllergenSearchCriteria(null, 1, 2));
        var second = await _queries.SearchAsync(new AllergenSearchCriteria(" ", 2, 2));

        Assert.Multiple(() =>
        {
            Assert.That(first.Items.Select(item => item.Code), Is.EqualTo(new[] { "special-percent", "milk" }));
            Assert.That(second.Items.Select(item => item.Code), Is.EqualTo(new[] { "peanut", "tree-nut" }));
            Assert.That(first.TotalCount, Is.EqualTo(5));
            Assert.That(second.TotalCount, Is.EqualTo(5));
        });
    }

    [TestCase("%", "special-percent")]
    [TestCase("_", "special-underscore")]
    public async Task SearchAsync_treats_wildcards_as_literals(string search, string expectedCode)
    {
        var result = await _queries.SearchAsync(new AllergenSearchCriteria(search));

        Assert.That(result.Items.Select(item => item.Code), Is.EqualTo(new[] { expectedCode }));
    }

    [Test]
    public async Task SearchAsync_returns_empty_page_and_keeps_total_past_end()
    {
        var result = await _queries.SearchAsync(new AllergenSearchCriteria("milk", int.MaxValue, 100));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.Empty);
            Assert.That(result.TotalCount, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task SearchAsync_projects_without_tracking()
    {
        var result = await _queries.SearchAsync(new AllergenSearchCriteria("milk"));

        Assert.Multiple(() =>
        {
            Assert.That(result.Items.Single().Description, Is.EqualTo("Milk and dairy products."));
            Assert.That(_context.ChangeTracker.Entries(), Is.Empty);
        });
    }
}
