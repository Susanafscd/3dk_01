using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class ProductSearchTests
{
    private DomainDbContext _context = null!;
    private ProductQueries _queries = null!;

    [SetUp]
    public async Task SetUp()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"product-search-{Guid.NewGuid():N}")
            .Options;

        _context = new DomainDbContext(options);
        var pizza = BaseProduct("margherita", "Margherita", "pizza", true, false, ["milk"]);
        var pasta = BaseProduct("pasta", "Pasta", "pasta", false, true, ["wheat"]);
        var inactive = BaseProduct("old-pizza", "Old Pizza", "pizza", true, false, []);

        _context.Products.AddRange(pizza, pasta, inactive);
        _context.Entry(pizza).Property("ComponentTypeCode").CurrentValue = "pizza-base";
        await _context.SaveChangesAsync();
        _context.ChangeTracker.Clear();
        _queries = new ProductQueries(_context);
    }

    [TearDown]
    public async Task TearDown() => await _context.DisposeAsync();

    [TestCase("margherita")]
    [TestCase("GHERI")]
    public async Task SearchAsync_matches_code_or_name_fragment(string search)
    {
        var result = await _queries.SearchAsync(new ProductSearchCriteria(search, null, null, null, null, null, null, null, null));

        Assert.That(result.Items.Select(item => item.Code), Is.EqualTo(new[] { "margherita" }));
    }

    [Test]
    public async Task SearchAsync_combines_business_code_and_flag_filters()
    {
        var result = await _queries.SearchAsync(new ProductSearchCriteria(
            null,
            ProductCategoryCode.Create("pizza"),
            AllergenCode.Create("milk"),
            "pizza-base",
            true,
            false,
            true,
            ProductKind.Base,
            true));

        Assert.Multiple(() =>
        {
            Assert.That(result.TotalCount, Is.EqualTo(1));
            Assert.That(result.Items.Single().Code, Is.EqualTo("margherita"));
            Assert.That(result.Items.Single().AllergenCodes, Is.EqualTo(new[] { "milk" }));
        });
    }

    [Test]
    public async Task SearchAsync_orders_paginates_and_keeps_unpaged_count()
    {
        var result = await _queries.SearchAsync(new ProductSearchCriteria(null, null, null, null, null, null, null, null, null, 1, 2));

        Assert.Multiple(() =>
        {
            Assert.That(result.TotalCount, Is.EqualTo(3));
            Assert.That(result.Items.Select(item => item.Code), Is.EqualTo(new[] { "margherita", "old-pizza" }));
        });
    }

    private static BaseProduct BaseProduct(
        string code,
        string name,
        string category,
        bool sellable,
        bool stockControlled,
        IReadOnlyList<string> allergens)
        => new BaseProductBuilder()
            .WithCode(code)
            .WithName(name)
            .WithDescription($"{name} description")
            .InCategory(category)
            .AsSellable(sellable)
            .WithPrice(sellable ? 10m : null)
            .StockControlled(stockControlled)
            .WithAllergens(allergens)
            .Build();
}
