using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class ProductCategoryLookupTests
{
    [Test]
    public async Task GetLookupByCodeAsync_returns_only_the_requested_untracked_projection()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"category-lookup-{Guid.NewGuid():N}")
            .Options;

        await using var context = new DomainDbContext(options);
        context.ProductCategories.AddRange(
            ProductCategory.Create("pizza-component", "Pizza Component", "Pizza parts.", true),
            ProductCategory.Create("beverages", "Beverages", null, false));
        await context.SaveChangesAsync();
        context.ChangeTracker.Clear();

        var result = await new ProductCategoryRepository(context).GetLookupByCodeAsync(
            ProductCategoryCode.Create("beverages"));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.Not.Null);
            Assert.That(result!.Code, Is.EqualTo("beverages"));
            Assert.That(result.Name, Is.EqualTo("Beverages"));
            Assert.That(result.Description, Is.Null);
            Assert.That(result.AllowsComponentTypes, Is.False);
            Assert.That(context.ChangeTracker.Entries(), Is.Empty);
            Assert.That(context.ProductCategories.Count(), Is.EqualTo(2));
        });
    }

    [Test]
    public async Task GetLookupByCodeAsync_returns_null_for_an_unknown_code_without_tracking()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"category-lookup-{Guid.NewGuid():N}")
            .Options;

        await using var context = new DomainDbContext(options);

        var result = await new ProductCategoryRepository(context).GetLookupByCodeAsync(
            ProductCategoryCode.Create("unknown"));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.Null);
            Assert.That(context.ChangeTracker.Entries(), Is.Empty);
        });
    }
}
