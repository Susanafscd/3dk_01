using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

/// <summary>
/// Persistence of predefined pizzas (BCK10). Uses an isolated database; never
/// reads or changes the configured project's data.
/// </summary>
[TestFixture]
[Category("PostgreSQL")]
public sealed class ComposedProductPostgresPersistenceTests
{
    private static readonly IReadOnlyCollection<ComponentTypeLimit> TypeLimits =
    [
        new("base-dough", 1, 1),
        new("cheese", 0, 1),
    ];

    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_composed_test_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
        context.ProductCategories.AddRange(
            ProductCategory.Create("pizza-component", "Pizza components", null, true),
            ProductCategory.Create("pizzas", "Pizzas", null, false));
        context.PizzaSizes.AddRange(PizzaSize.Create("small"), PizzaSize.Create("medium"));
        await context.SaveChangesAsync();

        var repository = new ProductRepository(context);
        await repository.AddAndSaveAsync(Component("classic-dough"));
        await repository.AddAndSaveAsync(Component("mozzarella"));
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null)
        {
            return;
        }

        try
        {
            if (_admin.State == System.Data.ConnectionState.Open)
            {
                await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
                await drop.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Stores_a_pizza_with_its_components_and_sizes_and_reloads_it()
    {
        await using (var context = new DomainDbContext(_options))
        {
            Assert.That(context.Database.HasPendingModelChanges(), Is.False);
            await new ProductRepository(context).AddAndSaveAsync(
                Pizza(["classic-dough", "mozzarella"], ["small", "medium"]));
        }

        await using var reload = new DomainDbContext(_options);
        var product = await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("margherita"));

        Assert.That(product, Is.InstanceOf<ComposedProduct>());
        var pizza = (ComposedProduct)product!;
        Assert.Multiple(() =>
        {
            Assert.That(pizza.Components.Select(code => code.Value), Is.EquivalentTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(pizza.AvailableSizes.Select(size => size.SizeName), Is.EquivalentTo(new[] { "small", "medium" }));
            Assert.That(pizza.IsSellable, Is.True);
            Assert.That(pizza.Sellable, Is.Null);
            Assert.That(pizza.StockControlled, Is.False);
            Assert.That(pizza.StockBalance, Is.Null);
            Assert.That(pizza.Active, Is.True);
        });
    }

    [Test]
    public async Task Rejects_a_pizza_whose_component_does_not_exist()
    {
        await using var context = new DomainDbContext(_options);

        var exception = Assert.ThrowsAsync<DbUpdateException>(() =>
            new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough", "ghost"], ["small"])));

        AssertForeignKeyViolation(exception);
    }

    [Test]
    public async Task Rejects_a_pizza_in_a_size_that_does_not_exist()
    {
        await using var context = new DomainDbContext(_options);

        var exception = Assert.ThrowsAsync<DbUpdateException>(() =>
            new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough"], ["huge"])));

        AssertForeignKeyViolation(exception);
    }

    [Test]
    public async Task A_component_used_by_a_pizza_cannot_be_deleted()
    {
        await using var context = new DomainDbContext(_options);
        await new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough", "mozzarella"], ["small"]));

        var exception = Assert.ThrowsAsync<PostgresException>(() =>
            context.Database.ExecuteSqlRawAsync("""DELETE FROM "Products" WHERE "Code" = 'mozzarella'"""));

        Assert.That(exception!.SqlState, Is.EqualTo(PostgresErrorCodes.ForeignKeyViolation));
    }

    [Test]
    public async Task Deactivating_a_component_used_by_a_pizza_is_allowed_and_preserves_the_pizza()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough", "mozzarella"], ["small"]));

            var component = await new ProductRepository(context).GetByCodeAsync(ProductCode.Create("mozzarella"));
            Assert.That(component, Is.Not.Null);
            Assert.That(component!.Deactivate(), Is.True);
            await new ProductRepository(context).SaveAsync(component);
        }

        await using var reload = new DomainDbContext(_options);
        var repository = new ProductRepository(reload);
        var componentAfterReload = await repository.GetByCodeAsync(ProductCode.Create("mozzarella"));
        var pizza = await repository.GetByCodeAsync(ProductCode.Create("margherita"));

        Assert.Multiple(() =>
        {
            Assert.That(componentAfterReload!.Active, Is.False);
            Assert.That(pizza, Is.InstanceOf<ComposedProduct>());
            Assert.That(pizza!.Active, Is.True);
            Assert.That(((ComposedProduct)pizza).Components.Select(code => code.Value),
                Is.EquivalentTo(new[] { "classic-dough", "mozzarella" }));
        });
    }

    [Test]
    public async Task A_size_used_by_a_pizza_cannot_be_deleted()
    {
        await using var context = new DomainDbContext(_options);
        await new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough"], ["small"]));

        var exception = Assert.ThrowsAsync<PostgresException>(() =>
            context.Database.ExecuteSqlRawAsync("""DELETE FROM "PizzaSizes" WHERE "Name" = 'small'"""));

        Assert.That(exception!.SqlState, Is.EqualTo(PostgresErrorCodes.ForeignKeyViolation));
    }

    [Test]
    public async Task Stores_a_replaced_configuration_and_sizes()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough", "mozzarella"], ["small"]));
        }

        await using (var context = new DomainDbContext(_options))
        {
            var repository = new ProductRepository(context);
            var pizza = (ComposedProduct)(await repository.GetByCodeAsync(ProductCode.Create("margherita")))!;
            pizza.ReplaceConfiguration(
                "Plain",
                "Dough only",
                [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
                TypeLimits,
                ["small", "medium"]);
            await repository.SaveAsync(pizza);
        }

        await using var reload = new DomainDbContext(_options);
        var stored = (ComposedProduct)(await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("margherita")))!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Name, Is.EqualTo("Plain"));
            Assert.That(stored.Components.Select(code => code.Value), Is.EqualTo(new[] { "classic-dough" }));
            Assert.That(stored.AvailableSizes.Select(size => size.SizeName), Is.EquivalentTo(new[] { "small", "medium" }));
        });
    }

    [Test]
    public async Task Rejects_a_replacement_in_a_size_that_does_not_exist()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await new ProductRepository(context).AddAndSaveAsync(Pizza(["classic-dough"], ["small"]));
        }

        await using var update = new DomainDbContext(_options);
        var repository = new ProductRepository(update);
        var pizza = (ComposedProduct)(await repository.GetByCodeAsync(ProductCode.Create("margherita")))!;
        pizza.ReplaceConfiguration(
            "Margherita",
            "Tomato and mozzarella",
            [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
            TypeLimits,
            ["huge"]);

        var exception = Assert.ThrowsAsync<DbUpdateException>(() => repository.SaveAsync(pizza));

        AssertForeignKeyViolation(exception);
    }

    private static void AssertForeignKeyViolation(DbUpdateException? exception)
    {
        Assert.That(exception!.InnerException, Is.InstanceOf<PostgresException>());
        Assert.That(((PostgresException)exception.InnerException!).SqlState, Is.EqualTo(PostgresErrorCodes.ForeignKeyViolation));
    }

    private static BaseProduct Component(string code) => new BaseProductBuilder()
        .WithCode(code)
        .WithName(code)
        .WithDescription("Pizza component")
        .InCategory("pizza-component")
        .StockControlled()
        .Build();

    private static ComposedProduct Pizza(IReadOnlyList<string> components, IReadOnlyCollection<string> sizes) =>
        ComposedProduct.Create(
            "margherita",
            "Margherita",
            "Tomato and mozzarella",
            "pizzas",
            components.Select((code, index) => new PizzaComponent(
                ProductCode.Create(code), true, index == 0 ? "base-dough" : "cheese")).ToList(),
            TypeLimits,
            sizes);
}
