using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class ProductCategoryUpdateTests
{
    [Test]
    public async Task UpdateAndSaveAsync_persists_details_without_changing_identity_or_code()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"category-update-{Guid.NewGuid():N}")
            .Options;

        var category = ProductCategory.Create("ingredients", "Ingredients", "Original", true);
        var id = category.Id;

        await using (var setup = new DomainDbContext(options))
        {
            setup.ProductCategories.Add(category);
            await setup.SaveChangesAsync();
        }

        await using (var writeContext = new DomainDbContext(options))
        {
            var repository = new ProductCategoryRepository(writeContext);
            var loaded = await repository.GetByCodeAsync(ProductCategoryCode.Create("ingredients"));
            loaded!.Update("Updated ingredients", null, true, false);

            await repository.UpdateAndSaveAsync(loaded);
        }

        await using var readContext = new DomainDbContext(options);
        var persisted = await readContext.ProductCategories.SingleAsync();

        Assert.Multiple(() =>
        {
            Assert.That(persisted.Id, Is.EqualTo(id));
            Assert.That(persisted.Code.Value, Is.EqualTo("ingredients"));
            Assert.That(persisted.Name, Is.EqualTo("Updated ingredients"));
            Assert.That(persisted.Description, Is.Null);
            Assert.That(persisted.AllowsComponentTypes, Is.True);
        });
    }
}
