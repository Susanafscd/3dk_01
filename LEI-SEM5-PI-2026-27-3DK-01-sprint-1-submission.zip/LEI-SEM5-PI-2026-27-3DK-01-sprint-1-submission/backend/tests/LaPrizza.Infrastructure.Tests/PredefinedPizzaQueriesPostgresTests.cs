using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.SizeConfigurations;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

/// <summary>
/// Facts that predefined pizzas read from other aggregates (BCK10). Uses an
/// isolated database; never reads or changes the configured project's data.
/// </summary>
[TestFixture]
[Category("PostgreSQL")]
public sealed class PredefinedPizzaQueriesPostgresTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_pizza_queries_test_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
        context.ProductCategories.AddRange(
            ProductCategory.Create("pizza-component", "Pizza components", null, true),
            ProductCategory.Create("beverages", "Beverages", null, false));
        context.PizzaSizes.AddRange(PizzaSize.Create("small"), PizzaSize.Create("medium"));
        context.PizzaComponentTypes.AddRange(
            PizzaComponentType.Create("base-dough", "pizza-component", "Base Dough", null, 1, 1, 1),
            PizzaComponentType.Create("topping", "pizza-component", "Topping", null, 4, 0, null));
        await context.SaveChangesAsync();

        var repository = new ProductRepository(context);
        var dough = Product("classic-dough", "pizza-component", "Classic dough");
        dough.SetSizeConfiguration(SizeConfiguration.Empty
            .AddSizeConfiguration("small", 2.00m, 1)
            .AddSizeConfiguration("medium", 3.00m, 1)
            .UpdateSizeConfiguration("medium", 3.00m, 1, active: false));
        await repository.AddAndSaveAsync(dough);
        await repository.AddAndSaveAsync(Product("cola", "beverages"));
        await context.Database.ExecuteSqlRawAsync(
            """UPDATE "Products" SET "ComponentTypeCode" = 'base-dough' WHERE "Code" = 'classic-dough'""");
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null)
        {
            return;
        }

        try
        {
            if (_admin.State == System.Data.ConnectionState.Open)
            {
                await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
                await drop.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Returns_the_type_category_rule_and_active_size_prices_of_a_component()
    {
        await using var context = new DomainDbContext(_options);

        var facts = await new PredefinedPizzaQueries(context).GetComponentsAsync([ProductCode.Create("classic-dough")]);

        var dough = facts.Single();
        Assert.Multiple(() =>
        {
            Assert.That(dough.Code.Value, Is.EqualTo("classic-dough"));
            Assert.That(dough.Name, Is.EqualTo("Classic dough"));
            Assert.That(dough.AssemblyOrder, Is.EqualTo(1));
            Assert.That(dough.IsBaseProduct, Is.True);
            Assert.That(dough.Active, Is.True);
            Assert.That(dough.CategoryAllowsComponentTypes, Is.True);
            Assert.That(dough.ComponentTypeCode, Is.EqualTo("base-dough"));
            // The medium configuration is inactive, so only small is offered.
            Assert.That(dough.ActiveSizePrices, Is.EquivalentTo(new Dictionary<string, decimal> { ["small"] = 2.00m }));
        });
    }

    [Test]
    public async Task Reports_a_product_whose_category_does_not_allow_component_types()
    {
        await using var context = new DomainDbContext(_options);

        var facts = await new PredefinedPizzaQueries(context).GetComponentsAsync([ProductCode.Create("cola")]);

        var cola = facts.Single();
        Assert.Multiple(() =>
        {
            Assert.That(cola.CategoryAllowsComponentTypes, Is.False);
            Assert.That(cola.ComponentTypeCode, Is.Null);
            Assert.That(cola.AssemblyOrder, Is.Null);
            Assert.That(cola.ActiveSizePrices, Is.Empty);
        });
    }

    [Test]
    public async Task Leaves_out_codes_that_do_not_exist()
    {
        await using var context = new DomainDbContext(_options);

        var facts = await new PredefinedPizzaQueries(context).GetComponentsAsync(
            [ProductCode.Create("classic-dough"), ProductCode.Create("ghost")]);

        Assert.That(facts.Select(fact => fact.Code.Value), Is.EqualTo(new[] { "classic-dough" }));
    }

    [Test]
    public async Task Reports_a_composed_product_as_not_a_base_product()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await new ProductRepository(context).AddAndSaveAsync(ComposedProduct.Create(
                "margherita", "Margherita", "Pizza", "pizza-component",
                [new PizzaComponent(ProductCode.Create("classic-dough"), true, "base-dough")],
                [new ComponentTypeLimit("base-dough", 1, 1)],
                ["small"]));
        }

        await using var reload = new DomainDbContext(_options);
        var facts = await new PredefinedPizzaQueries(reload).GetComponentsAsync([ProductCode.Create("margherita")]);

        Assert.That(facts.Single().IsBaseProduct, Is.False);
    }

    [Test]
    public async Task Returns_the_limits_of_every_component_type()
    {
        await using var context = new DomainDbContext(_options);

        var limits = await new PredefinedPizzaQueries(context).GetComponentTypeLimitsAsync();

        Assert.That(limits, Is.EquivalentTo(new[]
        {
            new ComponentTypeLimit("base-dough", 1, 1),
            new ComponentTypeLimit("topping", 0, null),
        }));
    }

    private static BaseProduct Product(string code, string category, string? name = null) => new BaseProductBuilder()
        .WithCode(code)
        .WithName(name ?? code)
        .WithDescription("Test product")
        .InCategory(category)
        .StockControlled()
        .Build();
}
