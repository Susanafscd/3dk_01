using LaPrizza.Domain.Allergens;
using LaPrizza.Application.Products.UpdateProduct;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

/// <summary>Uses an isolated database; never reads or changes the configured project's data.</summary>
[TestFixture]
[Category("PostgreSQL")]
public sealed class ProductPostgresPersistenceTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_product_test_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null)
        {
            return;
        }

        try
        {
            if (_admin.State == System.Data.ConnectionState.Open)
            {
                await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
                await drop.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Fresh_migrations_support_optional_prices_multiple_allergens_and_combined_search()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await context.Database.MigrateAsync();
            Assert.That(context.Database.HasPendingModelChanges(), Is.False);
            context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
            context.Allergens.AddRange(Allergen.Create("milk", "Milk", null), Allergen.Create("wheat", "Wheat", null));
            await context.SaveChangesAsync();

            var repository = new ProductRepository(context);
            await repository.AddAndSaveAsync(Product("flour", true, false, ["milk", "wheat"]));
            await repository.AddAndSaveAsync(Product("stock-only", false, true, []));
            context.ChangeTracker.Clear();

            var page = await new ProductQueries(context).SearchAsync(new ProductSearchCriteria(
                null, ProductCategoryCode.Create("ingredients"), AllergenCode.Create("milk"),
                null, true, false, false, ProductKind.Base, true));
            Assert.Multiple(() =>
            {
                Assert.That(page.TotalCount, Is.EqualTo(1));
                Assert.That(page.Items.Single().AllergenCodes, Is.EqualTo(new[] { "milk", "wheat" }));
            });
        }

        await using var reload = new DomainDbContext(_options);
        var repositoryAfterReload = new ProductRepository(reload);
        var sellable = await repositoryAfterReload.GetByCodeAsync(ProductCode.Create("flour"));
        var stockOnly = await repositoryAfterReload.GetByCodeAsync(ProductCode.Create("stock-only"));
        Assert.Multiple(() =>
        {
            Assert.That(sellable!.Sellable!.Price.Amount, Is.EqualTo(2.50m));
            Assert.That(sellable.Allergens.Select(code => code.Value), Is.EquivalentTo(new[] { "milk", "wheat" }));
            Assert.That(stockOnly!.Sellable, Is.Null);
            Assert.That(stockOnly.StockBalance, Is.Zero);
        });
    }

    [Test]
    public async Task Product_update_replaces_details_and_persists_stock_transition_atomically()
    {
        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
        context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
        context.Allergens.Add(Allergen.Create("milk", "Milk", null));
        await context.SaveChangesAsync();

        var repository = new ProductRepository(context);
        await repository.AddAndSaveAsync(Product("sample", true, true, []));

        var handler = new UpdateProductCommandHandler(
            repository,
            new ProductRelationshipQueries(context),
            new ProductUpdateQueries(context));

        var result = await handler.ExecuteAsync(new UpdateProductCommand(
            "sample", "Updated", "Updated description", "ingredients",
            true, false, 3.50m, ["milk"]));

        context.ChangeTracker.Clear();
        var reloaded = await repository.GetByCodeAsync(ProductCode.Create("sample"));
        Assert.Multiple(() =>
        {
            Assert.That(result.Name, Is.EqualTo("Updated"));
            Assert.That(result.StockBalance, Is.Null);
            Assert.That(reloaded!.Name, Is.EqualTo("Updated"));
            Assert.That(reloaded.StockControlled, Is.False);
            Assert.That(reloaded.StockBalance, Is.Null);
            Assert.That(reloaded.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "milk" }));
        });
    }

    [Test]
    public async Task Upgrade_and_downgrade_preserve_existing_product_price_and_allergen_rows()
    {
        var id = Guid.NewGuid();
        await using var context = new DomainDbContext(_options);
        var migrator = context.GetService<IMigrator>();
        const string original = "20261023161041_AddProductsAndAllergensTable";
        await migrator.MigrateAsync(original);
        context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
        context.Allergens.AddRange(Allergen.Create("milk", "Milk", null), Allergen.Create("wheat", "Wheat", null));
        await context.SaveChangesAsync();
        await context.Database.ExecuteSqlInterpolatedAsync($"""
            INSERT INTO "ProductAllergens" ("Id", "Code", "Name", "Description", "CategoryCode", "StockControlled", "StockBalance", "Active", "Kind")
            VALUES ({id}, 'legacy-product', 'Legacy', 'Existing product', 'ingredients', false, NULL, true, 'Base')
            """);
        await context.Database.ExecuteSqlInterpolatedAsync($"""
            INSERT INTO "Products" ("ProductId", "PriceAmount") VALUES ({id}, 2.50)
            """);
        await context.Database.ExecuteSqlInterpolatedAsync($"""
            INSERT INTO "AllergenCode" ("ProductId", "AllergenCode") VALUES ({id}, 'milk'), ({id}, 'wheat')
            """);

        await migrator.MigrateAsync();
        await AssertLegacyProduct(context, id);
        context.ChangeTracker.Clear();
        await migrator.MigrateAsync(original);
        await migrator.MigrateAsync();
        await AssertLegacyProduct(context, id);
    }

    [Test]
    public async Task Duplicate_product_creation_rolls_back_its_price_and_allergen_rows()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await context.Database.MigrateAsync();
            context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
            context.Allergens.AddRange(Allergen.Create("milk", "Milk", null), Allergen.Create("wheat", "Wheat", null));
            await context.SaveChangesAsync();
            await new ProductRepository(context).AddAndSaveAsync(Product("flour", true, false, ["milk"]));
        }

        await using (var duplicateContext = new DomainDbContext(_options))
        {
            Assert.ThrowsAsync<DuplicateProductCodeException>(() => new ProductRepository(duplicateContext)
                .AddAndSaveAsync(Product("flour", true, false, ["wheat"])));
        }

        await using var reload = new DomainDbContext(_options);
        var product = await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("flour"));
        Assert.Multiple(() =>
        {
            Assert.That(reload.Products.Count(), Is.EqualTo(1));
            Assert.That(product!.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "milk" }));
            Assert.That(product.Sellable!.Price.Amount, Is.EqualTo(2.50m));
        });
    }

    [Test]
    public async Task Existing_product_database_gains_size_configuration_without_recreating_catalogues()
    {
        var id = Guid.NewGuid();
        await using (var context = new DomainDbContext(_options))
        {
            await context.GetService<IMigrator>().MigrateAsync("20261023215215_AddProductComponentTypeProjection");
            context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, true));
            context.Allergens.Add(Allergen.Create("milk", "Milk", null));
            await context.SaveChangesAsync();
            await context.Database.ExecuteSqlInterpolatedAsync($"""
                INSERT INTO "Products" ("Id", "Code", "Name", "Description", "CategoryCode", "StockControlled", "StockBalance", "Active", "Kind")
                VALUES ({id}, 'existing-product', 'Existing', 'Before BCK08', 'ingredients', true, 0, true, 'Base')
                """);
            await context.Database.MigrateAsync();
            var product = (BaseProduct)(await new ProductRepository(context).GetByCodeAsync(ProductCode.Create("existing-product")))!;
            Assert.That(product.SizeConfiguration, Is.Null);
            product.SetSizeConfiguration(LaPrizza.Domain.SizeConfigurations.SizeConfiguration.Empty.AddSizeConfiguration("medium", 3m, 2));
            await context.SaveChangesAsync();
        }

        await using var reload = new DomainDbContext(_options);
        var stored = (BaseProduct)(await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("existing-product")))!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Id, Is.EqualTo(id));
            Assert.That(stored.SizeConfiguration!.SizeMappings["medium"].Price, Is.EqualTo(3m));
            Assert.That(stored.SizeConfiguration.SizeMappings["medium"].StockConsumption, Is.EqualTo(2));
            Assert.That(reload.ProductCategories.Single().Code.Value, Is.EqualTo("ingredients"));
            Assert.That(reload.Allergens.Single().Code.Value, Is.EqualTo("milk"));
        });
    }

    [Test]
    public async Task Common_product_update_replaces_details_and_allergens_without_changing_identity()
    {
        Guid id;
        await using (var context = new DomainDbContext(_options))
        {
            await context.Database.MigrateAsync();
            context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
            context.Allergens.AddRange(Allergen.Create("milk", "Milk", null), Allergen.Create("wheat", "Wheat", null));
            await context.SaveChangesAsync();

            var product = Product("update-me", true, true, ["milk"]);
            id = product.Id;
            await new ProductRepository(context).AddAndSaveAsync(product);
        }

        await using (var context = new DomainDbContext(_options))
        {
            var product = await new ProductRepository(context).GetByCodeAsync(ProductCode.Create("update-me"));
            product!.UpdateCommonDetails("Updated product", "Updated description", [AllergenCode.Create("wheat")]);
            await new ProductRepository(context).SaveAsync(product);
        }

        await using var reload = new DomainDbContext(_options);
        var stored = await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("update-me"));
        Assert.Multiple(() =>
        {
            Assert.That(stored!.Id, Is.EqualTo(id));
            Assert.That(stored.Code.Value, Is.EqualTo("update-me"));
            Assert.That(stored.Name, Is.EqualTo("Updated product"));
            Assert.That(stored.Description, Is.EqualTo("Updated description"));
            Assert.That(stored.Active, Is.True);
            Assert.That(stored.StockControlled, Is.True);
            Assert.That(stored.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "wheat" }));
        });
    }

    [Test]
    public async Task Deactivation_is_persisted_and_preserves_product_information()
    {
        await using (var context = new DomainDbContext(_options))
        {
            await context.Database.MigrateAsync();
            context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, true));
            context.Allergens.Add(Allergen.Create("milk", "Milk", null));
            await context.SaveChangesAsync();

            var product = Product("cheese", true, true, ["milk"]);
            ((BaseProduct)product).SetSizeConfiguration(
                LaPrizza.Domain.SizeConfigurations.SizeConfiguration.Empty
                    .AddSizeConfiguration("medium", 3m, 2));
            var repository = new ProductRepository(context);
            await repository.AddAndSaveAsync(product);
            product.IncreaseStock(7);
            await repository.SaveAsync(product);

            Assert.That(product.Deactivate(), Is.True);
            await repository.SaveAsync(product);
            Assert.That(product.Deactivate(), Is.False);
            await repository.SaveAsync(product);
        }

        await using var reload = new DomainDbContext(_options);
        var stored = (BaseProduct)(await new ProductRepository(reload)
            .GetByCodeAsync(ProductCode.Create("cheese")))!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Active, Is.False);
            Assert.That(stored.StockBalance, Is.EqualTo(7));
            Assert.That(stored.Allergens.Select(code => code.Value), Is.EqualTo(new[] { "milk" }));
            Assert.That(stored.SizeConfiguration!.SizeMappings["medium"].Price, Is.EqualTo(3m));
            Assert.That(stored.Code.Value, Is.EqualTo("cheese"));
        });
    }

    private static async Task AssertLegacyProduct(DomainDbContext context, Guid identity)
    {
        var product = await new ProductRepository(context).GetByCodeAsync(ProductCode.Create("legacy-product"));
        Assert.Multiple(() =>
        {
            Assert.That(product!.Id, Is.EqualTo(identity));
            Assert.That(product.Name, Is.EqualTo("Legacy"));
            Assert.That(product.Active, Is.True);
            Assert.That(product.Sellable!.Price.Amount, Is.EqualTo(2.50m));
            Assert.That(product.Allergens.Select(code => code.Value), Is.EquivalentTo(new[] { "milk", "wheat" }));
        });
    }

    private static BaseProduct Product(string code, bool sellable, bool stock, IReadOnlyList<string> allergens) =>
        new BaseProductBuilder().WithCode(code).WithName(code).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(sellable).WithPrice(sellable ? 2.50m : null)
            .StockControlled(stock).WithAllergens(allergens).Build();
}
