using LaPrizza.Domain.Allergens;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class AllergenUpdateTests
{
    [Test]
    public async Task UpdateAndSaveAsync_persists_new_details_without_changing_identity_or_code()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"allergen-update-{Guid.NewGuid():N}")
            .Options;

        var allergen = Allergen.Create("milk", "Milk", "Milk products.");
        var id = allergen.Id;

        await using (var setup = new DomainDbContext(options))
        {
            setup.Allergens.Add(allergen);
            await setup.SaveChangesAsync();
        }

        await using (var writeContext = new DomainDbContext(options))
        {
            var repository = new AllergenRepository(writeContext);
            var loaded = await repository.GetByCodeAsync(AllergenCode.Create("milk"));
            loaded!.UpdateDetails("Dairy", "Includes milk.");

            await repository.UpdateAndSaveAsync(loaded);
        }

        await using var readContext = new DomainDbContext(options);
        var persisted = await readContext.Allergens.SingleAsync();

        Assert.Multiple(() =>
        {
            Assert.That(persisted.Id, Is.EqualTo(id));
            Assert.That(persisted.Code.Value, Is.EqualTo("milk"));
            Assert.That(persisted.Name, Is.EqualTo("Dairy"));
            Assert.That(persisted.Description, Is.EqualTo("Includes milk."));
        });
    }
}
