using LaPrizza.Domain.Product;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
[Category("PostgreSQL")]
public sealed class ProductCategoryRemovalPostgresTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_category_removal_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null) return;
        try
        {
            await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
            await drop.ExecuteNonQueryAsync();
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Unused_category_can_be_removed_and_does_not_reappear()
    {
        await using var context = new DomainDbContext(_options);
        var category = ProductCategory.Create("unused", "Unused", null, false);
        context.ProductCategories.Add(category);
        await context.SaveChangesAsync();

        Assert.That(await new ProductCategoryUsageQueries(context)
            .HasProductReferencesAsync(category.Code), Is.False);
        await new ProductCategoryRepository(context).RemoveAsync(category);

        context.ChangeTracker.Clear();
        Assert.That(await context.ProductCategories.AnyAsync(), Is.False);
    }

    [TestCase(true)]
    [TestCase(false)]
    public async Task Active_and_inactive_product_references_block_removal(bool active)
    {
        await using var context = new DomainDbContext(_options);
        var category = ProductCategory.Create("ingredients", "Ingredients", null, false);
        context.ProductCategories.Add(category);
        var product = Product("referencing-product");
        context.Products.Add(product);
        await context.SaveChangesAsync();
        if (!active)
        {
            await context.Database.ExecuteSqlRawAsync(
                "UPDATE \"Products\" SET \"Active\" = FALSE WHERE \"Code\" = 'referencing-product'");
            context.ChangeTracker.Clear();
            category = await context.ProductCategories.SingleAsync();
        }

        Assert.That(await new ProductCategoryUsageQueries(context)
            .HasProductReferencesAsync(category.Code), Is.True);
        Assert.ThrowsAsync<ProductCategoryInUseException>(() =>
            new ProductCategoryRepository(context).RemoveAsync(category));

        context.ChangeTracker.Clear();
        Assert.Multiple(() =>
        {
            Assert.That(context.ProductCategories.Count(), Is.EqualTo(1));
            Assert.That(context.Products.Count(), Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Concurrent_product_reference_cannot_race_category_deletion()
    {
        await using (var seed = new DomainDbContext(_options))
        {
            seed.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
            await seed.SaveChangesAsync();
        }

        await using var writer = new DomainDbContext(_options);
        await using var transaction = await writer.Database.BeginTransactionAsync();
        writer.Products.Add(Product("concurrent-product"));
        await writer.SaveChangesAsync();

        await using var remover = new DomainDbContext(_options);
        var category = await remover.ProductCategories.SingleAsync();
        var removal = new ProductCategoryRepository(remover).RemoveAsync(category);

        await Task.Delay(150);
        await transaction.CommitAsync();

        Assert.ThrowsAsync<ProductCategoryInUseException>(async () => await removal);

        await using var verify = new DomainDbContext(_options);
        Assert.Multiple(() =>
        {
            Assert.That(verify.ProductCategories.Count(), Is.EqualTo(1));
            Assert.That(verify.Products.Count(), Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Component_type_reference_blocks_category_removal()
    {
        await using var context = new DomainDbContext(_options);
        var category = ProductCategory.Create("pizza-component", "Pizza component", null, true);
        context.ProductCategories.Add(category);
        await context.SaveChangesAsync();
        context.PizzaComponentTypes.Add(PizzaComponentType.Create(
            "base-dough", category.Code.Value, "Base dough", null, 1, 1, 1));
        await context.SaveChangesAsync();

        Assert.That(await new ProductCategoryUsageQueries(context)
            .HasComponentTypeReferencesAsync(category.Code), Is.True);
        Assert.ThrowsAsync<ProductCategoryInUseException>(() =>
            new ProductCategoryRepository(context).RemoveAsync(category));

        context.ChangeTracker.Clear();
        Assert.Multiple(() =>
        {
            Assert.That(context.ProductCategories.Count(), Is.EqualTo(1));
            Assert.That(context.PizzaComponentTypes.Count(), Is.EqualTo(1));
        });
    }

    private static BaseProduct Product(string code) =>
        new BaseProductBuilder().WithCode(code).WithName(code).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(true).WithPrice(2.50m)
            .StockControlled(false).WithAllergens([]).Build();
}
