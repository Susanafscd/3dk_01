using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class ProductCategorySearchTests
{
    private DomainDbContext _context = null!;
    private ProductCategoryQueries _queries = null!;

    [SetUp]
    public async Task SetUp()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"category-search-{Guid.NewGuid():N}")
            .Options;

        _context = new DomainDbContext(options);
        _context.ProductCategories.AddRange(
            ProductCategory.Create("classic-a", "Classic", null, false),
            ProductCategory.Create("classic-b", "Classic", "Second classic.", true),
            ProductCategory.Create("pizza-component", "Pizza Component", "Pizza parts.", true),
            ProductCategory.Create("special-percent", "100% Vegan", null, false),
            ProductCategory.Create("special-underscore", "Under_score", null, false));
        await _context.SaveChangesAsync();
        _context.ChangeTracker.Clear();
        _queries = new ProductCategoryQueries(_context);
    }

    [TearDown]
    public async Task TearDown() => await _context.DisposeAsync();

    [TestCase("pizza-component")]
    [TestCase("PIZZA COMP")]
    public async Task SearchAsync_matches_an_exact_code_or_name_fragment(string search)
    {
        var result = await _queries.SearchAsync(search, 1, 20);

        Assert.That(result.Items.Select(item => item.Code),
            Is.EqualTo(new[] { "pizza-component" }));
    }

    [Test]
    public async Task SearchAsync_does_not_match_a_partial_code()
    {
        var result = await _queries.SearchAsync("classic-", 1, 20);

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.Empty);
            Assert.That(result.TotalCount, Is.Zero);
        });
    }

    [Test]
    public async Task SearchAsync_sorts_by_name_then_code_and_pages_without_changing_total()
    {
        var firstPage = await _queries.SearchAsync(null, 1, 2);
        var secondPage = await _queries.SearchAsync("  ", 2, 2);

        Assert.Multiple(() =>
        {
            Assert.That(firstPage.Items.Select(item => item.Code),
                Is.EqualTo(new[] { "special-percent", "classic-a" }));
            Assert.That(secondPage.Items.Select(item => item.Code),
                Is.EqualTo(new[] { "classic-b", "pizza-component" }));
            Assert.That(firstPage.TotalCount, Is.EqualTo(5));
            Assert.That(secondPage.TotalCount, Is.EqualTo(5));
        });
    }

    [TestCase("%", "special-percent")]
    [TestCase("_", "special-underscore")]
    public async Task SearchAsync_treats_wildcard_characters_as_literals(
        string search,
        string expectedCode)
    {
        var result = await _queries.SearchAsync(search, 1, 20);

        Assert.That(result.Items.Select(item => item.Code), Is.EqualTo(new[] { expectedCode }));
    }

    [Test]
    public async Task SearchAsync_returns_empty_items_but_keeps_total_for_a_page_past_the_end()
    {
        var result = await _queries.SearchAsync("classic", int.MaxValue, 100);

        Assert.Multiple(() =>
        {
            Assert.That(result.Items, Is.Empty);
            Assert.That(result.TotalCount, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task SearchAsync_projects_all_public_fields_without_tracking()
    {
        var item = (await _queries.SearchAsync("classic-a", 1, 1)).Items.Single();

        Assert.Multiple(() =>
        {
            Assert.That(item.Code, Is.EqualTo("classic-a"));
            Assert.That(item.Name, Is.EqualTo("Classic"));
            Assert.That(item.Description, Is.Null);
            Assert.That(item.AllowsComponentTypes, Is.False);
            Assert.That(_context.ChangeTracker.Entries(), Is.Empty);
        });
    }
}
