using LaPrizza.Domain.Allergens;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class AllergenLookupTests
{
    [Test]
    public async Task GetLookupByCodeAsync_returns_only_the_requested_untracked_projection()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"allergen-lookup-{Guid.NewGuid():N}")
            .Options;

        await using var context = new DomainDbContext(options);
        context.Allergens.AddRange(
            Allergen.Create("tree-nuts", "Tree nuts", "Nuts from trees."),
            Allergen.Create("milk", "Milk", null));
        await context.SaveChangesAsync();
        context.ChangeTracker.Clear();

        var result = await new AllergenRepository(context).GetLookupByCodeAsync(
            AllergenCode.Create("milk"));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.Not.Null);
            Assert.That(result!.Code, Is.EqualTo("milk"));
            Assert.That(result.Name, Is.EqualTo("Milk"));
            Assert.That(result.Description, Is.Null);
            Assert.That(context.ChangeTracker.Entries(), Is.Empty);
            Assert.That(context.Allergens.Count(), Is.EqualTo(2));
        });
    }

    [Test]
    public async Task GetLookupByCodeAsync_returns_null_for_an_unknown_code_without_tracking()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"allergen-lookup-{Guid.NewGuid():N}")
            .Options;

        await using var context = new DomainDbContext(options);

        var result = await new AllergenRepository(context).GetLookupByCodeAsync(
            AllergenCode.Create("unknown"));

        Assert.Multiple(() =>
        {
            Assert.That(result, Is.Null);
            Assert.That(context.ChangeTracker.Entries(), Is.Empty);
        });
    }
}
