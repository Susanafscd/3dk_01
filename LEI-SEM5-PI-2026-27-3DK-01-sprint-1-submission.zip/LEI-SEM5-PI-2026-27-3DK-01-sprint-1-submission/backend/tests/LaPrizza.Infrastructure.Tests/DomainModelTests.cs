using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class DomainModelTests
{
    [Test]
    public void The_domain_model_has_a_matching_migration_snapshot()
    {
        using var context = CreateContext();
        Assert.That(context.Database.HasPendingModelChanges(), Is.False);
    }

    [Test]
    public void The_domain_model_maps_onto_the_relational_store()
    {
        using var context = CreateContext();

        Assert.Multiple(() =>
        {
            Assert.That(TableName<User>(context), Is.EqualTo("Users"));
            Assert.That(TableName<ProductCategory>(context), Is.EqualTo("ProductCategories"));
            Assert.That(TableName<Allergen>(context), Is.EqualTo("Allergens"));
            Assert.That(TableName<Product>(context), Is.EqualTo("Products"));
            var category = context.GetService<IDesignTimeModel>().Model
                .FindEntityType(typeof(ProductCategory))!;
            Assert.That(category.GetIndexes().Single(index =>
                index.Properties.Single().Name == nameof(ProductCategory.Code)).IsUnique, Is.True);
            Assert.That(category.GetCheckConstraints().Single(constraint =>
                constraint.Name == "CK_ProductCategories_Code").Sql,
                Is.EqualTo("\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));
            var allergen = context.GetService<IDesignTimeModel>().Model
                .FindEntityType(typeof(Allergen))!;
            Assert.That(allergen.GetIndexes().Single(index =>
                index.Properties.Single().Name == nameof(Allergen.Code)).IsUnique, Is.True);
            Assert.That(allergen.GetCheckConstraints().Single(constraint =>
                constraint.Name == "CK_Allergens_Code").Sql,
                Is.EqualTo("\"Code\" ~ '^[a-z0-9]+(-[a-z0-9]+)*$'"));
        });
    }

    [Test]
    public async Task An_allergen_is_round_tripped_with_its_business_identity()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"allergen-{Guid.NewGuid():N}")
            .Options;
        var allergen = Allergen.Create(
            "tree-nuts", "Tree nuts", "Tree nuts and products thereof.");

        using (var context = new DomainDbContext(options))
        {
            context.Allergens.Add(allergen);
            await context.SaveChangesAsync();
        }

        using (var context = new DomainDbContext(options))
        {
            var stored = await context.Allergens.SingleAsync();

            Assert.Multiple(() =>
            {
                Assert.That(stored.Code.Value, Is.EqualTo("tree-nuts"));
                Assert.That(stored.Name, Is.EqualTo("Tree nuts"));
                Assert.That(stored.Description, Is.EqualTo("Tree nuts and products thereof."));
            });
        }
    }

    [Test]
    public void A_customer_is_round_tripped_with_its_profile()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"domain-{Guid.NewGuid():N}")
            .Options;

        using (var context = new DomainDbContext(options))
        {
            context.Users.Add(Customer.Create(
                Email.Create("ada@example.com"),
                "Ada Lovelace",
                "Ada Lovelace",
                [],
                "+351 910 000 000"
                )
            );
            context.SaveChanges();
        }

        using (var context = new DomainDbContext(options))
        {
            var stored = context.Users.OfType<Customer>().Single();

            Assert.Multiple(() =>
            {
                Assert.That(stored.Email.Value, Is.EqualTo("ada@example.com"));
                Assert.That(stored.DisplayName, Is.EqualTo("Ada Lovelace"));
                Assert.That(stored.Name, Is.EqualTo("Ada Lovelace"));
                Assert.That(stored.Active, Is.True);
            });
        }
    }

    [Test]
    public async Task A_product_category_is_round_tripped_with_its_association_option()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"category-{Guid.NewGuid():N}")
            .Options;
        var category = ProductCategory.Create(
            "pizza-component", "Pizza Component", "Pizza ingredients.", true);

        using (var context = new DomainDbContext(options))
        {
            context.ProductCategories.Add(category);
            await context.SaveChangesAsync();
        }

        using (var context = new DomainDbContext(options))
        {
            var stored = await context.ProductCategories.SingleAsync();

            Assert.Multiple(() =>
            {
                Assert.That(stored.Code.Value, Is.EqualTo("pizza-component"));
                Assert.That(stored.Name, Is.EqualTo("Pizza Component"));
                Assert.That(stored.Description, Is.EqualTo("Pizza ingredients."));
                Assert.That(stored.AllowsComponentTypes, Is.True);
            });
        }
    }

    private static DomainDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql("Host=localhost;Database=laprizza_model;Username=test;Password=test")
            .Options;

        return new DomainDbContext(options);
    }

    private static string? TableName<TEntity>(DomainDbContext context) =>
        context.Model.FindEntityType(typeof(TEntity))?.GetTableName();
}
