using LaPrizza.Application.PredefinedPizzas.SearchPredefinedPizzas;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

/// <summary>
/// The predefined pizza search (BCK10, UC-45) on PostgreSQL. Uses an isolated
/// database; never reads or changes the configured project's data.
/// </summary>
[TestFixture]
[Category("PostgreSQL")]
public sealed class PredefinedPizzaSearchPostgresTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_pizza_search_test_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
        context.ProductCategories.AddRange(
            ProductCategory.Create("pizza-component", "Pizza components", null, true),
            ProductCategory.Create("pizzas", "Pizzas", null, false));
        context.PizzaSizes.Add(PizzaSize.Create("small"));
        await context.SaveChangesAsync();

        var repository = new ProductRepository(context);
        // A base product whose name also matches "marg" must never be returned.
        await repository.AddAndSaveAsync(new BaseProductBuilder()
            .WithCode("margherita-dough")
            .WithName("Margherita dough")
            .WithDescription("Pizza component")
            .InCategory("pizza-component")
            .StockControlled()
            .Build());
        await repository.AddAndSaveAsync(Pizza("quattro-formaggi", "Quattro Formaggi"));
        await repository.AddAndSaveAsync(Pizza("margherita", "Margherita"));
        var marinara = Pizza("marinara", "Marinara");
        marinara.Deactivate();
        await repository.AddAndSaveAsync(marinara);
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null)
        {
            return;
        }

        try
        {
            if (_admin.State == System.Data.ConnectionState.Open)
            {
                await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
                await drop.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Lists_only_predefined_pizzas_ordered_by_name()
    {
        var page = await SearchAsync(new PredefinedPizzaSearchCriteria(null, null, 1, 20));

        Assert.Multiple(() =>
        {
            Assert.That(page.TotalCount, Is.EqualTo(3));
            Assert.That(page.Items.Select(item => item.Code), Is.EqualTo(new[] { "margherita", "marinara", "quattro-formaggi" }));
            Assert.That(page.Items[0], Is.EqualTo(new PredefinedPizzaSearchItem("margherita", "Margherita", "pizzas", true)));
        });
    }

    [Test]
    public async Task Matches_part_of_the_name_case_insensitively()
    {
        var page = await SearchAsync(new PredefinedPizzaSearchCriteria("FORMAG", null, 1, 20));

        Assert.That(page.Items.Select(item => item.Code), Is.EqualTo(new[] { "quattro-formaggi" }));
    }

    [Test]
    public async Task Matches_a_full_code()
    {
        var page = await SearchAsync(new PredefinedPizzaSearchCriteria("marinara", null, 1, 20));

        Assert.That(page.Items.Select(item => item.Code), Is.EqualTo(new[] { "marinara" }));
    }

    [Test]
    public async Task Filters_by_active()
    {
        var page = await SearchAsync(new PredefinedPizzaSearchCriteria(null, false, 1, 20));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items.Select(item => item.Code), Is.EqualTo(new[] { "marinara" }));
            Assert.That(page.Items.Single().Active, Is.False);
        });
    }

    [Test]
    public async Task Pages_the_results_and_counts_them_before_pagination()
    {
        var second = await SearchAsync(new PredefinedPizzaSearchCriteria(null, null, 2, 1));
        var beyond = await SearchAsync(new PredefinedPizzaSearchCriteria(null, null, 5, 1));

        Assert.Multiple(() =>
        {
            Assert.That(second.Items.Select(item => item.Code), Is.EqualTo(new[] { "marinara" }));
            Assert.That(second.TotalCount, Is.EqualTo(3));
            Assert.That(beyond.Items, Is.Empty);
            Assert.That(beyond.TotalCount, Is.EqualTo(3));
        });
    }

    private async Task<PredefinedPizzaSearchPage> SearchAsync(PredefinedPizzaSearchCriteria criteria)
    {
        await using var context = new DomainDbContext(_options);
        return await new PredefinedPizzaQueries(context).SearchAsync(criteria);
    }

    private static ComposedProduct Pizza(string code, string name) => ComposedProduct.Create(
        code,
        name,
        "Pizza",
        "pizzas",
        [new PizzaComponent(ProductCode.Create("margherita-dough"), true, "base-dough")],
        [new ComponentTypeLimit("base-dough", 1, 1)],
        ["small"]);
}
