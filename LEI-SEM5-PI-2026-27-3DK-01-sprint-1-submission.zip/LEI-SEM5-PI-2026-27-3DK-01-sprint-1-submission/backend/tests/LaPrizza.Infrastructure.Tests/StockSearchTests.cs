using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using Microsoft.EntityFrameworkCore;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
public sealed class StockSearchTests
{
    private DomainDbContext _context = null!;
    private StockQueries _queries = null!;

    [SetUp]
    public async Task SetUp()
    {
        var options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseInMemoryDatabase($"stock-search-{Guid.NewGuid():N}")
            .Options;

        _context = new DomainDbContext(options);
        Add("mozzarella", "Mozzarella", "cheese", stockBalance: 12);
        // Names never tie here: the in-memory provider sorts in .NET and cannot
        // compare ProductCode, so the tie-break by code is tested on PostgreSQL.
        Add("buffalo-mozzarella", "Buffalo mozzarella", "cheese", stockBalance: 4);
        Add("basil", "Basil", "herbs", stockBalance: 0, active: false);
        Add("tomato", "Tomato", "vegetables", stockBalance: 30);
        Add("napkin", "Napkin", "supplies", stockBalance: null);
        await _context.SaveChangesAsync();
        _context.ChangeTracker.Clear();
        _queries = new StockQueries(_context);
    }

    [TearDown]
    public async Task TearDown() => await _context.DisposeAsync();

    [Test]
    public async Task SearchAsync_without_criteria_lists_only_stock_controlled_products_ordered_by_name_then_code()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria(null, null, null));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items.Select(item => item.ProductCode),
                Is.EqualTo(new[] { "basil", "buffalo-mozzarella", "mozzarella", "tomato" }));
            Assert.That(page.TotalCount, Is.EqualTo(4));
        });
    }

    [Test]
    public async Task SearchAsync_returns_the_category_active_state_and_quantity_of_each_product()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria("basil", null, null));

        Assert.That(page.Items.Single(), Is.EqualTo(new StockSearchItem("basil", "Basil", "herbs", false, 0)));
    }

    [TestCase("MOZZA")]
    [TestCase("zzare")]
    public async Task SearchAsync_matches_a_case_insensitive_part_of_the_name(string search)
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria(search, null, null));

        Assert.That(page.Items.Select(item => item.ProductCode),
            Is.EqualTo(new[] { "buffalo-mozzarella", "mozzarella" }));
    }

    [Test]
    public async Task SearchAsync_matches_the_full_business_code()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria("buffalo-mozzarella", null, null));

        Assert.That(page.Items.Select(item => item.ProductCode), Is.EqualTo(new[] { "buffalo-mozzarella" }));
    }

    [Test]
    public async Task SearchAsync_restricts_by_category_code()
    {
        var page = await _queries.SearchAsync(
            new StockSearchCriteria(null, ProductCategoryCode.Create("cheese"), null));

        Assert.That(page.Items.Select(item => item.ProductCode),
            Is.EqualTo(new[] { "buffalo-mozzarella", "mozzarella" }));
    }

    [TestCase(true, new[] { "buffalo-mozzarella", "mozzarella", "tomato" })]
    [TestCase(false, new[] { "basil" })]
    public async Task SearchAsync_restricts_by_the_active_filter(bool active, string[] expected)
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria(null, null, active));

        Assert.That(page.Items.Select(item => item.ProductCode), Is.EqualTo(expected));
    }

    [Test]
    public async Task SearchAsync_never_returns_products_without_stock_control()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria("napkin", null, null));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items, Is.Empty);
            Assert.That(page.TotalCount, Is.Zero);
        });
    }

    [Test]
    public async Task SearchAsync_paginates_and_reports_the_total_before_pagination()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria(null, null, null, Page: 2, PageSize: 3));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items.Select(item => item.ProductCode), Is.EqualTo(new[] { "tomato" }));
            Assert.That(page.TotalCount, Is.EqualTo(4));
        });
    }

    [Test]
    public async Task SearchAsync_returns_an_empty_page_beyond_the_last()
    {
        var page = await _queries.SearchAsync(new StockSearchCriteria(null, null, null, Page: 3, PageSize: 3));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items, Is.Empty);
            Assert.That(page.TotalCount, Is.EqualTo(4));
        });
    }

    /// <summary>
    /// The stock balance and the active flag are written through EF Core because
    /// the domain has no stock-changing operation yet (SCRUM-167/170) and no
    /// deactivation yet (BCK05, UC-27).
    /// </summary>
    private void Add(string code, string name, string category, int? stockBalance, bool active = true)
    {
        var stockControlled = stockBalance is not null;
        var product = new BaseProductBuilder().WithCode(code).WithName(name).WithDescription("Test product")
            .InCategory(category).AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).WithAllergens([]).Build();
        _context.Products.Add(product);
        _context.Entry(product).Property(p => p.StockBalance).CurrentValue = stockBalance;
        _context.Entry(product).Property(p => p.Active).CurrentValue = active;
    }
}
