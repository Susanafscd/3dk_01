using LaPrizza.Domain.Common;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
[Category("PostgreSQL")]
public sealed class ProductCategoryComponentTypeGuardPostgresTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_category_component_guard_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null) return;
        try
        {
            await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
            await drop.ExecuteNonQueryAsync();
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Disabling_a_category_with_a_component_type_is_rejected_by_the_database_guard()
    {
        const string categoryCode = "pizza-component";
        await using (var seed = new DomainDbContext(_options))
        {
            seed.ProductCategories.Add(ProductCategory.Create(categoryCode, "Pizza component", null, true));
            await seed.SaveChangesAsync();
            seed.PizzaComponentTypes.Add(PizzaComponentType.Create(
                "base-dough", categoryCode, "Base dough", null, 1, 1, 1));
            await seed.SaveChangesAsync();
        }

        await using (var writer = new DomainDbContext(_options))
        {
            var category = await new ProductCategoryRepository(writer)
                .GetByCodeAsync(ProductCategoryCode.Create(categoryCode));
            category!.Update("Pizza component", null, false, false);

            var exception = Assert.ThrowsAsync<CategoryComponentTypeReferenceException>(() =>
                new ProductCategoryRepository(writer).UpdateAndSaveAsync(category));
            Assert.That(exception!.Message, Does.Contain(categoryCode));
        }

        await using var verify = new DomainDbContext(_options);
        var persisted = await verify.ProductCategories.SingleAsync();
        Assert.That(persisted.AllowsComponentTypes, Is.True);
        Assert.That(await verify.PizzaComponentTypes.CountAsync(), Is.EqualTo(1));
    }

    [Test]
    public async Task A_component_type_cannot_be_added_to_a_category_that_disallows_components()
    {
        const string categoryCode = "non-component";
        await using (var seed = new DomainDbContext(_options))
        {
            seed.ProductCategories.Add(ProductCategory.Create(categoryCode, "Non component", null, false));
            await seed.SaveChangesAsync();
        }

        await using var writer = new DomainDbContext(_options);
        var type = PizzaComponentType.Create(
            "invalid-type", categoryCode, "Invalid type", null, 1, 1, 1);

        var exception = Assert.ThrowsAsync<DbUpdateException>(() =>
            new PizzaComponentTypeRepository(writer).Add(type));
        var postgres = exception!.InnerException as PostgresException;

        Assert.Multiple(() =>
        {
            Assert.That(postgres, Is.Not.Null);
            Assert.That(postgres!.SqlState, Is.EqualTo(PostgresErrorCodes.CheckViolation));
            Assert.That(postgres.ConstraintName, Is.EqualTo("CK_PizzaComponentTypes_CategoryAllowsTypes"));
        });

        await using var verify = new DomainDbContext(_options);
        Assert.That(await verify.PizzaComponentTypes.AnyAsync(), Is.False);
    }
}
