using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

[TestFixture]
[Category("PostgreSQL")]
public sealed class AllergenRemovalPostgresTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_allergen_removal_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null) return;
        try
        {
            await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
            await drop.ExecuteNonQueryAsync();
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Unused_allergen_can_be_removed_and_does_not_reappear()
    {
        await using var context = new DomainDbContext(_options);
        var allergen = Allergen.Create("unused", "Unused", null);
        context.Allergens.Add(allergen);
        await context.SaveChangesAsync();

        var usage = await new AllergenUsageQueries(context).GetUsageAsync(allergen.Code);
        Assert.That(usage.HasProductReferences, Is.False);
        await new AllergenRepository(context).RemoveAsync(allergen);

        context.ChangeTracker.Clear();
        Assert.That(await context.Allergens.AnyAsync(), Is.False);
    }

    [Test]
    public async Task Customer_dietary_restriction_blocks_allergen_removal()
    {
        await using var context = new DomainDbContext(_options);
        var allergen = Allergen.Create("milk", "Milk", null);
        var restriction = DietaryRestriction.Create("Dairy-free", [allergen]);
        var customer = Customer.Create(
            Email.Create("dietary-customer@example.com"),
            "Dietary Customer",
            "Dietary Customer",
            [restriction],
            "+351 910 000 000");

        context.Users.Add(customer);
        await context.SaveChangesAsync();

        var usage = await new AllergenUsageQueries(context).GetUsageAsync(allergen.Code);

        Assert.That(usage.HasDietaryRestrictions, Is.True);
        Assert.ThrowsAsync<AllergenInUseException>(() =>
            new AllergenRepository(context).RemoveAsync(allergen));

        context.ChangeTracker.Clear();
        Assert.Multiple(() =>
        {
            Assert.That(context.Allergens.Count(), Is.EqualTo(1));
            Assert.That(context.DietaryRestrictions.Count(), Is.EqualTo(1));
        });
    }

    [TestCase(true)]
    [TestCase(false)]
    public async Task Active_and_inactive_product_references_block_removal(bool active)
    {
        await using var context = new DomainDbContext(_options);
        await SeedReferences(context);
        context.Products.Add(Product("referencing-product"));
        await context.SaveChangesAsync();
        if (!active)
        {
            await context.Database.ExecuteSqlRawAsync(
                "UPDATE \"Products\" SET \"Active\" = FALSE WHERE \"Code\" = 'referencing-product'");
            context.ChangeTracker.Clear();
        }

        var allergen = await context.Allergens.SingleAsync();
        var usage = await new AllergenUsageQueries(context).GetUsageAsync(allergen.Code);
        Assert.That(usage.HasProductReferences, Is.True);
        Assert.ThrowsAsync<AllergenInUseException>(() =>
            new AllergenRepository(context).RemoveAsync(allergen));

        context.ChangeTracker.Clear();
        Assert.Multiple(() =>
        {
            Assert.That(context.Allergens.Count(), Is.EqualTo(1));
            Assert.That(context.Products.Count(), Is.EqualTo(1));
            Assert.That(context.Products.Single().Allergens.Single().Value, Is.EqualTo("milk"));
        });
    }

    [Test]
    public async Task Concurrent_product_reference_cannot_race_allergen_deletion()
    {
        await using (var seed = new DomainDbContext(_options))
        {
            await SeedReferences(seed);
        }

        await using var writer = new DomainDbContext(_options);
        await using var transaction = await writer.Database.BeginTransactionAsync();
        writer.Products.Add(Product("concurrent-product"));
        await writer.SaveChangesAsync();

        await using var remover = new DomainDbContext(_options);
        var allergen = await remover.Allergens.SingleAsync();
        var removal = new AllergenRepository(remover).RemoveAsync(allergen);

        await Task.Delay(150);
        await transaction.CommitAsync();

        Assert.ThrowsAsync<AllergenInUseException>(async () => await removal);

        await using var verify = new DomainDbContext(_options);
        Assert.Multiple(() =>
        {
            Assert.That(verify.Allergens.Count(), Is.EqualTo(1));
            Assert.That(verify.Products.Count(), Is.EqualTo(1));
        });
    }

    private static async Task SeedReferences(DomainDbContext context)
    {
        context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
        context.Allergens.Add(Allergen.Create("milk", "Milk", null));
        await context.SaveChangesAsync();
    }

    private static BaseProduct Product(string code) =>
        new BaseProductBuilder().WithCode(code).WithName(code).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(true).WithPrice(2.50m)
            .StockControlled(false).WithAllergens(["milk"]).Build();
}
