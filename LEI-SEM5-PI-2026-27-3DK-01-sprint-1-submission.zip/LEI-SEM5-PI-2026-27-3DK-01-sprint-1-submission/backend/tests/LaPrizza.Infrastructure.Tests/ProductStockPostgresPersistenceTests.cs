using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Application.Stock.DecreaseStock;
using LaPrizza.Application.Stock.GetProductStock;
using LaPrizza.Application.Stock.IncreaseStock;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using LaPrizza.Infrastructure.Persistence.Queries;
using LaPrizza.Infrastructure.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace LaPrizza.Infrastructure.Tests;

/// <summary>
/// Stock invariants enforced by PostgreSQL (BCK09, UC-39.1). Uses an isolated database;
/// never reads or changes the configured project's data.
/// </summary>
[TestFixture]
[Category("PostgreSQL")]
public sealed class ProductStockPostgresPersistenceTests
{
    private string _database = null!;
    private NpgsqlConnection _admin = null!;
    private DbContextOptions<DomainDbContext> _options = null!;

    [SetUp]
    public async Task SetUp()
    {
        var connection = Environment.GetEnvironmentVariable("LAPRIZZA_TEST_POSTGRES");
        if (string.IsNullOrWhiteSpace(connection))
        {
            Assert.Ignore("Set LAPRIZZA_TEST_POSTGRES to a PostgreSQL connection with permission to create test databases.");
        }

        _database = "laprizza_stock_test_" + Guid.NewGuid().ToString("N");
        _admin = new NpgsqlConnection(connection);
        await _admin.OpenAsync();
        await using var create = new NpgsqlCommand($"CREATE DATABASE {_database}", _admin);
        await create.ExecuteNonQueryAsync();
        _options = new DbContextOptionsBuilder<DomainDbContext>()
            .UseNpgsql(new NpgsqlConnectionStringBuilder(connection) { Database = _database }.ConnectionString)
            .Options;

        await using var context = new DomainDbContext(_options);
        await context.Database.MigrateAsync();
        context.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
        await context.SaveChangesAsync();
        var repository = new ProductRepository(context);
        await repository.AddAndSaveAsync(Product("mozzarella", stockControlled: true));
        await repository.AddAndSaveAsync(Product("napkin", stockControlled: false));
    }

    [TearDown]
    public async Task TearDown()
    {
        if (_admin is null)
        {
            return;
        }

        try
        {
            if (_admin.State == System.Data.ConnectionState.Open)
            {
                await using var drop = new NpgsqlCommand($"DROP DATABASE IF EXISTS {_database} WITH (FORCE)", _admin);
                await drop.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            await _admin.DisposeAsync();
            _admin = null!;
        }
    }

    [Test]
    public async Task Lookup_by_code_returns_the_stored_stock_balance()
    {
        await SetBalanceAsync("mozzarella", 7);

        await using var context = new DomainDbContext(_options);
        var repository = new ProductRepository(context);
        var stockControlled = await repository.GetByCodeAsync(ProductCode.Create("mozzarella"));
        var notStockControlled = await repository.GetByCodeAsync(ProductCode.Create("napkin"));

        Assert.Multiple(() =>
        {
            Assert.That(stockControlled!.StockControlled, Is.True);
            Assert.That(stockControlled.StockBalance, Is.EqualTo(7));
            Assert.That(notStockControlled!.StockControlled, Is.False);
            Assert.That(notStockControlled.StockBalance, Is.Null);
        });
    }

    [Test]
    public void Database_rejects_a_negative_stock_balance()
    {
        var exception = Assert.ThrowsAsync<PostgresException>(() => SetBalanceAsync("mozzarella", -1));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.SqlState, Is.EqualTo(PostgresErrorCodes.CheckViolation));
            Assert.That(exception.ConstraintName, Is.EqualTo("CK_Products_StockBalance_NonNegative"));
        });
    }

    [Test]
    public void Database_rejects_a_stock_balance_on_a_product_without_stock_control()
    {
        var exception = Assert.ThrowsAsync<PostgresException>(() => SetBalanceAsync("napkin", 0));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.SqlState, Is.EqualTo(PostgresErrorCodes.CheckViolation));
            Assert.That(exception.ConstraintName, Is.EqualTo("CK_Products_StockBalance_StockControlled"));
        });
    }

    [Test]
    public void Database_rejects_a_missing_stock_balance_on_a_stock_controlled_product()
    {
        var exception = Assert.ThrowsAsync<PostgresException>(() => SetBalanceAsync("mozzarella", null));

        Assert.Multiple(() =>
        {
            Assert.That(exception!.SqlState, Is.EqualTo(PostgresErrorCodes.CheckViolation));
            Assert.That(exception.ConstraintName, Is.EqualTo("CK_Products_StockBalance_StockControlled"));
        });
    }

    [Test]
    public async Task Retrieving_the_stock_of_an_inactive_product_reads_PostgreSQL_and_changes_nothing()
    {
        await SetBalanceAsync("mozzarella", 7);
        await using (var setup = new DomainDbContext(_options))
        {
            await setup.Database.ExecuteSqlRawAsync("""UPDATE "Products" SET "Active" = false WHERE "Code" = 'mozzarella'""");
        }

        await using var context = new DomainDbContext(_options);
        var result = await new GetProductStockQueryHandler(new ProductRepository(context))
            .HandleAsync(new GetProductStockQuery("mozzarella"));

        await using var reload = new DomainDbContext(_options);
        var stored = await new ProductRepository(reload).GetByCodeAsync(ProductCode.Create("mozzarella"));
        Assert.Multiple(() =>
        {
            Assert.That(result.QuantityInStock, Is.EqualTo(7));
            Assert.That(result.Active, Is.False);
            Assert.That(stored!.StockBalance, Is.EqualTo(7));
            Assert.That(stored.Active, Is.False);
        });
    }

    [Test]
    public async Task Stock_search_on_PostgreSQL_matches_case_insensitively_and_breaks_name_ties_by_code()
    {
        await using (var setup = new DomainDbContext(_options))
        {
            var repository = new ProductRepository(setup);
            // Same name as the "mozzarella" product of the set-up, so the order falls back to the code.
            await repository.AddAndSaveAsync(Product("buffalo-mozzarella", stockControlled: true, name: "mozzarella"));
            await repository.AddAndSaveAsync(Product("mozzarella-sticks", stockControlled: false, name: "Mozzarella sticks"));
        }

        await using var context = new DomainDbContext(_options);
        var page = await new StockQueries(context).SearchAsync(new StockSearchCriteria("MOZZA", null, null));

        Assert.Multiple(() =>
        {
            Assert.That(page.Items.Select(item => item.ProductCode),
                Is.EqualTo(new[] { "buffalo-mozzarella", "mozzarella" }));
            Assert.That(page.TotalCount, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task IncreaseAsync_adds_the_units_and_returns_the_stored_balance()
    {
        await SetBalanceAsync("mozzarella", 7);
        var id = await IdOfAsync("mozzarella");

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).IncreaseAsync(id, 5);

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.EqualTo(12));
            Assert.That(reloaded, Is.EqualTo(12));
        });
    }

    [Test]
    public async Task IncreaseAsync_increases_an_inactive_product()
    {
        await SetBalanceAsync("mozzarella", 7);
        await using (var setup = new DomainDbContext(_options))
        {
            await setup.Database.ExecuteSqlRawAsync("""UPDATE "Products" SET "Active" = false WHERE "Code" = 'mozzarella'""");
        }

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).IncreaseAsync(await IdOfAsync("mozzarella"), 1);

        Assert.That(stored, Is.EqualTo(8));
    }

    [Test]
    public async Task IncreaseAsync_changes_nothing_for_a_product_without_stock_control()
    {
        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).IncreaseAsync(await IdOfAsync("napkin"), 1);

        var reloaded = await BalanceOfAsync("napkin");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.Null);
            Assert.That(reloaded, Is.Null);
        });
    }

    [Test]
    public async Task IncreaseAsync_changes_nothing_when_the_result_would_exceed_the_upper_limit()
    {
        await SetBalanceAsync("mozzarella", int.MaxValue - 1);

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).IncreaseAsync(await IdOfAsync("mozzarella"), 2);

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.Null);
            Assert.That(reloaded, Is.EqualTo(int.MaxValue - 1));
        });
    }

    [Test]
    public async Task Concurrent_increases_are_never_lost()
    {
        const int increases = 20;
        await SetBalanceAsync("mozzarella", 0);
        var id = await IdOfAsync("mozzarella");

        await Task.WhenAll(Enumerable.Range(0, increases).Select(async _ =>
        {
            await using var context = new DomainDbContext(_options);
            await new StockRepository(context).IncreaseAsync(id, 1);
        }));

        Assert.That(await BalanceOfAsync("mozzarella"), Is.EqualTo(increases));
    }

    [TestCase(4, 6)]
    [TestCase(10, 0)]
    public async Task DecreaseAsync_removes_the_units_and_returns_the_stored_balance(int units, int expected)
    {
        await SetBalanceAsync("mozzarella", 10);

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).DecreaseAsync(await IdOfAsync("mozzarella"), units);

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.EqualTo(expected));
            Assert.That(reloaded, Is.EqualTo(expected));
        });
    }

    [Test]
    public async Task DecreaseAsync_decreases_an_inactive_product()
    {
        await SetBalanceAsync("mozzarella", 7);
        await using (var setup = new DomainDbContext(_options))
        {
            await setup.Database.ExecuteSqlRawAsync("""UPDATE "Products" SET "Active" = false WHERE "Code" = 'mozzarella'""");
        }

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).DecreaseAsync(await IdOfAsync("mozzarella"), 2);

        Assert.That(stored, Is.EqualTo(5));
    }

    [Test]
    public async Task DecreaseAsync_changes_nothing_for_a_product_without_stock_control()
    {
        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).DecreaseAsync(await IdOfAsync("napkin"), 1);

        var reloaded = await BalanceOfAsync("napkin");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.Null);
            Assert.That(reloaded, Is.Null);
        });
    }

    [Test]
    public async Task DecreaseAsync_changes_nothing_when_there_are_fewer_units_than_requested()
    {
        await SetBalanceAsync("mozzarella", 3);

        await using var context = new DomainDbContext(_options);
        var stored = await new StockRepository(context).DecreaseAsync(await IdOfAsync("mozzarella"), 4);

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored, Is.Null);
            Assert.That(reloaded, Is.EqualTo(3));
        });
    }

    [Test]
    public async Task Two_concurrent_decreases_that_together_exceed_the_stock_apply_at_most_one()
    {
        await SetBalanceAsync("mozzarella", 5);
        var id = await IdOfAsync("mozzarella");

        var stored = await Task.WhenAll(Enumerable.Range(0, 2).Select(async _ =>
        {
            await using var context = new DomainDbContext(_options);
            return await new StockRepository(context).DecreaseAsync(id, 3);
        }));

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored.Count(balance => balance is not null), Is.EqualTo(1));
            Assert.That(stored, Has.Member(2));
            Assert.That(reloaded, Is.EqualTo(2));
        });
    }

    [Test]
    public async Task Concurrent_decreases_never_make_the_stock_negative()
    {
        await SetBalanceAsync("mozzarella", 10);
        var id = await IdOfAsync("mozzarella");

        var stored = await Task.WhenAll(Enumerable.Range(0, 20).Select(async _ =>
        {
            await using var context = new DomainDbContext(_options);
            return await new StockRepository(context).DecreaseAsync(id, 1);
        }));

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(stored.Count(balance => balance is not null), Is.EqualTo(10));
            Assert.That(reloaded, Is.Zero);
        });
    }

    [Test]
    public async Task Increasing_through_the_use_case_stores_and_returns_the_balance_read_from_PostgreSQL()
    {
        await SetBalanceAsync("mozzarella", 12);

        // One context for the whole request, as in the API: the use case changes the
        // aggregate in memory and the statement must still start from the stored row.
        await using var context = new DomainDbContext(_options);
        var result = await new IncreaseStockCommandHandler(new ProductRepository(context), new StockRepository(context))
            .HandleAsync(new IncreaseStockCommand("mozzarella", 5));

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(result.QuantityInStock, Is.EqualTo(17));
            Assert.That(reloaded, Is.EqualTo(17));
        });
    }

    [Test]
    public async Task Concurrent_increases_through_the_use_case_each_return_a_stored_balance_and_none_is_lost()
    {
        const int increases = 10;
        await SetBalanceAsync("mozzarella", 0);

        var results = await Task.WhenAll(Enumerable.Range(0, increases).Select(async _ =>
        {
            await using var context = new DomainDbContext(_options);
            return await new IncreaseStockCommandHandler(new ProductRepository(context), new StockRepository(context))
                .HandleAsync(new IncreaseStockCommand("mozzarella", 1));
        }));

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(reloaded, Is.EqualTo(increases));
            Assert.That(results.Select(result => result.QuantityInStock).Order(),
                Is.EqualTo(Enumerable.Range(1, increases)));
        });
    }

    [Test]
    public async Task Decreasing_through_the_use_case_stores_and_returns_the_balance_read_from_PostgreSQL()
    {
        await SetBalanceAsync("mozzarella", 10);

        // One context for the whole request, as in the API.
        await using var context = new DomainDbContext(_options);
        var result = await new DecreaseStockCommandHandler(new ProductRepository(context), new StockRepository(context))
            .HandleAsync(new DecreaseStockCommand("mozzarella", 4));

        var reloaded = await BalanceOfAsync("mozzarella");
        Assert.Multiple(() =>
        {
            Assert.That(result.QuantityInStock, Is.EqualTo(6));
            Assert.That(reloaded, Is.EqualTo(6));
        });
    }

    [Test]
    public async Task A_decrease_whose_stock_was_consumed_after_it_was_read_returns_a_conflict_and_keeps_the_other_change()
    {
        await SetBalanceAsync("mozzarella", 5);

        // Another request decreases 3 units between this request's read (5 units, so the
        // rule allows 3) and its update, deterministically.
        await using var context = new DomainDbContext(_options);
        var stock = new CompetingDecreaseStockRepository(new StockRepository(context), async (id, units) =>
        {
            await using var other = new DomainDbContext(_options);
            await new StockRepository(other).DecreaseAsync(id, units);
        });

        Assert.ThrowsAsync<ConflictException>(() =>
            new DecreaseStockCommandHandler(new ProductRepository(context), stock)
                .HandleAsync(new DecreaseStockCommand("mozzarella", 3)));
        Assert.That(await BalanceOfAsync("mozzarella"), Is.EqualTo(2));
    }

    private async Task<Guid> IdOfAsync(string code)
    {
        await using var context = new DomainDbContext(_options);
        var product = await new ProductRepository(context).GetByCodeAsync(ProductCode.Create(code));
        return product!.Id;
    }

    private async Task<int?> BalanceOfAsync(string code)
    {
        await using var context = new DomainDbContext(_options);
        var product = await new ProductRepository(context).GetByCodeAsync(ProductCode.Create(code));
        return product!.StockBalance;
    }

    private async Task SetBalanceAsync(string code, int? balance)
    {
        await using var context = new DomainDbContext(_options);
        await context.Database.ExecuteSqlInterpolatedAsync(
            $"""UPDATE "Products" SET "StockBalance" = {balance} WHERE "Code" = {code}""");
    }

    /// <summary>Runs a competing decrease just before delegating, as a concurrent request would.</summary>
    private sealed class CompetingDecreaseStockRepository(
        IStockRepository inner,
        Func<Guid, int, Task> competingDecrease) : IStockRepository
    {
        public Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default) =>
            inner.IncreaseAsync(productId, units, cancellationToken);

        public async Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default)
        {
            await competingDecrease(productId, units);
            return await inner.DecreaseAsync(productId, units, cancellationToken);
        }
    }

    private static BaseProduct Product(string code, bool stockControlled, string? name = null) =>
        new BaseProductBuilder().WithCode(code).WithName(name ?? code).WithDescription("Test product")
            .InCategory("ingredients").AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).Build();
}
