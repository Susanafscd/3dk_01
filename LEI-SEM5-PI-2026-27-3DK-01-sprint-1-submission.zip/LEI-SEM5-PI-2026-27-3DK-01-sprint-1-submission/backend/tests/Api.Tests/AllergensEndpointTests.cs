using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Allergens;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Api.Tests;

[TestFixture]
public sealed class AllergensEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;
    private RecordingCatalogueCacheInvalidator _cache = null!;

    [SetUp]
    public async Task SetUp()
    {
        _cache = new RecordingCatalogueCacheInvalidator();
        _factory = new ApiTestFactory(services => services.AddSingleton<ICatalogueCacheInvalidator>(_cache));
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Test Manager", "Manager", Array.Empty<Guid>()));
        db.Users.Add(Customer.Create(Email.Create("customer@laprizza.local"), "Customer", "Customer", Array.Empty<DietaryRestriction>(), "+351 910 000 000"));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Update_replaces_details_and_preserves_business_identity()
    {
        await SeedAllergen("milk", "Milk", "Original.");
        Guid identity;
        using (var scope = _factory.Services.CreateScope())
        {
            identity = (await scope.ServiceProvider.GetRequiredService<DomainDbContext>()
                .Allergens.SingleAsync()).Id;
        }

        using var response = await Put("milk", """
            {"name":"  Dairy  ","description":"  Updated.  "}
            """);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        using var verificationScope = _factory.Services.CreateScope();
        var stored = await verificationScope.ServiceProvider.GetRequiredService<DomainDbContext>()
            .Allergens.SingleAsync();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("milk"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Dairy"));
            Assert.That(body.GetProperty("description").GetString(), Is.EqualTo("Updated."));
            Assert.That(stored.Id, Is.EqualTo(identity));
            Assert.That(stored.Code.Value, Is.EqualTo("milk"));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [TestCase("{}")]
    [TestCase("{\"name\":\"   \"}")]
    [TestCase("{\"name\":\"Dairy\",\"code\":\"other\"}")]
    [TestCase("{\"name\":\"Dairy\",\"productCodes\":[]}")]
    public async Task Update_rejects_invalid_or_unsupported_fields_without_mutation(string json)
    {
        await SeedAllergen("milk", "Milk", "Original.");

        using var response = await Put("milk", json);
        using var scope = _factory.Services.CreateScope();
        var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>()
            .Allergens.SingleAsync();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            Assert.That(stored.Name, Is.EqualTo("Milk"));
            Assert.That(stored.Description, Is.EqualTo("Original."));
            Assert.That(_cache.Invalidations, Is.Zero);
        });
    }

    [Test]
    public async Task Update_returns_404_for_an_unknown_code()
    {
        using var response = await Put("unknown", "{\"name\":\"Unknown\"}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        Assert.That(_cache.Invalidations, Is.Zero);
    }

    [Test]
    public async Task Update_invalidates_a_warmed_read_projection_after_commit()
    {
        using var factory = new ApiTestFactory(services =>
        {
            var productionInvalidator = services.First(descriptor =>
                descriptor.ServiceType == typeof(ICatalogueCacheInvalidator)
                && descriptor.ImplementationType is not null);
            services.RemoveAll<ICatalogueCacheInvalidator>();
            services.Add(productionInvalidator);
        });
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");
        using (var scope = factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
            await db.Database.EnsureCreatedAsync();
            db.Users.Add(Staff.Create(
                Email.Create("test-manager@laprizza.local"), "Manager", "Manager", Array.Empty<Guid>()));
            db.Allergens.Add(Allergen.Create("milk", "Milk", null));
            await db.SaveChangesAsync();
        }

        using var before = await client.GetAsync("/api/v1/allergens/milk");
        using var update = await client.PutAsync(
            "/api/v1/allergens/milk",
            new StringContent("{\"name\":\"Dairy\"}", Encoding.UTF8, "application/json"));
        using var after = await client.GetAsync("/api/v1/allergens/milk");
        var updated = await after.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(before.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(update.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(after.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(updated.GetProperty("name").GetString(), Is.EqualTo("Dairy"));
        });
    }

    [Test]
    public async Task Search_returns_filtered_page_with_stable_metadata()
    {
        await SeedAllergen("milk", "Milk", null);
        await SeedAllergen("peanut", "Peanut", "Peanuts.");
        await SeedAllergen("tree-nut", "Tree Nut", null);

        using var response = await _client.GetAsync("/api/v1/allergens?search=PEAN&page=1&pageSize=1");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        var items = body.GetProperty("items");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(items.GetArrayLength(), Is.EqualTo(1));
            Assert.That(items[0].GetProperty("code").GetString(), Is.EqualTo("peanut"));
            Assert.That(body.GetProperty("page").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("pageSize").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Search_without_matches_returns_an_empty_successful_page()
    {
        await SeedAllergen("milk", "Milk", null);

        using var response = await _client.GetAsync("/api/v1/allergens?search=absent");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("items").GetArrayLength(), Is.Zero);
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.Zero);
            Assert.That(body.GetProperty("page").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("pageSize").GetInt32(), Is.EqualTo(20));
        });
    }

    [TestCase("page=0")]
    [TestCase("page=-1")]
    [TestCase("pageSize=0")]
    [TestCase("pageSize=101")]
    [TestCase("page=not-a-number")]
    public async Task Search_rejects_invalid_pagination(string query)
    {
        using var response = await _client.GetAsync($"/api/v1/allergens?{query}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [Test]
    public async Task Get_returns_all_business_fields_without_product_data()
    {
        await SeedAllergen("tree-nuts", "Tree nuts", "Nuts from trees.");

        using var response = await _client.GetAsync("/api/v1/allergens/tree-nuts");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("tree-nuts"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Tree nuts"));
            Assert.That(body.GetProperty("description").GetString(), Is.EqualTo("Nuts from trees."));
            Assert.That(body.EnumerateObject().Select(property => property.Name),
                Is.EquivalentTo(new[] { "code", "name", "description" }));
        });
    }

    [TestCase("Tree-Nuts")]
    [TestCase("tree--nuts")]
    [TestCase("tree_nuts")]
    public async Task Get_rejects_a_malformed_business_code(string code)
    {
        using var response = await _client.GetAsync($"/api/v1/allergens/{code}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [Test]
    public async Task Get_returns_404_for_an_unknown_well_formed_code()
    {
        using var response = await _client.GetAsync("/api/v1/allergens/unknown");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [Test]
    public async Task Create_returns_business_identity_and_invalidates_after_commit()
    {
        _cache.BeforeInvalidation = async () =>
        {
            using var scope = _factory.Services.CreateScope();
            var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Allergens.SingleAsync();
            Assert.That(stored.Code.Value, Is.EqualTo("tree-nuts"));
        };
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens",
            new { code = "tree-nuts", name = " Tree nuts ", description = " Nuts from trees " });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(response.Headers.Location!.OriginalString, Is.EqualTo("/api/v1/allergens/tree-nuts"));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("tree-nuts"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Tree nuts"));
            Assert.That(body.GetProperty("description").GetString(), Is.EqualTo("Nuts from trees"));
            Assert.That(body.EnumerateObject().Select(p => p.Name), Is.EquivalentTo(new[] { "code", "name", "description" }));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\",\"description\":null}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\",\"description\":\"   \"}")]
    public async Task Create_returns_null_for_an_absent_or_blank_description(string json)
    {
        using var response = await Post(json);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(body.GetProperty("description").ValueKind, Is.EqualTo(JsonValueKind.Null));
        });
    }

    [TestCase("{}")]
    [TestCase("{\"code\":\"milk\"}")]
    [TestCase("{\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"Milk\",\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"milk--nuts\",\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"milk\\n\",\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"   \"}")]
    [TestCase("{\"code\":123,\"name\":\"Milk\"}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\",\"description\":123}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\",\"productCodes\":[]}")]
    [TestCase("{\"code\":\"milk\",\"name\":\"Milk\",\"id\":\"unexpected\"}")]
    [TestCase("not-json")]
    [TestCase("null")]
    public async Task Invalid_payload_returns_problem_details_without_writing_or_invalidating(string json)
    {
        using var response = await Post(json);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
        await AssertNoAllergens();
    }

    [TestCase(1, 1, 0, 201)]
    [TestCase(100, 200, 1000, 201)]
    [TestCase(101, 200, 1000, 400)]
    [TestCase(100, 201, 1000, 400)]
    [TestCase(100, 200, 1001, 400)]
    public async Task Create_checks_transport_length_boundaries(int codeLength, int nameLength, int descriptionLength, int status)
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens", new
        {
            code = new string('a', codeLength),
            name = new string('n', nameLength),
            description = new string('d', descriptionLength),
        });
        Assert.That((int)response.StatusCode, Is.EqualTo(status));
        if (status == 400)
        {
            await AssertNoAllergens();
        }
    }

    [Test]
    public async Task Duplicate_code_returns_conflict_without_replacing_or_invalidating_again()
    {
        using var first = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Original" });
        using var duplicate = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Replacement" });
        using var scope = _factory.Services.CreateScope();
        var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Allergens.SingleAsync();
        Assert.Multiple(() =>
        {
            Assert.That(first.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(duplicate.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
            Assert.That(duplicate.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
            Assert.That(stored.Name, Is.EqualTo("Original"));
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Anonymous_request_returns_401()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Anonymous", "true");
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Milk" });
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Unauthorized));
        await AssertNoAllergens();
    }

    [Test]
    public async Task Authenticated_non_manager_returns_403()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Milk" });
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
        await AssertNoAllergens();
    }

    [Test]
    public async Task Inactive_manager_returns_403()
    {
        using (var scope = _factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
            (await db.Users.SingleAsync(u => u.Email == Email.Create("test-manager@laprizza.local"))).Deactivate();
            await db.SaveChangesAsync();
        }
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Milk" });
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
        await AssertNoAllergens();
    }

    [Test]
    public async Task Missing_required_header_returns_400()
    {
        _client.DefaultRequestHeaders.Remove(AntiforgeryDefaults.HeaderName);
        using var response = await _client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Milk" });
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        await AssertNoAllergens();
    }

    [Test]
    public async Task Cache_failure_keeps_the_committed_allergen_and_returns_201()
    {
        var failedCache = new FailingDistributedCache();
        using var factory = new ApiTestFactory(services =>
        {
            var productionInvalidator = services.First(d => d.ServiceType == typeof(ICatalogueCacheInvalidator));
            services.RemoveAll<ICatalogueCacheInvalidator>();
            services.Add(productionInvalidator);
            services.RemoveAll<IDistributedCache>();
            services.AddSingleton<IDistributedCache>(failedCache);
        });
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Manager", "Manager", Array.Empty<Guid>()));
        await db.SaveChangesAsync();

        using var response = await client.PostAsJsonAsync("/api/v1/allergens", new { code = "milk", name = "Milk" });
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(failedCache.Writes, Is.GreaterThan(0));
            Assert.That(db.Allergens.Single().Code.Value, Is.EqualTo("milk"));
        });
    }

    private Task<HttpResponseMessage> Post(string json) =>
        _client.PostAsync("/api/v1/allergens", new StringContent(json, Encoding.UTF8, "application/json"));

    private Task<HttpResponseMessage> Put(string code, string json) =>
        _client.PutAsync(
            $"/api/v1/allergens/{code}",
            new StringContent(json, Encoding.UTF8, "application/json"));

    private async Task SeedAllergen(string code, string name, string? description)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        db.Allergens.Add(Allergen.Create(code, name, description));
        await db.SaveChangesAsync();
    }

    private async Task AssertNoAllergens()
    {
        using var scope = _factory.Services.CreateScope();
        Assert.That(await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Allergens.CountAsync(), Is.Zero);
        Assert.That(_cache.Invalidations, Is.Zero);
    }
}
