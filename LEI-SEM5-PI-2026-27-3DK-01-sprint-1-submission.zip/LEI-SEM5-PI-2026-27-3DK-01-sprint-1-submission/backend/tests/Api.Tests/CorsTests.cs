using System.Net;
using Api.Tests.Support;

namespace Api.Tests;

[TestFixture]
public sealed class CorsTests
{
    [Test]
    public async Task Allows_the_local_frontend_origin()
    {
        using var factory = new ApiTestFactory();
        using var client = factory.CreateClient();
        using var request = new HttpRequestMessage(HttpMethod.Options, "/api/v1/health");
        request.Headers.Add("Origin", "http://localhost:5173");
        request.Headers.Add("Access-Control-Request-Method", "GET");

        using var response = await client.SendAsync(request);

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            Assert.That(response.Headers.GetValues("Access-Control-Allow-Origin"),
                Is.EquivalentTo(new[] { "http://localhost:5173" }));
        });
    }
}
