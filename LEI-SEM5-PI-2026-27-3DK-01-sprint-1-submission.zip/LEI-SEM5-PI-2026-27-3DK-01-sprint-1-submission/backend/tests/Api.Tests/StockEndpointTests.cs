using System.Net;
using System.Net.Http.Json;
using Api.Tests.Support;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

/// <summary>
/// End-to-end tests for the stock endpoints (BCK09): they go through routing,
/// model binding, the use cases and the product store, backed by an in-memory
/// database. The stock changes use <see cref="InMemoryStockRepository"/>, because
/// the in-memory database cannot run the PostgreSQL statement.
/// </summary>
[TestFixture]
public sealed class StockEndpointTests
{
    private ApiTestFactory _baseFactory = null!;
    private WebApplicationFactory<Program> _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task StartServerAsync()
    {
        _baseFactory = new ApiTestFactory();
        _factory = _baseFactory.WithWebHostBuilder(builder => builder.ConfigureTestServices(services =>
            services.AddScoped<IStockRepository, InMemoryStockRepository>()));
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        // The stock endpoints require a Manager (BCK09); the test caller signs in as this one.
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Test Manager", "Manager", Array.Empty<Guid>()));
        db.Users.Add(Customer.Create(
            Email.Create("customer@laprizza.local"), "Customer", "Customer", Array.Empty<DietaryRestriction>(), "+351 910 000 000"));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void StopServer()
    {
        _client.Dispose();
        _factory.Dispose();
        _baseFactory.Dispose();
    }

    [Test]
    public async Task GetProductStock_returns_the_stored_stock_of_a_stock_controlled_product()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.GetAsync("/api/v1/products/mozzarella/stock");
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("mozzarella", "Mozzarella", true, 12)));
        });
    }

    [Test]
    public async Task GetProductStock_returns_an_inactive_product_with_active_false()
    {
        await SeedProductAsync("basil", "Basil", stockControlled: true, stockBalance: 3, active: false);

        using var response = await _client.GetAsync("/api/v1/products/basil/stock");
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("basil", "Basil", false, 3)));
        });
    }

    [Test]
    public async Task GetProductStock_leaves_the_store_unchanged()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.GetAsync("/api/v1/products/mozzarella/stock");

        using var scope = _factory.Services.CreateScope();
        var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Products
            .SingleAsync(product => product.Code == ProductCode.Create("mozzarella"));
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(stored.StockBalance, Is.EqualTo(12));
            Assert.That(stored.Active, Is.True);
        });
    }

    // Uppercase, whitespace, consecutive hyphens and over 100 characters (section 6 of the BCK09 design).
    [TestCase("Mozzarella")]
    [TestCase("mozza%20rella")]
    [TestCase("mozza--rella")]
    [TestCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")]
    public async Task GetProductStock_rejects_a_malformed_code(string code)
    {
        using var response = await _client.GetAsync($"/api/v1/products/{code}/stock");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task GetProductStock_returns_404_for_an_unknown_product()
    {
        using var response = await _client.GetAsync("/api/v1/products/unknown/stock");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task GetProductStock_returns_409_for_a_product_without_stock_control()
    {
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.GetAsync("/api/v1/products/napkin/stock");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task SearchStock_returns_a_page_of_stock_controlled_products_with_its_metadata()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12, category: "cheese");
        await SeedProductAsync("basil", "Basil", stockControlled: true, stockBalance: 3, active: false);
        await SeedProductAsync("tomato", "Tomato", stockControlled: true, stockBalance: 30);
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.GetAsync("/api/v1/stock?page=1&pageSize=2");
        var body = await response.Content.ReadFromJsonAsync<StockSearchPagePayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body!.Items, Is.EqualTo(new[]
            {
                new StockSearchItemPayload("basil", "Basil", false, "ingredients", 3),
                new StockSearchItemPayload("mozzarella", "Mozzarella", true, "cheese", 12),
            }));
            Assert.That(body.Page, Is.EqualTo(1));
            Assert.That(body.PageSize, Is.EqualTo(2));
            Assert.That(body.TotalCount, Is.EqualTo(3));
        });
    }

    [Test]
    public async Task SearchStock_applies_the_search_term_category_and_active_filters()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12, category: "cheese");
        await SeedProductAsync("buffalo-mozzarella", "Buffalo mozzarella", stockControlled: true, stockBalance: 4,
            active: false, category: "cheese");
        await SeedProductAsync("mozzarella-sticks", "Mozzarella sticks", stockControlled: true, stockBalance: 8);

        using var response = await _client.GetAsync("/api/v1/stock?search=MOZZA&categoryCode=cheese&active=true");
        var body = await response.Content.ReadFromJsonAsync<StockSearchPagePayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body!.Items.Select(item => item.ProductCode), Is.EqualTo(new[] { "mozzarella" }));
            Assert.That(body.TotalCount, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task SearchStock_returns_an_empty_page_when_nothing_matches()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.GetAsync("/api/v1/stock?search=anchovy");
        var body = await response.Content.ReadFromJsonAsync<StockSearchPagePayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body!.Items, Is.Empty);
            Assert.That(body.TotalCount, Is.Zero);
        });
    }

    [Test]
    public async Task SearchStock_leaves_the_store_unchanged()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.GetAsync("/api/v1/stock?search=mozzarella");

        using var scope = _factory.Services.CreateScope();
        var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Products
            .SingleAsync(product => product.Code == ProductCode.Create("mozzarella"));
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(stored.StockBalance, Is.EqualTo(12));
            Assert.That(stored.Active, Is.True);
        });
    }

    [TestCase("page=0")]
    [TestCase("pageSize=0")]
    [TestCase("pageSize=101")]
    [TestCase("categoryCode=Not%20A%20Code")]
    [TestCase("active=maybe")]
    public async Task SearchStock_rejects_invalid_query_parameters(string query)
    {
        using var response = await _client.GetAsync($"/api/v1/stock?{query}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task IncreaseStock_adds_the_units_and_returns_the_stored_stock()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/increase", new { units = 5 });
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("mozzarella", "Mozzarella", true, 17)));
        });
    }

    [Test]
    public async Task IncreaseStock_rejects_units_that_are_not_positive()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/increase", new { units = 0 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task IncreaseStock_returns_404_for_an_unknown_product()
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/products/unknown/stock/increase", new { units = 1 });

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task IncreaseStock_returns_409_for_a_product_without_stock_control()
    {
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/napkin/stock/increase", new { units = 1 });

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task IncreaseStock_increases_an_inactive_product()
    {
        await SeedProductAsync("basil", "Basil", stockControlled: true, stockBalance: 3, active: false);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/basil/stock/increase", new { units = 2 });
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("basil", "Basil", false, 5)));
        });
    }

    [Test]
    public async Task IncreaseStock_above_the_upper_limit_returns_409_and_keeps_the_stock()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: int.MaxValue - 1);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/increase", new { units = 2 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
        Assert.That(await StoredBalanceAsync("mozzarella"), Is.EqualTo(int.MaxValue - 1));
    }

    // Negative, fractional, missing and non-numeric units (section 6 of the BCK09 design).
    [TestCase("""{ "units": -1 }""")]
    [TestCase("""{ "units": 1.5 }""")]
    [TestCase("""{ }""")]
    [TestCase("""{ "units": "five" }""")]
    public async Task IncreaseStock_rejects_invalid_units_and_keeps_the_stock(string json)
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        using var response = await _client.PostAsync("/api/v1/products/mozzarella/stock/increase", content);

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(await StoredBalanceAsync("mozzarella"), Is.EqualTo(12));
    }

    [TestCase("Mozzarella")]
    [TestCase("mozza%20rella")]
    [TestCase("mozza--rella")]
    [TestCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")]
    public async Task IncreaseStock_rejects_a_malformed_code(string code)
    {
        using var response = await _client.PostAsJsonAsync($"/api/v1/products/{code}/stock/increase", new { units = 1 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task IncreaseStock_creates_no_stock_for_a_product_without_stock_control()
    {
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/napkin/stock/increase", new { units = 1 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
        Assert.That(await StoredBalanceAsync("napkin"), Is.Null);
    }

    [Test]
    public async Task DecreaseStock_removes_the_units_and_returns_the_stored_stock()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 10);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/decrease", new { units = 4 });
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("mozzarella", "Mozzarella", true, 6)));
        });
    }

    [Test]
    public async Task DecreaseStock_rejects_units_that_are_not_positive()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 10);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/decrease", new { units = 0 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task DecreaseStock_returns_404_for_an_unknown_product()
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/products/unknown/stock/decrease", new { units = 1 });

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task DecreaseStock_returns_409_for_a_product_without_stock_control()
    {
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/napkin/stock/decrease", new { units = 1 });

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
    }

    [Test]
    public async Task DecreaseStock_decreases_an_inactive_product()
    {
        await SeedProductAsync("basil", "Basil", stockControlled: true, stockBalance: 3, active: false);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/basil/stock/decrease", new { units = 2 });
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body, Is.EqualTo(new StockPayload("basil", "Basil", false, 1)));
        });
    }

    [Test]
    public async Task DecreaseStock_may_use_up_the_whole_stock()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 10);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/decrease", new { units = 10 });
        var body = await response.Content.ReadFromJsonAsync<StockPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body!.QuantityInStock, Is.Zero);
        });
    }

    [Test]
    public async Task DecreaseStock_by_more_than_the_stock_returns_409_and_keeps_the_stock()
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 3);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/mozzarella/stock/decrease", new { units = 4 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
        Assert.That(await StoredBalanceAsync("mozzarella"), Is.EqualTo(3));
    }

    // Negative, fractional, missing and non-numeric units (section 6 of the BCK09 design).
    [TestCase("""{ "units": -1 }""")]
    [TestCase("""{ "units": 1.5 }""")]
    [TestCase("""{ }""")]
    [TestCase("""{ "units": "five" }""")]
    public async Task DecreaseStock_rejects_invalid_units_and_keeps_the_stock(string json)
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);

        using var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        using var response = await _client.PostAsync("/api/v1/products/mozzarella/stock/decrease", content);

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(await StoredBalanceAsync("mozzarella"), Is.EqualTo(12));
    }

    [TestCase("Mozzarella")]
    [TestCase("mozza%20rella")]
    [TestCase("mozza--rella")]
    [TestCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")]
    public async Task DecreaseStock_rejects_a_malformed_code(string code)
    {
        using var response = await _client.PostAsJsonAsync($"/api/v1/products/{code}/stock/decrease", new { units = 1 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task DecreaseStock_creates_no_stock_for_a_product_without_stock_control()
    {
        await SeedProductAsync("napkin", "Napkin", stockControlled: false, stockBalance: null);

        using var response = await _client.PostAsJsonAsync("/api/v1/products/napkin/stock/decrease", new { units = 1 });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
        Assert.That(await StoredBalanceAsync("napkin"), Is.Null);
    }

    private async Task<int?> StoredBalanceAsync(string code)
    {
        using var scope = _factory.Services.CreateScope();
        return await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Products.AsNoTracking()
            .Where(product => product.Code == ProductCode.Create(code))
            .Select(product => product.StockBalance)
            .SingleAsync();
    }

    /// <summary>
    /// Stores a product directly. The stock balance and the active flag are
    /// written through EF Core because the domain has no stock-changing operation
    /// yet (SCRUM-167/170) and no deactivation yet (BCK05, UC-27).
    /// </summary>
    [TestCase("GET", "/api/v1/products/mozzarella/stock")]
    [TestCase("GET", "/api/v1/stock")]
    [TestCase("POST", "/api/v1/products/mozzarella/stock/increase")]
    [TestCase("POST", "/api/v1/products/mozzarella/stock/decrease")]
    public async Task Stock_endpoints_return_403_for_a_customer(string method, string path)
    {
        await SeedProductAsync("mozzarella", "Mozzarella", stockControlled: true, stockBalance: 12);
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");

        using var request = new HttpRequestMessage(new HttpMethod(method), path);
        if (method == "POST")
        {
            request.Content = JsonContent.Create(new { units = 1 });
        }

        using var response = await _client.SendAsync(request);

        using var scope = _factory.Services.CreateScope();
        var stored = await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Products
            .SingleAsync(product => product.Code == ProductCode.Create("mozzarella"));
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
            Assert.That(stored.StockBalance, Is.EqualTo(12));
        });
    }

    private async Task SeedProductAsync(
        string code, string name, bool stockControlled, int? stockBalance, bool active = true,
        string category = "ingredients")
    {
        using var scope = _factory.Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var product = new BaseProductBuilder().WithCode(code).WithName(name).WithDescription("Test product")
            .InCategory(category).AsSellable(!stockControlled).WithPrice(stockControlled ? null : 1.00m)
            .StockControlled(stockControlled).WithAllergens([]).Build();
        context.Products.Add(product);
        context.Entry(product).Property(p => p.StockBalance).CurrentValue = stockBalance;
        context.Entry(product).Property(p => p.Active).CurrentValue = active;
        await context.SaveChangesAsync();
    }

    private sealed record StockPayload(
        string ProductCode,
        string ProductName,
        bool Active,
        int QuantityInStock);

    private sealed record StockSearchItemPayload(
        string ProductCode,
        string ProductName,
        bool Active,
        string CategoryCode,
        int QuantityInStock);

    private sealed record StockSearchPagePayload(
        StockSearchItemPayload[] Items,
        int Page,
        int PageSize,
        int TotalCount);
}
