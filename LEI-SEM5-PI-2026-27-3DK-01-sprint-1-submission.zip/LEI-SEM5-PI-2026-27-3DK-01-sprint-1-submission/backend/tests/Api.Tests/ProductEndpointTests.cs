using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class ProductEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.ProductCategories.Add(ProductCategory.Create("pizza", "Pizza", null, false));
        db.Users.Add(Staff.Create(
            Email.Create("test-manager@laprizza.local"),
            "Test Manager",
            "Manager"));
        db.Products.Add(new BaseProductBuilder()
            .WithCode("margherita")
            .WithName("Margherita")
            .WithDescription("Tomato and cheese")
            .InCategory("pizza")
            .AsSellable()
            .WithPrice(9.50m)
            .StockControlled()
            .WithAllergens([])
            .Build());
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Get_returns_the_product_projection_by_business_code()
    {
        using var response = await _client.GetAsync("/api/v1/products/margherita");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("margherita"));
            Assert.That(body.GetProperty("categoryCode").GetString(), Is.EqualTo("pizza"));
            Assert.That(body.GetProperty("kind").GetString(), Is.EqualTo("Base"));
            Assert.That(body.GetProperty("isPizzaComponent").GetBoolean(), Is.False);
            Assert.That(body.GetProperty("componentTypeCode").ValueKind, Is.EqualTo(JsonValueKind.Null));
            Assert.That(body.GetProperty("sellable").GetBoolean(), Is.True);
            Assert.That(body.GetProperty("price").GetDecimal(), Is.EqualTo(9.50m));
            Assert.That(body.GetProperty("allergenCodes").GetArrayLength(), Is.EqualTo(0));
        });
    }

    [Test]
    public async Task Get_returns_404_for_an_unknown_product_code()
    {
        using var response = await _client.GetAsync("/api/v1/products/unknown");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
    }

    [TestCase("Pizza-Component")]
    [TestCase("pizza_component")]
    public async Task Get_returns_400_for_a_malformed_product_code(string code)
    {
        using var response = await _client.GetAsync($"/api/v1/products/{code}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }
}
