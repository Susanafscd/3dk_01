using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Application.Products.UpdateProduct;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;

namespace Api.Tests;

/// <summary>HTTP contract tests using a workflow double; these do not prove database integrity.</summary>
public class UpdateProductContractTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;
    private WorkflowDouble _workflow = null!;

    [SetUp]
    public async Task SetUp()
    {
        _workflow = new WorkflowDouble();
        _factory = new ApiTestFactory(services => services.AddSingleton<IUpdateProductUseCase>(_workflow));
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add("X-CSRF-TOKEN", "test-token");
        await SeedManager(_factory);
    }

    private static async Task SeedManager(ApiTestFactory factory)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Manager", "Manager"));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    private static async Task<HttpResponseMessage> Send(HttpClient client, string code = "sample", string? body = null)
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, "/api/v1/products/" + code);
        request.Content = new StringContent(body ?? """{"name":"Renamed","description":"Updated","categoryCode":"ingredients","sellable":true,"stockControlled":false,"price":2.5,"allergenCodes":["milk"]}""", Encoding.UTF8, "application/json");
        return await client.SendAsync(request);
    }

    [Test]
    public async Task Successful_workflow_maps_business_identity_and_response()
    {
        using var response = await Send(_client);
        Assert.That((int)response.StatusCode, Is.EqualTo(200));
        Assert.That(_workflow.Last!.Code, Is.EqualTo("sample"));
        Assert.That(_workflow.Calls, Is.EqualTo(1));
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("sample"));
        Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Renamed"));
        Assert.That(_workflow.Last.Name, Is.EqualTo("Renamed"));
    }

    [TestCase(404)]
    [TestCase(409)]
    public async Task Workflow_failures_map_to_problem_details(int status)
    {
        _workflow.Failure = status;
        using var response = await Send(_client);
        Assert.That((int)response.StatusCode, Is.EqualTo(status));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [TestCase("Invalid_Code")]
    [TestCase("sample--code")]
    public async Task Invalid_code_never_invokes_workflow(string code)
    {
        using var response = await Send(_client, code);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(_workflow.Calls, Is.Zero);
    }

    [Test]
    public async Task Missing_csrf_header_never_invokes_workflow()
    {
        _client.DefaultRequestHeaders.Remove("X-CSRF-TOKEN");
        using var response = await Send(_client);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(_workflow.Calls, Is.Zero);
    }

    [Test]
    public async Task Production_workflow_is_registered_and_does_not_return_501()
    {
        using var factory = new ApiTestFactory();
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CSRF-TOKEN", "test-token");
        await SeedManager(factory);
        using var response = await Send(client);
        Assert.That((int)response.StatusCode, Is.Not.EqualTo(501));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [TestCase("{}")]
    [TestCase("null")]
    [TestCase("not-json")]
    [TestCase("""{"name":"Renamed","description":"Updated","categoryCode":"ingredients","sellable":true,"stockControlled":false,"price":2.5,"allergenCodes":["milk"],"code":"changed"}""")]
    [TestCase("""{"name":"","description":"Updated","categoryCode":"ingredients","sellable":true,"stockControlled":false,"price":2.5,"allergenCodes":["milk"]}""")]
    public async Task Invalid_body_never_invokes_workflow(string json)
    {
        using var response = await Send(_client, body: json);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(_workflow.Calls, Is.Zero);
    }

    private sealed class WorkflowDouble : IUpdateProductUseCase
    {
        public int Failure { get; set; }
        public int Calls { get; private set; }
        public UpdateProductCommand? Last { get; private set; }

        public Task<LaPrizza.Application.Products.GetProduct.ProductLookupResult> ExecuteAsync(UpdateProductCommand command, CancellationToken cancellationToken = default)
        {
            Last = command;
            Calls++;
            if (Failure == 404) throw new NotFoundException("Unknown business code.");
            if (Failure == 409) throw new ConflictException("Protected references prevent this change.");
            LaPrizza.Application.Products.GetProduct.ProductLookupResult result = new(Guid.NewGuid(), command.Code, command.Name, command.Description, "Base", command.CategoryCode, command.Sellable, command.Price, null, false, command.StockControlled, null, true, command.AllergenCodes);
            return Task.FromResult(result);
        }
    }
}
