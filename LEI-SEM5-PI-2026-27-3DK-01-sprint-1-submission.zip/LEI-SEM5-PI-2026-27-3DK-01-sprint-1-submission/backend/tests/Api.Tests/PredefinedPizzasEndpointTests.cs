using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.SizeConfigurations;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

/// <summary>
/// End-to-end tests for the predefined pizza endpoints (BCK10): they go through
/// routing, model binding, authorization, the use cases and the product store,
/// backed by an in-memory database.
/// </summary>
[TestFixture]
public sealed class PredefinedPizzasEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task StartServerAsync()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Test Manager", "Manager", Array.Empty<Guid>()));
        db.Users.Add(Customer.Create(Email.Create("customer@laprizza.local"), "Customer", "Customer", Array.Empty<DietaryRestriction>(), "+351 910 000 000"));
        db.ProductCategories.AddRange(
            ProductCategory.Create("pizza-component", "Pizza components", null, true),
            ProductCategory.Create("pizzas", "Pizzas", null, false));
        db.PizzaSizes.AddRange(PizzaSize.Create("small"), PizzaSize.Create("medium"));
        db.PizzaComponentTypes.AddRange(
            PizzaComponentType.Create("base-dough", "pizza-component", "Base Dough", null, 1, 1, 1),
            PizzaComponentType.Create("cheese", "pizza-component", "Cheese", null, 3, 0, 1));
        AddComponent(db, "mozzarella", "Mozzarella", "cheese", ("small", 1.00m), ("medium", 1.50m));
        AddComponent(db, "classic-dough", "Classic dough", "base-dough", ("small", 2.00m), ("medium", 3.00m));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void StopServer()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_returns_201_with_the_location_the_ordered_configuration_and_the_price_per_size()
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita());
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(response.Headers.Location?.ToString(), Does.EndWith("/api/v1/predefined-pizzas/margherita"));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("margherita"));
            Assert.That(body.GetProperty("active").GetBoolean(), Is.True);
            Assert.That(
                body.GetProperty("defaultConfiguration").EnumerateArray().Select(c => c.GetProperty("productCode").GetString()),
                Is.EqualTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(
                body.GetProperty("availableSizes").EnumerateArray()
                    .Select(s => (s.GetProperty("sizeId").GetString(), s.GetProperty("price").GetDecimal())),
                Is.EquivalentTo(new[] { ("small", 3.00m), ("medium", 4.50m) }));
        });
        Assert.That(await StoredPizzaCountAsync(), Is.EqualTo(1));
    }

    [Test]
    public async Task Create_returns_400_for_an_unknown_component()
    {
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/predefined-pizzas",
            Margherita(componentCodes: ["classic-dough", "ghost"]));

        await AssertProblemAsync(response, HttpStatusCode.BadRequest);
    }

    [Test]
    public async Task Create_returns_409_when_a_rule_of_the_configuration_is_broken()
    {
        // Base Dough requires exactly one component.
        using var response = await _client.PostAsJsonAsync(
            "/api/v1/predefined-pizzas",
            Margherita(componentCodes: ["mozzarella"]));

        await AssertProblemAsync(response, HttpStatusCode.Conflict);
    }

    [Test]
    public async Task Create_returns_401_for_an_anonymous_caller()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Anonymous", "true");

        using var response = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita());

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Unauthorized));
        Assert.That(await StoredPizzaCountAsync(), Is.Zero);
    }

    [Test]
    public async Task Create_returns_403_for_a_customer()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");

        using var response = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita());

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
        Assert.That(await StoredPizzaCountAsync(), Is.Zero);
    }

    [Test]
    public async Task Get_returns_the_created_pizza_with_its_configuration_and_prices()
    {
        using (var created = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita()))
        {
            Assert.That(created.StatusCode, Is.EqualTo(HttpStatusCode.Created));
        }

        using var response = await _client.GetAsync("/api/v1/predefined-pizzas/margherita");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("margherita"));
            Assert.That(
                body.GetProperty("defaultConfiguration").EnumerateArray().Select(c => c.GetProperty("productCode").GetString()),
                Is.EqualTo(new[] { "classic-dough", "mozzarella" }));
            Assert.That(
                body.GetProperty("availableSizes").EnumerateArray()
                    .Select(s => (s.GetProperty("sizeId").GetString(), s.GetProperty("price").GetDecimal())),
                Is.EquivalentTo(new[] { ("small", 3.00m), ("medium", 4.50m) }));
        });
    }

    [Test]
    public async Task Get_returns_404_for_an_unknown_pizza()
    {
        using var response = await _client.GetAsync("/api/v1/predefined-pizzas/calzone");

        await AssertProblemAsync(response, HttpStatusCode.NotFound);
    }

    [Test]
    public async Task Get_returns_400_for_a_malformed_code()
    {
        using var response = await _client.GetAsync("/api/v1/predefined-pizzas/Calzone");

        await AssertProblemAsync(response, HttpStatusCode.BadRequest);
    }

    [Test]
    public async Task Get_returns_403_for_a_customer()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");

        using var response = await _client.GetAsync("/api/v1/predefined-pizzas/margherita");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
    }

    [Test]
    public async Task Search_returns_the_matching_pizzas_with_the_page_and_count()
    {
        using (var created = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita()))
        {
            Assert.That(created.StatusCode, Is.EqualTo(HttpStatusCode.Created));
        }

        using var response = await _client.GetAsync("/api/v1/predefined-pizzas?search=MARG&active=true&page=1&pageSize=10");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("page").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("pageSize").GetInt32(), Is.EqualTo(10));
            var item = body.GetProperty("items").EnumerateArray().Single();
            Assert.That(item.GetProperty("code").GetString(), Is.EqualTo("margherita"));
            Assert.That(item.GetProperty("categoryCode").GetString(), Is.EqualTo("pizzas"));
            Assert.That(item.GetProperty("active").GetBoolean(), Is.True);
        });
    }

    [Test]
    public async Task Search_returns_400_for_a_page_size_above_the_maximum()
    {
        using var response = await _client.GetAsync("/api/v1/predefined-pizzas?pageSize=101");

        await AssertProblemAsync(response, HttpStatusCode.BadRequest);
    }

    [Test]
    public async Task Search_returns_403_for_a_customer()
    {
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");

        using var response = await _client.GetAsync("/api/v1/predefined-pizzas");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
    }

    [Test]
    public async Task Update_returns_200_with_the_replaced_pizza_and_stores_it()
    {
        await CreateMargheritaAsync();

        using var response = await _client.PutAsJsonAsync(
            "/api/v1/predefined-pizzas/margherita",
            Replacement(componentCodes: ["classic-dough"], sizeIds: ["medium"]));
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        using var reread = await _client.GetAsync("/api/v1/predefined-pizzas/margherita");
        var stored = await reread.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Plain"));
            Assert.That(
                body.GetProperty("availableSizes").EnumerateArray()
                    .Select(s => (s.GetProperty("sizeId").GetString(), s.GetProperty("price").GetDecimal())),
                Is.EqualTo(new[] { ("medium", 3.00m) }));
            Assert.That(
                stored.GetProperty("defaultConfiguration").EnumerateArray().Select(c => c.GetProperty("productCode").GetString()),
                Is.EqualTo(new[] { "classic-dough" }));
        });
    }

    [Test]
    public async Task Update_returns_404_for_an_unknown_pizza()
    {
        using var response = await _client.PutAsJsonAsync("/api/v1/predefined-pizzas/calzone", Replacement());

        await AssertProblemAsync(response, HttpStatusCode.NotFound);
    }

    [Test]
    public async Task Update_returns_400_for_an_unknown_component_and_changes_nothing()
    {
        await CreateMargheritaAsync();

        using var response = await _client.PutAsJsonAsync(
            "/api/v1/predefined-pizzas/margherita",
            Replacement(componentCodes: ["classic-dough", "ghost"]));

        await AssertUpdateRejectedAsync(response, HttpStatusCode.BadRequest);
    }

    [Test]
    public async Task Update_returns_409_when_a_rule_of_the_configuration_is_broken_and_changes_nothing()
    {
        await CreateMargheritaAsync();

        using var response = await _client.PutAsJsonAsync(
            "/api/v1/predefined-pizzas/margherita",
            Replacement(componentCodes: ["mozzarella"]));

        await AssertUpdateRejectedAsync(response, HttpStatusCode.Conflict);
    }

    [Test]
    public async Task Update_returns_403_for_a_customer()
    {
        await CreateMargheritaAsync();
        _client.DefaultRequestHeaders.Add("X-Test-Email", "customer@laprizza.local");

        using var response = await _client.PutAsJsonAsync("/api/v1/predefined-pizzas/margherita", Replacement());

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
    }

    private async Task CreateMargheritaAsync()
    {
        using var created = await _client.PostAsJsonAsync("/api/v1/predefined-pizzas", Margherita());
        Assert.That(created.StatusCode, Is.EqualTo(HttpStatusCode.Created));
    }

    private async Task AssertUpdateRejectedAsync(HttpResponseMessage response, HttpStatusCode status)
    {
        using var reread = await _client.GetAsync("/api/v1/predefined-pizzas/margherita");
        var stored = await reread.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(status));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
            Assert.That(stored.GetProperty("name").GetString(), Is.EqualTo("Margherita"));
            Assert.That(stored.GetProperty("defaultConfiguration").GetArrayLength(), Is.EqualTo(2));
        });
    }

    private static object Replacement(string[]? componentCodes = null, string[]? sizeIds = null) => new
    {
        name = "Plain",
        description = "Dough only",
        componentCodes = componentCodes ?? ["classic-dough"],
        sizeIds = sizeIds ?? new[] { "small" },
    };

    private async Task AssertProblemAsync(HttpResponseMessage response, HttpStatusCode status)
    {
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(status));
            Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/problem+json"));
        });
        Assert.That(await StoredPizzaCountAsync(), Is.Zero);
    }

    private async Task<int> StoredPizzaCountAsync()
    {
        using var scope = _factory.Services.CreateScope();
        return await scope.ServiceProvider.GetRequiredService<DomainDbContext>().Products.OfType<ComposedProduct>().CountAsync();
    }

    private static object Margherita(string[]? componentCodes = null) => new
    {
        code = "margherita",
        name = "Margherita",
        description = "Tomato and mozzarella",
        categoryCode = "pizzas",
        componentCodes = componentCodes ?? ["mozzarella", "classic-dough"],
        sizeIds = new[] { "small", "medium" },
    };

    private static void AddComponent(
        DomainDbContext db,
        string code,
        string name,
        string componentType,
        params (string Size, decimal Price)[] prices)
    {
        var component = new BaseProductBuilder()
            .WithCode(code)
            .WithName(name)
            .WithDescription("Pizza component")
            .InCategory("pizza-component")
            .StockControlled()
            .Build();
        var configuration = prices.Aggregate(
            SizeConfiguration.Empty,
            (current, price) => current.AddSizeConfiguration(price.Size, price.Price, 1));
        component.SetSizeConfiguration(configuration);
        db.Products.Add(component);

        // The component type is a shadow property set by BCK05 (ComponentTypeCode).
        db.Entry(component).Property("ComponentTypeCode").CurrentValue = componentType;
    }
}
