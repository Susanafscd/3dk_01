using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.SizeConfigurations;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class PizzaSizesEndpointTests
{
    private const string BasePath = "/api/v1/pizza-sizes";

    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();

        db.Users.Add(Staff.Create(
            Email.Create("test-manager@laprizza.local"),
            "Test Manager",
            "Manager",
            Array.Empty<Guid>()));

        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_returns_location_and_size()
    {
        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            name = "small",
            description = "The 25 cm base size"
        });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("small"));
            Assert.That(body.TryGetProperty("id", out _), Is.True);
        });

        // Location must match the created id.
        var id = body.GetProperty("id").GetGuid();
        Assert.That(response.Headers.Location!.OriginalString, Is.EqualTo($"{BasePath}/{id}"));
    }

    [Test]
    public async Task Get_returns_size_by_id_or_404_for_unknown()
    {
        var createdId = await CreateSize("medium", "The 33 cm base size");

        using var existing = await _client.GetAsync($"{BasePath}/{createdId}");
        using var missing = await _client.GetAsync($"{BasePath}/00000000-0000-0000-0000-000000000000");

        Assert.Multiple(() =>
        {
            Assert.That(existing.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(missing.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        });
    }

    [Test]
    public async Task Search_finds_by_name_fragment_and_orders_by_name_then_id()
    {
        await CreateSize("large", "The 50 cm base size");
        await CreateSize("small", "The 25 cm base size");

        using var response = await _client.GetAsync($"{BasePath}?search=lar&page=1&pageSize=20");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("items")[0].GetProperty("name").GetString(), Is.EqualTo("large"));
        });
    }

    [Test]
    public async Task Delete_removes_unused_size()
    {
        var createdId = await CreateSize("large", null);

        using var response = await _client.DeleteAsync($"{BasePath}/{createdId}");
        using var afterwards = await _client.GetAsync($"{BasePath}/{createdId}");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            Assert.That(afterwards.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        });
    }

    [Test]
    public async Task Delete_rejects_size_in_use_by_size_configurations()
    {
        var created = await CreateSize("medium", null);

        using (var scope = _factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();

            // BCK08 stores the configured size identifiers in a jsonb value object.
            // The in-use check must detect references.
            var product = new BaseProductBuilder()
                .WithCode("component")
                .WithName("Component")
                .WithDescription("Test component")
                .InCategory("ingredients")
                .AsSellable()
                .WithPrice(1m)
                .WithAllergens(Array.Empty<string>())
                .WithConfiguration(p =>
                    p.SetSizeConfiguration(
                        SizeConfiguration.Empty.AddSizeConfiguration("medium", 1m, 0)));

            db.Products.Add(product.Build());
            await db.SaveChangesAsync();
        }

        using var response = await _client.DeleteAsync($"{BasePath}/{created}");
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
    }

    private async Task<Guid> CreateSize(string name, string? description)
    {
        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            name,
            description
        });
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        return body.GetProperty("id").GetGuid();
    }
}
