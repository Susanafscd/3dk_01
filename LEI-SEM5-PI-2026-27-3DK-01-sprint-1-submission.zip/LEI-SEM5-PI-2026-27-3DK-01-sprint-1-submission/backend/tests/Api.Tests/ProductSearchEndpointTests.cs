using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class ProductSearchEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(
            Email.Create("test-manager@laprizza.local"),
            "Test Manager",
            "Manager"));
        db.ProductCategories.Add(ProductCategory.Create("pizza", "Pizza", null, false));
        db.Products.AddRange(
            Product("margherita", "Margherita", ["milk"]),
            Product("marinara", "Marinara", []),
            Product("dessert", "Dessert", ["milk"]));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Search_combines_filters_and_returns_count_and_stable_items()
    {
        using var response = await _client.GetAsync(
            "/api/v1/products?categoryCode=pizza&allergenCode=milk&page=1&pageSize=1");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.EqualTo(2));
            Assert.That(body.GetProperty("items").GetArrayLength(), Is.EqualTo(1));
            Assert.That(body.GetProperty("page").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("pageSize").GetInt32(), Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Search_returns_empty_page_for_no_matches()
    {
        using var response = await _client.GetAsync("/api/v1/products?search=unknown");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("items").GetArrayLength(), Is.EqualTo(0));
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.EqualTo(0));
        });
    }

    [TestCase("page=0")]
    [TestCase("pageSize=101")]
    [TestCase("componentTypeCode=base")]
    public async Task Search_rejects_invalid_filters(string query)
    {
        using var response = await _client.GetAsync($"/api/v1/products?{query}");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    private static BaseProduct Product(string code, string name, IReadOnlyList<string> allergens) =>
        new BaseProductBuilder()
            .WithCode(code)
            .WithName(name)
            .WithDescription(name)
            .InCategory("pizza")
            .AsSellable()
            .WithPrice(5m)
            .WithAllergens(allergens)
            .Build();
}
