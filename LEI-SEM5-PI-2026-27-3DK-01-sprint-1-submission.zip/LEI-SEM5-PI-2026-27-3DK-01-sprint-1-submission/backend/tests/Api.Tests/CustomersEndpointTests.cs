using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class CustomersEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(
            Email.Create("test-manager@laprizza.local"),
            "Test Manager",
            "Manager",
            []));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_creates_the_customer_and_its_identity_account()
    {
        const string email = "new.customer@example.com";

        using var response = await _client.PostAsJsonAsync("/api/v1/customers", new
        {
            name = "New Customer",
            email,
            phoneNumber = "+351 910 000 011",
            vatNumber = "PT501964843",
            password = "Password123!"
        });

        using var scope = _factory.Services.CreateScope();
        var domainDb = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var identityManager = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();
        var customer = await domainDb.Users.OfType<Customer>()
            .SingleAsync(user => user.Email == Email.Create(email));
        var identityUser = await identityManager.FindByEmailAsync(email);
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(body.GetProperty("vatNumber").GetString(), Is.EqualTo("PT501964843"));
            Assert.That(customer.Active, Is.True);
            Assert.That(identityUser, Is.Not.Null);
            Assert.That(identityUser!.Email, Is.EqualTo(email));
        });
    }

    [Test]
    public async Task Search_matches_customer_name_phone_and_exact_email()
    {
        await SeedCustomer("Ana Ferreira", "ana.ferreira@example.com", "+351 910 111 111");
        await SeedCustomer("Miguel Santos", "miguel.santos@example.com", "+351 910 222 222");

        using var nameSearch = await _client.GetAsync("/api/v1/customers?search=ferreira");
        using var phoneSearch = await _client.GetAsync("/api/v1/customers?search=222");
        using var emailSearch = await _client.GetAsync("/api/v1/customers?search=miguel.santos@example.com");

        var nameBody = await nameSearch.Content.ReadFromJsonAsync<JsonElement>();
        var phoneBody = await phoneSearch.Content.ReadFromJsonAsync<JsonElement>();
        var emailBody = await emailSearch.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(nameSearch.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(nameBody.GetArrayLength(), Is.EqualTo(1));
            Assert.That(nameBody[0].GetProperty("name").GetString(), Is.EqualTo("Ana Ferreira"));
            Assert.That(phoneBody.GetArrayLength(), Is.EqualTo(1));
            Assert.That(phoneBody[0].GetProperty("name").GetString(), Is.EqualTo("Miguel Santos"));
            Assert.That(emailBody.GetArrayLength(), Is.EqualTo(1));
            Assert.That(emailBody[0].GetProperty("email").GetString(), Is.EqualTo("miguel.santos@example.com"));
        });
    }

    [Test]
    public async Task Update_changes_profile_fields_but_preserves_email()
    {
        var id = await CreateCustomer("Original Name", "original@example.com", "+351 910 000 001");

        using var response = await _client.PutAsJsonAsync(
            $"/api/v1/customers/{id}",
            new { name = "Updated Name", phoneNumber = "+351 910 000 002" });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Updated Name"));
            Assert.That(body.GetProperty("phoneNumber").GetString(), Is.EqualTo("+351 910 000 002"));
            Assert.That(body.GetProperty("email").GetString(), Is.EqualTo("original@example.com"));
        });
    }

    [Test]
    public async Task Customer_can_read_and_update_their_own_profile()
    {
        const string email = "self.customer@example.com";
        var id = await SeedCustomer("Self Customer", email, "+351 910 100 001");

        using var getRequest = new HttpRequestMessage(HttpMethod.Get, $"/api/v1/customers/{id}");
        getRequest.Headers.Add("X-Test-Email", email);
        using var getResponse = await _client.SendAsync(getRequest);

        using var updateRequest = new HttpRequestMessage(HttpMethod.Put, $"/api/v1/customers/{id}")
        {
            Content = JsonContent.Create(new
            {
                name = "Updated Self Customer",
                phoneNumber = "+351 910 100 002",
            }),
        };
        updateRequest.Headers.Add("X-Test-Email", email);
        using var updateResponse = await _client.SendAsync(updateRequest);

        Assert.Multiple(() =>
        {
            Assert.That(getResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(updateResponse.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        });
    }

    [Test]
    public async Task Customer_cannot_read_or_update_another_customer()
    {
        const string ownEmail = "own.customer@example.com";
        const string otherEmail = "other.customer@example.com";
        await SeedCustomer("Own Customer", ownEmail, "+351 910 200 001");
        var otherId = await SeedCustomer("Other Customer", otherEmail, "+351 910 200 002");

        using var getRequest = new HttpRequestMessage(HttpMethod.Get, $"/api/v1/customers/{otherId}");
        getRequest.Headers.Add("X-Test-Email", ownEmail);
        using var getResponse = await _client.SendAsync(getRequest);

        using var updateRequest = new HttpRequestMessage(HttpMethod.Put, $"/api/v1/customers/{otherId}")
        {
            Content = JsonContent.Create(new
            {
                name = "Unauthorized Update",
                phoneNumber = "+351 910 200 003",
            }),
        };
        updateRequest.Headers.Add("X-Test-Email", ownEmail);
        using var updateResponse = await _client.SendAsync(updateRequest);

        Assert.Multiple(() =>
        {
            Assert.That(getResponse.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
            Assert.That(updateResponse.StatusCode, Is.EqualTo(HttpStatusCode.Forbidden));
        });
    }

    [Test]
    public async Task Deactivate_marks_the_customer_inactive_without_deleting_it()
    {
        var id = await CreateCustomer("To Deactivate", "inactive@example.com", "+351 910 000 003");

        using var response = await _client.DeleteAsync($"/api/v1/customers/{id}");
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var customer = await db.Users.OfType<Customer>().SingleAsync(user => user.Id == id);

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            Assert.That(customer.Active, Is.False);
        });
    }

    private async Task<Guid> CreateCustomer(string name, string email, string phoneNumber)
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/customers", new
        {
            name,
            email,
            phoneNumber,
            password = "Password123!"
        });
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        return body.GetProperty("id").GetGuid();
    }

    private async Task<Guid> SeedCustomer(string name, string email, string phoneNumber)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        db.Users.Add(Customer.Create(
            Email.Create(email),
            name,
            name,
            [],
            phoneNumber));
        await db.SaveChangesAsync();
        return db.Users.OfType<Customer>().Single(user => user.Email == Email.Create(email)).Id;
    }
}
