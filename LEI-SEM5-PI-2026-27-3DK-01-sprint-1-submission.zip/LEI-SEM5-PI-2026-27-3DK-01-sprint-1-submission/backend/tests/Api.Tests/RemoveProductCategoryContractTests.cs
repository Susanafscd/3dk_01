using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Application.Abstractions;
using LaPrizza.Application.ProductCategories.RemoveProductCategory;
using LaPrizza.Application.Common.Exceptions;
using LaPrizza.Domain.Users;
using LaPrizza.Domain.Product;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;

namespace Api.Tests;

/// <summary>HTTP contract tests using a workflow double; these do not prove database integrity.</summary>
public class RemoveProductCategoryContractTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;
    private WorkflowDouble _workflow = null!;

    [SetUp]
    public async Task SetUp()
    {
        _workflow = new WorkflowDouble();
        _factory = new ApiTestFactory(services => services.AddSingleton<IRemoveProductCategoryUseCase>(_workflow));
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add("X-CSRF-TOKEN", "test-token");
        await SeedManager(_factory);
    }

    private static async Task SeedManager(ApiTestFactory factory)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Manager", "Manager"));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    private static async Task<HttpResponseMessage> Send(HttpClient client, string code = "sample", string? body = null)
    {
        using var request = new HttpRequestMessage(HttpMethod.Delete, "/api/v1/product-categories/" + code);
        
        return await client.SendAsync(request);
    }

    [Test]
    public async Task Successful_workflow_maps_business_identity_and_response()
    {
        using var response = await Send(_client);
        Assert.That((int)response.StatusCode, Is.EqualTo(204));
        Assert.That(_workflow.Last!.Code, Is.EqualTo("sample"));
        Assert.That(_workflow.Calls, Is.EqualTo(1));
        Assert.That(await response.Content.ReadAsStringAsync(), Is.Empty);
    }

    [TestCase(404)]
    [TestCase(409)]
    public async Task Workflow_failures_map_to_problem_details(int status)
    {
        _workflow.Failure = status;
        using var response = await Send(_client);
        Assert.That((int)response.StatusCode, Is.EqualTo(status));
        Assert.That(response.Content.Headers.ContentType!.MediaType, Is.EqualTo("application/problem+json"));
    }

    [TestCase("Invalid_Code")]
    [TestCase("sample--code")]
    public async Task Invalid_code_never_invokes_workflow(string code)
    {
        using var response = await Send(_client, code);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(_workflow.Calls, Is.Zero);
    }

    [Test]
    public async Task Missing_csrf_header_never_invokes_workflow()
    {
        _client.DefaultRequestHeaders.Remove("X-CSRF-TOKEN");
        using var response = await Send(_client);
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        Assert.That(_workflow.Calls, Is.Zero);
    }

    [Test]
    public async Task Registered_workflow_removes_an_unused_category_and_invalidates_cache()
    {
        using var factory = new ApiTestFactory();
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CSRF-TOKEN", "test-token");
        await SeedManager(factory);
        using (var scope = factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
            db.ProductCategories.Add(ProductCategory.Create("unused", "Unused", null, false));
            await db.SaveChangesAsync();
        }

        using var response = await Send(client, "unused");

        using var verificationScope = factory.Services.CreateScope();
        var verificationDb = verificationScope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var cache = (RecordingCatalogueCacheInvalidator)verificationScope.ServiceProvider
            .GetRequiredService<ICatalogueCacheInvalidator>();
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            Assert.That(verificationDb.ProductCategories.Any(), Is.False);
            Assert.That(cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Registered_workflow_preserves_a_category_referenced_by_an_inactive_product()
    {
        using var factory = new ApiTestFactory();
        using var client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-CSRF-TOKEN", "test-token");
        await SeedManager(factory);
        using (var scope = factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
            db.ProductCategories.Add(ProductCategory.Create("ingredients", "Ingredients", null, false));
            var product = new BaseProductBuilder().WithCode("ingredient").WithName("Ingredient")
                .WithDescription("Test").InCategory("ingredients").AsSellable(true).WithPrice(1m)
                .StockControlled(false).WithAllergens([]).Build();
            db.Products.Add(product);
            await db.SaveChangesAsync();
            db.Entry(product).Property("Active").CurrentValue = false;
            await db.SaveChangesAsync();
        }

        using var response = await Send(client, "ingredients");

        using var verificationScope = factory.Services.CreateScope();
        var verificationDb = verificationScope.ServiceProvider.GetRequiredService<DomainDbContext>();
        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
            Assert.That(verificationDb.ProductCategories.Count(), Is.EqualTo(1));
            Assert.That(verificationDb.Products.Count(), Is.EqualTo(1));
        });
    }

    private sealed class WorkflowDouble : IRemoveProductCategoryUseCase
    {
        public int Failure { get; set; }
        public int Calls { get; private set; }
        public RemoveProductCategoryCommand? Last { get; private set; }

        public Task ExecuteAsync(RemoveProductCategoryCommand command, CancellationToken cancellationToken = default)
        {
            Last = command;
            Calls++;
            if (Failure == 404) throw new NotFoundException("Unknown business code.");
            if (Failure == 409) throw new ConflictException("Protected references prevent this change.");
            return Task.CompletedTask;
        }
    }
}
