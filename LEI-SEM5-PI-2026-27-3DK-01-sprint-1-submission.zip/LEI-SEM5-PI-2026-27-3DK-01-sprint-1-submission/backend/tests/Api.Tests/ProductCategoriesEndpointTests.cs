using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class ProductCategoriesEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;
    private RecordingCatalogueCacheInvalidator _cache = null!;

    [SetUp]
    public async Task SetUp()
    {
        _cache = new RecordingCatalogueCacheInvalidator();
        _factory = new ApiTestFactory(services => services.AddSingleton<ICatalogueCacheInvalidator>(_cache));
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Test Manager", "Manager", Array.Empty<Guid>()));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_returns_business_code_location_and_invalidates_after_commit()
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/product-categories", new
        {
            code = "pizza",
            name = " Pizza ",
            description = " Main pizzas ",
            allowsComponentTypes = false,
        });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(response.Headers.Location!.OriginalString, Is.EqualTo("/api/v1/product-categories/pizza"));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("pizza"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Pizza"));
            Assert.That(body.GetProperty("description").GetString(), Is.EqualTo("Main pizzas"));
            Assert.That(body.GetProperty("allowsComponentTypes").GetBoolean(), Is.False);
            Assert.That(_cache.Invalidations, Is.EqualTo(1));
        });
    }

    [Test]
    public async Task Create_rejects_duplicate_business_code()
    {
        await Seed("pizza", "Pizza", null, false);
        using var response = await _client.PostAsJsonAsync("/api/v1/product-categories", new
        {
            code = "pizza",
            name = "Other",
            allowsComponentTypes = true,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
    }

    [Test]
    public async Task Get_returns_all_category_fields_and_unknown_is_404()
    {
        await Seed("pizza", "Pizza", null, false);
        using var response = await _client.GetAsync("/api/v1/product-categories/pizza");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        using var missing = await _client.GetAsync("/api/v1/product-categories/unknown");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("pizza"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Pizza"));
            Assert.That(body.GetProperty("allowsComponentTypes").GetBoolean(), Is.False);
            Assert.That(missing.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        });
    }

    [Test]
    public async Task Search_filters_and_pages_categories_with_total_count()
    {
        await Seed("pizza", "Pizza", null, false);
        await Seed("dessert", "Dessert", "Sweet", false);
        await Seed("pizza-component", "Pizza Component", null, true);

        using var response = await _client.GetAsync("/api/v1/product-categories?search=PIZ&page=1&pageSize=1");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("items").GetArrayLength(), Is.EqualTo(1));
            Assert.That(body.GetProperty("totalCount").GetInt32(), Is.EqualTo(2));
            Assert.That(body.GetProperty("page").GetInt32(), Is.EqualTo(1));
            Assert.That(body.GetProperty("pageSize").GetInt32(), Is.EqualTo(1));
        });
    }

    [TestCase("page=0")]
    [TestCase("pageSize=101")]
    [TestCase("page=not-a-number")]
    public async Task Search_rejects_invalid_pagination(string query)
    {
        using var response = await _client.GetAsync($"/api/v1/product-categories?{query}");
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    private async Task Seed(string code, string name, string? description, bool allowsComponentTypes)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        db.ProductCategories.Add(ProductCategory.Create(code, name, description, allowsComponentTypes));
        await db.SaveChangesAsync();
    }
}
