using System.Net;
using System.Net.Http.Json;
using Api.Tests.Support;
using LaPrizza.Domain.Users;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class CustomerDietaryRestrictionsEndpointTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.Users.Add(Staff.Create(
            Email.Create("test-manager@laprizza.local"),
            "Test Manager",
            "Manager",
            []));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_customer_persists_restrictions_with_empty_allergen_lists()
    {
        using var response = await _client.PostAsJsonAsync("/api/v1/customers", new
        {
            name = "Ada Lovelace",
            email = "ada@example.com",
            phoneNumber = "+351 910 000 010",
            password = "Password123!",
            dietaryRestrictions = new[] { "Vegan", "Gluten-free" }
        });

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var customer = await db.Users.OfType<Customer>()
            .Include(value => value.DietaryRestrictions)
            .SingleAsync(value => value.Email == Email.Create("ada@example.com"));

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(customer.DietaryRestrictions.Select(value => value.Name),
                Is.EquivalentTo(new[] { "Vegan", "Gluten-free" }));
            Assert.That(customer.DietaryRestrictions.All(value => value.Allergens.Count == 0), Is.True);
        });
    }
}
