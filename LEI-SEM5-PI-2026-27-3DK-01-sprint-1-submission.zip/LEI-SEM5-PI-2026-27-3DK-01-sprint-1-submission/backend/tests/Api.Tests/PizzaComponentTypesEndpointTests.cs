using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Api.Tests.Support;
using LaPrizza.Domain.ComponentTypes;
using LaPrizza.Domain.Users;
using LaPrizza.Domain.ProductCategories;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Tests;

[TestFixture]
public sealed class PizzaComponentTypesEndpointTests
{
    private const string BasePath = "/api/v1/pizza-component-types";

    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;

    [SetUp]
    public async Task SetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
        _client.DefaultRequestHeaders.Add(AntiforgeryDefaults.HeaderName, "test-request-token");

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        await db.Database.EnsureCreatedAsync();
        db.ProductCategories.Add(ProductCategory.Create("pizza-component", "Pizza Components", null, true));
        db.Users.Add(Staff.Create(Email.Create("test-manager@laprizza.local"), "Test Manager", "Manager", Array.Empty<Guid>()));
        await db.SaveChangesAsync();
    }

    [TearDown]
    public void TearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Create_returns_business_code_and_location_and_never_exposes_the_guid()
    {
        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            code = "topping",
            categoryCode = "pizza-component",
            name = " Topping ",
            description = "Extra toppings",
            assemblyOrder = 4,
            minQuantity = 0,
        });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(response.Headers.Location!.OriginalString, Is.EqualTo($"{BasePath}/topping"));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("topping"));
            Assert.That(body.GetProperty("categoryCode").GetString(), Is.EqualTo("pizza-component"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Topping"));
            Assert.That(body.GetProperty("assemblyOrder").GetInt32(), Is.EqualTo(4));
            Assert.That(body.TryGetProperty("id", out _), Is.False);
        });
    }

    [Test]
    public async Task Create_rejects_duplicate_code()
    {
        await Seed("topping", "Topping", 4);

        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            code = "topping",
            categoryCode = "pizza-component",
            name = "Other",
            assemblyOrder = 5,
            minQuantity = 0,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
    }

    [Test]
    public async Task Create_rejects_duplicate_name_ignoring_case()
    {
        await Seed("topping", "Topping", 4);

        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            code = "other-topping",
            categoryCode = "pizza-component",
            name = "topping",
            assemblyOrder = 5,
            minQuantity = 0,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Conflict));
    }

    [TestCase("Topping")]
    [TestCase("base dough")]
    [TestCase("base--dough")]
    public async Task Create_rejects_invalid_code(string code)
    {
        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            code,
            categoryCode = "pizza-component",
            name = "Topping",
            assemblyOrder = 4,
            minQuantity = 0,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task Create_requires_a_code()
    {
        using var response = await _client.PostAsJsonAsync(BasePath, new
        {
            name = "Topping",
            assemblyOrder = 4,
            minQuantity = 0,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
    }

    [Test]
    public async Task Get_by_code_returns_the_type_and_unknown_code_is_404()
    {
        await Seed("topping", "Topping", 4);

        using var response = await _client.GetAsync($"{BasePath}/topping");
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();
        using var missing = await _client.GetAsync($"{BasePath}/unknown");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("topping"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Topping"));
            Assert.That(body.TryGetProperty("id", out _), Is.False);
            Assert.That(missing.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        });
    }

    [Test]
    public async Task Get_by_guid_is_no_longer_supported()
    {
        var id = await Seed("topping", "Topping", 4);

        using var response = await _client.GetAsync($"{BasePath}/{id}");

        Assert.That(response.StatusCode, Is.Not.EqualTo(HttpStatusCode.OK));
    }

    [Test]
    public async Task Search_finds_by_exact_code_or_name_fragment_ordered_by_assembly_order_without_ids()
    {
        await Seed("topping", "Topping", 4);
        await Seed("base-dough", "Base Dough", 1);
        await Seed("cheese", "Cheese", 3);

        using var all = await _client.GetAsync(BasePath);
        var allBody = await all.Content.ReadFromJsonAsync<JsonElement>();
        using var byCode = await _client.GetAsync($"{BasePath}?search=cheese");
        var byCodeBody = await byCode.Content.ReadFromJsonAsync<JsonElement>();
        using var byName = await _client.GetAsync($"{BasePath}?search=DOUGH");
        var byNameBody = await byName.Content.ReadFromJsonAsync<JsonElement>();

        var codes = allBody.GetProperty("items").EnumerateArray()
            .Select(item => item.GetProperty("code").GetString())
            .ToList();

        Assert.Multiple(() =>
        {
            Assert.That(all.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(codes, Is.EqualTo(new[] { "base-dough", "cheese", "topping" }));
            Assert.That(allBody.GetProperty("totalCount").GetInt32(), Is.EqualTo(3));
            Assert.That(allBody.GetProperty("items")[0].TryGetProperty("id", out _), Is.False);
            Assert.That(byCodeBody.GetProperty("items")[0].GetProperty("code").GetString(), Is.EqualTo("cheese"));
            Assert.That(byNameBody.GetProperty("items")[0].GetProperty("code").GetString(), Is.EqualTo("base-dough"));
        });
    }

    [Test]
    public async Task Update_changes_details_but_never_the_code()
    {
        await Seed("topping", "Topping", 4);

        using var response = await _client.PutAsJsonAsync($"{BasePath}/topping", new
        {
            name = "Toppings",
            description = "Updated",
            assemblyOrder = 5,
            minQuantity = 0,
        });
        var body = await response.Content.ReadFromJsonAsync<JsonElement>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(body.GetProperty("code").GetString(), Is.EqualTo("topping"));
            Assert.That(body.GetProperty("name").GetString(), Is.EqualTo("Toppings"));
            Assert.That(body.GetProperty("assemblyOrder").GetInt32(), Is.EqualTo(5));
        });
    }

    [Test]
    public async Task Update_unknown_code_is_404()
    {
        using var response = await _client.PutAsJsonAsync($"{BasePath}/unknown", new
        {
            name = "Toppings",
            assemblyOrder = 5,
            minQuantity = 0,
        });

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
    }

    [Test]
    public async Task Delete_removes_the_type_by_code()
    {
        await Seed("topping", "Topping", 4);

        using var response = await _client.DeleteAsync($"{BasePath}/topping");
        using var afterwards = await _client.GetAsync($"{BasePath}/topping");

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            Assert.That(afterwards.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
        });
    }

    [Test]
    public async Task Delete_unknown_code_is_404()
    {
        using var response = await _client.DeleteAsync($"{BasePath}/unknown");

        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.NotFound));
    }

    private async Task<Guid> Seed(string code, string name, int assemblyOrder)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DomainDbContext>();
        var type = PizzaComponentType.Create(code, name, null, assemblyOrder, 0, null);
        db.PizzaComponentTypes.Add(type);
        await db.SaveChangesAsync();
        return type.Id;
    }
}
