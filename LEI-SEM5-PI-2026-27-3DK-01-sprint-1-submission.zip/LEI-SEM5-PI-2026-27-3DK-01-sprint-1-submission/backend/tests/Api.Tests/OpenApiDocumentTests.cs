using System.Net;
using System.Text.Json;
using System.Text.Json.Nodes;
using Api.Tests.Support;

namespace Api.Tests;

/// <summary>
/// Verifies that the contract served at /swagger/v1/swagger.json is the committed
/// document at docs/api/openapi.json, and that the committed contract describes
/// the implemented endpoints, their payloads and the way clients authenticate.
/// The contract is the input of the API (see src/Api/nswag.json), so these tests
/// guard the contract itself.
/// </summary>
[TestFixture]
public sealed class OpenApiDocumentTests
{
    private ApiTestFactory _factory = null!;
    private HttpClient _client = null!;
    private JsonElement _document;
    private string _json = null!;

    [OneTimeSetUp]
    public async Task OneTimeSetUp()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();

        var response = await _client.GetAsync("/swagger/v1/swagger.json");
        Assert.That(
            response.StatusCode,
            Is.EqualTo(HttpStatusCode.OK),
            "The OpenAPI contract must be served, otherwise Swagger UI has nothing to show.");
        Assert.That(response.Content.Headers.ContentType?.MediaType, Is.EqualTo("application/json"));

        _json = await response.Content.ReadAsStringAsync();
        _document = JsonDocument.Parse(_json).RootElement.Clone();
    }

    [OneTimeTearDown]
    public void OneTimeTearDown()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public void Document_declares_the_openapi_version_and_the_api_metadata()
    {
        Assert.That(_document.GetProperty("openapi").GetString(), Does.StartWith("3."));

        var info = _document.GetProperty("info");
        Assert.That(info.GetProperty("title").GetString(), Is.EqualTo("LaPrizza API"));
        Assert.That(info.GetProperty("version").GetString(), Is.Not.Empty);
        Assert.That(info.GetProperty("description").GetString(), Is.Not.Null.And.Not.Empty);
    }

    [Test]
    public void Document_describes_the_create_customer_operation()
    {
        var operation = GetOperation("/api/v1/customers", "post");

        var requestSchema = operation
            .GetProperty("requestBody")
            .GetProperty("content")
            .GetProperty("application/json")
            .GetProperty("schema");
        Assert.That(
            requestSchema.GetProperty("$ref").GetString(),
            Is.EqualTo("#/components/schemas/CreateCustomerRequest"));

        var responseSchema = operation
            .GetProperty("responses")
            .GetProperty("201")
            .GetProperty("content")
            .GetProperty("application/json")
            .GetProperty("schema");
        Assert.That(
            responseSchema.GetProperty("$ref").GetString(),
            Is.EqualTo("#/components/schemas/CustomerResponse"));
    }

    [Test]
    public void Document_describes_the_customer_search_operation()
    {
        var operation = GetOperation("/api/v1/customers", "get");

        var responseSchema = operation
            .GetProperty("responses")
            .GetProperty("200")
            .GetProperty("content")
            .GetProperty("application/json")
            .GetProperty("schema");

        Assert.That(responseSchema.GetProperty("type").GetString(), Is.EqualTo("array"));
        Assert.That(
            responseSchema.GetProperty("items").GetProperty("$ref").GetString(),
            Is.EqualTo("#/components/schemas/CustomerResponse"));
    }

    [Test]
    public void Create_customer_request_requires_name_email_password_and_phone()
    {
        var required = _document
            .GetProperty("components")
            .GetProperty("schemas")
            .GetProperty("CreateCustomerRequest")
            .GetProperty("required")
            .EnumerateArray()
            .Select(property => property.GetString())
            .ToArray();

        Assert.That(required, Is.EquivalentTo(new[] { "name", "email", "password", "phoneNumber" }));
    }

    [Test]
    public void Document_does_not_describe_a_generic_users_endpoint()
    {
        var paths = _document.GetProperty("paths");

        Assert.That(
            paths.TryGetProperty("/api/v1/users", out _),
            Is.False,
            "User management is not a requirement; customers are the exposed resource.");
    }

    [Test]
    public void Unsafe_operations_require_the_antiforgery_header()
    {
        var operation = GetOperation("/api/v1/customers", "post");

        Assert.That(ParameterNames(operation), Does.Contain("X-CSRF-TOKEN"));
    }

    [Test]
    public void Safe_operations_do_not_require_the_antiforgery_header()
    {
        var operation = GetOperation("/api/v1/health", "get");

        Assert.That(ParameterNames(operation), Does.Not.Contain("X-CSRF-TOKEN"));
    }

    [Test]
    public void Document_exposes_reusable_parameters_and_responses()
    {
        var components = _document.GetProperty("components");

        var parameters = components.GetProperty("parameters");
        Assert.That(parameters.TryGetProperty("X-CSRF-TOKEN", out _), Is.True);
        Assert.That(
            parameters.TryGetProperty("CustomerId", out _),
            Is.True);

        var responses = components.GetProperty("responses");
        foreach (var name in new[] { "BadRequest", "Unauthorized", "NotFound", "Conflict" })
        {
            Assert.That(
                responses.TryGetProperty(name, out _),
                Is.True,
                $"'{name}' must be a reusable response so operations reference it instead of repeating it.");
        }
    }

    [Test]
    public void Document_declares_the_session_cookie_security_scheme()
    {
        var scheme = _document
            .GetProperty("components")
            .GetProperty("securitySchemes")
            .GetProperty("cookieAuth");

        Assert.That(scheme.GetProperty("type").GetString(), Is.EqualTo("apiKey"));
        Assert.That(scheme.GetProperty("in").GetString(), Is.EqualTo("cookie"));
        Assert.That(scheme.GetProperty("name").GetString(), Is.EqualTo("Api.Auth"));
    }

    [Test]
    public void Protected_operations_require_authentication()
    {
        var operation = GetOperation("/api/v1/customers", "post");

        Assert.That(operation.TryGetProperty("security", out var security), Is.True);
        Assert.That(security.EnumerateArray().Any(), Is.True);
    }

    [Test]
    public void Anonymous_operations_are_documented_without_authentication()
    {
        var operation = GetOperation("/api/v1/health", "get");

        Assert.That(operation.TryGetProperty("security", out _), Is.False);
    }

    [Test]
    public void Served_document_is_the_committed_contract()
    {
        var specificationPath = RepositoryPaths.OpenApiSpecification;

        Assert.That(
            File.Exists(specificationPath),
            Is.True,
            $"{specificationPath} is missing. It is the input of the API.");

        var committed = JsonNode.Parse(File.ReadAllText(specificationPath));
        var served = JsonNode.Parse(_json);

        Assert.That(
            JsonNode.DeepEquals(committed, served),
            Is.True,
            "The document served at /swagger/v1/swagger.json must be docs/api/openapi.json.");
    }

    [Test]
    public void Allergen_registration_declares_business_code_location_validation_and_errors()
    {
        var operation = GetOperation("/api/v1/allergens", "post");
        var schema = _document.GetProperty("components").GetProperty("schemas").GetProperty("CreateAllergenRequest");
        var response = _document.GetProperty("components").GetProperty("schemas").GetProperty("AllergenResponse");
        Assert.Multiple(() =>
        {
            Assert.That(operation.GetProperty("operationId").GetString(), Is.EqualTo("createAllergen"));
            Assert.That(operation.GetProperty("responses").GetProperty("201").GetProperty("headers").TryGetProperty("Location", out _), Is.True);
            Assert.That(ParameterNames(operation), Does.Contain("X-CSRF-TOKEN"));
            Assert.That(schema.GetProperty("additionalProperties").GetBoolean(), Is.False);
            Assert.That(schema.GetProperty("required").EnumerateArray().Select(p => p.GetString()), Is.EquivalentTo(new[] { "code", "name" }));
            Assert.That(response.GetProperty("properties").TryGetProperty("id", out _), Is.False);
        });
        foreach (var status in new[] { "400", "401", "403", "409" })
        {
            Assert.That(operation.GetProperty("responses").TryGetProperty(status, out _), Is.True);
        }
    }

    [Test]
    public void Allergen_retrieval_uses_business_code_and_semantic_responses()
    {
        var operation = GetOperation("/api/v1/allergens/{allergenCode}", "get");
        var parameter = operation.GetProperty("parameters")[0];
        var responses = operation.GetProperty("responses");

        Assert.Multiple(() =>
        {
            Assert.That(operation.GetProperty("operationId").GetString(), Is.EqualTo("getAllergen"));
            Assert.That(parameter.GetProperty("name").GetString(), Is.EqualTo("allergenCode"));
            Assert.That(parameter.GetProperty("schema").GetProperty("pattern").GetString(),
                Is.EqualTo("^[a-z0-9]+(?:-[a-z0-9]+)*$"));
            Assert.That(responses.TryGetProperty("200", out _), Is.True);
            Assert.That(responses.TryGetProperty("400", out _), Is.True);
            Assert.That(responses.TryGetProperty("404", out _), Is.True);
        });
    }

    [Test]
    public void Allergen_search_contract_describes_filters_paging_and_count()
    {
        var operation = GetOperation("/api/v1/allergens", "get");
        var parameterNames = ParameterNames(operation);
        var schema = _document.GetProperty("components").GetProperty("schemas")
            .GetProperty("AllergenSearchResponse");

        Assert.Multiple(() =>
        {
            Assert.That(operation.GetProperty("operationId").GetString(), Is.EqualTo("searchAllergens"));
            Assert.That(parameterNames, Is.EquivalentTo(new[] { "search", "page", "pageSize" }));
            Assert.That(schema.GetProperty("required").EnumerateArray().Select(value => value.GetString()),
                Is.EquivalentTo(new[] { "items", "page", "pageSize", "totalCount" }));
            Assert.That(operation.GetProperty("responses").TryGetProperty("200", out _), Is.True);
            Assert.That(operation.GetProperty("responses").TryGetProperty("400", out _), Is.True);
        });
    }

    [Test]
    public void Allergen_update_contract_preserves_route_identity_and_rejects_extra_fields()
    {
        var operation = GetOperation("/api/v1/allergens/{allergenCode}", "put");
        var schema = _document.GetProperty("components").GetProperty("schemas")
            .GetProperty("UpdateAllergenRequest");
        var responses = operation.GetProperty("responses");

        Assert.Multiple(() =>
        {
            Assert.That(operation.GetProperty("operationId").GetString(), Is.EqualTo("updateAllergen"));
            Assert.That(ParameterNames(operation), Does.Contain("allergenCode"));
            Assert.That(ParameterNames(operation), Does.Contain("X-CSRF-TOKEN"));
            Assert.That(schema.GetProperty("additionalProperties").GetBoolean(), Is.False);
            Assert.That(schema.GetProperty("required").EnumerateArray().Select(value => value.GetString()),
                Is.EquivalentTo(new[] { "name" }));
        });

        foreach (var status in new[] { "200", "400", "401", "403", "404", "409" })
        {
            Assert.That(responses.TryGetProperty(status, out _), Is.True);
        }
    }

    private string[] ParameterNames(JsonElement operation)
    {
        if (!operation.TryGetProperty("parameters", out var parameters))
        {
            return [];
        }

        return parameters
            .EnumerateArray()
            .Select(parameter => parameter.TryGetProperty("$ref", out var reference)
                ? ResolveParameter(reference.GetString()!).GetProperty("name").GetString()!
                : parameter.GetProperty("name").GetString()!)
            .ToArray();
    }

    private JsonElement ResolveParameter(string reference)
    {
        var name = reference.Split('/')[^1];
        return _document.GetProperty("components").GetProperty("parameters").GetProperty(name);
    }

    private JsonElement GetOperation(string path, string method)
    {
        var paths = _document.GetProperty("paths");

        Assert.That(
            paths.TryGetProperty(path, out var pathItem),
            Is.True,
            $"The document must describe '{path}'. Actual paths: "
                + string.Join(", ", paths.EnumerateObject().Select(item => item.Name)));

        Assert.That(
            pathItem.TryGetProperty(method, out var operation),
            Is.True,
            $"'{path}' must describe the '{method}' operation.");

        return operation;
    }
}
