using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using LaPrizza.Application.Abstractions;
using LaPrizza.Domain.Users;

namespace Api.Tests.Support;

/// <summary>
/// Authentication scheme used by the end-to-end tests. Login is not implemented
/// yet, so every test request is treated as an authenticated manager.
/// </summary>
internal sealed class TestAuthHandler(
    IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger,
    UrlEncoder encoder,
    IUserRepository userRepository)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "Test";

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (Request.Headers["X-Test-Anonymous"] == "true")
        {
            return AuthenticateResult.NoResult();
        }

        var email = Request.Headers["X-Test-Email"].FirstOrDefault() ?? "test-manager@laprizza.local";
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, "test-manager"),
            new(ClaimTypes.Name, "Test Manager"),
            new(ClaimTypes.Email, email),
        };

        if (Email.TryCreate(email, out var parsedEmail)
            && await userRepository.GetByEmailAsync(parsedEmail) is Staff { Active: true })
        {
            claims.Add(new Claim(ClaimTypes.Role, "Manager"));
        }

        var identity = new ClaimsIdentity(claims, SchemeName);

        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, SchemeName);

        return AuthenticateResult.Success(ticket);
    }
}
