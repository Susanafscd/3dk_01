using LaPrizza.Application.Abstractions;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Api.Tests.Support;

/// <summary>
/// Boots the real application but swaps the relational stores for in-memory
/// databases and the authentication/antiforgery plumbing for test doubles, so
/// the tests run without Postgres, a login or a CSRF token.
/// </summary>
internal sealed class ApiTestFactory(Action<IServiceCollection>? configureServices = null) : WebApplicationFactory<Program>
{
    private readonly string _identityDatabase = $"identity-{Guid.NewGuid():N}";
    private readonly string _domainDatabase = $"domain-{Guid.NewGuid():N}";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        // Test failures must not depend on Windows EventLog write permissions.
        builder.ConfigureLogging(logging => logging.ClearProviders());
        builder.ConfigureTestServices(services =>
        {
            ReplaceDbContext<AppDbContext>(services, _identityDatabase);
            ReplaceDbContext<DomainDbContext>(services, _domainDatabase);

            services
                .AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = TestAuthHandler.SchemeName;
                    options.DefaultChallengeScheme = TestAuthHandler.SchemeName;
                    options.DefaultScheme = TestAuthHandler.SchemeName;
                })
                .AddScheme<AuthenticationSchemeOptions, TestAuthHandler>(TestAuthHandler.SchemeName, _ => { });

            services.AddSingleton<IAntiforgery, NoOpAntiforgery>();
            services.AddSingleton<ICatalogueCacheInvalidator, RecordingCatalogueCacheInvalidator>();
            configureServices?.Invoke(services);
        });
    }

    private static void ReplaceDbContext<TContext>(IServiceCollection services, string databaseName)
        where TContext : DbContext
    {
        var toRemove = services
            .Where(descriptor =>
                descriptor.ServiceType == typeof(DbContextOptions<TContext>)
                || descriptor.ServiceType == typeof(DbContextOptions)
                || IsOptionsConfigurationFor<TContext>(descriptor.ServiceType))
            .ToList();

        foreach (var descriptor in toRemove)
        {
            services.Remove(descriptor);
        }

        services.AddDbContext<TContext>(options => options.UseInMemoryDatabase(databaseName));
    }

    private static bool IsOptionsConfigurationFor<TContext>(Type serviceType)
    {
        if (!serviceType.IsGenericType)
        {
            return false;
        }

        var fullName = serviceType.GetGenericTypeDefinition().FullName;
        return fullName?.StartsWith(
                "Microsoft.EntityFrameworkCore.Infrastructure.IDbContextOptionsConfiguration",
                StringComparison.Ordinal) == true
            && serviceType.GetGenericArguments()[0] == typeof(TContext);
    }
}
