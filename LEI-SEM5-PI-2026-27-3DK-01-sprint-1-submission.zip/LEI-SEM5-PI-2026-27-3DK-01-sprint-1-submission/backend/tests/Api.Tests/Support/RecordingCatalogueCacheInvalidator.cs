using LaPrizza.Application.Abstractions;

namespace Api.Tests.Support;

internal sealed class RecordingCatalogueCacheInvalidator : ICatalogueCacheInvalidator
{
    public int Invalidations { get; private set; }
    public Func<Task>? BeforeInvalidation { get; set; }

    public async Task InvalidateAllergensAsync(CancellationToken cancellationToken = default)
    {
        if (BeforeInvalidation is not null)
        {
            await BeforeInvalidation();
        }
        Invalidations++;
    }

    public Task InvalidateProductCategoriesAsync(CancellationToken cancellationToken = default)
    {
        Invalidations++;
        return Task.CompletedTask;
    }

    public async Task InvalidateProductsAsync(CancellationToken cancellationToken = default)
    {
        if (BeforeInvalidation is not null)
        {
            await BeforeInvalidation();
        }
        Invalidations++;
    }
}
