namespace Api.Tests.Support;

/// <summary>
/// Locates files that live in the repository rather than in the test output,
/// such as the committed OpenAPI specification under <c>docs/api</c>. Tests run
/// from <c>bin/&lt;Configuration&gt;/&lt;TargetFramework&gt;/</c>, so the repository
/// root is found by walking upwards until the solution is seen.
/// </summary>
internal static class RepositoryPaths
{
    /// <summary>Absolute path of the committed document at <c>docs/api/openapi.json</c>.</summary>
    public static string OpenApiSpecification { get; } = Path.Combine(
        FindRepositoryRoot(),
        "docs",
        "api",
        "openapi.json");

    private static string FindRepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);

        while (directory is not null)
        {
            if (File.Exists(Path.Combine(directory.FullName, "backend", "Api.sln")))
            {
                return directory.FullName;
            }

            directory = directory.Parent;
        }

        throw new InvalidOperationException(
            "Could not locate the repository root (the folder containing backend/Api.sln) "
                + $"starting from '{AppContext.BaseDirectory}'.");
    }
}
