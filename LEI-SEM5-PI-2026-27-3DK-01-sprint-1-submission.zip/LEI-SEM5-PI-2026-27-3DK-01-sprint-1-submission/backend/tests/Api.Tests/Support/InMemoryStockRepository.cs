using LaPrizza.Domain.Product;
using LaPrizza.Domain.Products;
using LaPrizza.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Api.Tests.Support;

/// <summary>
/// Stand-in for the PostgreSQL stock store in the API tests, which run on an
/// in-memory database that cannot execute the real <c>UPDATE … RETURNING</c>. It
/// applies the same conditions; the real statement is verified on PostgreSQL in
/// <c>ProductStockPostgresPersistenceTests</c>.
/// </summary>
internal sealed class InMemoryStockRepository(DomainDbContext db) : IStockRepository
{
    public Task<int?> IncreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default) =>
        ChangeAsync(productId, balance => balance <= Product.MaximumStockBalance - units, units, cancellationToken);

    public Task<int?> DecreaseAsync(Guid productId, int units, CancellationToken cancellationToken = default) =>
        ChangeAsync(productId, balance => balance >= units, -units, cancellationToken);

    private async Task<int?> ChangeAsync(
        Guid productId, Func<int, bool> allowed, int delta, CancellationToken cancellationToken)
    {
        // Like the SQL statement, work from the stored row, not from an aggregate the
        // use case may already have changed in memory within the same request.
        var stored = await db.Products.AsNoTracking()
            .Where(p => p.Id == productId)
            .Select(p => new { p.StockControlled, p.StockBalance })
            .SingleOrDefaultAsync(cancellationToken);
        if (stored is null
            || !stored.StockControlled
            || stored.StockBalance is not { } balance
            || !allowed(balance))
        {
            return null;
        }

        var product = await db.Products.SingleAsync(p => p.Id == productId, cancellationToken);
        db.Entry(product).Property(p => p.StockBalance).CurrentValue = balance + delta;
        await db.SaveChangesAsync(cancellationToken);
        return balance + delta;
    }
}
