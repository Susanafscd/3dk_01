using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Http;

namespace Api.Tests.Support;

/// <summary>
/// Lets unsafe requests through in tests. The browser would carry a real token;
/// the tests exercise the endpoint, not antiforgery itself.
/// </summary>
internal sealed class NoOpAntiforgery : IAntiforgery
{
    public AntiforgeryTokenSet GetAndStoreTokens(HttpContext httpContext) => GetTokens(httpContext);

    public AntiforgeryTokenSet GetTokens(HttpContext httpContext) =>
        new("test-request-token", "test-cookie-token", "test-form-field", "X-CSRF-Token");

    public Task<bool> IsRequestValidAsync(HttpContext httpContext) => Task.FromResult(true);

    public Task ValidateRequestAsync(HttpContext httpContext) => Task.CompletedTask;

    public void SetCookieTokenAndHeader(HttpContext httpContext)
    {
        // Tests do not need a cookie: the request is validated by the stub above.
    }
}
