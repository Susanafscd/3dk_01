using System.Net;
using System.Net.Http.Json;
using Api.Tests.Support;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Api.Tests;

/// <summary>
/// Boots the real application in memory and calls the one endpoint that exists.
/// This is the test to copy when the team starts testing its own endpoints.
/// </summary>
[TestFixture]
public sealed class HealthEndpointTests
{
    private WebApplicationFactory<Program> _factory = null!;
    private HttpClient _client = null!;

    [OneTimeSetUp]
    public void StartServer()
    {
        _factory = new ApiTestFactory();
        _client = _factory.CreateClient();
    }

    [OneTimeTearDown]
    public void StopServer()
    {
        _client.Dispose();
        _factory.Dispose();
    }

    [Test]
    public async Task Health_reports_that_the_service_is_running()
    {
        using var response = await _client.GetAsync("/api/v1/health");
        var payload = await response.Content.ReadFromJsonAsync<HealthPayload>();

        Assert.Multiple(() =>
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(payload, Is.Not.Null);
            Assert.That(payload!.Status, Is.EqualTo("ok"));
            Assert.That(payload.Version, Is.Not.Empty);
            Assert.That(payload.Timestamp.Kind, Is.EqualTo(DateTimeKind.Utc));
        });
    }

    private sealed record HealthPayload(string Status, string Version, DateTime Timestamp);
}
