# LaPrizza — Core Domain Model (Sprint 1)

**Artefact:** ARC01 — Core Domain Analysis and Modelling
**Diagram:** [`DM.puml`](DM.puml) (PlantUML) — see also the rendered diagrams in this folder · rendered `.svg` / `.png`
**C# realization:** [`CD.puml`](CD.puml) — domain class diagram (entities, namespaces, behaviour)
**Sources:** PART II – System Specification (v1.0) · PART III – Sprint 1 User Stories (v1.0)

The domain model is **conceptual**: it describes business concepts, attributes, relationships
and business rules. It deliberately excludes persistence, transport, presentation and
infrastructure concerns, which are addressed by the architecture documents (ARC02–ARC05).

The analysis covers the whole core domain, as required by ARC01, and not only the concepts
implemented in Sprint 1. Concepts outside the Sprint 1 scope are drawn in **yellow** and the
ones inside the Sprint 1 scope in **green** (legend in the diagram).

---

## 1. Traceability: User Stories → domain concepts

| US | Requirement | Concepts in the model |
|---|---|---|
| BCK01 | User and authentication management | `User` (`Customer`, `Staff`), `Role`, `Permission` |
| BCK02 | Customer management | `Customer` (`Address`, `DietaryRestriction` modelled for later) |
| BCK03 | Product category management | `ProductCategory`, `Product` |
| BCK04 | Allergen management | `Allergen`, `Product` |
| BCK05 | Product management | `Product`, `ProductCategory`, `Allergen`, `PizzaComponentType`, `Money` |
| BCK06 | Pizza size management | `PizzaSize` |
| BCK07 | Pizza component type management | `PizzaComponentType` |
| BCK08 | Pizza component configuration | `ComponentSizeConfiguration`, `Product`, `PizzaSize`, `Money` |
| BCK09 | Stock information management | `StockInformation`, `Product` |
| BCK10 | Predefined pizza management | `PredefinedPizza`, `PizzaConfiguration`, `ConfiguredComponent`, `PizzaSize` |
| BCK11 | Product catalogue and product information | `Product`, `PredefinedPizza`, `PizzaConfiguration`, `Allergen`, `PizzaSize` |
| ARC01 | Core domain analysis and modelling | the above **plus** `Order`, `OrderItem`, `PreparationActivity`, `PreparationActivityTemplate`, `KitchenResource`, `FoodPreparationSchedule`, `Consent`, `Address` |

¹ `Address`, `DietaryRestriction` and `Consent` are required by PART II but not by the Sprint 1 acceptance
criteria, so they are modelled (for future sprints) but not implemented now.

---

## 2. Concept catalogue

### 2.1 Identity and access

| Concept | Description | Main attributes | Relationships |
|---|---|---|---|
| `User` | Identified system user that authenticates before accessing protected operations. Customers register themselves; restaurant staff operate the business. | `email`, `displayName`, `active` | specialises `Customer`, `Staff`; assigned `Role`s |
| `Customer` | Person served by LaPrizza. | `name`, `phoneNumber` | has `Address`es and `DietaryRestriction`s, gives `Consent`, places `Order`s |
| `Staff` | Restaurant employee operating or managing the business. | `jobTitle` | holds `Role`s |
| `Role` | Set of responsibilities defining the operations a user may perform (e.g. manager, staff, customer). | `name`, `description` | many-to-many with `User` and `Permission` |
| `Permission` | Operation a role is allowed to perform (e.g. `product:manage`). | `name` | granted by `Role`s |

### 2.2 Customers

| Concept | Description | Main attributes | Relationships |
|---|---|---|---|
| `DietaryRestriction` | Food intolerance or dietary restriction declared by a customer, relevant to food safety. | `name`, `description` | declared by `Customer`¹; may relate to `Allergen`¹ |
| `Address` | Customer identification/contact and delivery location. | `street`, `streetNumber`, `postalCode`, `city`, `country` | belongs to `Customer`¹ |
| `Consent` | Explicit consent of the customer for marketing or other optional uses of personal data (GDPR). | `purpose`, `granted`, `grantedAt`, `withdrawnAt` | given by `Customer`¹ |

### 2.3 Catalogue

| Concept | Description | Main attributes | Relationships |
|---|---|---|---|
| `Product` | Any item managed by the restaurant. Being a product does not imply it is sold. A product combines any applicable **roles**: sellable, stock-controlled, pizza component. | `code`, `name`, `description`, `sellable`, `stockControlled`, `active`, `price` | stores `categoryCode`, optional `componentTypeCode` and zero or more allergen codes; maintains `StockInformation` and `ComponentSizeConfiguration`s; may define a `PreparationActivityTemplate`¹ |
| `ProductCategory` | Catalogue classification of products. | `code`, `name`, `description`, `allowsComponentTypes` | referenced by products and pizza component types through `categoryCode` |
| `Allergen` | Allergen recognised by the restaurant; basis for food-safety information. | `code`, `name`, `description` | referenced by product allergen-code associations and dietary restrictions¹ |
| `StockInformation` | Quantity currently available for a stock-controlled product, in **abstract stock units**. | `quantityInStock` | maintained by `Product` |
| `PizzaSize` | Commercial size of a pizza; influences component prices, stock consumption and availability. | `name`, `description` | has `ComponentSizeConfiguration`s; `PredefinedPizza` availability |

### 2.4 Pizza configuration

| Concept | Description | Main attributes | Relationships |
|---|---|---|---|
| `PizzaComponentType` | Configurable classification of the role a component plays in a pizza (Base Dough, Base Sauce, Cheese, Topping, …). Defines assembly order and cardinality. | `code`, `categoryCode`, `name`, `description`, `assemblyOrder`, `minQuantity`, `maxQuantity`, `active` | classifies pizza-component products through `componentTypeCode`; role of `ConfiguredComponent`s |
| `ComponentSizeConfiguration` | Size-dependent information applicable when a component is used in a pizza of a given size. | `price`, `stockUnitsConsumed` | configures a `Product` (pizza component) for one `PizzaSize` |
| `PredefinedPizza` | Sellable product that defines a **default pizza configuration** offered by LaPrizza (e.g. Margherita). | — | is a `Product`; defines a default `PizzaConfiguration`; available in `PizzaSize`s |
| `PizzaConfiguration` | Composition of pizza components. In Sprint 1 it represents the **default configuration** of a `PredefinedPizza`; in later sprints it also represents a customer **personalized** configuration that keeps a reference to the predefined pizza it originates from. | — | composed of `ConfiguredComponent`s; optional `PizzaSize`¹; optional originating `PredefinedPizza`¹ |
| `ConfiguredComponent` | A pizza component participating in a configuration in the role defined by its `PizzaComponentType`. | — | refers to a `Product` (pizza component) and to a `PizzaComponentType` |
| `Money` | Value object for monetary amounts. | `amount`, `currency` | attribute type of prices |

### 2.5 Orders and food preparation (modelled, not implemented in Sprint 1)

| Concept | Description | Main attributes | Relationships |
|---|---|---|---|
| `Order` | Customer request composed of order items, progressing through the operational process. | `orderNumber`, `orderDate`, `status`, `totalPrice` | placed by `Customer`; contains `OrderItem`s |
| `OrderItem` | Requested item: either a sellable product or a preserved pizza configuration. | `quantity`, `unitPrice`, `subtotal`, `status` | refers to `Product`¹ or preserves `PizzaConfiguration`¹; generates `PreparationActivity`s¹ |
| `PreparationActivityTemplate` | Operational information of a product requiring preparation: duration, required resource type and dependencies. | `name`, `estimatedDuration`, `requiredResourceType` | belongs to a `Product`¹; depends on other templates¹ |
| `PreparationActivity` | Preparation work generated for an order item, sequenced and allocated by the schedule. | `sequence`, `startTime`, `endTime`, `status` | instance of a `PreparationActivityTemplate`¹; assigned to a `KitchenResource`¹; scheduled in a `FoodPreparationSchedule`¹ |
| `KitchenResource` | Individual resource or group of equivalent resources (e.g. ovens, preparation stations). | `name`, `quantity`, `capacity`, `available` | of a `KitchenResourceType`¹ |
| `FoodPreparationSchedule` | Result of the scheduling process: sequence, timing and resource allocation of pending activities. | `generatedAt`, `version` | schedules `PreparationActivity`s¹ |

¹ Modelled in the domain model but **outside the Sprint 1 implementation scope** (yellow in the diagram).

---

## 3. Business rules and constraints

**Identity**

- **BR-01** Every user has a unique identity and must be authenticated before accessing protected
  operations (BCK01). Roles determine the operations each user is authorised to perform.

**Catalogue**

- **BR-02** A product is classified by exactly one `ProductCategory`; a category classifies any number
  of products (BCK03).
- **BR-03** A product may be associated with one or more `Allergen`s; an allergen may be associated
  with any number of products (BCK04, BCK05).
- **BR-04** The product roles are independent and combinable: *sellable*, *stock-controlled* and
  *pizza component* (BCK05).
- **BR-05** A product designated as a pizza component is associated with **exactly one**
  `PizzaComponentType`; a product that is not a component has none (BCK05).
- **BR-06** A sellable product provides the commercial information required to be offered for sale
  (BCK05).
- **BR-07** Products that should no longer be actively used are marked **inactive** rather than
  deleted, preserving historically relevant information and existing relationships (BCK05).
- **BR-07a** Product categories and allergens cannot be removed while referenced by persisted
  business information. Category checks include active and inactive products and component types;
  allergen checks include active and inactive products and customer dietary restrictions (BCK03, BCK04).
- **BR-08** `StockInformation` exists **only** for stock-controlled products; `quantityInStock` is a
  non-negative integer number of abstract stock units, and no operation may make it negative
  (BCK09).
- **BR-09** Pizza sizes and pizza component types are business data maintained by the restaurant;
  their set may evolve without invalidating existing information (BCK06, BCK07).

**Pizza configuration**

- **BR-10** Each `PizzaComponentType` defines a unique `assemblyOrder` (no two types share it) and
  the minimum and maximum number of components of that type that may participate in a configuration;
  the maximum may be unbounded (BCK07).
- **BR-11** Only products designated as pizza components may have `ComponentSizeConfiguration`s, and
  at most one configuration exists per *(component, size)* pair. `price` is mandatory;
  `stockUnitsConsumed` is represented when the component is stock-controlled (BCK08).
- **BR-12** The default configuration of a `PredefinedPizza` may only contain active products
  currently designated as pizza components, may not repeat the same component, and must satisfy the
  minimum and maximum cardinality of each `PizzaComponentType` (BCK10).
- **BR-13** A `PredefinedPizza` is only available in pizza sizes for which **all** components of its
  default configuration have a `ComponentSizeConfiguration` (BCK10).

**Catalogue consultation**

- **BR-14** The catalogue exposes the active sellable products with their category, pricing and
  allergen information; for a predefined pizza it also exposes its default configuration and the
  pizza sizes in which it is available (BCK11).

**Orders and preparation (future sprints)**

- **BR-15** An order item refers **either** to a sellable product **or** preserves a pizza
  configuration (mutually exclusive).
- **BR-16** A preserved pizza configuration determines the item's price, allergens, stock consumption
  and preparation requirements independently of later catalogue changes.
- **BR-17** The overall `Order` status is derived from the status of its `OrderItem`s (awaiting
  preparation, in preparation, ready, served).
- **BR-18** The activities required by an order item are determined by the preparation information of
  the ordered product; their sequencing constraints come from the activity dependencies and their
  allocation from the available `KitchenResource`s.

---

## 4. Modelling decisions and assumptions

Decisions that are not evident from the diagram itself:

- **MD-01 — A pizza component is not a distinct product type.** PART II states that the designation
  adds pizza-specific classification to an existing product. The model therefore keeps a single
  `Product` concept with role attributes and an optional association to exactly one
  `PizzaComponentType`, instead of a `PizzaComponent` subclass.
- **MD-02 — Pizza component types are data, not classes.** PART II requires the set of component
  types to evolve without changing the fundamental product model. `Base Dough`, `Base Sauce`,
  `Cheese` and `Topping` are therefore *instances* (seed data) of `PizzaComponentType`, and the
  configuration rules are expressed as attributes (`assemblyOrder`, `minQuantity`, `maxQuantity`)
  rather than as hardcoded subclasses.
- **MD-03 — `PredefinedPizza` is modelled as a specialisation of `Product`.** PART II defines a
  predefined pizza as *a sellable product that defines a default pizza configuration*; the
  specialisation expresses exactly that, without introducing a separate catalogue product kind.
- **MD-04 — The default configuration is size-independent.** BCK10 defines the default configuration
  as a composition of components, and the set of sizes in which the pizza is available is a separate
  business fact (BR-13). `PizzaConfiguration` therefore has an *optional* size: it is absent for
  default configurations and present for personalized ones (PART II).
- **MD-05 — `ConfiguredComponent` makes the *(component, role)* pair explicit.** A configuration
  associates a product with the component type it plays in the pizza, which is what allows the
  cardinality rules of BR-10/BR-12 to be enforced per component type.
- **MD-06 — Authentication credentials are not domain concepts.** BCK01 requires secure handling of
  credentials; this is an authentication/infrastructure concern and is excluded from the domain model
  in accordance with ARC01. The domain model keeps identity, roles and permissions only.
- **MD-07 — Technical identifiers are a persistence concern.** Concepts are identified in the domain
  by business codes and descriptive names (`Product.code`, `Allergen.code`, `Order.orderNumber`).
  Surrogate keys and uniqueness enforcement belong to the persistence model (ARC04).
- **MD-07a — Aggregate references use business codes.** `ProductCategory`, `Allergen`, `Product` and
  `PizzaComponentType` remain separate aggregates. Their relationships are represented by codes
  (`categoryCode`, `componentTypeCode` and allergen codes), never by direct object references or
  technical database IDs. The database may enforce these references, but that is an infrastructure
  concern and does not change the domain model.
- **MD-08 — Preparation template vs. activity instance.** PART II states that the activities of an
  order item are *determined from* the operational information of the product (duration, required
  resource type, dependencies). The definition (`PreparationActivityTemplate`, attached to the
  product) and its scheduled instances (`PreparationActivity`, generated per order item) are
  therefore modelled as separate concepts.
- **MD-09 — Scope is explicit, not implicit.** Following ARC01 and the Sprint 1 deliverable, concepts
  outside the Sprint 1 back-end scope are modelled but colour-marked as later-sprint work, so that the
  documented model is a superset of the implemented model.
- **MD-10 — Search, filtering and pagination are not modelled.** BCK02–BCK09 require products,
  customers, categories, allergens, sizes, component types and stock to be *searchable*. Searching is
  a query concern and not a business concept, so it does not appear in the domain model; it will be
  addressed in the API design (ARC03).
- **MD-11 — Consent is modelled explicitly.** PART II and II.3.6 require marketing preferences and
  consent for optional uses of personal data to be managed explicitly (GDPR), which justifies
  `Consent` as a customer-related concept rather than a boolean attribute.

---

## 5. Open points (to be resolved by later Sprint Backlogs)

- **OP-01** Price rules for predefined and personalized pizzas — the relationship between the price of
  the predefined pizza and the prices of added, removed or replaced components is explicitly deferred
  by PART II to the corresponding User Stories.
- **OP-02** Whether a pizza's commercial price varies per size: PART II states that it may, while the
  Sprint 1 stories only require the *availability* of sizes (BR-13).
- **OP-03** The business event that records the stock reduction (order confirmation, preparation
  start, or item completion) — PART II defers it to the applicable User Stories.
- **OP-04** Derived availability: a sellable product may be unavailable because of its own stock or the
  stock of the products required for its preparation.
- **OP-05** Replenishment information (e.g. minimum stock levels) used to identify products that
  require replenishment.
- **OP-06** Initial roles and permissions to seed (e.g. manager, staff, customer), to be aligned with
  the authorization requirements of the following sprints.
