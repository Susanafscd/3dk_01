# Sprint Planning 2: Product and Pizza Catalogue

**Prepared:** 2 October 2026  
**Document status:** Sprint planning record for team review.

## Planning goal

Develop the restaurant's product-management and pizza-configuration capabilities and the customer-facing catalogue, covering categories, allergens, products, sizes, component types and configuration, stock, predefined pizzas, and product information.

The issues listed below belong to the existing active Sprint 1. This document groups them by functional scope for planning purposes and does not imply that a separate Jira sprint has been created.

## Work in progress

| Jira Issue | Assignee |
|---|---|
| [SCRUM-6 — BCK03: Product Category Management](https://lapr5-board.atlassian.net/browse/SCRUM-6) | Rafael Vieira |
| [SCRUM-7 — BCK04: Allergen Management](https://lapr5-board.atlassian.net/browse/SCRUM-7) | Rafael Vieira |
| [SCRUM-8 — BCK05: Product Management](https://lapr5-board.atlassian.net/browse/SCRUM-8) | Rafael Vieira |
| [SCRUM-12 — BCK09: Stock Information Management](https://lapr5-board.atlassian.net/browse/SCRUM-12) | João Miguel Carneiro Ferreira |
| [SCRUM-13 — BCK10: Predefined Pizza Management](https://lapr5-board.atlassian.net/browse/SCRUM-13) | João Miguel Carneiro Ferreira |

## Pending work

The following issues are currently in **Dependency** status and should be addressed according to their actual prerequisites.

| Jira Issue | Assignee |
|---|---|
| [SCRUM-9 — BCK06: Pizza Size Management](https://lapr5-board.atlassian.net/browse/SCRUM-9) | Guilherme Gomes Machado |
| [SCRUM-10 — BCK07: Pizza Component Type Management](https://lapr5-board.atlassian.net/browse/SCRUM-10) | Guilherme Gomes Machado |
| [SCRUM-11 — BCK08: Pizza Component Configuration](https://lapr5-board.atlassian.net/browse/SCRUM-11) | Tiago Silva Lima |
| [SCRUM-14 — BCK11: Product Catalogue and Product Information](https://lapr5-board.atlassian.net/browse/SCRUM-14) | Tiago Silva Lima |

The retrieved Jira issue-link fields do not establish explicit blocker relationships. The team should confirm the prerequisites before determining the implementation sequence.

## Planning priorities

1. **Product management:** Coordinate the completion of category, allergen, and product management (SCRUM-6, SCRUM-7, and SCRUM-8) with Rafael Vieira.
2. **Resolve dependencies:** Confirm the prerequisites for pizza sizes, component types, component configuration, and the product catalogue (SCRUM-9, SCRUM-10, SCRUM-11, and SCRUM-14) with the respective assignees.
3. **Pizza configuration:** Ensure consistency between pizza sizes, component types, and size-dependent component characteristics.
4. **Stock and predefined pizzas:** Coordinate the implementation and validation of SCRUM-12 and SCRUM-13 with João Miguel Carneiro Ferreira.
5. **Catalogue integration:** Validate product information, pricing, and available options once the required functionality is available.
6. **Integration and testing:** Coordinate REST API integration and regression testing with SCRUM-17 and SCRUM-19, covered in Sprint Planning 1.

These priorities are proposed planning guidance. Due dates and any changes to assignments must be agreed upon by the team.

## Acceptance criteria

The following checks are proposed for validating the work:

- Verify that implemented functionality meets the requirements described in each Jira issue.
- Validate consistency between products, categories, allergens, pizza sizes, and component configuration.
- Verify stock-management and predefined-pizza behaviour.
- Confirm that the catalogue presents the agreed product information, prices, and available options.
- Record relevant code-review and passing-test evidence before marking issues as Done.

## Outstanding governance item

[SCRUM-3 — ENG03: Self and Peer Evaluation](https://lapr5-board.atlassian.net/browse/SCRUM-3) remains **To Do**, with no assignee recorded in the retrieved snapshot. The team should agree on its ownership and timing.

## Sources and related planning record

- [SCRUM board 1](https://lapr5-board.atlassian.net/jira/software/projects/SCRUM/boards/1/backlog): issue population and sprint placement.
- Linked Jira issues: issue descriptions, statuses, assignees, and available issue-link information, retrieved on 2 October 2026.
- Related document: **LaPrizza — Sprint Planning 1: Foundations and Core Services**.

No code repository, deployment record, or test-run evidence was inspected. The statuses and assignments reflect the retrieved Jira snapshot.