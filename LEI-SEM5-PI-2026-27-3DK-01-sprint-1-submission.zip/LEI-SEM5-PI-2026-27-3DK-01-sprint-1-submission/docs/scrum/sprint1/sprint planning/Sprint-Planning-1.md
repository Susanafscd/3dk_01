# Sprint Planning 1: Foundations and Core Services

**Prepared:** 1 October 2026

## Scope and current status
| Jira Issue | Assignee |
|---|---|
| [SCRUM-1 — ENG01: Project Repository and Development Environment](https://lapr5-board.atlassian.net/browse/SCRUM-1) | Team |
| [SCRUM-2 — ENG02: Sprint Planning and Project Monitoring](https://lapr5-board.atlassian.net/browse/SCRUM-2) | Team |
| [SCRUM-16 — ARC02: System Architecture](https://lapr5-board.atlassian.net/browse/SCRUM-16) | Team |
| [SCRUM-18 — ARC04: Persistence and Data Integrity](https://lapr5-board.atlassian.net/browse/SCRUM-18) | Team |
| [SCRUM-4 — BCK01: User and Authentication Management](https://lapr5-board.atlassian.net/browse/SCRUM-4) | Rodrigo Junqueira Mendes |
| [SCRUM-15 — ARC01: Core Domain Analysis and Modelling](https://lapr5-board.atlassian.net/browse/SCRUM-15) | Team |
| [SCRUM-17 — ARC03: REST API](https://lapr5-board.atlassian.net/browse/SCRUM-17) | Rafael Vieira |
| [SCRUM-5 — BCK02: Customer Management](https://lapr5-board.atlassian.net/browse/SCRUM-5) | Rodrigo Junqueira Mendes |
| [SCRUM-19 — ARC05: Automated Testing](https://lapr5-board.atlassian.net/browse/SCRUM-19) | Team |
