# Sprint 1 Daily Meetings

## Daily — 02/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Reviewed the system specifications and Sprint 1 user stories.
- What am I going to do: Identify the main domain entities and their relationships.
- Encountered obstacles: None.

### Tiago Lima
- What did I do: Reviewed the sprint requirements and project management needs.
- What am I going to do: Organize the tasks on the project board.
- Encountered obstacles: Some user stories need to be split into smaller tasks.

### Rafael Vieira
- What did I do: Investigated backend technologies and REST API requirements.
- What am I going to do: Evaluate backend frameworks and databases.
- Encountered obstacles: None.

### Guilherme Machado
- What did I do: Reviewed frontend requirements and API communication.
- What am I going to do: Evaluate frontend technologies and styling options.
- Encountered obstacles: User role separation needs further discussion.

### João Ferreira
- What did I do: Reviewed system requirements and identified the main actors.
- What am I going to do: Evaluate the use of a non-relational database.
- Encountered obstacles: Database responsibilities need clarification.

### Impediments
- Some requirements need further analysis.
- The technology stack is not yet finalized.

---

## Daily — 05/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Identified domain entities and started the C4 System Context diagram.
- What am I going to do: Improve comprehension of the domain model and system interactions.
- Encountered obstacles: None.

### Tiago Lima
- What did I do: Started defining domain entities and their relationships.
- What am I going to do: Update the project board and task priorities.
- Encountered obstacles: Some architecture decisions are still pending.

### Rafael Vieira
- What did I do: Organized sprint tasks and dependencies.
- What am I going to do: Define the backend stack and authentication approach.
- Encountered obstacles: None.

### Guilherme Machado
- What did I do: Evaluated Angular
- What am I going to do: Define the frontend stack and API integration.
- Encountered obstacles: User role separation needs clarification.

### João Ferreira
- What did I do: Reviewed the system actors and database requirements.
- What am I going to do: Refine the System Context diagram.
- Encountered obstacles: PostgreSQL and MongoDB responsibilities need clarification.

### Impediments
- Backend and frontend technology choices need agreement.
- Database responsibilities need to be defined.

---

## Daily — 07/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Reviewed the domain model and REST API requirements.
- What am I going to do: Refine the domain model and identify API operations.
- Encountered obstacles: Domain and API boundaries need clarification.

### Tiago Lima
- What did I do: Reviewed sprint tasks and dependencies.
- What am I going to do: Track task progress on the project board.
- Encountered obstacles: Some architecture decisions are still pending.

### Rafael Vieira
- What did I do: Investigated Redis caching.
- What am I going to do: Compare caching strategies and invalidation methods.
- Encountered obstacles: Cache consistency needs to be addressed.

### Guilherme Machado
- What did I do: Investigated frontend architecture and lazy loading.
- What am I going to do: Define how to load features efficiently.
- Encountered obstacles: None.

### João Ferreira
- What did I do: Reviewed the C4 architecture and infrastructure components.
- What am I going to do: Develop the C4 Container diagram.
- Encountered obstacles: Redis and Object Storage responsibilities need clarification.

### Impediments
- The caching strategy is not finalized.
- The architecture and component interactions need clarification.

---

## Daily — 09/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Developed the C4 Container diagram and reviewed component interactions.
- What am I going to do: Develop the C4 Component diagram and reviewed component interactions.
- Encountered obstacles: Responsibilities between layers need clarification.

### Tiago Lima
- What did I do: Reviewed sprint progress and outstanding tasks.
- What am I going to do: Update the project board and track pending decisions.
- Encountered obstacles: Some architecture decisions are still pending.

### Rafael Vieira
- What did I do: Compared Redis caching approaches and database integration.
- What am I going to do: Define the caching and invalidation strategy.
- Encountered obstacles: Keeping the cache consistent with the database requires care.

### Guilherme Machado
- What did I do: Reviewed frontend API integration and asset handling.
- What am I going to do: Define how the frontend accesses stored assets.
- Encountered obstacles: Object Storage access needs clarification.

### João Ferreira
- What did I do: Reviewed the domain model and persistence layer.
- What am I going to do: 
- Encountered obstacles: None

### Impediments
- Cache consistency needs further analysis.
- Object Storage integration needs to be defined.
- Some architecture decisions remain open.


## Daily — 14/10/2026 11:22 - 11:20

### Rodrigo Mendes
- What did I do: Improved Logical View L3 and started implementing it in the project and folder structure
- What am I going to do: Make the project persist data following clean architecture
- Encountered obstacles: Difficulties setting up persistence

### Tiago Lima
- What did I do: Improved Domain Model and documented it on a ADR
- What am I going to do: Document indivual USs
- Encountered obstacles: None.

### Rafael Vieira
- What did I do: Define the caching and invalidation strategy.
- What am I going to do: Document indivual USs
- Encountered obstacles: Missing openAPI contract clarifications.

### Guilherme Machado
- What did I do: Reviewed frontend API integration and asset handling.
- What am I going to do: Define how the frontend accesses stored assets.
- Encountered obstacles: Object Storage access needs clarification.

### João Ferreira
- What did I do: Reviewed the domain model and persistence layer.
- What am I going to do: Document indivual USs
- Encountered obstacles: None.

### Impediments
- Missing openAPI contract clarifications.
- Difficulties setting up persistence


# Sprint 1 Daily Meetings

## Daily — 16/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Continued implementing the backend project structure and configuring data persistence according to Clean Architecture.
- What am I going to do: Continue integrating the domain and infrastructure layers and verify that domain entities can be persisted correctly.
- Encountered obstacles: Persistence configuration and integration between layers require further work.

### Tiago Lima
- What did I do: Continued documenting individual user stories and refining the requirements for the Sprint 1 use cases.
- What am I going to do: Refine the acceptance criteria and implementation tasks for the remaining user stories.
- Encountered obstacles: Some API contracts and dependencies need clarification.

### Rafael Vieira
- What did I do: Continued investigating Redis caching and the REST API implementation requirements.
- What am I going to do: Finalize the caching approach and continue implementing the backend use cases.
- Encountered obstacles: Cache invalidation and consistency with persistent data need to be addressed.

### Guilherme Machado
- What did I do: Continued reviewing frontend architecture and the integration between the frontend and backend.
- What am I going to do: Refine the frontend integration approach and determine how stored assets will be accessed.
- Encountered obstacles: Object Storage integration and access to stored assets need clarification.

### João Ferreira
- What did I do: Continued documenting individual user stories and reviewing the persistence requirements for the domain model.
- What am I going to do: Refine the stock and predefined pizza use cases and their persistence requirements.
- Encountered obstacles: Dependencies between domain entities and persistence need further analysis.

### Impediments
- Persistence integration requires further validation.
- API contracts and dependencies need clarification.
- Cache invalidation and Object Storage integration require further definition.

---

## Daily — 19/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Continued implementing the backend architecture and integrating the application with the persistence layer.
- What am I going to do: Verify the persistence configuration and continue implementing authentication-related functionality.
- Encountered obstacles: Integration between authentication, domain users and persistent data requires careful handling.

### Tiago Lima
- What did I do: Continued refining the user stories and organizing implementation work around the required use cases.
- What am I going to do: Review the remaining backlog items and clarify dependencies between API implementation and testing.
- Encountered obstacles: Some use cases depend on shared domain functionality and API contracts.

### Rafael Vieira
- What did I do: Continued implementing the backend functionality for product categories and allergens and reviewing the REST API requirements.
- What am I going to do: Continue implementing domain rules, persistence and API operations for the relevant use cases.
- Encountered obstacles: Domain constraints and API validation need to remain consistent.

### Guilherme Machado
- What did I do: Continued reviewing the pizza configuration requirements and the frontend's interaction with backend resources.
- What am I going to do: Refine the implementation requirements for pizza sizes and component types.
- Encountered obstacles: The relationships between pizza sizes, component types and size configurations require careful handling.

### João Ferreira
- What did I do: Continued reviewing the stock and predefined pizza requirements and their relationships with other domain entities.
- What am I going to do: Refine the implementation requirements for stock operations and predefined pizza management.
- Encountered obstacles: The use cases depend on consistent domain relationships and persistence rules.

### Impediments
- Some use cases depend on shared domain and persistence functionality.
- API validation and domain rules need to remain consistent.
- Pizza configuration and predefined pizza relationships require further clarification.

---

## Daily — 21/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Continued working on authentication and the backend architecture, including the integration of application services with infrastructure.
- What am I going to do: Verify authentication flows and continue implementing automated tests for the authentication endpoints.
- Encountered obstacles: Authentication behaviour must remain consistent with the API contract and domain-user persistence.

### Tiago Lima
- What did I do: Continued refining and organizing the implementation tasks for the remaining backend use cases.
- What am I going to do: Continue coordinating API implementation and testing tasks for the product catalogue and pizza configuration functionality.
- Encountered obstacles: Some tasks depend on API endpoints and underlying application functionality being available.

### Rafael Vieira
- What did I do: Worked on product category and allergen management requirements and continued implementing the associated domain functionality.
- What am I going to do: Continue implementing category and allergen operations, including persistence and API integration.
- Encountered obstacles: Business identifiers, uniqueness constraints and domain invariants need to be enforced consistently.

### Guilherme Machado
- What did I do: Continued reviewing the pizza size and component type use cases and their implementation requirements.
- What am I going to do: Continue preparing the implementation of pizza size and component type management.
- Encountered obstacles: Removal rules and references between existing configurations need to be considered.

### João Ferreira
- What did I do: Continued working on stock management and predefined pizza use cases.
- What am I going to do: Continue refining the implementation of stock operations and predefined pizza creation, retrieval and update.
- Encountered obstacles: These operations depend on consistent domain relationships and persistence behaviour.

### Impediments
- Authentication and domain-user persistence require integration testing.
- Product category and allergen management depend on domain constraints and persistence.
- Pizza configuration operations require clear removal and reference-handling rules.
- Some backend tasks remain dependent on shared functionality.

---

## Daily — 23/10/2026 13:50 - 13:56

### Rodrigo Mendes
- What did I do: Continued implementing authentication-related functionality and automated tests, while refining the architecture documentation to reflect the current implementation.
- What am I going to do: Continue validating the Clean Architecture boundaries, persistence integration and consistency between the documented architecture and the code.
- Encountered obstacles: Some persistence and architecture validation tasks remain unfinished.

### Tiago Lima
- What did I do: Continued working on the pizza component configuration use cases, including size configuration mappings, API endpoints and unit tests.
- What am I going to do: Complete the remaining API integration work and address outstanding end-to-end testing dependencies.
- Encountered obstacles: Some end-to-end tests depend on API endpoints and supporting functionality being available.

### Rafael Vieira
- What did I do: Continued implementing product category and allergen functionality and reviewing the REST API requirements.
- What am I going to do: Continue implementing the remaining domain and API operations and verify that the implementation follows the defined contracts.
- Encountered obstacles: Some API operations and validation tasks remain unfinished or dependent on other implementation work.

### Guilherme Machado
- What did I do: Continued reviewing the implementation requirements for pizza sizes and component types.
- What am I going to do: Progress the pizza size and component type use cases and verify that the implementation respects the domain constraints.
- Encountered obstacles: Some pizza configuration use cases remain to be implemented, including the handling of existing references.

### João Ferreira
- What did I do: Continued working on stock management and predefined pizza functionality, reviewing the requirements and dependencies for the corresponding use cases.
- What am I going to do: Continue implementing the stock and predefined pizza operations and address the remaining dependencies.
- Encountered obstacles: Several operations depend on shared domain functionality, persistence and API integration.

### Impediments
- Some persistence and architecture validation work remains outstanding.
- End-to-end testing depends on the availability of the relevant API endpoints.
- Several product management and pizza configuration operations remain unfinished.
- Shared domain functionality and persistence constraints continue to affect implementation dependencies.

---