# Sprint 1 — Sprint Goal

## Goal Statement

Establish the technical and organisational foundations of the LaPrizza information system: set up the development environment, model the core business domain, document the architecture, and implement the first back-end capabilities exposed through a consistent REST API.

The sprint is intentionally a **vertical foundation slice**, not a complete product. Its value is that later sprints can build on a running, tested and documented baseline instead of starting from scratch.

## Why this goal

LaPrizza is planned as a modular, web-based information system whose areas (Web Application, 3D Visualization, Artificial Intelligence, and Systems Administration/Infrastructure) integrate progressively. Before those areas can be integrated, the system needs:

- a shared understanding of the business domain and its language;
- a documented architecture that keeps domain rules separate from presentation, persistence and infrastructure;
- a working back-end skeleton with a stable API contract for future clients.

Sprint 1 delivers exactly that foundation.

## Scope

The sprint covers the first back-end increment, corresponding to user stories **BCK01–BCK11** of PART II (System Specification):

| ID | Capability |
| --- | --- |
| BCK01 | User and authentication management |
| BCK02 | Customer management |
| BCK03 | Product category management |
| BCK04 | Allergen management |
| BCK05 | Product management |
| BCK06 | Pizza size management |
| BCK07 | Pizza component type management |
| BCK08 | Pizza component size configuration |
| BCK09 | Stock management |
| BCK10 | Predefined pizza management |
| BCK11 | Product catalogue and product information |

Architecture and modelling artefacts are also in scope:

- Domain model (DM), DDD tactical model, and domain class diagram.
- Software Architecture Document (SAD) following the SEI template with the C4 view model.
- C4 Context (C1), Container (C2) and Component (C3) diagrams.
- Architecture Decision Records (ADRs) for the significant technical choices.
- Domain glossary.

## Deliverables

| Deliverable | Where |
| ----------- | ----- |
| Running full-stack skeleton (frontend + backend) | `frontend/`, `backend/` |
| Core domain model and DDD tactical model | `docs/DM.md`, `docs/DM.puml`, `docs/DomainModelDDD.puml` |
| Architecture documentation and C4 diagrams | `docs/architecture/` |
| Architecture Decision Records | `docs/architecture/ADR/` |
| REST API for the Sprint 1 user stories | `backend/src/Api` |
| Automated tests for implemented rules and endpoints | `backend/tests/Api.Tests`, `frontend` |
| Domain glossary | `docs/GLOSSARY.md` |
| Requirements analysis | `docs/requirements.md` |

## Definition of Done (Sprint 1)

A Sprint 1 item is considered done when:

- The domain model and business rules it depends on are documented.
- The behaviour is implemented in the back-end and exposed through the versioned REST API (`/api/v1`).
- The relevant business rules are covered by automated tests that run with `dotnet test` / `npm test`.
- The code follows the project conventions (`dotnet format --verify-no-changes`, `npm run lint`, `npm run format:check`).
- Documentation that the item affects has been updated (glossary, requirements, architecture).
- The change has been reviewed and merged into `main`.

## Out of Scope

The following are explicitly **not** part of Sprint 1 and belong to later sprints:

- Customer order processing and order lifecycle.
- Food preparation scheduling and kitchen resource allocation.
- AI-based schedule generation.
- 3D visualization of pizzas.
- Personalized pizza configuration at order time.
- Notifications and other external integrations.

The architecture must nevertheless anticipate these concerns so they can be integrated without reworking the foundations.

## Risks and Assumptions

- **Assumption:** the team shares one toolchain version (see `backend/README.md` and `frontend/README.md`); mismatches cause avoidable build errors.
- **Risk:** the two planned data stores (PostgreSQL and MongoDB) add cost. Their division of responsibility must be justified and documented.
- **Risk:** architecture and domain documentation can lag implementation. Keeping them in sync is part of the Definition of Done.
