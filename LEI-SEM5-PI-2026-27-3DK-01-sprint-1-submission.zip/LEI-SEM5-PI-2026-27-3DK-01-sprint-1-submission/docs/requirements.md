# Throughout this file, we'll analyse each and every user story in this project and, through analysis, reach a conclusion on what will be needed for each

## BCK01 User and Authentication Management
### As a LaPrizza Manager, I want the system to maintain users and roles and authenticate registered users, so that access to protected operations can be associated with an identified and authorized user.

### Acceptance Criteria and Comments:
- The system must support the registration and management of the users required to access protected system functionality;
- each user must have a unique identifier and appropriate authentication credentials;
- the system must support the roles required to distinguish the responsibilities and permitted operations of different users;
- registered users must be able to authenticate using their credentials;
- successful authentication must establish the identity of the user for subsequent protected operations;
- invalid authentication attempts must not provide access to protected functionality;
- authentication credentials must be handled and stored using appropriate security practices;
- the resulting authentication and role model must provide an appropriate foundation for the authorization requirements introduced throughout the project.

### Requirements:
- User registration and management: The system must support the registration and management of users who need access to protected functionality.
- Unique user identification: Each user must have a unique identifier.
- Authentication credentials: Each user must have appropriate authentication credentials.
- Role management: The system must support the roles required to distinguish different user responsibilities and permitted operations.
- User authentication: Registered users must be able to authenticate using their credentials.
- Authenticated user identity: Successful authentication must establish the user's identity for subsequent protected operations.
- Protection against invalid authentication: Invalid authentication attempts must not provide access to protected functionality.
- Security and authorization foundation: Authentication credentials must be handled and stored using appropriate security practices. The authentication and role model must provide an appropriate foundation for the authorization requirements introduced later in the project.
 
## BCK02 Customer Management
### As a LaPrizza Manager, I want to register and manage customers, so that the restaurant can maintain the information required to provide its services to them.

### Acceptance Criteria and Comments:
- The system must support the creation of customer records;
- the system must support the updating of customer records;
- each customer must have a unique identifier;
- customer information must include, at least, the customer’s name and appropriate contact information;
- data used to uniquely identify or contact customers must be appropriately validated;
- customers must be searchable using relevant identifying information;
- customer information that is referenced by other business information cannot be removed in a way that compromises the consistency of that information.

### Requirements:
- Customer registration: The system must support the creation of customer records.
- Customer management: The system must support the updating of existing customer records.
- Unique customer identification: Each customer must have a unique identifier.
- Customer information: Each customer must have, at minimum:
     - Name
     - Appropriate contact information
- Customer data validation: Information used to identify or contact customers must be appropriately validated. For example, contact information should follow the expected format.
- Customer search: Customers must be searchable using relevant identifying information.
- Data consistency / referential integrity: Customer information that is referenced by other business information must not be deleted in a way that breaks the consistency of that information. In practice, this could mean preventing deletion or using an appropriate approach such as deactivation/soft deletion.

## BCK03 Product Category Management
### As a LaPrizza Manager, I want to maintain product categories, so that the products managed by the restaurant can be appropriately classified.

### Acceptance Criteria and Comments:
- The system must maintain a catalogue of Product Categories;
- each Product Category must have a unique identifier and a descriptive name;
- products must be associable with an appropriate Product Category;
- Product Categories must be searchable using relevant identifying information;
- a Product Category referenced by existing products must not be removed in a manner that compromises the consistency of the corresponding business information.

### Requirements:
- Product Category catalogue: The system must maintain a catalogue of Product Categories. This should support the management of the categories used by the restaurant.
- Product Category identification: Each Product Category must have:
    - A unique identifier
    - A descriptive name
- Product–Category association: Products must be able to be associated with an appropriate Product Category.
- Product Category search: Product Categories must be searchable using relevant identifying information. For example, searching by category name or identifier.
- Data consistency: A Product Category that is referenced by existing products must not be removed in a way that breaks the consistency of the related business information. In practice, this could mean preventing deletion of a category that is still being used, or using another mechanism that preserves the relationship.

## BCK04 Allergen Management
### As a LaPrizza Manager, I want to maintain the allergens recognized by the restaurant, so that products can be associated with appropriate allergen information.

### Acceptance Criteria and Comments:
- The system must maintain a catalogue of allergens;
- each allergen must have a unique identifier and a descriptive name;
- allergens must be available for association with products;
- a product may be associated with one or more allergens;
- allergens must be searchable using relevant identifying information;
- anallergen referenced by existing business information must not be removed in a manner that compromises the consistency of that information

### Requirements:

- Allergen catalogue: The system must maintain a catalogue of allergens recognized by the restaurant.
- Allergen identification: Each allergen must have:
    - A unique identifier
    - A descriptive name
- Allergen availability for products: Allergens must be available for association with products.
- Product–Allergen association: A product must be able to be associated with one or more allergens. This means the relationship must support multiple allergens per product.
- Allergen search: Allergens must be searchable using relevant identifying information, such as their name or identifier.
- Data consistency: An allergen that is referenced by existing business information must not be removed in a way that compromises the consistency of that information. For example, the system could prevent the deletion of an allergen that is currently associated with products.

## BCK05 Product Management
### As a LaPrizza Manager, I want to register and manage products, so that the restaurant can maintain the items relevant to its business operation.

### Acceptance Criteria and Comments:
- The system must support the creation and update of products;
- each product must have a unique identifier, a name, and a description;
- a product must be associable with an appropriate Product Category;
- a product may be designated as sellable, subject to stock control, suitable for use as a Pizza Component, or any applicable combination of these characteristics, according to the business rules defined in the System Specification;
- a product designated as a Pizza Component must be associated with exactly one Pizza Component Type;
- sellable products must provide the commercial information required to make them available for sale;
- products may be associated with one or more allergens;
- products must be searchable and filterable using relevant information;
- the system must allow products that should no longer be actively used to be distinguished without compromising historically relevant information;
- changes to product information must preserve the consistency of existing relationships with other business concepts.

### Requirements:
- Product creation and management: The system must support the creation and updating of products.
- Product identification and basic information: Each product must have:
    - A unique identifier
    - A name
    - A description
- Product Category association: A product must be able to be associated with an appropriate Product Category.
- Product characteristics: A product must be able to be designated as:
    - Sellable
    - Subject to stock control
    - Suitable for use as a Pizza Component
    - Or any applicable combination of these characteristics, according to the defined business rules.
- Pizza Component Type association: If a product is designated as a Pizza Component, it must be associated with exactly one Pizza Component Type.
- Commercial information for sellable products: Products designated as sellable must contain the commercial information required to make them available for sale.
- Allergen association: A product must be able to be associated with one or more allergens.

## BCK06 Pizza Size Management
### As a LaPrizza Manager, I want to maintain the pizza sizes offered by the restaurant, so that pizza configurations and size-dependenti formation can refer to a consistent set of available sizes.

## Acceptance Criteria and Comments
- The system must maintain the Pizza Sizes recognized by LaPrizza: each Pizza Size must have a unique identifier and a descriptive name;
- Pizza Sizes must be available for use in pizza-related configurations: Pizza Sizes must be searchable using relevant identifying information, the system must allow the set of available Pizza Sizes to evolve without compromising existing business information. A Pizza Size referenced by existing business information must not be removed in a manner that compromises its consistency.
- Product search and filtering: Products must be searchable and filterable using relevant information.
- Product deactivation: The system must allow products that should no longer be actively used to be distinguished as inactive without compromising historically relevant information.
- Data and relationship consistency: Changes to product information must preserve the consistency of existing relationships with other business concepts.

### Requirements: 

- Pizza Size catalogue: The system must maintain the Pizza Sizes recognized by LaPrizza.
- Pizza Size identification: Each Pizza Size must have:
  - A unique identifier
  - A descriptive name
- Pizza Size availability: Pizza Sizes must be available for use in pizza-related configurations.
- Pizza Size search: Pizza Sizes must be searchable using relevant identifying information.
- Pizza Size evolution: The system must allow the set of available Pizza Sizes to evolve over time without compromising existing business information. For example, new sizes can be added without affecting existing pizza configurations.
- Data consistency: A Pizza Size referenced by existing business information must not be removed in a way that compromises the consistency of that information.

## BCK07 Pizza Component Type Management

### As a LaPrizza Manager, I want to maintain Pizza Component Types, so that products suitable for use in pizzas can be classified according to the role they play in a pizza configuration.

### Acceptance Criteria and Comments:
- The system must maintain the Pizza Component Types recognized by LaPrizza;
- each Pizza Component Type must define its relative assembly order within a pizza
configuration, and two Pizza Component Types must not have the same assembly order;
- each Pizza Component Type must define the minimum and maximum number of com
ponents of that type that may participate in a pizza configuration;
- the maximum number of components may be left unbounded;
- the set of Pizza Component Types and their properties must be configurable and must
not be unnecessarily fixed in the application source code;
- the initial configuration must include, at least, the following Pizza Component Types:
  - Base Dough: minimum 1, maximum 1, assembly order 1;
  - Base Sauce: minimum 0, maximum 1, assembly order 2;
  - Cheese: minimum 0, maximum 1, assembly order 3;
  - Topping: minimum 0, unbounded maximum, assembly order 4.
- Pizza Component Types must be searchable using relevant identifying information;
- a Pizza Component Type referenced by existing business information must not be removed in a manner that compromises its consistency.

### Requirements:
- Pizza Component Type catalogue: The system must maintain the Pizza Component Types recognized by LaPrizza.
- Assembly order: Each Pizza Component Type must define its assembly order within a pizza configuration. Two Pizza Component Types must not have the same assembly order.
- Minimum and maximum components: Each Pizza Component Type must define:
  - A minimum number of components allowed.
  - A maximum number of components allowed.
  - The maximum must be allowed to be unbounded when applicable.
- Configurable Pizza Component Types: The Pizza Component Types and their properties must be configurable. They must not be unnecessarily fixed in the application's source code. This means the system should allow the configuration to be changed without having to modify the application code unnecessarily.
- Initial Pizza Component Type configuration: The initial configuration must include at least:

| Component Type | Minimum | Maximum | Assembly Order |
| -------------- | ------- | ------- | -------------- |
| Base Dough     | 1       | 1       | 1              |
| Base Sauce     | 0       | 1       | 2              |
| Cheese         | 0       | 1       | 3              |
| Topping        | 0       | Unbounded | 4            |


- Pizza Component Type search: Pizza Component Types must be searchable using relevant identifying information.
Data consistency. A Pizza Component Type referenced by existing business information must not be removed in a way that compromises the consistency of that information.

- Validation of configuration rules: The system must enforce the defined rules for:
  - Unique assembly orders
  - Minimum component quantities
  - Maximum component quantities
  - Unbounded maximums where applicable


## BCK08 Pizza Component Configuration

### As a LaPrizza Manager, I want to configure the size-dependent characteristics of products used as pizza components, so that the system can determine the information applicable when a component is used in a pizza of a particular size.

### Acceptance Criteria and Comments:
- Only products designated for use as Pizza Components may have Component Size Configurations;
- a Component Size Configuration must associate a Pizza Component with a Pizza Size;
- for a given Pizza Component and Pizza Size, at most one applicable Component Size Configuration may exist;
- a Component Size Configuration must define the price applicable to the component when used in a pizza of the corresponding size;
- when the corresponding product is subject to stock control, the Component Size Configuration must allow the number of abstract stock units consumed for that Pizza Size to be represented;
- prices and stock-consumption values must satisfy the corresponding business validation rules;
- the system must allow the size-dependent configurations of a Pizza Component to be consulted;
- changes to Component Size Configurations must preserve the consistency of existing business information.

### Requiremtns:

- Pizza Component eligibility: Only products designated as Pizza Components may have a Component Size Configuration.
- Component Size Configuration association: A Component Size Configuration must associate:
  - One Pizza Component
  - One Pizza Size
- Unique configuration per component and size: For a given Pizza Component + Pizza Size combination, there must be at most one applicable Component Size Configuration. This prevents conflicting configurations for the same component and size.
- Size-dependent component price: Each Component Size Configuration must define the price applicable to that component when it is used in a pizza of the corresponding size.
- Stock consumption: If the corresponding Pizza Component is subject to stock control, the configuration must allow the number of abstract stock units consumed for that Pizza Size to be represented.
- Price and stock validation: Prices and stock-consumption values must satisfy the corresponding business validation rules. For example, invalid values should not be accepted if they violate the rules defined in the System Specification.
- Consultation of configurations: The system must allow the size-dependent configurations of a Pizza Component to be consulted. In other words, users should be able to see how a component behaves/configures for the different pizza sizes.
- Data consistency: Changes to Component Size Configurations must preserve the consistency of existing business information.

## BCK09 Stock Information Management

### As a LaPrizza Manager, I want to maintain stock information for products subject to stock control, so that the restaurant knows the quantity currently available for each applicable product.

### Acceptance Criteria and Comments:
- Stock information must only be maintained for products designated as subject to stock control;
- each stock-controlled product must have an identifiable current stock quantity;
- stock quantities must be represented using the abstract stock-unit model defined in the System Specification;
- stock quantities must be represented as non-negative integer numbers of abstract stock units;
- the system must allow the current stock level of an individual stock-controlled product to be consulted;
- stock information must be searchable using relevant product information;
- the system must provide operations for increasing or decreasing the current stock quantity by a specified number of abstract stock units;
- a stock reduction must not result in a negative stock quantity;
- operations that change stock quantities must validate the requested change and preserve the consistency of the resulting stock information;
- the stock model must provide an appropriate foundation for the ordering and operational functionality introduced in subsequent sprints.

### Requirement:
- Stock control eligibility: Stock information must only be maintained for products designated as subject to stock control. Products that are not stock-controlled must not have stock information maintained.
- Current stock quantity: Each stock-controlled product must have an identifiable current stock quantity.
- Abstract stock-unit model: Stock quantities must use the abstract stock-unit model defined in the System Specification.
- Non-negative integer quantities: Stock quantities must be represented as non-negative integer numbers of abstract stock units. Therefore, quantities cannot be negative or fractional.
- Individual stock consultation: The system must allow the current stock level of an individual stock-controlled product to be consulted.
- Stock search: Stock information must be searchable using relevant product information.
- Increase and decrease stock: The system must provide operations to:
  - Increase the current stock quantity by a specified number of stock units.
  - Decrease the current stock quantity by a specified number of stock units.
- Prevent negative stock: A stock reduction must never result in a negative stock quantity.
- Stock operation validation and consistency: Operations that modify stock quantities must:
  - Validate the requested change.
  - Preserve the consistency of the resulting stock information.
- Foundation for future functionality: The stock model must provide an appropriate foundation for the ordering and operational functionality that will be introduced in later sprints.

## BCK10 Predefined Pizza Management

### As a LaPrizza Manager, I want to define and manage predefined pizzas, so that the restaurant can maintain the standard pizza configurations offered to its customers.

### Acceptance Criteria and Comments:
- A Predefined Pizza must be represented by an appropriate sellable product;
- a Predefined Pizza must define a default pizza configuration composed of products designated as Pizza Components;
- only active products currently designated as Pizza Components may be included in a default pizza configuration;
- the same Pizza Component must not occur more than once in the same default pizza configuration;
- the default configuration must satisfy the minimum and maximum cardinality rules defined for each Pizza Component Type;
- a Predefined Pizza may only be made available in Pizza Sizes for which all Pizza Components in its default configuration have a corresponding Component Size Configuration;
- the system must allow the default configuration of a Predefined Pizza to be consulted;
- the information maintained for a Predefined Pizza must provide an appropriate basis for the pizza customization functionality introduced in subsequent sprints.

### Requirements:
- Predefined Pizza as a sellable product: A Predefined Pizza must be represented by an appropriate sellable product.
- Default pizza configuration: A Predefined Pizza must define a default pizza configuration. The configuration must be composed of products designated as Pizza Components.
- Active Pizza Components only: Only active products currently designated as Pizza Components may be included in a Predefined Pizza's default configuration.
- No duplicate Pizza Components: The same Pizza Component must not occur more than once in the same default pizza configuration.
- Component Type cardinality rules: The default configuration must satisfy the minimum and maximum cardinality rules defined for each Pizza Component Type. For example, if a Component Type requires at least one component, the predefined pizza must contain one.
- Pizza Size availability: A Predefined Pizza may only be made available in a Pizza Size when all Pizza Components in its default configuration have a corresponding Component Size Configuration for that size.
- Configuration consultation: The system must allow the default configuration of a Predefined Pizza to be consulted.
- Foundation for future customization: The information maintained for a Predefined Pizza must provide an appropriate basis for the pizza customization functionality that will be introduced in later sprints.

## BCK11 Product Catalogue and Product Information

### As a Customer, I want to consult the products offered by LaPrizza, so that I can understand the available options, their pricing, and other relevant product information.

### Acceptance Criteria and Comments:
- The system must provide access to the products currently offered for sale by LaPrizza;
- the catalogue must provide relevant information about each sellable product, including, where applicable, its name, description, category, pricing information, and allergen information;
- users must be able to consult the details of an individual sellable product;
- for a Predefined Pizza, the catalogue must provide its default configuration and the Pizza Sizes in which it is available;
- the information presented in the catalogue must be consistent with the corresponding business information maintained by the system

### Requirements: 
- Sellable product catalogue: The system must provide access to the products currently offered for sale by LaPrizza. The catalogue should only include products that are currently sellable/offered for sale.
- Product information: The catalogue must provide relevant information about each sellable product, including, where applicable:
  - Name
  - Description
  - Product Category
  - Pricing information
  - Allergen information
- Individual product details: Users must be able to consult the details of an individual sellable product.
- Predefined Pizza information: For a Predefined Pizza, the catalogue must provide:
  - Its default configuration
  - The Pizza Sizes in which it is available
- Catalogue information consistency: The information presented in the catalogue must be consistent with the corresponding business information maintained by the system. The catalogue should therefore reflect the actual product data rather than maintaining a separate, potentially conflicting version.
