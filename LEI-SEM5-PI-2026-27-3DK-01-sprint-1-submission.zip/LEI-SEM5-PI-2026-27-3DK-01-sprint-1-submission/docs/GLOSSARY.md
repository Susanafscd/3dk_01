# LaPrizza - Domain Glossary

**Purpose:** This glossary defines the business terminology used throughout the LaPrizza system, based on PART II (System Specification) and the Sprint 1 domain analysis.

| Term | Definition | Source/Notes |
|---|---|---|
| Active product | A product that is currently in use by the restaurant (not marked inactive). Inactive products are preserved for historical consistency. | BCK05 |
| Abstract Stock Unit | A normalised, product-specific unit used to represent stock quantities and consumption, avoiding physical units of measurement. | BCK09, PART II |
| Address | Location information associated with a customer (street, number, postal code, city, country) used for identification/contact and delivery. | BCK02, PART II |
| Allergen | A substance recognised by the restaurant that may cause an adverse reaction in some people. Products may be associated with one or more allergens. | BCK04 |
| Catalogue | The set of products offered by LaPrizza, including predefined pizzas and sellable items. | BCK11 |
| Component Size Configuration | Size-dependent information for a pizza component when used in a pizza of a given size: price and, if stock-controlled, stock units consumed. At most one configuration per (component, size) pair. | BCK08, BR-11 |
| Configured Component | A pizza component participating in a pizza configuration in the role defined by its Pizza Component Type. | PART II, DM |
| Consent | Explicit agreement by a customer for a specific purpose (e.g. marketing), with granted/withdrawn timestamps to satisfy data protection requirements (GDPR). | PART II, GDPR |
| Customer | A person who interacts with LaPrizza, places orders and may declare dietary restrictions. | BCK02 |
| Dietary Restriction | A food intolerance or dietary restriction declared by a customer; may relate to allergens. | BCK02 |
| Food Preparation Schedule | The planned sequence and timing of preparation activities allocated to kitchen resources. | PART II |
| Kitchen Resource | A resource used in food preparation (Oven, Preparation Station, Assembly Table). May represent a single resource or a group of equivalent resources. | PART II |
| Money | Value Object representing a monetary amount (amount and currency). | DM/CD/DDD |
| Order | A customer request composed of one or more order items, progressing through operational states. Its overall status is derived from the status of its items. | PART II, BR-17 |
| Order Item | Part of an order: either a reference to a sellable product, or a preserved personalized pizza configuration. Exactly one of these alternatives applies. | PART II, BR-15, BR-16 |
| Order Number | Unique business identifier of an order. | PART II |
| Permission | An operation a role is authorised to perform. Roles and permissions are business data, not hardcoded. | BCK01 |
| Personalized Pizza | An order-specific pizza configuration derived from a predefined pizza. Its configuration is preserved in the order item independently of catalogue changes. | PART II, BR-16 |
| Pizza Component | A product designated for use as a component in pizza configuration. Has exactly one Pizza Component Type. | BCK05, BR-05 |
| Pizza Component Type | Business classification of a component's role (Base Dough, Base Sauce, Cheese, Topping). Defines assembly order (unique), min and max quantities; max may be unbounded. | BCK07, BR-10 |
| Pizza Configuration | Composition of pizza components. Default configuration belongs to a predefined pizza (size-independent). Personalized configuration is order-specific and may reference the originating predefined pizza and an optional pizza size. | PART II, BCK10 |
| Pizza Size | Commercial size of a pizza. Affects component size configurations and determines the sizes in which a predefined pizza is available. | BCK06 |
| Predefined Pizza | A sellable product that defines a default pizza configuration and is available in specific pizza sizes. The default configuration must only contain active pizza components, with no repetitions and respecting cardinalities. | BCK10, BR-12, BR-13 |
| Preparation Activity | A scheduled instance of preparation work generated from an order item, allocated to kitchen resources with defined timing and sequence. | PART II |
| Preparation Activity Template | Operational definition of preparation for a product (duration, required resource type, dependencies between activities). Used to generate activity instances per order item. | PART II |
| Product | Core domain item managed by the restaurant. May be sellable, stock-controlled, pizza component, or any combination. Inactive products remain in the catalogue to preserve historical information. | BCK05, BR-04, BR-07 |
| Product Category | Classification of products in the catalogue. | BCK03 |
| Role | A set of permissions/responsibilities assigned to a user. | BCK01 |
| Staff | Restaurant employee operating the system under assigned roles. | BCK01 |
| Stock Information | Current quantity of a stock-controlled product, expressed in abstract stock units. Must be non-negative; operations must not make it negative. | BCK09, BR-08 |
| User | Authenticated system actor (Customer or Staff). Each user has a unique identity and is authenticated before accessing protected operations. | BCK01 |