# LaPrizza — Key Scenarios

This document identifies the scenarios that drive the LaPrizza architecture: the end-to-end behaviours the system must support (functional scenarios) and the quality expectations it must satisfy (quality-attribute scenarios). Each functional scenario is traced to the user stories and business rules it exercises; each quality scenario states a stimulus, a response and a measurable (or at least testable) response measure.

These scenarios are the basis for the Use-Case, Logical and Process views of the [Software Architecture Document](architecture/SAD.md).

## 1. Key Functional Scenarios (Sprint 1)

### KS-1 — Authenticate and authorise an operator

- **Actor:** Manager or Staff.
- **Trigger:** An operator submits credentials to the system.
- **Main flow:**
  1. The operator sends credentials to the authentication endpoint.
  2. The system validates the credentials against the identity store.
  3. On success, the system establishes the operator's identity (cookie) and resolves their roles and permissions.
  4. Protected operations are then permitted only if the operator's roles authorise them.
- **Postconditions:** The operator is authenticated; unauthorised operations are rejected.
- **Traces:** BCK01 · BR-01.

### KS-2 — Maintain the product catalogue

- **Actor:** Manager.
- **Trigger:** The manager creates or updates product categories, allergens, pizza sizes and component types.
- **Main flow:**
  1. The manager submits the resource details.
  2. The system validates them (unique identifying data, required fields, format).
  3. The system persists the resource.
  4. Resources referenced by other business data cannot be removed in a way that breaks consistency.
- **Postconditions:** The catalogue contains consistent, searchable reference data.
- **Traces:** BCK03, BCK04, BCK06, BCK07 · BR-02, BR-03, BR-09, BR-10.

### KS-3 — Register and manage a product

- **Actor:** Manager.
- **Trigger:** The manager registers a product and designates its roles.
- **Main flow:**
  1. The manager submits the product with its category and any allergens.
  2. The manager designates the applicable roles (sellable, stock-controlled, pizza component).
  3. If the product is a pizza component, exactly one component type is assigned.
  4. The system validates and persists the product.
  5. Products no longer in active use are deactivated rather than deleted.
- **Postconditions:** The product exists with consistent relationships and preserved history.
- **Traces:** BCK05 · BR-02 … BR-07.

### KS-4 — Configure a pizza component for each size

- **Actor:** Manager.
- **Trigger:** The manager defines the size-dependent information of a pizza component.
- **Main flow:**
  1. The system checks that the product is designated as a pizza component.
  2. The manager associates the component with a pizza size and provides the price and, if stock-controlled, the units consumed.
  3. The system enforces at most one configuration per *(component, size)* pair and validates the values.
  4. The system persists the configuration.
- **Postconditions:** The component can be priced and its stock consumption determined per size.
- **Traces:** BCK08 · BR-11.

### KS-5 — Define a predefined pizza

- **Actor:** Manager.
- **Trigger:** The manager defines a predefined pizza and its default configuration.
- **Main flow:**
  1. The manager selects active pizza components for the default configuration.
  2. The system rejects repeated components and enforces the cardinality rules of each component type.
  3. The system exposes the pizza only in sizes for which every component has a size configuration.
  4. The system persists the predefined pizza.
- **Postconditions:** A valid predefined pizza is available to the catalogue.
- **Traces:** BCK10 · BR-12, BR-13.

### KS-6 — Manage stock

- **Actor:** Manager.
- **Trigger:** The manager increases or decreases the stock of a stock-controlled product.
- **Main flow:**
  1. The system checks that the product is stock-controlled.
  2. The manager requests a change by a number of abstract stock units.
  3. The system validates that quantities are non-negative integers and that a decrease does not make stock negative.
  4. The system persists the new stock level.
- **Postconditions:** The stock level is consistent and never negative.
- **Traces:** BCK09 · BR-08.

### KS-7 — Consult the product catalogue

- **Actor:** Customer.
- **Trigger:** The customer browses or opens a product.
- **Main flow:**
  1. The system returns the active sellable products with their category, pricing and allergen information.
  2. For a predefined pizza, the system also returns its default configuration and the sizes in which it is available.
- **Postconditions:** The customer sees accurate, up-to-date information derived from the source of truth.
- **Traces:** BCK11 · BR-14.

## 2. Key Functional Scenarios (Later Sprints)

### KS-8 — Place an order with a personalised pizza

- **Actor:** Customer.
- **Trigger:** The customer configures a pizza and submits an order.
- **Main flow:**
  1. The customer derives a personalised configuration from a predefined pizza (adding, removing or changing components).
  2. The system validates the configuration and prices it using the applicable size configurations.
  3. The order item preserves the configuration independently of later catalogue changes.
  4. The order progresses through its derived states.
- **Postconditions:** A preserved, order-specific pizza configuration exists.
- **Traces:** BR-15 … BR-17.

### KS-9 — Generate a food preparation schedule

- **Actor:** Kitchen system / Staff.
- **Trigger:** An order in a preparable state is submitted for scheduling.
- **Main flow:**
  1. The system derives the required preparation activities from the products' preparation templates.
  2. Sequencing constraints come from activity dependencies and allocation from available kitchen resources.
  3. The AI scheduling component computes the sequence, timing and resource allocation.
  4. The result is stored as a schedule version.
- **Postconditions:** A feasible preparation schedule exists for the pending activities.
- **Traces:** BR-18.

### KS-10 — Visualise a pizza in 3D

- **Actor:** Customer.
- **Trigger:** The customer opens the 3D view of a pizza.
- **Main flow:**
  1. The front-end requests the pizza configuration from the API.
  2. The 3D visualization container renders the configuration.
- **Postconditions:** The customer sees a visual representation consistent with the configuration.
- **Traces:** PART II (3D visualization area).

## 3. Quality-Attribute Scenarios

| ID | Quality | Stimulus | Response | Response measure |
| -- | ------- | -------- | -------- | ---------------- |
| QA-1 | Security | An unauthenticated or unauthorised request reaches a protected endpoint. | The system rejects the request without disclosing protected data. | Every protected endpoint requires authentication; invalid attempts never grant access. |
| QA-2 | Security | An unsafe request is submitted without a valid antiforgery token. | The system rejects it with `400` and the standard error contract. | No state change occurs. |
| QA-3 | Reliability | The cache is unavailable. | The system falls back to the source of truth and continues to serve correct data. | No request fails because of a cache outage. |
| QA-4 | Performance | A frequently read catalogue query is repeated under load. | The system serves it from cache where configured. | Repeated reads do not hit the database; response time is bounded by the cache. |
| QA-5 | Data integrity | A business rule is violated (e.g. negative stock, duplicate size configuration). | The system rejects the change and returns a clear error. | Invalid state is never persisted; a `400`/`409` is returned. |
| QA-6 | Modifiability | A new component type or pizza size must be added. | The change is made as business data, not source-code changes. | No application code change is required. |
| QA-7 | Maintainability | A business rule changes. | The change is made in the domain layer only. | No changes to controllers, persistence or infrastructure are required. |
| QA-8 | Testability | A business rule must be verified. | The rule is covered by an automated test. | The test runs with `dotnet test` without a database or browser. |
| QA-9 | Interoperability | A new client (web, 3D or AI) integrates with the back-end. | It consumes the documented REST API under `/api/v1`. | The OpenAPI contract is sufficient to integrate without back-end changes. |
| QA-10 | Traceability | A change is proposed. | The related story, rule and diagram can be identified. | Every behaviour traces to a story (BCKxx) and rule (BR-xx). |

## 4. Related Artefacts

- [Requirements analysis](requirements.md) — user stories and derived requirements.
- [Domain analysis](DM.md) — business rules (BR-xx) and modelling decisions.
- [Software Architecture Document](architecture/SAD.md) — Use-Case, Logical and Process views.
- [Domain glossary](GLOSSARY.md) — terminology used in the scenarios.
