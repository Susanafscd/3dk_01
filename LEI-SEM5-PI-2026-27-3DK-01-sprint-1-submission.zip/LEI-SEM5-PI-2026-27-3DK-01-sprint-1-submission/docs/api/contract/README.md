# LaPrizza OpenAPI contract

This folder holds the OpenAPI contract, split into small JSON files that are
merged into a single bundled document, [`../openapi.json`](../openapi.json), by
[`../../backend/tools/OpenApiBundler/bundle.cs`](../../backend/tools/OpenApiBundler/bundle.cs).

The contract is organised by **role** rather than by use case, so a change touches
one small file:

| Path | Contents |
| ---- | -------- |
| [`openapi.json`](openapi.json) | Root document: `openapi`, `info`, `tags` and the list of folders to merge (`x-includes`) |
| [`paths/`](paths) | One file per resource, keyed by URL (for example `customers.json` holds both `/api/v1/customers` and `/api/v1/customers/{id}`) |
| [`components/schemas/`](components/schemas) | One file per schema, named after the schema (`CustomerResponse.json`) |
| [`components/parameters/`](components/parameters) | One file per reusable parameter (`X-CSRF-TOKEN.json`, `CustomerId.json`) |
| [`components/responses/`](components/responses) | One file per reusable response (`BadRequest.json`, `Unauthorized.json`, ...) |
| [`components/securitySchemes/`](components/securitySchemes) | One file per security scheme (`cookieAuth.json`) |

## How a fragment is written

Every file under `paths/` contains a JSON object keyed by URL path; its entries
are merged into the root `paths`. Every file under a `components/<collection>/`
folder defines exactly one component; it is merged under `components.<collection>`
using the file name (without `.json`) as its key.

A fragment never repeats `openapi`, `info` or `tags`; those describe the whole API
and live in the root file. References between fragments use the normal internal
form, for example `"$ref": "#/components/schemas/CustomerResponse"` or
`"$ref": "#/components/responses/NotFound"`; once the folders are merged they
resolve against the root document.

The root `openapi.json` lists the folders to merge in `x-includes`. The bundler
walks each folder in name order, so the result is deterministic. To add a schema,
parameter, response or security scheme, drop a file into the matching folder; to
add a path, add it to the resource file under `paths/`. Then build and commit the
regenerated bundle:

```bash
cd backend
dotnet build Api.sln
```

The bundled [`../openapi.json`](../openapi.json) is committed but is generated;
never edit it by hand.
