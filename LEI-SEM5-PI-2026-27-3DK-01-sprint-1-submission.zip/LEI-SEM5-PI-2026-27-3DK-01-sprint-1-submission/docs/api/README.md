# LaPrizza — REST API

This document describes the HTTP API exposed by the LaPrizza back-end. The API is the integration point between the back-end and the web application.

The openAPI contract is the single source of truth for both back-end and front-end implementations.

## Machine-readable contract

The contract is split into small files under [`contract/`](contract), grouped by **role**:

| Path | Contents |
| ---- | -------- |
| [`contract/openapi.json`](contract/openapi.json) | Root document: API metadata, tags and the list of fragment folders (`x-includes`) |
| [`contract/paths/`](contract/paths) | One file per resource, keyed by URL (health, customers, auth, antiforgery) |
| [`contract/components/schemas/`](contract/components/schemas) | One file per schema |
| [`contract/components/parameters/`](contract/components/parameters) | One file per reusable parameter |
| [`contract/components/responses/`](contract/components/responses) | One file per reusable response |
| [`contract/components/securitySchemes/`](contract/components/securitySchemes) | One file per security scheme |

NSwag and Swagger UI both need a single self-contained document, so the fragments
are merged into [`openapi.json`](openapi.json) by a small bundler
(`backend/tools/OpenApiBundler/bundle.cs`). That bundle is the file NSwag reads,
the document the API serves at `/swagger/v1/swagger.json`, and the one the tests
compare against. It is committed but **generated** — never edit it by hand.

Make a change in the file that owns the definition (the resource file under
`paths/`, or the component file), then build; the bundle and the generated code
follow:

```bash
cd backend
dotnet build src/Api/Api.csproj   # bundles docs/api/openapi.json, then regenerates src/Api/OpenApi/Generated/Contract.g.cs
```

`dotnet test Api.sln` fails if what the API serves is not the committed bundle.

## 1. Conventions

| Aspect | Convention |
| ------ | ---------- |
| Base path | `/api/v1` |
| Media type | JSON (`application/json`) |
| Errors | `application/problem+json` (RFC 9457) |
| Naming | Plural, lower-case resource names; identifiers in the path |
| Dates/times | ISO 8601 UTC |
| Pagination | `page` and `pageSize` query parameters; responses include total count |
| Filtering/search | Query parameters on collection endpoints (e.g. `?search=`, `?categoryCode=`, `?allergenCode=`) |
| Documentation | OpenAPI/Swagger at `/swagger` |

### Methods

| Method | Use |
| ------ | --- |
| `GET` | Retrieve a resource or collection (safe, idempotent) |
| `POST` | Create a resource |
| `PUT` | Replace a resource |
| `PATCH` | Partially update a resource |
| `DELETE` | Remove a resource (or deactivate, where history must be preserved) |

### Status codes

| Code | Meaning |
| ---- | ------- |
| `200 OK` | Success |
| `201 Created` | Resource created (with `Location` header) |
| `204 No Content` | Success with no body |
| `400 Bad Request` | Validation failure or rejected antiforgery token |
| `401 Unauthorized` | Not authenticated |
| `403 Forbidden` | Authenticated but not authorised |
| `404 Not Found` | Resource does not exist |
| `409 Conflict` | Business rule or consistency conflict |
| `500 Internal Server Error` | Unexpected failure |

## 2. Authentication and Authorisation

- Authentication uses **ASP.NET Core Identity over cookie authentication**.
- Cookies are `HttpOnly`, `SameSite=Lax` and `Secure` in production; in development they follow the request scheme, so the API can also be called over plain HTTP locally. Production deployments must use HTTPS.
- Endpoints require an authenticated user by default and opt out with `[AllowAnonymous]`.
- Unsafe requests (anything other than `GET`/`HEAD`/`OPTIONS`) require an **antiforgery token** supplied in the `X-CSRF-TOKEN` header. Clients obtain the token from the antiforgery cookie issued by the token endpoint.
- Authorisation is role- and permission-based. Roles and permissions are business data, not hard-coded.
- A first manager account (with the `Manager` role) and three sample customers can be seeded by running the separate bootstrap project (`dotnet run --project src/Bootstrap`; `manager@laprizza.local` / `Manager123!` and `customer@laprizza.local`, `ana.ferreira@laprizza.local`, `miguel.santos@laprizza.local` / `Customer123!`), so the system has an administrator and some data from the beginning. The credentials are development defaults and must be changed before deployment.

> Note: an unknown URL currently returns `401` rather than `404`, because the default authorisation policy applies to unmatched requests. This prevents unauthenticated route probing.

## 3. Error Contract

Errors follow `application/problem+json`:

```json
{
  "type": "https://tools.ietf.org/html/rfc9457",
  "title": "Validation failed",
  "status": 400,
  "detail": "The 'name' field is required.",
  "instance": "/api/v1/customers"
}
```


## 4. Versioning and Evolution

- The API is versioned in the URL (`/api/v1`). Breaking changes require a new version.
- Additive, backward-compatible changes are made within the current version.
- The OpenAPI contract (the fragments in [`contract/`](contract), bundled into [`openapi.json`](openapi.json)) is the machine-readable contract and the input of the server code; keep it and this document aligned (change the fragment, then rebuild).
