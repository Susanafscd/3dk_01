# LaPrizza — Principles and Guidelines

This document records the engineering principles and working guidelines the team follows on the LaPrizza project. It is a living document: when a decision changes, the relevant guideline is updated here and, when the decision is architecturally significant, recorded as an ADR.

## 1. Guiding Principles

| Principle | What it means for LaPrizza |
| --------- | -------------------------- |
| Separation of concerns | Domain logic is independent of presentation, persistence and infrastructure. The domain must not know about the web, EF Core, MongoDB or Redis. |
| Single source of truth | Each business fact is owned by one place. Derived values (e.g. order status) are computed from that source, not stored twice. |
| Dependency inversion | Higher-level policy depends on abstractions (interfaces), and implementation details depend on those abstractions. The domain defines repository interfaces; infrastructure implements them. |
| SOLID | Classes and components have a single responsibility, are open for extension, respect substitutability, keep interfaces small and depend on abstractions. |
| DRY | Avoid duplicating knowledge. Duplicating *code* that changes for different reasons is acceptable; duplicating *rules* is not. |
| KISS / YAGNI | Choose the simplest design that satisfies the current sprint; do not build for hypothetical future needs. |
| Fail fast and explicitly | Validate at boundaries, surface errors with clear messages, and never swallow exceptions silently. |
| Security by default | Authentication and authorisation are required unless explicitly opted out. Secrets never enter version control. |
| Testability | Behaviour is designed so it can be tested without a database, a browser or a network. |

## 2. Architecture Guidelines

1. **Layering and dependency direction.** Dependencies point inward: Presentation → Application → Domain. Infrastructure implements interfaces declared by the inner layers. The domain depends on nothing.
2. **Domain purity.** The domain model contains aggregates, entities, value objects, domain services and business invariants. It does not reference ASP.NET Core, EF Core, serialization attributes or infrastructure types.
3. **Aggregates as consistency boundaries.** Load and persist whole aggregates through their roots; reference other aggregates by identity, not by object graph.
4. **Application layer.** The application layer orchestrates use cases, loads aggregates, invokes domain behaviour, coordinates transactions and translates between DTOs and the domain. It does not contain business rules that belong to the domain.
5. **Repositories.** Data access is hidden behind repository interfaces. Repositories abstract persistence details; the application layer must not know how or where data is stored.
6. **Caching.** Caching is an optimisation, never a source of truth. It is configured per use case and may be bypassed without changing behaviour. If a cache is unavailable, the system falls back to the source of truth.
7. **Explicit contracts.** Cross-container communication uses documented REST contracts under `/api/v1`; internal modules use interfaces.
8. **No premature distribution.** Keep the system a modular monolith until a deployment or scaling requirement justifies splitting it.

## 3. Back-End Guidelines (C# / .NET)

- **Language and platform:** .NET 10 / ASP.NET Core 10, C# 14. Keep the SDK version consistent across the team.
- **Structure:** keep domain, application, infrastructure and API responsibilities separated as the architecture is introduced. The skeleton in `backend/src/Api` is a starting point, not a target layout.
- **Naming:** C# naming conventions (PascalCase for types/members, camelCase for locals/parameters, `_camelCase` for private fields). Use intention-revealing names from the [domain glossary](../GLOSSARY.md).
- **Formatting:** formatting is enforced by `.editorconfig` and `dotnet format`. Run it before committing.
- **Validation:** validate at the API boundary (model state) and enforce business rules in the domain. Do not duplicate a domain rule as an ad-hoc controller check.
- **Errors:** return the standard `application/problem+json` (RFC 9457) error contract. Unexpected exceptions are handled centrally.
- **Configuration:** environment-based settings; secrets only via environment variables or user secrets, never committed. `.env` files are git-ignored.
- **Async:** use `async`/`await` for I/O, pass `CancellationToken` through call chains, and avoid blocking calls.
- **Tests:** NUnit for unit tests and `WebApplicationFactory` for API tests. Copy the existing health-endpoint fixture when testing new endpoints. Business rules must be covered by tests.

## 4. Front-End Guidelines (Angular / TypeScript)

- **Language and platform:** Angular 22, TypeScript 6 in `strict` mode. Keep Node on the version pinned by `.nvmrc`.
- **Structure:** feature-based layout with `core/`, `shared/` and `features/`. `core/` holds genuinely cross-cutting singletons (config, auth, HTTP interceptors); feature-specific code stays in its feature.
- **Components:** standalone components; keep them focused on presentation and delegate data access to services.
- **State:** Angular signals as the decided state approach. Do not introduce a global store without a recorded decision.
- **API access:** centralise calls in the API client and read the base URL from `environment.apiBaseUrl`. Do not scatter raw URLs through components.
- **Styling:** Tailwind CSS utility classes, following the configured Prettier formatting.
- **Formatting and linting:** `npm run lint`, `npm run format` / `npm run format:check`.
- **Tests:** Vitest with Angular `TestBed`. Add tests next to the code they cover.

## 5. Source Control Guidelines

- **Main branch:** `main` is always in a working state. Work is integrated through reviewed changes.
- **Feature Branches:** for each feature (may equate to multiple USs) a branch will be created and when this one reaches the definition of done it will be merged to main afer peer review.
- **Commits:** small, focused and written in the imperative mood; explain *what* and *why*. Reference the related story or issue when applicable (e.g. `BCK05 ...`).
- **Before committing:** run formatting, linting and tests (`dotnet format --verify-no-changes`, `dotnet test`, `npm run lint`, `npm test`).
- **Never commit:** secrets, `.env` files, build output, IDE-local settings or generated artifacts that are git-ignored.
- **Generated diagrams:** commit both the PlantUML source and the rendered output so documentation is readable without a toolchain.

## 6. Documentation Guidelines

- Business terminology has a single definition in the [domain glossary](../GLOSSARY.md); use it consistently.
- Architecture is documented in the [SAD](../architecture/SAD.md) and C4 diagrams under `docs/architecture/diagrams/`.
- Significant technical decisions are captured as ADRs in `docs/architecture/ADR/`.
- Requirements and their derived rules live in [requirements.md](../requirements.md).
- Documentation changes that accompany a code change belong in the same change.


## 7 Definition of Ready (DoR)

"Are we ready to start working on this task?"

- Is the task clearly defined and understood?
- Are all business rules known?
- Are all dependencies identified and clarified?
- Are the acceptance criteria defined?
- Is there a test plan in place?


## 7. Definition of Done (DoD)

"Can we consider this task complete?"
- Analysis and design documentation are updated.
- Code is committed with an appropriate commit message.
- Unit tests are implemented and passing.
- Functional tests are performed and their results are documented.

## 8. References

- [Project context](../context.md)
- [Domain analysis](../DM.md) and [glossary](../GLOSSARY.md)
- [Software Architecture Document](../architecture/SAD.md)
- [Requirements](../requirements.md)
- Back-end and front-end READMEs (`backend/README.md`, `frontend/README.md`)
