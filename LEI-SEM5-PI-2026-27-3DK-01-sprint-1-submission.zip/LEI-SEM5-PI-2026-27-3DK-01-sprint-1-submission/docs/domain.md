# LaPrizza — Domain Overview

This document gives a high-level view of the LaPrizza business domain: what the system is about, how the domain is organised, and where the detailed artefacts live. It is the entry point to the domain documentation; the detailed analysis is in [DM.md](DM.md) and the tactical model in [DomainModelDDD.puml](DomainModelDDD.puml).

## 1. Core Domain

The **core domain** of LaPrizza is the restaurant's catalogue and its pizza configuration rules. This is where the business differentiates itself and where the most valuable and complex rules live:

- Products that combine independent roles — *sellable*, *stock-controlled* and *pizza component*.
- Pizza component types with configurable assembly order and cardinality rules.
- Size-dependent component information (price and stock consumption).
- Predefined pizzas whose default configuration must satisfy those rules and be available only in sizes for which every component is configured.

Everything else either supports this core (identity, customers, stock) or builds on it in later sprints (orders, food preparation).

## 2. Ubiquitous Language

The domain uses a precise vocabulary defined in the [Domain Glossary](GLOSSARY.md). The most important distinctions are:

- A **Product** is any item managed by the restaurant; being a product does not imply it is sold.
- The product **roles** (*sellable*, *stock-controlled*, *pizza component*) are independent and combinable.
- A **Pizza Component Type** (Base Dough, Base Sauce, Cheese, Topping) describes the role a component plays in a pizza; it is business data, not code.
- A **Predefined Pizza** is a sellable product with a default configuration.
- **Stock** is expressed in abstract stock units, not physical units.
- Catalogue aggregates are identified by immutable business codes: `ProductCategory.code`,
  `Allergen.code`, `Product.code` and `PizzaComponentType.code`. A display name may change
  without changing the lookup identity.

## 3. Subdomains

| Subdomain | Responsibility | Sprint 1 |
| --------- | -------------- | :------: |
| Identity and access | Users, roles, permissions, authentication and authorisation. | ✅ |
| Customers | Customer records, contact information, dietary restrictions and consent. | ✅ |
| Catalogue | Product categories, products, allergens, pizza sizes and component types. | ✅ |
| Pizza configuration | Component size configurations and predefined pizzas. | ✅ |
| Stock | Abstract stock units and stock movements for stock-controlled products. | ✅ |
| Catalogue consultation | Read access to the products offered for sale. | ✅ |
| Ordering | Orders, order items and their lifecycle. | ⏳ |
| Food preparation | Preparation templates and activities, kitchen resources and schedules. | ⏳ |
| Scheduling (AI) | Generation and optimisation of preparation schedules. | ⏳ |
| Visualization (3D) | Visual representation of pizzas and configurations. | ⏳ |

✅ = implemented in Sprint 1 · ⏳ = modelled now, implemented in later sprints.

## 4. Tactical Model (DDD)

The tactical model is documented in [DomainModelDDD.puml](DomainModelDDD.puml) and follows these conventions:

- **Aggregate** — a consistency boundary; the **aggregate root** is its only entry point.
- **Entity** — has identity and lifecycle *inside* an aggregate.
- **Value Object** — no identity, immutable, replaced as a whole and compared by value (e.g. `Money`, `Address`).
- **References between aggregates** are by identifier only; aggregates are not navigated across boundaries.

### Aggregate roots

| Aggregate root | Consistency boundary |
| -------------- | -------------------- |
| `User` | Identity, credentials and roles of system users. |
| `Role` | Roles, their permissions and assignments. |
| `Product` | Product attributes, role designations, stock and component size configurations. |
| `ProductCategory` | Catalogue classification of products. |
| `Allergen` | Allergen catalogue. |
| `PizzaComponentType` | Component role, assembly order and cardinality rules. |
| `PizzaSize` | Commercial pizza sizes. |
| `Order` | Orders and their order items. |
| `KitchenResource` | Individual or grouped kitchen resources. |

The default configuration of a `PredefinedPizza` is modelled inside the **Product** aggregate, because a predefined pizza is a product and its configuration is part of that product's invariants.

## 5. Key Business Rules

The full set of business rules (BR-01…BR-18) and modelling decisions (MD-01…) is documented in [DM.md](DM.md). The rules that most influence the architecture are:

- A product designated as a pizza component is associated with **exactly one** `PizzaComponentType` (BR-05).
- Products are **deactivated**, not deleted, to preserve historical information (BR-07).
- Product categories and allergens are removed only when no protected reference exists. Checks
  include inactive products; category removal also checks pizza component types, and allergen
  removal also checks customer dietary restrictions. Rejected removal never cascades to dependent data.
- Stock exists only for stock-controlled products and cannot become negative (BR-08).
- Each `PizzaComponentType` defines a unique assembly order and min/max cardinality; the maximum may be unbounded (BR-10).
- At most one `ComponentSizeConfiguration` exists per *(component, size)* pair (BR-11).
- A predefined pizza's default configuration only contains active components, without repetition, respecting cardinalities, and is available only in sizes where all components are configured (BR-12, BR-13).

## 6. Domain Services and Invariants

Most business rules are enforced inside aggregate roots, which is where the model keeps its invariants. When a rule spans more than one aggregate, or needs information that does not naturally belong to a single aggregate, it is expressed as a **domain service** rather than forced into an entity.

Key invariants are enforced at the point where the state changes, so invalid state cannot be persisted. Examples are the ones listed under [Key Business Rules](#5-key-business-rules).

References between these aggregates use business codes rather than object navigation. A product
stores `categoryCode`, `componentTypeCode` (when it is a pizza component) and a set of allergen
codes. A pizza component type stores its `categoryCode`. These links are validated by application
ports and protected by PostgreSQL constraints/reference checks; the Domain layer does not depend on
EF Core, PostgreSQL, Redis or ASP.NET.

## 7. Related Artefacts

| Artefact | Location |
| -------- | -------- |
| Domain analysis, business rules and modelling decisions | [DM.md](DM.md) |
| Conceptual domain model | [DM.puml](conceptualDM.png) |
| DDD tactical model (aggregates, entities, value objects) | [DomainModelDDD.puml](DDD-model.png) |
| Domain glossary | [GLOSSARY.md](GLOSSARY.md) |
| Product requirements analysis | [requirements.md](requirements.md) |
| Architecture | [architecture/SAD.md](architecture/SAD.md) |
