# Angular SPA - Level 3 Logical View

## 1. Overview

The Angular Single-Page Application (SPA) is the frontend container responsible for presenting the user interface, coordinating user interactions, managing frontend state, and communicating with the backend REST API.

The frontend is organized into four logical areas:

- **Presentation Layer:** manages navigation, pages, and user interface components.
- **Application Layer:** coordinates frontend operations and manages application state.
- **Communication Layer:** encapsulates HTTP communication with the backend REST API.
- **Shared Frontend Definitions:** provides data transfer objects, interfaces, validation rules, and reusable domain helpers.

## 2. Routing & Guards

The Routing & Guards component manages navigation within the application and controls access to routes through client-side navigation restrictions.

Routing associates URLs with the appropriate pages or feature views, allowing users to navigate between application areas such as products, orders, and user administration.

Route guards can verify conditions such as whether a user is authenticated before allowing navigation to a protected route. However, client-side guards do not replace backend authorization, which must independently enforce access restrictions on protected operations.

## 3. Presentation Layer

The Presentation Layer is responsible for displaying information and collecting user input. It consists of Pages / Feature Views and UI Components.

### 3.1 Pages / Feature Views

Pages / Feature Views represent the application's main feature areas and coordinate the presentation of individual use cases.

Examples include product management, order management, catalogue viewing, and user administration pages.

Pages compose UI components, invoke application services, and coordinate the presentation of operation results. They may also manage presentation-specific concerns such as loading indicators, error messages, and the visibility of dialogs.

### 3.2 UI Components

UI Components provide reusable elements for presenting information and collecting user input.

Examples include forms, tables, dialogs, buttons, search fields, and pagination controls.

These components primarily handle presentation and user interaction. They may emit events or invoke appropriate application operations, depending on the implementation, while leaving broader use-case coordination to the relevant page or application service.

## 4. Application Layer

### 4.1 Application Services / State

Application Services / State coordinates frontend operations and manages the state required by the user interface.

Application services and facades provide an interface through which pages and components initiate operations, such as loading products, creating orders, or updating user information. They coordinate calls to API services and expose operation results to the presentation layer.

Frontend state represents information required by the interface, including loaded data, selected items, loading status, search filters, and error messages.

Separating application coordination from presentation components reduces duplication and helps keep the user interface independent of the details of HTTP communication.

## 5. Communication Layer

The Communication Layer isolates the rest of the frontend from the details of communicating with the backend REST API. It consists of API Services and HTTP Interceptors.

### 5.1 API Services (REST Clients)

API Services encapsulate the HTTP operations used to communicate with the backend REST API.

They define the requests required by the frontend, including retrieving, creating, updating, and deleting resources, according to the operations exposed by the backend.

API services use Angular's HTTP client to send requests and receive responses. They provide a dedicated communication interface for application services, preventing HTTP endpoint details from being unnecessarily duplicated throughout the presentation layer.

### 5.2 HTTP Interceptors

HTTP Interceptors provide centralized processing of outgoing HTTP requests and incoming responses.

Their responsibilities may include adding authentication headers, handling common HTTP errors, logging requests, and applying other cross-cutting communication policies.

Interceptors operate within Angular's HTTP request/response pipeline. They complement API services rather than replacing them: API services define the operations to be invoked, while interceptors apply common processing to the associated HTTP traffic.
It can inspect or modify outgoing HTTP requests and incoming HTTP responses without requiring every API service to implement the same logic.

## 6. Shared Frontend Definitions

Shared Frontend Definitions groups data structures and reusable utilities used across the frontend. These definitions support the other architectural components and do not necessarily represent a single physical module.

### 6.1 API DTOs & Interfaces

Data Transfer Objects (DTOs) represent the data exchanged between the frontend and the backend API. Interfaces define the structure of request payloads, response data, and contracts used between frontend components.

These definitions improve consistency and readability by establishing expected data structures for operations such as retrieving products or submitting orders.

TypeScript interfaces provide compile-time type information but do not validate incoming JSON at runtime. Runtime validation may be necessary when the application must verify that received data conforms to an expected structure.

### 6.2 Client-Side Validation & Domain Helpers

Client-Side Validation & Domain Helpers provides reusable validation rules and supporting logic required by the frontend.

Examples include validating form input, checking field constraints, calculating derived values, and applying reusable client-side rules.

Client-side validation improves usability by identifying invalid input before requests are submitted. Nevertheless, the backend remains responsible for independently validating incoming data and enforcing authoritative business rules.

Presentation-specific validation and domain-related rules may be organized separately when their responsibilities differ significantly.

## 7. Backend REST API

The Backend REST API is a separate container that exposes the operations consumed by the Angular SPA.

It receives HTTP requests from frontend API services through its controllers and returns the corresponding responses. Controllers act as entry points to backend request processing and delegate application operations to the appropriate backend components.

The backend is responsible for enforcing authorization, validating requests, and applying the business rules required to maintain system integrity.

## 8. Component Relationships

The main interaction flow begins when a user navigates to a page or performs an action in the interface.

1. **Routing & Guards** selects the appropriate page and applies client-side route restrictions.
2. **Pages / Feature Views** compose the interface and coordinate the presentation of the relevant use case.
3. **UI Components** display information and collect user input.
4. **Application Services / State** coordinates operations and manages the state required by the interface.
5. **API Services** translate application operations into HTTP requests to the backend.
6. **HTTP Interceptors** process outgoing requests and incoming responses according to configured communication policies.
7. **Backend REST API** receives the requests, processes the operations, and returns responses.
8. The application services and presentation components use the results to update the displayed information.

API DTOs, interfaces, validation rules, and domain helpers support the relevant components throughout this process.

## 9. Architectural Considerations

The logical decomposition establishes clear responsibilities within the frontend:

- **Separation of concerns:** presentation, application coordination, HTTP communication, and shared definitions have distinct responsibilities.
- **Reusability:** UI components, validation rules, and API services can be reused where appropriate.
- **Maintainability:** isolating backend communication and application coordination reduces duplication and simplifies changes.
- **Testability:** components with clearly defined responsibilities can be tested independently.
- **Security:** client-side navigation restrictions and validation improve the user experience but do not replace backend authorization or validation.

The diagram documents the frontend's significant architectural components and their relationships.