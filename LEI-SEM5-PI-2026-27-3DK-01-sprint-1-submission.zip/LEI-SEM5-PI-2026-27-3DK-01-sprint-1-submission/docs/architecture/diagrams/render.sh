#!/usr/bin/env bash
# Regenerate all PlantUML diagrams and images for the LaPrizza architecture docs.
# Requires: Java + a PlantUML JAR (or use plantuml). C4 diagrams fetch from the
# internet unless vendored; see https://github.com/plantuml-stdlib/C4-PlantUML
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

JAR="${PLANTUML_JAR:-$HOME/.vscode/extensions/jebbs.plantuml-2.18.1/plantuml.jar}"
export PLANTUML_LIMIT_SIZE="${PLANTUML_LIMIT_SIZE:-4096}"

if [ -f "$JAR" ]; then
  PUCMD=(java -jar "$JAR" -charset UTF-8)
elif command -v plantuml >/dev/null 2>&1; then
  PUCMD=(plantuml -charset UTF-8)
else
  echo "ERROR: plantuml.jar not found at $JAR and 'plantuml' not on PATH" >&2
  echo "Set PLANTUML_JAR to the path of plantuml.jar" >&2
  exit 1
fi

echo "Using: ${PUCMD[*]}"

find . -name "*.puml" -type f -not -path "*/node_modules/*" | sort | while read -r f; do
  echo "Rendering $(basename "$f")"
  "${PUCMD[@]}" -tpng -tsvg "$f"
done

# Normalise output names to match SAD references
# Logical C1
[ -f logical-view/C4-Context.png ] && mv -f logical-view/C4-Context.png "logical-view/LaPrizza - C4 System Context (C1).png"
[ -f logical-view/C4-Context.svg ] && mv -f logical-view/C4-Context.svg "logical-view/LaPrizza - C4 System Context (C1).svg"

# Logical abstract view
[ -f "logical-view/Logical View Component.png" ] && mv -f "logical-view/Logical View Component.png" "logical-view/LaPrizza - Logical View Component.png"
[ -f "logical-view/Logical View Component.svg" ] && mv -f "logical-view/Logical View Component.svg" "logical-view/LaPrizza - Logical View Component.svg"
rm -f "logical-view/Logical View Components with implementation information.svg"

# Level 3 WebApp
rm -f logical-view/Level3_WebApp_Components/AngularSPA_Level3.svg

# Remove stale oddly-named C1
rm -f logical-view/LaPrizza-C4-System-Context-C1.svg

# Name new diagrams from @startuml titles
for dir in data-view development-view process-view; do
  [ -d "$dir" ] || continue
  for f in "$dir"/*.puml; do
    [ -f "$f" ] || continue
    base="$(basename "$f" .puml)"
    title="$(grep -oP '@startuml \K.*' "$f" | head -1 | tr -d '"')"
    [ -z "$title" ] && continue
    [ "$title" = "$base" ] && continue
    [ -f "$dir/${base}.png" ] && mv -f "$dir/${base}.png" "$dir/${title}.png"
    [ -f "$dir/${base}.svg" ] && mv -f "$dir/${base}.svg" "$dir/${title}.svg"
  done
done

echo "Done. Remember to commit both the .puml sources and the rendered images."
