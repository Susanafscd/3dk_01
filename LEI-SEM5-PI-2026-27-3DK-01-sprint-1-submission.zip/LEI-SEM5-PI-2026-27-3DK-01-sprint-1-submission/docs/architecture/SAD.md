# Software Architecture Document (SAD)

**Project:** LaPrizza - Integrative Project (LEI-SEM5-PI-2026-27-3DK-01)

## Table of Contents

1. [Introduction](#1-introduction)
2. [Architectural Representation](#2-architectural-representation)
3. [Architectural Goals and Constraints](#3-architectural-goals-and-constraints)
4. [Use-Case View](#4-use-case-view)
5. [Logical View](#5-logical-view)
6. [Process View](#6-process-view)
7. [Development View](#7-development-view)
8. [Physical View](#8-physical-view)
9. [Data View](#9-data-view)
10. [Size and Performance](#10-size-and-performance)
11. [Quality](#11-quality)
12. [Conclusion](#12-conclusion)
13. [References](#13-references)
14. [Appendix A: ADR Index](#appendix-a-adr-index)

---

## 1. Introduction

### 1.1 Purpose

This Software Architecture Document (SAD) describes the architecture of the **LaPrizza** system. It provides a comprehensive view of the system's structure, behaviour, and deployment, supporting communication among stakeholders (team members, supervisors, and future developers) and guiding implementation decisions. 

### 1.2 Scope

LaPrizza is a modular web-based information system that supports restaurant operations, including catalogue management, pizza configuration, ordering, customer management, stock management, food preparation planning, 3D visualisation, and AI-assisted scheduling. This document covers the architecture as designed and implemented in the current sprint, including the backend API, frontend SPA, data stores, and deployment model.

### 1.3 Definitions, Acronyms, and Abbreviations

| Term | Definition |
| --- | --- |
| ADR | Architecture Decision Record |
| API | Application Programming Interface |
| C4 | C4 Model for visualising software architecture (Context, Container, Component, Code) |
| CD | Class Diagram |
| DDD | Domain-Driven Design |
| DI | Dependency Injection |
| EF Core | Entity Framework Core (ORM) |
| GDPR | General Data Protection Regulation |
| HTTP | HyperText Transfer Protocol |
| JWT | JSON Web Token (not used by LaPrizza; cookie authentication is used) |
| JSON | JavaScript Object Notation |
| NFR | Non-Functional Requirement |
| OpenAPI | OpenAPI Specification (REST API contract) |
| REST | Representational State Transfer |
| SAD | Software Architecture Document |
| SPA | Single Page Application |
| TPH | Table Per Hierarchy (EF Core inheritance mapping) |
| UC | Use Case |
| UML | Unified Modeling Language |

### 1.4 References

| Reference | Description |
| --- | --- |
| [docs/requirements.md](../../requirements.md) | User stories (BCK01–BCK11) and acceptance criteria |
| [docs/context.md](../../context.md) | Project context and business background |
| [docs/principles and guidelines.md](../../principles%20and%20guidelines.md) | Engineering principles, working guidelines, and branching strategy |
| [docs/GLOSSARY.md](../../GLOSSARY.md) | Domain glossary |
| [docs/DM.md](../../DM.md) | Domain model documentation |
| [docs/domain.md](../../domain.md) | Domain analysis |
| [docs/LaPrizza - Domain Class Diagram (C#).svg](../../LaPrizza%20-%20Domain%20Class%20Diagram%20%28C%23%29.svg) | Conceptual/class-level domain diagram |
| [docs/DDD-model.svg](../../DDD-model.svg) | DDD tactical model (aggregates, entities, value objects) |
| [docs/conceptualDM.svg](../../conceptualDM.svg) | Conceptual domain model |
| [docs/architecture/ADR/](ADR/) | Architecture Decision Records (ADR-001 through ADR-006) |
| [docs/api/openapi.json](../../api/openapi.json) | Authoritative OpenAPI 3.0.4 contract for the LaPrizza API |
| [docs/api/contract/](../../api/contract/) | Modular OpenAPI contract fragments |
| [backend/README.md](../../../backend/README.md) | Backend architecture and implementation details |
| [backend/SETUP.md](../../../backend/SETUP.md) | Backend setup guide for new developers |
| [frontend/README.md](../../../frontend/README.md) | Frontend architecture and implementation details |
| [frontend/SETUP.md](../../../frontend/SETUP.md) | Frontend setup guide for new developers |
| [compose.yaml](../../../compose.yaml) | Docker Compose deployment configuration |
| [C4 Model](https://c4model.com/) | Architecture visualisation methodology |

### 1.5 Overview

The remainder of this document follows a view-based architecture description (inspired by the 4+1 View Model and the C4 model). Each section describes a different perspective on the system, cross-referenced with ADRs, diagrams, and implementation artifacts in the repository.

---

## 2. Architectural Representation

### 2.1 Architectural Views

LaPrizza is described using the following views:

| View | Purpose | Artifacts |
| --- | --- | --- |
| Logical View | Static structure of the domain, layers, and components (what the system is made of). | C4 Context/Container/Component, DDD model, class diagrams |
| Process View | Runtime behaviour: request flows, concurrency, transactions. | Request lifecycle sequence diagram |
| Development View | Organisation of the codebase, modules, dependencies, and build/test pipeline. | Project dependency diagram, solution structure |
| Physical View | Deployment topology, infrastructure, networking, and containers. | C4 deployment/container diagrams, Docker Compose |
| Data View | Data persistence strategy, schemas, and data store allocation. | Data store allocation diagram, EF Core configurations, migrations |
| Use-Case View | Functional scope as driven by user stories. | Use-case diagrams (BCK01, BCK02) and [requirements.md](../../requirements.md) |
| Scenarios/Quality | Non-functional requirements and quality attributes. | Section 11 of this document |

### 2.2 C4 Model Summary

The team uses the [C4 Model](https://c4model.com/) to visualise architecture at increasing levels of detail:

| Level | Name | Scope | Diagram |
| --- | --- | --- | --- |
| C1 | System Context | System, users/actors, and external dependencies. | Logical and Physical views |
| C2 | Container | Deployable/run-time containers (API, SPA, databases, cache, services). | Logical and Physical views |
| C3 | Component | Internal structure of a container (e.g., API components following Clean Architecture). | Logical view |
| C4 | Code | Classes/interfaces as needed (covered by IDE and code). | — |


## 3. Architectural Goals and Constraints

### 3.1 Architectural Goals

| Goal | Rationale | How it's achieved |
| --- | --- | --- |
| **Preserve business invariants** | The domain must be correct regardless of transport/persistence. | DDD in `LaPrizza.Domain`, aggregates/entities/value objects, explicit guards/exceptions. |
| **Keep layers independent** | Changes to HTTP, EF Core, MongoDB, or Redis must not leak into the domain. | Clean Architecture (ADR-004); `LaPrizza.Domain` has no external dependencies. |
| **API contract is the source of truth** | Frontend and backend stay aligned and changes are explicit. | OpenAPI contract-first (ADR-005). Controllers are generated/aligned to `docs/api/openapi.json`. NSwag MSBuild integration and an OpenAPI bundler are present. |
| **Security by default** | Authentication, authorisation, and CSRF protection must not be opt-in accidentally. | Cookies + ASP.NET Core Identity (ADR-004), fallback authorization policy (all endpoints protected by default, opt-out with `[AllowAnonymous]`), global antiforgery filter for state-changing requests. |
| **Testability** | Use cases must be testable without HTTP/DB infrastructure. | Application layer depends on ports; repositories/DbContexts are in Infrastructure; solution includes `LaPrizza.Domain.Tests`, `LaPrizza.Application.Tests`, `LaPrizza.Infrastructure.Tests`, `Api.Tests`. |
| **Performance where it matters** | Catalogue/read paths should be cache-friendly. | Redis-backed distributed cache via `IDistributedCache` (`IDistributedCacheService`) behind an application port (ADR-002). Cache is disposable, never the source of truth. |
| **Reproducible delivery** | The system must run consistently across developer machines and in containers. | Docker Compose (ADR-006), environment-driven configuration, `.env.example` files, health checks, pinned base images. |
| **Justified, pragmatic technology** | The RFP mandates no fixed technology/architecture; the team must justify choices. | Documented in ADR-001 and this SAD. |

### 3.2 Architectural Constraints

| Constraint | Source | Impact |
| --- | --- | --- |
| **Clean Architecture dependency rule** | ADR-004, [principles and guidelines.md](../../principles%20and%20guidelines.md) | Dependencies point inwards (Domain ← Application ← Infrastructure ← Api). The domain cannot reference frameworks or outer layers. |
| **Cookie-based authentication (no JWT)** | ADR-004 | Identity uses ASP.NET Core Identity with session cookies; credentials and identity are not domain concepts (MD-06). API returns 401/403, not HTML redirects. |
| **Two persistence contexts for PostgreSQL** | ADR-004 | `DomainDbContext` holds business aggregates; `AppDbContext` (Identity) holds credentials/roles/claims. They share the PostgreSQL server but are separate DbContexts. |
| **OpenAPI contract-first** | ADR-005 | The REST contract in `docs/api/openapi.json` drives integration; API routes and the contract are kept aligned. |
| **Modular monolith first** | ADR-004, ADR-006 | The backend is a single deployable (API + supporting projects) orchestrated via Docker Compose, avoiding premature distribution. |
| **Environment-driven configuration** | Implementation | Connection strings, CORS origins, Redis/Mongo settings come from configuration/env vars. No secrets in source control. |
| **All endpoints protected by default** | ADR-004, Api/Program.cs | Authorization fallback policy requires an authenticated user; only `[AllowAnonymous]` endpoints (e.g. `GET /api/v1/health`) are public. Unknown routes return `401` (not `404`) due to the fallback policy. |
| **Antiforgery for state-changing requests** | Implementation | Global `AntiforgeryValidationFilter`; clients must obtain a token from `GET /api/v1/antiforgery/token` and send it in `X-CSRF-TOKEN`. |
| **.NET 10 / Angular 22** | ADR-001, repo tooling | Targets as specified in ADR-001 and the project files. |

---

### 3.3 Layered Architecture (Clean Architecture)

LaPrizza follows Clean Architecture (ADR-004). Dependencies always point inwards; the domain is the core and has no framework dependencies.

| Layer | Projects | Responsibility |
| --- | --- | --- |
| **Domain** | `LaPrizza.Domain` | Aggregates, entities, value objects, domain rules, and repository interfaces. No references to other projects or frameworks. |
| **Application** | `LaPrizza.Application` | Use cases (Commands/Queries with Handlers), DTOs/results, and ports (`IUnitOfWork`, `IUserAccountManager`). Depends only on Domain. |
| **Infrastructure** | `LaPrizza.Infrastructure` | Adapters: EF Core (`DomainDbContext`, `AppDbContext`, repositories, `UnitOfWork`), ASP.NET Core Identity (`UserAccountManager`), Redis (`StackExchange.Redis`), MongoDB client/database, options/configuration. Implements Application ports and maps Domain aggregates. |
| **Presentation/Composition** | `src/Api`, `src/Bootstrapper` | HTTP transport (controllers, middleware, filters), composition roots, dependency wiring, and bootstrap/seeding orchestration. |





## 4. Use-Case View

The functional requirements are captured as user stories in [docs/requirements.md](../requirements.md).


![LaPrizza - Use Case View](diagrams/Use_Case_View-Use_Case_View.svg)

**PlantUML source:** [diagrams/use-case-view.puml](diagrams/use-case-view.puml)


The API exposes (from [docs/api/openapi.json](../../api/openapi.json))

---

## 5. Logical View

### 5.2 System Context (C1) - Logical View

The logical system context shows the actors that interact with the LaPrizza Information System and the responsibilities of the system.

![LaPrizza - C4 System Context (C1)](diagrams/logical-view/C4-Context-LaPrizza___Logical_View_System_Context__C1_.svg)

**PlantUML source:** [diagrams/logical-view/C4-Context.puml](diagrams/logical-view/C4-Context.puml)

**Actors:**
- **Customer** — Browses the catalogue, configures pizzas, places and consults orders.
- **Manager** — Manages catalogue, allergens, pizza components and customers.
- **Restaurant Staff** — Follows planned and ongoing preparation activities and updates stock.

### 5.3 Container (C2) - Logical View

The logical container view shows the high-level technology containers that make up the system and how they interact.

![LaPrizza - C4 Container (C2)](diagrams/logical-view/C4-Container-LaPrizza_Information_System___Logical_View__Level_2_.svg)

**PlantUML source:** [diagrams/logical-view/C4-Container.puml](diagrams/logical-view/C4-Container.puml)

**Key containers (logical):**

| Container | Technology  | Purpose  |
| --------------------- | -------------------------------- | ----- |
| Web Application (SPA) | Angular 22 (TypeScript)  | User interface for all actors. Communicates with the API over HTTPS/JSON. |
| Back-End API | ASP.NET Core 10 Web API  | REST API, authentication/authorisation, business logic orchestration, OpenAPI contract. |
| AI Scheduling Service | Prolog service  | Computes food preparation schedules from orders, activities, resources and constraints. |
| Relational Database | PostgreSQL  | Source of truth for domain data and Identity data (separate DbContexts/schemas). |
| Non-Relational Database | MongoDB | Document store for use cases where a document model fits better. |
| Cache | Redis  | Distributed cache (via `HybridCache` / `StackExchange.Redis`) for disposable read copies. Never a source of truth. |
| File / Object Store | Object Storage  | Static assets (images, 3D models). |

### 5.4 Component (C3) - Back-End API (Logical View)

This view shows the internal components of the Back-End API container, aligned with the Clean Architecture decisions in [ADR-004](ADR/ADR-004.md).

![LaPrizza - C4 Component (C3)](diagrams/logical-view/C4-Component-C3_Logical_View.svg)

**PlantUML source:** [diagrams/logical-view/C4-Component.puml](diagrams/logical-view/C4-Component.puml)

### 5.5 Implementation (C4) - Back-End API (Logical View)

This view shows the internal components of the Back-End API container with a more implementation focused point of view.

![LaPrizza - C4 Component (C3)](diagrams/logical-view/Logical_View_Components_with_implementation_information.svg)

**PlantUML source:** [diagrams/logical-view/level3.5](diagrams/logical-view/level3.5.puml)


**Notable details:**
- **Authentication & Authorization** uses ASP.NET Core Identity with **cookie authentication** (HttpOnly, SameSite, Secure in production). The API returns `401`/`403` on auth failures rather than redirecting to a login page (ADR-004).
- **Identity** (accounts, roles, claims) is persisted through a separate `AppDbContext` (Identity schema) in the same PostgreSQL server.
- **Domain Model** and **Application Services** sit at the core; dependencies point inwards. **Outbound Adapters** (Repositories, UoW, Cache, Mongo, Object Storage, AI adapter) depend on Application/Domain abstractions (dependency inversion).
- **Antiforgery** is enforced globally for state-changing requests via a double-submit token header (`X-CSRF-TOKEN`) delivered by `GET /api/v1/antiforgery/token`.



### 5.6 Component View - Angular SPA (Level 3)

The frontend follows a layered structure inside the SPA container (Routing/Guards, Presentation, Application/State, Communication, Shared definitions). See [frontend/README.md](../../../frontend/README.md) for the current skeleton details.

![Angular SPA - Level 3 Logical View](diagrams/logical-view/Level3_WebApp_Components/Level3_WebApp_Components.png)

**PlantUML source:** [diagrams/logical-view/Level3_WebApp_Components/Level3_WebApp_Components.puml](diagrams/logical-view/Level3_WebApp_Components/Level3_WebApp_Components.puml)  
**Notes:** [diagrams/logical-view/Level3_WebApp_Components/Level3_WebApp_Components.md](diagrams/logical-view/Level3_WebApp_Components/Level3_WebApp_Components.md)


### 5.7 API Contract Surface

The authoritative contract is [docs/api/openapi.json](../api/openapi.json) (OpenAPI 3.0.4). Modular fragments live under [docs/api/contract/](../api/contract/). The API is versioned under `/api/v1`. Security is declared via `cookieAuth` (session cookie). Endpoints are protected by default via the authorization fallback policy.

---

## 6. Process View

### 6.1 Request Lifecycle

The diagram below shows the real middleware/pipeline order as configured in `backend/src/Api/Program.cs`, including authentication, authorization, antiforgery, controllers, the application layer, repositories, and error handling.

![LaPrizza - API Request Lifecycle](diagrams/process-view/LaPrizza%20-%20Request%20Lifecycle.png)

**PlantUML source:** [diagrams/process-view/Request-Lifecycle.puml](diagrams/process-view/Request-Lifecycle.puml)

### 6.2 Key Runtime Notes

- **Error contract:** `AddProblemDetails()` + `UseExceptionHandler<GlobalExceptionHandler>()` + `UseStatusCodePages()` ensure unhandled exceptions and status codes return `problem+json`.
- **CORS:** Configured from `Cors:AllowedOrigins`; credentials are allowed because authentication uses cookies.
- **Antiforgery:** Global `AntiforgeryValidationFilter` validates tokens for state-changing requests; safe verbs (`GET`, `HEAD`, `OPTIONS`, `TRACE`) are skipped. Tokens are obtained via `GET /api/v1/antiforgery/token`.
- **Request logging:** `RequestLoggingMiddleware` logs requests/responses.
- **OpenAPI/Swagger:** Exposed via `UseApiDocumentation()` (serving the contract from `docs/api/openapi.json` copied next to the app).

---

## 7. Development View

### 7.1 Solution Organisation

The backend is a multi-project .NET 10 solution (`backend/Api.sln`):

| Project | Type | Purpose |
| --- | --- | --- |
| `LaPrizza.Domain` | Class library | Core domain (no dependencies). |
| `LaPrizza.Application` | Class library | Use cases and ports. References Domain. |
| `LaPrizza.Infrastructure` | Class library | Adapters (EF Core, Identity, Redis, MongoDB). References Application and Domain. |
| `Api` | Web API | HTTP host/controllers/middleware. References Application and Infrastructure. |
| `Bootstrapper` | Console app (CLI) | Ordered bootstrap actions and seeding (Roles, Users/Managers, Customers, Product Categories, Allergens). References Application and Infrastructure. |
| `LaPrizza.Domain.Tests` / `LaPrizza.Application.Tests` / `LaPrizza.Infrastructure.Tests` / `Api.Tests` | Test projects | Unit/integration tests (NUnit). |

### 7.2 Project Dependencies

![LaPrizza - Project Dependencies](diagrams/development-view/LaPrizza___Project_Dependencies-LaPrizza___Solution_and_Project_Dependencies__Development_View_.svg)

**PlantUML source:** [diagrams/development-view/Project-Dependencies.puml](diagrams/development-view/Project-Dependencies.puml)

### 7.3 Tooling and Processes

| Concern | Tool/Approach | Notes |
| --- | --- | --- |
| **Build/Runtime** | .NET SDK 10 | See [backend/SETUP.md](../../../backend/SETUP.md) for exact versions. |
| **Frontend build** | Angular CLI 22, Vite/npm, TypeScript 6 (strict) | Zoneless by default; Tailwind CSS. See [frontend/SETUP.md](../../../frontend/SETUP.md). |
| **API contract-first** | OpenAPI 3.0.4 + NSwag MSBuild + OpenApiBundler | Contract in `docs/api/`. `tools/OpenApiBundler/bundle.cs` bundles fragments. `Api/OpenApi/Generated/Contract.g.cs` is generated. |
| **Testing** | NUnit (backend), Vitest (frontend unit), Playwright (frontend E2E, when needed) | Bruno collections under `backend/e2e/` for manual/automated API testing. |
| **Formatting/Linting** | `dotnet format`, ESLint, Prettier | Enforced in CI mindset; see project configs. |
| **Migrations** | EF Core Migrations (separate for Domain and Identity) | `LaPrizza.Infrastructure/Persistence/Migrations/Domain/` and `Migrations/Identity/`. |
| **Branching/Workflow** | Feature branches, ADRs for significant decisions | Documented in [docs/principles and guidelines.md](../../principles%20and%20guidelines.md). |
| **Containerisation** | Docker, Docker Compose | See [compose.yaml](../../../compose.yaml) and [backend/Dockerfile](../../../backend/Dockerfile). |

### 7.4 Build and Test (Quick Reference)

```bash
# Backend
cd backend
dotnet restore
dotnet build
dotnet test

# Frontend
cd frontend
npm ci
npm run build
npm test
npm run lint
npm run format:check
```

Full setup instructions are in [backend/SETUP.md](../../../backend/SETUP.md) and [frontend/SETUP.md](../../../frontend/SETUP.md).

---

## 8. Physical View

### 8.2 Deployment Containers (C2) - Physical View

Docker Compose deploys the API and backing services on the same network with named volumes and health checks.

![LaPrizza - C4 Container (C2) - Physical View](diagrams/physical-view/LaPrizza___C4_Container__C2____Physical_View-LaPrizza_Information_System___C4_Container__Level_2____Physical___Deployment_View.svg)

**PlantUML source:** [diagrams/physical-view/C4-Container.puml](diagrams/physical-view/C4-Container.puml)

### 8.3 Docker Compose Configuration

From [compose.yaml](../../../compose.yaml):

| Service | Image | Port (host:container) | Purpose | Health Check |
| --- | --- | --- | --- | --- |
| `postgres` | `postgres:18-alpine` | `5432:5432` (configurable) | PostgreSQL 18 | `pg_isready` |
| `mongodb` | `mongo:8` | `27017:27017` (configurable) | MongoDB 8 | `mongosh` ping |
| `redis` | `redis:8-alpine` | `6379:6379` (configurable) | Redis 8 | `redis-cli ping` |
| `api` | Built from `backend/Dockerfile` | `8080:8080` | LaPrizza API | HTTP GET to health endpoint (with retries) |

All services share network `laprizza-network`. Data persists in named volumes (`postgres_data`, `mongodb_data`, `redis_data`). Environment variables are passed via `.env` (see `.env.example`).

The API container runs as non-root, listens on `8080`, and depends on healthy PostgreSQL, MongoDB, and Redis instances.

### 8.4 Local Development Deployment

For local development:
- **Backend:** Run from `backend/` with `dotnet run --project src/Api` (HTTPS profile by default in launch settings) or via the Docker stack.
- **Frontend:** Run with `npm start` from `frontend/` on port `5173` (aligned with backend CORS).
- **Services:** Can run via Docker Compose or locally installed instances.

See [backend/SETUP.md](../../../backend/SETUP.md) and [frontend/SETUP.md](../../../frontend/SETUP.md) for details.

---

## 9. Data View

### 9.1 Data Store Allocation

![LaPrizza - Data Store Allocation](diagrams/data-view/LaPrizza%20-%20Data%20Store%20Allocation.png)

**PlantUML source:** [diagrams/data-view/Data-Store-Allocation.puml](diagrams/data-view/Data-Store-Allocation.puml)

### 9.2 Relational Data (PostgreSQL)

PostgreSQL is the **source of truth**. The team uses **two separate DbContexts** (ADR-004):

| DbContext | Purpose | Tables (from migrations) |
| --- | --- | --- |
| `DomainDbContext` | Business aggregates | Catalogue and pizza-domain aggregates, including `ProductCategories`, `Allergens`, `Products` and their business-code associations, plus `Users` (TPH: `User`/`Customer`/`Staff` with discriminator `UserType`), `Roles` and owned `RolePermissions`. `User` stores `RoleIds` as a comma-separated string with a value comparer. `Email` is a value object converted to/from string. |
| `AppDbContext` (ASP.NET Core Identity) | Authentication/authorisation | `AspNetUsers`, `AspNetRoles`, `AspNetUserRoles`, `AspNetUserClaims`, `AspNetRoleClaims`, `AspNetUserLogins`, `AspNetUserTokens`. |

EF Core configurations live in `LaPrizza.Infrastructure/Persistence/Configurations/`. Migrations are split under `Migrations/Domain/` and `Migrations/Identity/`. Repositories participating in one business operation share the scoped `DomainDbContext` and its transaction/save operation. The database is the source of truth for business-code uniqueness and referential safeguards; Redis/HybridCache contains only disposable projections.

For BCK03–BCK05, PostgreSQL keeps the aggregate boundaries while enforcing the important links:
products reference categories by `CategoryCode`, pizza component types by `ComponentTypeCode`, and
allergens through business-code association rows. Category and allergen removal is guarded by
references from both active and inactive products (and by component types or dietary restrictions
where applicable). The shared write flow performs checks and the commit through `DomainDbContext`,
then invalidates affected `HybridCache` projections.

### 9.3 Caching (Redis)

Redis is used as a **disposable distributed cache** (ADR-002). 
- Registered via `AddStackExchangeRedisCache()` with instance name `LaPrizza` and `ConnectionMultiplexer`.
- Accessed through `IDistributedCacheService` (Application port) implemented by `DistributedCacheService` (Infrastructure).
- Never a source of truth — cache misses are expected and the system must remain correct without cached data.

### 9.4 Document Store (MongoDB)

MongoDB is registered (`IMongoClient`, `IMongoDatabase`) and configured via `MongoOptions`, but **no use case currently uses it**. It is available for future requirements where a document model is a better fit.

### 9.5 Object Storage (Planned)

A file/object store for static assets (images, 3D models) is planned. The browser will load assets directly from the store via URLs provided by the API.

### 9.6 Domain Model References

- [docs/LaPrizza - Domain Class Diagram (C#).svg](../../LaPrizza%20-%20Domain%20Class%20Diagram%20%28C%23%29.svg) / [.png](../../LaPrizza%20-%20Domain%20Class%20Diagram%20%28C%23%29.png)
- [docs/DDD-model.svg](../../DDD-model.svg) / [.png](../../DDD-model.png)
- [docs/conceptualDM.svg](../../conceptualDM.svg) / [.png](../../conceptualDM.png)
- [docs/DM.md](../../DM.md)

---

## 10. Size and Performance

### 10.1 Performance Considerations

| Concern | Approach | Status |
| --- | --- | --- |
| **Catalogue/read-heavy paths** | Redis-backed distributed cache behind `IDistributedCacheService` (ADR-002). Cache-aside pattern intended. | Implemented. |
| **Database access** | EF Core with explicit configurations, repositories, and a Unit of Work. Two DbContexts separated by concern. | Implemented. |
| **API contract alignment** | OpenAPI contract-first reduces integration churn and supports code generation (ADR-005). | Implemented. |
| **Container startup** | Docker health checks ensure dependencies are ready before the API starts. | Configured in `compose.yaml`. |


---

## 11. Quality

### 11.1 Quality Attributes and Tactics

Derived from [docs/principles and guidelines.md](../../principles%20and%20guidelines.md) and ADRs:

| Quality Attribute | Goal | Architectural Tactic |
| --- | --- | --- |
| **Maintainability** | Easy to understand, extend, and test. | Clean Architecture, separation of concerns, SOLID, small focused projects, consistent structure. |
| **Testability** | Business rules testable in isolation. | Domain has no dependencies; Application uses ports; DI throughout; test projects per layer. |
| **Security** | Protect credentials and authorise access correctly. | ASP.NET Core Identity + HttpOnly/SameSite/Secure cookies (ADR-004), fallback auth policy, global antiforgery, no credentials in domain model. |
| **Extensibility** | Add features without breaking existing rules. | DDD aggregates, ports/adapters, feature-based organisation in Application, OpenAPI contract-first (ADR-005). |
| **Reliability** | Predictable errors and safe failure modes. | Global exception handler → `problem+json`, status code pages, validation, health endpoint, container health checks. |
| **Reproducibility** | Consistent builds/deployments. | Docker Compose (ADR-006), environment configuration, no secrets in VCS, documented setup guides. |
| **Performance** | Efficient reads when appropriate. | Redis cache as a disposable optimisation (ADR-002), never blocking correctness. |
| **Traceability** | Decisions are documented and reviewable. | ADRs in `docs/architecture/ADR/`, SAD in version control, principles and guidelines kept up to date. |

### 11.2 Quality Scenarios (Examples)

| Scenario | Stimulus | Response | Measure |
| --- | --- | --- | --- |
| **Unauthenticated access** | Request to a protected endpoint without a session cookie. | API returns `401 Unauthorized`. | All non-anonymous endpoints behave this way (fallback policy). |
| **State change without CSRF token** | `POST` without valid `X-CSRF-TOKEN`. | API returns `400 Bad Request` (antiforgery validation). | Global antiforgery filter enforced. |
| **Domain rule violation** | Invalid state transition or invariant breach. | Domain exception → mapped to appropriate problem+json (e.g. `409 Conflict`, `404 Not Found`). | Handled by `GlobalExceptionHandler`. |
| **Cache unavailable** | Redis down. | Cache operations fail gracefully; system falls back to source of truth (PostgreSQL). | Redis is never a source of truth. |
| **Missing configuration** | No PostgreSQL connection string. | API fails fast at startup with a clear exception. | Configured in `Api/Program.cs`. |

---

## 12. Conclusion

LaPrizza is being built as a **modular monolith** with a **Clean Architecture** backend (`.NET 10`), a **standalone Angular SPA** frontend, **PostgreSQL** as the source of truth (split across Domain and Identity DbContexts), **Redis** for disposable caching, and **MongoDB** available for document use cases. 

Key architectural decisions are recorded in the ADR folder and enforced by the structure: dependencies point inwards, the domain has no framework dependencies, the OpenAPI contract is authoritative, authentication uses secure cookies with antiforgery protection, and the system is deployable via Docker Compose.

The architecture is intentionally incremental. Planned elements (AI scheduling service, object storage) are clearly marked as such in the diagrams. As new features are implemented, this document and the diagrams should be kept in sync with the codebase.

---

## 13. References

- [C4 Model](https://c4model.com/)
- [OpenAPI Specification](https://spec.openapis.org/oas/v3.0.4)
- [Clean Architecture (Robert C. Martin)](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Domain-Driven Design (Eric Evans)](https://www.domainlanguage.com/ddd/)

---

## Appendix A: ADR Index

| ADR | Title | Status | Summary |
| --- | --- | --- | --- |
| [ADR-001](ADR/ADR-001.md) | Full-Stack Technology Selection | Accepted | TypeScript/Angular, npm/Angular CLI; C#/ASP.NET Core Web API, EF Core, PostgreSQL, MongoDB, REST/JSON, cookies, ASP.NET Core Identity. |
| [ADR-002](ADR/ADR-002.md) | Caching Strategy (HybridCache + Redis) | Accepted | Redis-backed caching for catalogue/read paths using `IDistributedCache`/HybridCache patterns, with Redis as a cache store (not source of truth). |
| [ADR-003](ADR/ADR-003-Product_Modeling.md) | Product Domain Modeling (DDD) | Accepted | DDD approach for the Product/Catalogue domain with aggregates, entities, value objects, and invariants. |
| [ADR-004](ADR/ADR-004.md) | ASP.NET Core Identity and Cookie Authentication within a Clean Architecture | Accepted | Clean Architecture layers, domain purity, cookie authentication (not JWT), separate Identity and domain DbContexts in PostgreSQL, DI, policies/claims, secure cookie configuration. |
| [ADR-005](ADR/ADR-005.md) | OpenAPI Contract-First Development | Accepted | Authoritative OpenAPI contract in `docs/api/openapi.json`, contract-first workflow, generated/aligned controllers. |
| [ADR-006](ADR/ADR-006.md) | Docker Containerization | Accepted | Containerise API and dependencies with Docker Compose, health checks, volumes, non-root containers, environment-driven configuration. |
| [ADR-007](ADR/ADR-007.md) | Persistence Strategy — PostgreSQL and MongoDB | Accepted | Selected PostgreSQL (EF Core) as the primary database and MongoDB "where a document-oriented model provides a clear advantage" |
