# ADR-003: Domain Product Modeling

- **Status:** Accepted
- **Date:** 2026-10-10
- **Decision Makers:** Development Team
- **Scope:** Backend

## Context / Requirements

LaPrizza is a modern pizza restaurant that prepares and sells pizzas, beverages, and other food products to its customers.

A product represents an item managed by the restaurant and may correspond to a beverage, a prepared food item, or a component used in pizza preparation. Products may be organized into categories and fulfil different roles within the restaurant's operations.

In particular, a product may be available for direct sale to customers, used as a component in pizza preparation, subject to stock control, or associated with multiple of these characteristics.

Therefore, being a product does not necessarily imply that an item is directly sellable. The domain model must support these different roles while preserving the relevant business rules and allowing the product catalogue to evolve as the restaurant's needs change.

**Related requirements:** BCK05, BCK06, BCK08, BCK10 (see `requirements.md`).

## Decision

`Product` is modeled as an abstract class containing common product information and behavior, such as name, description, and product category. It also defines the operations that its subclasses must implement.

Two concrete subclasses are introduced:

- **`BaseProduct`:** Represents a product that is not composed of other products.
- **`ComposedProduct`:** Represents a product composed of one or more `BaseProduct` instances.

This distinction allows the domain model to support both individual products and products assembled from other products, while preventing composed products from containing other composed products.

`Product` also aggregates the following product characteristics:

- **`StockControl`:** Represents stock-related information and behavior.
- **`Sellable`:** Represents the information and behavior required for direct sale.
- **`SizeConfiguration`:** Represents product size-related configuration.

These characteristics allow products to combine different capabilities without requiring a separate product subclass for every possible combination.

`ProductCategory` classifies products into categories such as beverages, pizzas, and pizza components. `ComponentType` provides a more specific classification for products used as pizza components.

The distinction between `ProductCategory` and `ComponentType` allows the model to represent both a product's general category and its specific role in pizza preparation.

## Rationale

A primary objective of this decision is to make the product model extensible while accommodating the different types of products and combinations of characteristics required by the business.

Using an abstract `Product` class and the `BaseProduct` and `ComposedProduct` subclasses promotes code reuse and polymorphism. Common information and behavior are defined once, while the subclasses represent the fundamental distinction between individual and composed products.

Representing `StockControl`, `Sellable`, and `SizeConfiguration` as separate characteristics allows products to combine capabilities without introducing a dedicated subclass for every combination. This reduces the potential growth of the class hierarchy as new product characteristics are introduced.

The distinction between base and composed products also enforces an important domain rule: a composed product cannot contain another composed product. This avoids unsupported nested compositions, such as a pizza being composed of other pizzas, and keeps the composition model aligned with the intended business rules.

Finally, this structure provides a foundation for future expansion of the product catalogue, including the introduction of new product categories, such as burgers, without requiring a fundamental redesign of the product model.

By centralizing common behavior and enforcing domain rules within the domain model, the design aims to preserve domain invariants and reduce the risk of changes introducing inconsistencies.

## Alternatives

An alternative considered was to create separate classes for the different combinations of product characteristics rather than representing those characteristics independently within `Product`.

For example, the model could introduce classes such as `ComposedProduct`, `ComposedProductStockControl`, `BaseProductComponent`, `BaseProductSellable`, and `BaseProductSellableComponent`, with further classes required for additional combinations.

This approach could avoid representing unused characteristics on products that do not require them. However, it would increase the number of classes and introduce additional complexity as the number of product characteristics and their possible combinations grew.

Every new characteristic or combination could require additional classes, making the model harder to maintain and extend.

The chosen approach therefore favors a smaller class hierarchy and the reuse of product characteristics over representing every possible combination through inheritance.

## Consequences

**Positive consequences:**

- Common product information and behavior are centralized in `Product`.
- Polymorphism allows products to be handled through a shared abstraction.
- Product characteristics can be combined without creating a separate subclass for every combination.
- The distinction between base and composed products supports the intended composition rules.
- New product categories and characteristics can be introduced without necessarily changing the fundamental product hierarchy.

**Negative consequences:**

- Product creation and configuration require validation to ensure that the selected product type, category, characteristics, and composition satisfy the domain rules.
- A factory or other controlled creation mechanism may be required to prevent invalid product configurations.
- Changes to domain invariants may require updates to the creation logic and the relevant domain behavior.
- The model may contain optional characteristics that are not applicable to every product, requiring clear rules for their initialization and use.

## Limitations

- The inheritance hierarchy distinguishes only between base and composed products. If the business later requires additional composition models, such as composed products containing other composed products, the model and its invariants will need to be reconsidered.
- Representing product characteristics through composition does not automatically guarantee that every combination is valid. The domain model must explicitly enforce the relevant constraints.
- The current distinction between `ProductCategory` and `ComponentType` requires clear validation rules to prevent inconsistent classifications.
- Adding new characteristics may still increase the complexity of product configuration and validation, even if it does not require a new subclass for every combination.
