# LaPrizza — Project Context

## 1. Background

LaPrizza is a modern pizza restaurant that needs an information system to support and improve its business and operational processes. Its activities involve several interconnected concerns, including customer management, product and allergen management, pizza configuration, stock control, customer orders, and food preparation.

These concerns are interdependent: changes in one area affect the others. A product's allergen information affects food-safety advice for a customer; a pizza configuration depends on which products are currently active and how much stock they consume; an order depends on the catalogue and drives kitchen preparation. Managing them in an integrated way is therefore central to the project.

The project is a proof of concept developed as part of the Software Engineering Project course (LEI-SEM5-PI, 2026/2027). It is built progressively across several development sprints rather than delivered as a single complete system.

## 2. Problem

Without an integrated information system, the restaurant's concerns are handled in a fragmented or manual way. There is no single reliable source for customers and dietary restrictions, the product catalogue and its allergen information, pizza configurations and their size-dependent pricing and stock consumption, stock levels, orders, or kitchen preparation.

The result is inconsistent information, weak traceability, difficulty enforcing business rules, and a poor basis for the reporting and automation the restaurant needs.

## 3. Scope

The system covers the business information and processes described in the System Specification (PART II):

- **Identity and access:** users, roles, permissions and authentication.
- **Customers:** customer records, contact information and dietary restrictions.
- **Catalogue:** product categories, products, allergens, pizza sizes and pizza component types.
- **Pizza configuration:** size-dependent component information, predefined pizzas and (in later sprints) personalised pizzas.
- **Stock:** abstract stock units and stock movements for stock-controlled products.
- **Orders and preparation:** orders, order items, preparation activities and kitchen resources (later sprints).
- **Catalogue consultation:** read access to the products offered for sale.

The initial increment (Sprint 1) focuses on setting up the environment, modelling the core domain, defining the architecture, and implementing the first back-end capabilities (BCK01–BCK11). Ordering, food preparation scheduling, AI scheduling and 3D visualization are anticipated by the architecture but implemented later.

See [requirements.md](requirements.md) for the detailed user-story analysis and [scrum/sprint1/Sprint Goal.md](scrum/sprint1/Sprint%20Goal.md) for the Sprint 1 scope.

## 4. System Overview

LaPrizza is envisioned as a **modular, web-based information system** composed of several technological areas that integrate progressively:

| Area | Responsibility |
| ---- | -------------- |
| **Web Application** | User interface for customers and staff, built as a single-page application. |
| **Back-End API** | Core business logic, domain rules and REST API for the other areas. |
| **3D Visualization and Interaction** | Visual representation and interaction with pizza configurations. |
| **Artificial Intelligence** | Generation of food-preparation schedules. |
| **Systems Administration and Infrastructure** | Deployment, configuration and operational concerns. |

These areas communicate through well-defined interfaces and APIs while remaining sufficiently independent to be developed, maintained and evolved separately.

## 5. Stakeholders

| Stakeholder | Interest |
| ----------- | -------- |
| LaPrizza Manager | Manage products, categories, allergens, pizza configuration, stock and users; consult the catalogue. |
| Restaurant Staff | Operate the system under assigned roles and permissions. |
| Customer | Consult the catalogue and, in later sprints, place and track orders. |
| Development team | Design, implement and maintain the system; keep documentation and architecture consistent. |
| Course instructors / evaluators | Assess engineering quality, documentation and adherence to the specification. |

## 6. Driving Requirements

| Driver | Description |
| ------ | ----------- |
| Modularity and extensibility | The architectural areas must evolve and integrate progressively. |
| Separation of concerns | Domain logic must remain independent of presentation, persistence and infrastructure. |
| REST-based integration | Functionality is exposed through consistent REST APIs suitable for future clients and modules. |
| Data persistence and integrity | Business information is stored persistently with valid identifiers and relationships. |
| Security and access control | Users are authenticated and authorised through roles and permissions. |
| Maintainability and scalability | The foundations must support growth without rework. |
| Automated testing | Business rules and API behaviour are covered by repeatable tests. |

## 7. Related Documentation

- [README](../README.md) — project overview.
- [Requirements analysis](requirements.md) — user stories and derived requirements.
- [Domain glossary](GLOSSARY.md) — ubiquitous language.
- [Domain analysis](DM.md) and [domain model](DomainModelDDD.puml) — core domain and DDD tactical model.
- [Software Architecture Document](architecture/SAD.md) and [C4 diagrams](architecture/diagrams/) — architecture.
- [Problem statement](architecture/problem%20statement.md) — formal problem definition.
- [Sprint 1 goal](scrum/sprint1/Sprint%20Goal.md) — sprint scope and deliverables.
