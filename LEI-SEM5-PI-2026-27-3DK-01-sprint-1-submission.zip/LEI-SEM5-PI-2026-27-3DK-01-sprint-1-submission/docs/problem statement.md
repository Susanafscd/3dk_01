# Problem Statement

## Context
LaPrizza is a modern pizza restaurant that requires a technological solution to support and improve its business and operational processes. As described in PART II of the project specification, the restaurant needs to manage customers, products, allergens, pizza configurations, orders, stock control, food preparation, and other operational concerns.

## Problem
The current operational model lacks an integrated information system that connects these interdependent business concerns. Managing customers and their dietary restrictions, maintaining an up-to-date product catalogue with allergen information, handling pizza configurations (including size-dependent pricing and stock consumption), processing orders, controlling stock using abstract units, and coordinating kitchen resources for food preparation are currently handled in a fragmented or manual way.

## Goals
The goal of the project is to design and develop a modular, web-based information system (LaPrizza) that:
- Supports customer management, including dietary restrictions and consent handling.
- Maintains a product catalogue with categories, allergens, and pricing.
- Enables pizza configuration (predefined and personalized pizzas) with size-dependent information.
- Provides order management and stock control.
- Supports food preparation scheduling and kitchen resource management.
- Integrates web, 3D visualization, and AI-based scheduling in a coherent architecture.
- Ensures data integrity, security, and maintainability following sound software engineering practices.

## Scope
This problem statement covers the requirements defined in PART II (System Specification) and the functionality planned across sprints, with the initial increment (Sprint 1) focused on domain modelling, architecture, and core back-end functionality (BCK01-BCK11).

## Success Criteria
- A coherent domain model and architecture supporting progressive development.
- A functional back-end with REST APIs covering the Sprint 1 user stories.
- Consistent integration points for frontend, 3D visualization, and AI components.
- Evidence of good engineering practices (version control, documentation, testing).
